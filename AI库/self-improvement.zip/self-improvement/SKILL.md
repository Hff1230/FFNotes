---
name: self-improvement
description: "捕获学习心得、错误和纠正以实现持续改进。适用场景：(1) 命令或操作意外失败时，(2) 用户纠正Claude时（'不对...'、'实际上是...'），(3) 用户请求不存在的功能时，(4) 外部API或工具失败时，(5) Claude意识到知识过时或不正确时，(6) 发现处理重复任务的更好方法时。在执行主要任务前也应查阅学习记录。如需CI环境下的无界面学习捕获，请使用self-improvement-ci。"
---

# 自我改进技能

## 安装

```bash
npx skills add pskoett/pskoett-ai-skills/self-improvement
```

CI环境执行请使用：

```bash
npx skills add pskoett/pskoett-ai-skills/self-improvement-ci
```

将学习心得和错误记录到markdown文件中，实现持续改进。编码代理后续可将其处理成修复方案，重要的学习心得会被提升到项目记忆中。

## 快速参考

| 情境 | 操作 |
|------|------|
| 命令/操作失败 | 记录到 `.learnings/ERRORS.md` |
| 用户纠正你 | 记录到 `.learnings/LEARNINGS.md`，类别为 `correction` |
| 用户想要缺失的功能 | 记录到 `.learnings/FEATURE_REQUESTS.md` |
| API/外部工具失败 | 记录到 `.learnings/ERRORS.md`，包含集成详情 |
| 知识已过时 | 记录到 `.learnings/LEARNINGS.md`，类别为 `knowledge_gap` |
| 发现更好的方法 | 记录到 `.learnings/LEARNINGS.md`，类别为 `best_practice` |
| 简化/加固重复模式 | 记录/更新 `.learnings/LEARNINGS.md`，添加 `Source: simplify-and-harden` 和稳定的 `Pattern-Key` |
| 与已有条目相似 | 用 `**See Also**` 关联，考虑提升优先级 |
| 广泛适用的学习 | 提升到 `CLAUDE.md`、`AGENTS.md` 和/或 `.github/copilot-instructions.md` |
| 工作流改进 | 提升到 `AGENTS.md`（openclaw工作区） |
| 工具陷阱 | 提升到 `TOOLS.md`（openclaw工作区） |
| 行为模式 | 提升到 `SOUL.md`（openclaw工作区） |

## 设置

如果项目根目录不存在 `.learnings/` 目录，请创建：

```bash
mkdir -p .learnings
```

从 `assets/` 复制模板或创建带标题的文件。

## 记录格式

### 学习条目

追加到 `.learnings/LEARNINGS.md`：

```markdown
## [LRN-YYYYMMDD-XXX] 类别

**Logged**: ISO-8601时间戳
**Priority**: low | medium | high | critical
**Status**: pending
**Area**: frontend | backend | infra | tests | docs | config

### Summary
一句话描述学到了什么

### Details
完整上下文：发生了什么、哪里错了、什么是正确的

### Suggested Action
建议采取的具体修复或改进措施

### Metadata
- Source: conversation | error | user_feedback
- Related Files: path/to/file.ext
- Tags: tag1, tag2
- See Also: LRN-20250110-001（如果与已有条目相关）
- Pattern-Key: simplify.dead_code | harden.input_validation（可选，用于重复模式跟踪）
- Recurrence-Count: 1（可选）
- First-Seen: 2025-01-15（可选）
- Last-Seen: 2025-01-15（可选）

---
```

### 错误条目

追加到 `.learnings/ERRORS.md`：

```markdown
## [ERR-YYYYMMDD-XXX] skill_or_command_name

**Logged**: ISO-8601时间戳
**Priority**: high
**Status**: pending
**Area**: frontend | backend | infra | tests | docs | config

### Summary
简要描述失败的情况

### Error
```
实际错误消息或输出
```

### Context
- 尝试的命令/操作
- 使用的输入或参数
- 相关的环境详情

### Suggested Fix
如果可识别，可能的解决方案

### Metadata
- Reproducible: yes | no | unknown
- Related Files: path/to/file.ext
- See Also: ERR-20250110-001（如果重复出现）

---
```

### 功能请求条目

追加到 `.learnings/FEATURE_REQUESTS.md`：

```markdown
## [FEAT-YYYYMMDD-XXX] capability_name

**Logged**: ISO-8601时间戳
**Priority**: medium
**Status**: pending
**Area**: frontend | backend | infra | tests | docs | config

### Requested Capability
用户想要做什么

### User Context
为什么需要它、解决什么问题

### Complexity Estimate
simple | medium | complex

### Suggested Implementation
如何构建、可能扩展什么

### Metadata
- Frequency: first_time | recurring
- Related Features: existing_feature_name

---
```

## ID生成

格式：`TYPE-YYYYMMDD-XXX`
- TYPE：`LRN`（学习）、`ERR`（错误）、`FEAT`（功能）
- YYYYMMDD：当前日期
- XXX：序号或随机3字符（如 `001`、`A7B`）

示例：`LRN-20250115-001`、`ERR-20250115-A3F`、`FEAT-20250115-002`

## 解决条目

当问题修复后，更新条目：

1. 将 `**Status**: pending` 改为 `**Status**: resolved`
2. 在Metadata后添加解决信息块：

```markdown
### Resolution
- **Resolved**: 2025-01-16T09:00:00Z
- **Commit/PR**: abc123 或 #42
- **Notes**: 简要描述做了什么
```

其他状态值：
- `in_progress` - 正在积极处理
- `wont_fix` - 决定不处理（在Resolution notes中添加原因）
- `promoted` - 提升到CLAUDE.md、AGENTS.md或.github/copilot-instructions.md

## 提升到项目记忆

当学习心得具有广泛适用性（不是一次性修复）时，将其提升为永久项目记忆。

### 何时提升

- 学习适用于多个文件/功能
- 任何贡献者（人类或AI）都应知道的知识
- 防止重复错误
- 记录项目特定约定

### 提升目标

| 目标 | 适用内容 |
|------|----------|
| `CLAUDE.md` | 所有Claude交互的项目事实、约定、陷阱 |
| `AGENTS.md` | 代理特定工作流、工具使用模式、自动化规则 |
| `.github/copilot-instructions.md` | GitHub Copilot的项目上下文和约定 |
| `SOUL.md` | 行为准则、沟通风格、原则（openclaw） |
| `TOOLS.md` | 工具能力、使用模式、集成陷阱（openclaw） |

### 如何提升

1. **提炼**学习心得为简洁的规则或事实
2. **添加**到目标文件的适当部分（如需要则创建文件）
3. **更新**原条目：
   - 将 `**Status**: pending` 改为 `**Status**: promoted`
   - 添加 `**Promoted**: CLAUDE.md`、`AGENTS.md`或`.github/copilot-instructions.md`

### 提升示例

**学习心得**（详细）：
> 项目使用pnpm workspaces。尝试`npm install`但失败。
> 锁文件是`pnpm-lock.yaml`。必须使用`pnpm install`。

**在CLAUDE.md中**（简洁）：
```markdown
## Build & Dependencies
- Package manager: pnpm (not npm) - use `pnpm install`
```

**学习心得**（详细）：
> 修改API端点时，必须重新生成TypeScript客户端。
> 忘记这点会导致运行时类型不匹配。

**在AGENTS.md中**（可操作）：
```markdown
## After API Changes
1. Regenerate client: `pnpm run generate:api`
2. Check for type errors: `pnpm tsc --noEmit`
```

## 重复模式检测

如果记录的内容与已有条目相似：

1. **先搜索**：`grep -r "keyword" .learnings/`
2. **关联条目**：在Metadata中添加 `**See Also**: ERR-20250110-001`
3. **提升优先级**如果问题持续出现
4. **考虑系统性修复**：重复出现的问题通常表明：
   - 缺少文档（→提升到CLAUDE.md或.github/copilot-instructions.md）
   - 缺少自动化（→添加到AGENTS.md）
   - 架构问题（→创建技术债务工单）

## 简化与加固反馈

使用此工作流从`simplify-and-harden`技能中获取重复模式，
并将其转化为持久的提示词指导。

### 摄取工作流

1. 从任务摘要中读取 `simplify_and_harden.learning_loop.candidates`。
2. 对于每个候选项，使用 `pattern_key` 作为稳定的去重键。
3. 在 `.learnings/LEARNINGS.md` 中搜索具有该键的已有条目：
   - `grep -n "Pattern-Key: <pattern_key>" .learnings/LEARNINGS.md`
4. 如果找到：
   - 递增 `Recurrence-Count`
   - 更新 `Last-Seen`
   - 添加 `See Also` 链接到相关条目/任务
5. 如果未找到：
   - 创建新的 `LRN-...` 条目
   - 设置 `Source: simplify-and-harden`
   - 设置 `Pattern-Key`、`Recurrence-Count: 1` 和 `First-Seen`/`Last-Seen`

### 提升规则（系统提示词反馈）

当以下条件全部满足时，将重复模式提升到代理上下文/系统提示词文件：

- `Recurrence-Count >= 3`
- 至少跨2个不同任务出现
- 在30天时间窗口内发生

提升目标：
- `CLAUDE.md`
- `AGENTS.md`
- `.github/copilot-instructions.md`
- `SOUL.md` / `TOOLS.md` 用于openclaw工作区级指导（如适用）

将提升的规则写成简短的预防规则（编码前/编码时要做什么），
而不是冗长的事件描述。

## 定期审查

在自然断点处审查 `.learnings/`：

### 何时审查
- 开始新的主要任务前
- 完成功能后
- 在有过往学习记录的领域工作时
- 活跃开发期间的每周

### 快速状态检查
```bash
# 统计待处理项
grep -h "Status\*\*: pending" .learnings/*.md | wc -l

# 列出待处理的高优先级项
grep -B5 "Priority\*\*: high" .learnings/*.md | grep "^## \["

# 查找特定领域的学习记录
grep -l "Area\*\*: backend" .learnings/*.md
```

### 审查操作
- 解决已修复的项目
- 提升适用的学习心得
- 关联相关条目
- 上报重复出现的问题

## 检测触发器

当你注意到以下情况时自动记录：

**纠正**（→类别为 `correction` 的学习）：
- "不对，不是这样的..."
- "实际上，应该是..."
- "你关于...的理解是错的"
- "那已经过时了..."

**功能请求**（→功能请求）：
- "你能不能也..."
- "我希望你能..."
- "有没有办法..."
- "为什么你不能..."

**知识缺口**（→类别为 `knowledge_gap` 的学习）：
- 用户提供了你不知道的信息
- 你参考的文档已过时
- API行为与你的理解不同

**错误**（→错误条目）：
- 命令返回非零退出码
- 异常或堆栈跟踪
- 意外的输出或行为
- 超时或连接失败

## 优先级指南

| 优先级 | 使用场景 |
|--------|----------|
| `critical` | 阻塞核心功能、数据丢失风险、安全问题 |
| `high` | 重大影响、影响常见工作流、重复出现的问题 |
| `medium` | 中等影响、存在变通方法 |
| `low` | 轻微不便、边缘情况、锦上添花 |

## 领域标签

用于按代码库区域筛选学习记录：

| 领域 | 范围 |
|------|------|
| `frontend` | UI、组件、客户端代码 |
| `backend` | API、服务、服务端代码 |
| `infra` | CI/CD、部署、Docker、云 |
| `tests` | 测试文件、测试工具、覆盖率 |
| `docs` | 文档、注释、README |
| `config` | 配置文件、环境、设置 |

## 最佳实践

1. **立即记录** - 问题刚发生时上下文最清晰
2. **具体明确** - 未来的代理需要快速理解
3. **包含复现步骤** - 尤其是错误
4. **关联相关文件** - 使修复更容易
5. **建议具体修复** - 不要只说"调查"
6. **使用一致的类别** - 便于筛选
7. **积极提升** - 如有疑问，添加到CLAUDE.md或.github/copilot-instructions.md
8. **定期审查** - 过时的学习记录会失去价值

## Gitignore选项

**保持学习记录本地化**（每个开发者）：
```gitignore
.learnings/
```

**在仓库中跟踪学习记录**（团队共享）：
不要添加到.gitignore - 学习记录成为共享知识。

**混合模式**（跟踪模板，忽略条目）：
```gitignore
.learnings/*.md
!.learnings/.gitkeep
```

## 钩子集成

通过代理钩子启用自动提醒。这是**可选的** - 你必须显式配置钩子。

### 快速设置（Claude Code / Codex）

在项目中创建 `.claude/settings.json`：

```json
{
  "hooks": {
    "UserPromptSubmit": [{
      "matcher": "",
      "hooks": [{
        "type": "command",
        "command": "./skills/self-improvement/scripts/activator.sh"
      }]
    }]
  }
}
```

这会在每次提示后注入学习评估提醒（约50-100 token开销）。

### 完整设置（带错误检测）

```json
{
  "hooks": {
    "UserPromptSubmit": [{
      "matcher": "",
      "hooks": [{
        "type": "command",
        "command": "./skills/self-improvement/scripts/activator.sh"
      }]
    }],
    "PostToolUse": [{
      "matcher": "Bash",
      "hooks": [{
        "type": "command",
        "command": "./skills/self-improvement/scripts/error-detector.sh"
      }]
    }]
  }
}
```

### 可用钩子脚本

| 脚本 | 钩子类型 | 用途 |
|------|----------|------|
| `scripts/activator.sh` | UserPromptSubmit | 任务后提醒评估学习记录 |
| `scripts/error-detector.sh` | PostToolUse (Bash) | 命令错误时触发 |

详细配置和故障排除请参见 `references/hooks-setup.md`。

## 自动技能提取

当学习心得足够有价值成为可复用技能时，使用提供的帮助程序进行提取。

### 技能提取标准

当满足以下任一条件时，学习心得可进行技能提取：

| 标准 | 描述 |
|------|------|
| **重复出现** | 有2个以上类似问题的 `See Also` 链接 |
| **已验证** | 状态为 `resolved` 且有有效修复 |
| **非显而易见** | 需要实际调试/调查才能发现 |
| **广泛适用** | 非项目特定；跨代码库有用 |
| **用户标记** | 用户说"把这个保存为技能"或类似表述 |

### 提取工作流

1. **识别候选**：学习心得符合提取标准
2. **运行帮助程序**（或手动创建）：
   ```bash
   ./skills/self-improvement/scripts/extract-skill.sh skill-name --dry-run
   ./skills/self-improvement/scripts/extract-skill.sh skill-name
   ```
3. **自定义SKILL.md**：用学习内容填充模板
4. **更新学习记录**：将状态设为 `promoted_to_skill`，添加 `Skill-Path`
5. **验证**：在新会话中阅读技能确保自包含

### 手动提取

如果你更喜欢手动创建：

1. 创建 `skills/<skill-name>/SKILL.md`
2. 使用 `assets/SKILL-TEMPLATE.md` 中的模板
3. 遵循 [Agent Skills规范](https://agentskills.io/specification)：
   - 带有 `name` 和 `description` 的YAML前置数据
   - 名称必须匹配文件夹名称
   - 技能文件夹内不要有README.md

### 提取检测触发器

留意这些学习应成为技能的信号：

**在对话中：**
- "把这个保存为技能"
- "我一直遇到这个问题"
- "这对其他项目也有用"
- "记住这个模式"

**在学习条目中：**
- 多个 `See Also` 链接（重复问题）
- 高优先级 + 已解决状态
- 类别：具有广泛适用性的 `best_practice`
- 用户反馈赞扬解决方案

### 技能质量门

提取前，验证：

- [ ] 解决方案已测试且有效
- [ ] 无需原始上下文描述也很清晰
- [ ] 代码示例是自包含的
- [ ] 没有项目特定的硬编码值
- [ ] 遵循技能命名约定（小写、连字符）

## 多代理支持

此技能适用于不同的AI编码代理，具有代理特定的激活方式。

### Claude Code

**激活**：钩子（UserPromptSubmit、PostToolUse）
**设置**：带钩子配置的 `.claude/settings.json`
**检测**：通过钩子脚本自动

### Codex CLI

**激活**：钩子（与Claude Code相同的模式）
**设置**：带钩子配置的 `.codex/settings.json`
**检测**：通过钩子脚本自动

### GitHub Copilot

**激活**：手动（无钩子支持）
**设置**：添加到 `.github/copilot-instructions.md`：

```markdown
## Self-Improvement

在解决非显而易见的问题后，考虑记录到 `.learnings/`：
1. 使用self-improvement技能的格式
2. 用See Also关联相关条目
3. 将高价值学习提升为技能

在聊天中询问："我应该把这个记录为学习吗？"
```

**检测**：会话结束时手动审查

### OpenClaw（可选）

OpenClaw特定的设置、提升目标和混合使用详情保存在
`references/openclaw-integration.md` 中，以便此主技能专注于
编码代理的核心自我改进工作流。

### 代理无关指导

无论使用哪种代理，在以下情况下应用自我改进：

1. **发现非显而易见的事物** - 解决方案不是立即明确的
2. **纠正自己** - 最初的方法是错误的
3. **学习项目约定** - 发现未记录的模式
4. **遇到意外错误** - 尤其是诊断困难时
5. **找到更好的方法** - 改进了原始解决方案

### Copilot聊天集成

对于Copilot用户，在相关时将此添加到你的提示词中：

> 完成此任务后，评估是否有任何学习应该使用self-improvement技能格式记录到 `.learnings/`。

或使用快速提示：
- "把这个记录到学习"
- "从这个解决方案创建一个技能"
- "检查 .learnings/ 中的相关问题"
