---
name: self-improvement
description: "在代理启动期间注入自我改进提醒"
metadata: {"openclaw":{"emoji":"🧠","events":["agent:bootstrap"]}}
---

# 自我改进钩子

在代理启动期间注入评估学习记录的提醒。

## 功能

- 在 `agent:bootstrap` 时触发（工作区文件注入之前）
- 添加提醒块以检查 `.learnings/` 中的相关条目
- 提示代理记录纠正、错误和发现

## 配置

无需配置。使用以下命令启用：

```bash
openclaw hooks enable self-improvement
```
