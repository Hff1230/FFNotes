# 条目示例

格式完整、包含所有字段的具体条目示例。

## 学习：纠正

```markdown
## [LRN-20250115-001] correction

**Logged**: 2025-01-15T10:30:00Z
**Priority**: high
**Status**: pending
**Area**: tests

### Summary
错误地假设pytest fixtures默认是函数作用域

### Details
编写测试fixtures时，我假设所有fixtures都是函数作用域的。
用户纠正说虽然函数作用域是默认的，但代码库
约定使用模块作用域的fixtures处理数据库连接以提高测试性能。

### Suggested Action
创建涉及昂贵设置（DB、网络）的fixtures时，
在默认使用函数作用域之前检查现有fixtures的作用域模式。

### Metadata
- Source: user_feedback
- Related Files: tests/conftest.py
- Tags: pytest, testing, fixtures

---
```

## 学习：知识缺口（已解决）

```markdown
## [LRN-20250115-002] knowledge_gap

**Logged**: 2025-01-15T14:22:00Z
**Priority**: medium
**Status**: resolved
**Area**: config

### Summary
项目使用pnpm而非npm进行包管理

### Details
尝试运行 `npm install` 但项目使用pnpm workspaces。
锁文件是 `pnpm-lock.yaml`，不是 `package-lock.json`。

### Suggested Action
在假设npm之前检查 `pnpm-lock.yaml` 或 `pnpm-workspace.yaml`。
此项目使用 `pnpm install`。

### Metadata
- Source: error
- Related Files: pnpm-lock.yaml, pnpm-workspace.yaml
- Tags: package-manager, pnpm, setup

### Resolution
- **Resolved**: 2025-01-15T14:30:00Z
- **Commit/PR**: N/A - 知识更新
- **Notes**: 已添加到CLAUDE.md供将来参考

---
```

## 学习：提升到CLAUDE.md

```markdown
## [LRN-20250115-003] best_practice

**Logged**: 2025-01-15T16:00:00Z
**Priority**: high
**Status**: promoted
**Promoted**: CLAUDE.md
**Area**: backend

### Summary
API响应必须包含请求头中的关联ID

### Details
所有API响应应回显请求中的X-Correlation-ID头。
这是分布式追踪所必需的。没有此头的响应
会破坏可观测性管道。

### Suggested Action
始终在API处理程序中包含关联ID传递。

### Metadata
- Source: user_feedback
- Related Files: src/middleware/correlation.ts
- Tags: api, observability, tracing

---
```

## 学习：提升到AGENTS.md

```markdown
## [LRN-20250116-001] best_practice

**Logged**: 2025-01-16T09:00:00Z
**Priority**: high
**Status**: promoted
**Promoted**: AGENTS.md
**Area**: backend

### Summary
OpenAPI规范更改后必须重新生成API客户端

### Details
修改API端点时，必须重新生成TypeScript客户端。
忘记这点会导致只在运行时出现的类型不匹配。
生成脚本还会运行验证。

### Suggested Action
添加到代理工作流：任何API更改后，运行 `pnpm run generate:api`。

### Metadata
- Source: error
- Related Files: openapi.yaml, src/client/api.ts
- Tags: api, codegen, typescript

---
```

## 错误条目

```markdown
## [ERR-20250115-A3F] docker_build

**Logged**: 2025-01-15T09:15:00Z
**Priority**: high
**Status**: pending
**Area**: infra

### Summary
Docker构建在M1 Mac上因平台不匹配失败

### Error
```
error: failed to solve: python:3.11-slim: no match for platform linux/arm64
```

### Context
- Command: `docker build -t myapp .`
- Dockerfile使用 `FROM python:3.11-slim`
- 运行在Apple Silicon（M1/M2）上

### Suggested Fix
添加平台标志：`docker build --platform linux/amd64 -t myapp .`
或更新Dockerfile：`FROM --platform=linux/amd64 python:3.11-slim`

### Metadata
- Reproducible: yes
- Related Files: Dockerfile

---
```

## 错误条目：重复问题

```markdown
## [ERR-20250120-B2C] api_timeout

**Logged**: 2025-01-20T11:30:00Z
**Priority**: critical
**Status**: pending
**Area**: backend

### Summary
结账时第三方支付API超时

### Error
```
TimeoutError: Request to payments.example.com timed out after 30000ms
```

### Context
- Command: POST /api/checkout
- 超时设置为30秒
- 在高峰时段发生（午餐、晚上）

### Suggested Fix
实现带指数退避的重试。考虑熔断器模式。

### Metadata
- Reproducible: yes（高峰时段）
- Related Files: src/services/payment.ts
- See Also: ERR-20250115-X1Y, ERR-20250118-Z3W

---
```

## 功能请求

```markdown
## [FEAT-20250115-001] export_to_csv

**Logged**: 2025-01-15T16:45:00Z
**Priority**: medium
**Status**: pending
**Area**: backend

### Requested Capability
将分析结果导出为CSV格式

### User Context
用户运行周报，需要与非技术相关方
在Excel中分享结果。目前手动复制输出。

### Complexity Estimate
simple

### Suggested Implementation
在analyze命令中添加 `--output csv` 标志。使用标准csv模块。
可以扩展现有的 `--output json` 模式。

### Metadata
- Frequency: recurring
- Related Features: analyze命令, json输出

---
```

## 功能请求：已解决

```markdown
## [FEAT-20250110-002] dark_mode

**Logged**: 2025-01-10T14:00:00Z
**Priority**: low
**Status**: resolved
**Area**: frontend

### Requested Capability
仪表板支持暗色模式

### User Context
用户深夜工作，觉得明亮界面刺眼。
其他几个用户也非正式地提到过这个问题。

### Complexity Estimate
medium

### Suggested Implementation
使用CSS变量处理颜色。在用户设置中添加切换。
考虑系统偏好检测。

### Metadata
- Frequency: recurring
- Related Features: 用户设置, 主题系统

### Resolution
- **Resolved**: 2025-01-18T16:00:00Z
- **Commit/PR**: #142
- **Notes**: 已实现系统偏好检测和手动切换

---
```

## 学习：提升为技能

```markdown
## [LRN-20250118-001] best_practice

**Logged**: 2025-01-18T11:00:00Z
**Priority**: high
**Status**: promoted_to_skill
**Skill-Path**: skills/docker-m1-fixes
**Area**: infra

### Summary
Docker构建在Apple Silicon上因平台不匹配失败

### Details
在M1/M2 Mac上构建Docker镜像时，构建失败因为
基础镜像没有ARM64变体。这是一个常见问题
影响许多开发者。

### Suggested Action
在docker build命令中添加 `--platform linux/amd64`，或在
Dockerfile中使用 `FROM --platform=linux/amd64`。

### Metadata
- Source: error
- Related Files: Dockerfile
- Tags: docker, arm64, m1, apple-silicon
- See Also: ERR-20250115-A3F, ERR-20250117-B2D

---
```

## 提取的技能示例

当上述学习被提取为技能时，变成：

**文件**：`skills/docker-m1-fixes/SKILL.md`

```markdown
---
name: docker-m1-fixes
description: "修复Apple Silicon（M1/M2）上的Docker构建失败。当docker build因平台不匹配错误失败时使用。"
---

# Docker M1修复

Apple Silicon Mac上Docker构建问题的解决方案。

## 快速参考

| 错误 | 修复 |
|------|------|
| `no match for platform linux/arm64` | 在构建中添加 `--platform linux/amd64` |
| 镜像运行但崩溃 | 使用模拟或找到ARM兼容的基础镜像 |

## 问题

许多Docker基础镜像没有ARM64变体。在
Apple Silicon（M1/M2/M3）上构建时，Docker默认
尝试拉取ARM64镜像，导致平台不匹配错误。

## 解决方案

### 选项1：构建标志（推荐）

在构建命令中添加平台标志：

\`\`\`bash
docker build --platform linux/amd64 -t myapp .
\`\`\`

### 选项2：Dockerfile修改

在FROM指令中指定平台：

\`\`\`dockerfile
FROM --platform=linux/amd64 python:3.11-slim
\`\`\`

### 选项3：Docker Compose

在服务中添加平台：

\`\`\`yaml
services:
  app:
    platform: linux/amd64
    build: .
\`\`\`

## 权衡

| 方法 | 优点 | 缺点 |
|------|------|------|
| 构建标志 | 无需修改文件 | 必须记住标志 |
| Dockerfile | 显式、版本化 | 影响所有构建 |
| Compose | 开发方便 | 需要compose |

## 性能说明

在ARM64上运行AMD64镜像使用Rosetta 2模拟。这对
开发有效但可能较慢。对于生产，尽可能找到ARM原生
替代方案。

## 来源

- Learning ID: LRN-20250118-001
- Category: best_practice
- Extraction Date: 2025-01-18
```
