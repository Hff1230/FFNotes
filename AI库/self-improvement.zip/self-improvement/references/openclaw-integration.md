# OpenClaw集成指南

将self-improvement技能与OpenClaw分布式学习模型集成的完整设置和使用指南。

## 概述

OpenClaw是一个基于终端的AI编码助手，使用基于工作区的提示注入。与Claude Code的钩子系统不同，OpenClaw在会话开始时从工作区文件注入上下文，并支持代理间通信。

## 架构对比

| 特性 | Claude Code | OpenClaw |
|------|-------------|----------|
| 学习存储 | 项目中的 `.learnings/` | 工作区文件（`~/clawd/`） |
| 激活方式 | 钩子（UserPromptSubmit） | 启动时工作区注入 |
| 提升目标 | `CLAUDE.md`、`AGENTS.md` | `SOUL.md`、`TOOLS.md`、`AGENTS.md` |
| 代理间通信 | 非内置 | `sessions_*` 工具 |
| 技能注册表 | 手动 / agentskills.io | ClawdHub集成 |

## 工作区设置

### 默认结构

```
~/clawd/                          # 可通过 ~/.openclaw/openclaw.json 配置
├── AGENTS.md                    # 多代理协调模式
├── SOUL.md                      # 行为准则和个性
├── TOOLS.md                     # 工具能力和MCP陷阱
├── skills/                      # ClawdHub技能缓存
│   └── <skill-name>/
│       └── SKILL.md
└── sessions/                    # 自动管理的会话记录
    └── <session-id>.jsonl
```

### 配置

编辑 `~/.openclaw/openclaw.json`：

```json
{
  "workspace": "~/clawd",
  "model": "claude-sonnet-4-20250514",
  "inject_files": ["AGENTS.md", "SOUL.md", "TOOLS.md"],
  "session_history": true
}
```

## 注入的提示词文件

### AGENTS.md

用途：多代理工作流和委托模式。

```markdown
# Agent Coordination

## Delegation Rules
- 使用explore agent处理开放式代码库问题
- 使用research-agent处理外部文档查询
- 复杂实现前使用Plan agent

## Session Handoff
当委托给另一个会话时：
1. 在交接消息中提供完整上下文
2. 包含相关文件路径
3. 指定预期输出格式
```

### SOUL.md

用途：行为准则和沟通风格。

```markdown
# Behavioral Guidelines

## Communication Style
- 直接且简洁
- 避免不必要的注意事项和免责声明
- 使用适合上下文的技术语言

## Decision Making
- 偏好简单解决方案而非巧妙方案
- 尽早提出澄清问题
- 在展示选项时解释权衡

## Error Handling
- 及时承认错误
- 立即提供正确信息
- 将重大错误记录到学习记录
```

### TOOLS.md

用途：工具能力、MCP服务器知识、集成陷阱。

```markdown
# Tool Knowledge

## MCP Servers

### atlassian
- 使用 `search` 进行Jira/Confluence的常规查询
- 仅在显式需要JQL语法时使用 `searchJiraIssuesUsingJql`
- CloudId可从URL中提取（工具处理转换）
- 页面ID在URL路径中：`/pages/123456789/`

### leanix
- 使用external_id（非internal id）进行查找
- expand_teams/expand_apps用于嵌套数据

## Built-in Tools

### Bash
- 偏好专用工具而非bash（用Read而非cat，用Glob而非find）
- 用于git操作、npm/pnpm、docker命令

### Task
- 使用explore agent处理代码库问题
- 使用research-agent处理外部文档
```

## 学习工作流

### 捕获学习

1. **会话内**：照常记录到 `.learnings/`（项目特定）
2. **跨项目**：提升到工作区文件（openclaw）

### 提升决策树

```
学习是项目特定的吗？
├── 是 → 提升到CLAUDE.md或.learnings/
└── 否 → 与行为/风格相关吗？
    ├── 是 → 提升到SOUL.md
    └── 否 → 与工具/MCP相关吗？
        ├── 是 → 提升到TOOLS.md
        └── 否 → 提升到AGENTS.md（工作流）
```

### 提升格式示例

**从学习：**
> MCP atlassian服务器：search工具用于常规查询。仅当用户明确提及JQL或CQL语法时才使用JQL/CQL工具。

**到TOOLS.md：**
```markdown
### atlassian
- `search`: 用于常规查询（默认）
- `searchJiraIssuesUsingJql`: 仅当明确请求JQL时
- `searchConfluenceUsingCql`: 仅当明确请求CQL时
```

## 代理间通信

OpenClaw提供跨会话通信的工具：

### sessions_list

查看活跃和最近的会话：
```
sessions_list --active
sessions_list --recent 10
```

### sessions_history

读取另一个会话的记录：
```
sessions_history --session <session-id> --last 50
```

### sessions_send

向另一个会话发送消息：
```
sessions_send --to <session-id> --message "Learning: API requires X-Custom-Header"
```

### 学习共享模式

当在会话A中发现有价值的内容时：

1. 检查其他会话是否在处理相关代码：
   ```
   sessions_list --active
   ```

2. 分享学习：
   ```
   sessions_send --to session-b --message "FYI: 发现auth API需要每30分钟刷新令牌"
   ```

3. 如果广泛适用，记录到工作区文件：
   - 编辑 `~/clawd/TOOLS.md` 或适当文件

## ClawdHub集成

ClawdHub是OpenClaw的技能注册表（类似agentskills.io）。

### 安装技能

```bash
clawd skill install <skill-name>
```

技能缓存在 `~/clawd/skills/`。

### 发布技能

1. 按照agentskills.io规范创建技能
2. 注册到ClawdHub
3. 技能对所有OpenClaw用户可用

### 技能兼容性

此仓库的技能兼容：
- Claude Code（通过钩子）
- Codex CLI（通过钩子）
- OpenClaw（通过ClawdHub）
- GitHub Copilot（通过手动设置）

## 混合设置：Claude Code + OpenClaw

在同一代码库上同时使用两种工具时：

### 推荐分工

| 关注点 | 存储位置 |
|--------|----------|
| 项目约定 | `CLAUDE.md`（在仓库中） |
| 项目学习 | `.learnings/`（在仓库中） |
| 个人偏好 | `SOUL.md`（openclaw工作区） |
| 工具知识 | `TOOLS.md`（openclaw工作区） |
| 跨项目工作流 | `AGENTS.md`（openclaw工作区） |

### 同步策略

高价值学习应同时存在于两处：

1. 首先记录到 `.learnings/`（项目上下文）
2. 如果广泛适用，也添加到openclaw工作区
3. 使用一致的格式便于grep

### 双重提升示例

学习："Playwright测试需要--headed标志进行调试"

**在 `.learnings/LEARNINGS.md`：**
```markdown
## [LRN-20250126-001] correction

**Status**: promoted
**Promoted**: CLAUDE.md, TOOLS.md (openclaw)

### Summary
Playwright测试需要--headed标志进行视觉调试

### Details
...
```

**在 `CLAUDE.md`：**
```markdown
## Testing
- Playwright调试：使用 `--headed` 标志
```

**在 `~/clawd/TOOLS.md`：**
```markdown
## Playwright
- 调试模式：`npx playwright test --headed`
- 跟踪查看器：`npx playwright show-trace trace.zip`
```

## OpenClaw的检测触发器

### 标准触发器（与Claude Code相同）
- 用户纠正
- 命令失败
- API错误
- 知识缺口

### OpenClaw特定触发器

| 触发器 | 操作 |
|--------|------|
| MCP服务器错误 | 记录到TOOLS.md，包含服务器名称 |
| 会话交接混乱 | 记录到AGENTS.md，包含委托模式 |
| 模型行为意外 | 记录到SOUL.md，包含预期与实际 |
| ClawdHub技能问题 | 记录到TOOLS.md或上报上游 |

## 故障排除

### 工作区文件未注入

检查 `~/.openclaw/openclaw.json`：
- 验证 `workspace` 路径存在
- 验证 `inject_files` 包含所需文件

### 会话通信失败

- 验证目标会话活跃：`sessions_list --active`
- 检查会话ID是否正确
- 会话可能已结束

### 学习未持久化

OpenClaw不会自动持久化学习。你必须：
1. 显式写入工作区文件
2. 或对项目特定存储使用 `.learnings/`
