# 技能模板

从学习记录提取技能的模板。复制并自定义。

---

## SKILL.md模板

```markdown
---
name: skill-name-here
description: "简洁描述何时以及为何使用此技能。包含触发条件。"
---

# 技能名称

简要介绍此技能解决的问题及其来源。

## 快速参考

| 情境 | 操作 |
|------|------|
| [触发条件1] | [操作1] |
| [触发条件2] | [操作2] |

## 背景

为什么这个知识很重要。它能防止什么问题。原始学习的上下文。

## 解决方案

### 步骤

1. 第一步，包含代码或命令
2. 第二步
3. 验证步骤

### 代码示例

\`\`\`language
// 演示解决方案的示例代码
\`\`\`

## 常见变体

- **变体A**：描述及处理方法
- **变体B**：描述及处理方法

## 注意事项

- 警告或常见错误 #1
- 警告或常见错误 #2

## 相关

- 相关文档链接
- 相关技能链接

## 来源

从学习条目提取。
- **Learning ID**: LRN-YYYYMMDD-XXX
- **Original Category**: correction | insight | knowledge_gap | best_practice
- **Extraction Date**: YYYY-MM-DD
```

---

## 精简模板

用于不需要所有部分的简单技能：

```markdown
---
name: skill-name-here
description: "此技能做什么以及何时使用。"
---

# 技能名称

[一句话问题描述]

## 解决方案

[包含代码/命令的直接解决方案]

## 来源

- Learning ID: LRN-YYYYMMDD-XXX
```

---

## 带脚本的模板

用于包含可执行帮助程序的技能：

```markdown
---
name: skill-name-here
description: "此技能做什么以及何时使用。"
---

# 技能名称

[介绍]

## 快速参考

| 命令 | 用途 |
|------|------|
| `./scripts/helper.sh` | [功能描述] |
| `./scripts/validate.sh` | [功能描述] |

## 使用

### 自动方式（推荐）

\`\`\`bash
./skills/skill-name/scripts/helper.sh [args]
\`\`\`

### 手动步骤

1. 第一步
2. 第二步

## 脚本

| 脚本 | 描述 |
|------|------|
| `scripts/helper.sh` | 主要工具 |
| `scripts/validate.sh` | 验证检查器 |

## 来源

- Learning ID: LRN-YYYYMMDD-XXX
```

---

## 命名约定

- **技能名称**：小写，空格用连字符
  - 正确：`docker-m1-fixes`、`api-timeout-patterns`
  - 错误：`Docker_M1_Fixes`、`APITimeoutPatterns`

- **描述**：以动作动词开头，提及触发条件
  - 正确："处理Apple Silicon上的Docker构建失败。当构建因平台不匹配失败时使用。"
  - 错误："Docker相关内容"

- **文件**：
  - `SKILL.md` - 必需，主要文档
  - `scripts/` - 可选，可执行代码
  - `references/` - 可选，详细文档
  - `assets/` - 可选，模板

---

## 提取检查清单

从学习创建技能前：

- [ ] 学习已验证（状态：resolved）
- [ ] 解决方案广泛适用（非一次性）
- [ ] 内容完整（包含所有需要的上下文）
- [ ] 名称遵循约定
- [ ] 描述简洁但信息丰富
- [ ] 快速参考表格可操作
- [ ] 代码示例已测试
- [ ] 已记录来源学习ID

创建后：

- [ ] 用 `promoted_to_skill` 状态更新原始学习
- [ ] 在学习元数据中添加 `Skill-Path: skills/skill-name`
- [ ] 在新会话中阅读技能进行测试
