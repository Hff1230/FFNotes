---
name: {{SKILL_NAME}}
description: {{它的功能}} 在{{触发条件}}时使用。
---

<objective>
{{此技能完成的明确陈述}}
</objective>

<quick_start>
{{立即可操作的指导 - Claude 应该首先做什么}}
</quick_start>

<process>
## 步骤 1：{{第一个操作}}

{{步骤 1 的指令}}

## 步骤 2：{{第二个操作}}

{{步骤 2 的指令}}

## 步骤 3：{{第三个操作}}

{{步骤 3 的指令}}
</process>

<success_criteria>
{{技能名称}}在以下情况下完成：
- [ ] {{第一个成功标准}}
- [ ] {{第二个成功标准}}
- [ ] {{第三个成功标准}}
</success_criteria>
