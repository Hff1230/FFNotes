---
name: plan_review
description: 让多个专业代理并行审查计划
argument-hint: "[计划文件路径或计划内容]"
---

让 @agent-dhh-rails-reviewer @agent-kieran-rails-reviewer @agent-code-simplicity-reviewer 并行审查此计划。
