---
name: create-agent-skill
description: 创建或编辑 Claude Code 技能,提供结构和最佳实践的专业指导
allowed-tools: Skill(create-agent-skills)
argument-hint: [技能描述或需求]
---

调用 create-agent-skills 技能以处理: $ARGUMENTS
