# xsearch Usage Guide

## Quick Reference

xsearch uses mcporter to call Firecrawl MCP. It is **not** a standard skill — it must be invoked via mcporter CLI directly.

### Config Path

```
~/AppData/Local/hermes/skills/customer/xsearch/scripts/mcporter.json
```

### Use the Wrapper Script (Recommended)

A wrapper script auto-detects the config path from its own location:

```bash
cd ~/AppData/Local/hermes/skills/customer/xsearch/scripts/
./xsearch.sh <tool_name> [args...]
```

**Examples:**

```bash
# Search
./xsearch.sh web-search-mcp.firecrawl_search query="keywords" limit:5

# Scrape
./xsearch.sh web-search-mcp.firecrawl_scrape url="https://example.com"

# Site Map
./xsearch.sh web-search-mcp.firecrawl_map url="https://example.com"
```

### Direct mcporter Call

```bash
CONFIG="$HOME/AppData/Local/hermes/skills/customer/xsearch/scripts/mcporter.json"
mcporter call --config "$CONFIG" web-search-mcp.firecrawl_search query="keywords" limit:5
```

PowerShell:

```powershell
$CONFIG = "$HOME\AppData\Local\hermes\skills\customer\xsearch\scripts\mcporter.json"
mcporter call --config $CONFIG web-search-mcp.firecrawl_search query="keywords" limit:5
```

## Tools

| Tool | Command |
|------|---------|
| Search | `./xsearch.sh web-search-mcp.firecrawl_search query="..." limit:5` |
| Scrape | `./xsearch.sh web-search-mcp.firecrawl_scrape url="..."` |
| Site Map | `./xsearch.sh web-search-mcp.firecrawl_map url="..."` |

## Output Format

- **Search**: JSON with `web` array — each item has `url`, `title`, `description`
- **Scrape**: JSON with `markdown` (page content) and `metadata`

## Known Issues

### skill_view fails on Windows

`skill_view` has a GBK encoding bug on Windows — it fails to read SKILL.md files containing non-ASCII bytes (Chinese characters, em-dashes). Use `read_file` or `cat` in terminal instead.

### firecrawl_scrape may timeout

The scrape endpoint can be slow or timeout. Use search instead to get links, then navigate with browser to read content.
