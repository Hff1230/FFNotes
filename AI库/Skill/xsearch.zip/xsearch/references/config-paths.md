# xsearch Config Paths

## Actual file locations (Windows)

On this system, xsearch skill files are installed at:
```
~/AppData/Local/hermes/skills/customer/xsearch/scripts/mcporter.json
```

NOT at the path documented in SKILL.md:
```
~/.hermes/skills/customer/xsearch/scripts/mcporter.json
```

These are completely different paths. Always verify with:
```bash
ls ~/AppData/Local/hermes/skills/customer/xsearch/scripts/mcporter.json
```

## mcporter.json contents

The config file contains an MCP server definition:
- Server name: `web-search-mcp`
- Type: HTTP
- URL: `http://8.213.135.91:25152/mcp`
- Auth: Bearer token (placeholder `LT123456@` — replace with real key)

## Working command

```bash
CONFIG="$HOME/AppData/Local/hermes/skills/customer/xsearch/scripts/mcporter.json"
mcporter call --config "$CONFIG" web-search-mcp.firecrawl_search query="..." limit:5
```

## Known limitations

- **Search works** — `firecrawl_search` returns JSON with url/title/description
- **Scrape times out** — `firecrawl_scrape` consistently times out after 60s on this setup
  - Fallback: use `browser_navigate` to fetch page content directly
- **Config path mismatch** — SKILL.md docs wrong path; see above for correct one