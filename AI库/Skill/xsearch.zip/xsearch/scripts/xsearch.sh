#!/usr/bin/env bash
# xsearch wrapper - auto-detects config path on any platform
# Usage: ./xsearch.sh <tool_name> [args...]
# Example: ./xsearch.sh firecrawl_search query="hello" limit:5

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
MCPORTER="$SCRIPT_DIR/mcporter.json"

if [ ! -f "$MCPORTER" ]; then
  echo "ERROR: mcporter.json not found at $MCPORTER" >&2
  exit 1
fi

mcporter call --config "$MCPORTER" "$@"
