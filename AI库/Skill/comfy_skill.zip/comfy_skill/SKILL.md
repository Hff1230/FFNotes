---
name: comfy-skill
description: Generate images and videos using ComfyUI workflows. Use this skill when user requests AI image/video generation, style transfer, or ComfyUI-related tasks.
allowed-tools: Bash, Read, Write
---

# Comfy-Skill

## When to Use

Use this skill when:
- User asks to generate images from text descriptions
- User wants to transform/modify existing images
- User requests video generation
- User mentions ComfyUI workflows
- User asks for style transfer or artistic transformations

## ⚠️ IMPORTANT: Use Sub-Agent

**All image/video generation tasks MUST be delegated to a sub-agent.** Do NOT run ComfyUI commands directly in the main session.

- Image/video generation takes 1-5 minutes per task
- Multiple generations can run in parallel via sub-agents
- Prevents blocking the main session

Spawn a sub-agent for each generation task:

```bash
# Single task
Agent with prompt: "Run: export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js txt2img 'a beautiful sunset'"

# Batch multiple generations in one sub-agent
Agent with prompt: "
  export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli &&
  node src/index.js txt2img 'prompt 1' --seed 123 &&
  node src/index.js txt2img 'prompt 2' --seed 124
"
```

## ⚠️ Command Execution Pattern

All commands MUST set `COMFY_PROJECT_ROOT` before `cd`:

```bash
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js <command> [options]
```

## Command Overview

| Command | Description | Quick Example |
|---------|-------------|---------------|
| `list` | List available workflows | `node src/index.js list` |
| `txt2img` | Text to image generation | `node src/index.js txt2img "sunset" --size mid` |
| `img2img` | Image to image transformation (1-4 images) | `node src/index.js img2img photo.jpg "oil painting"` |
| `txt2vid` | Text to video generation | `node src/index.js txt2vid "cat walking" --fps 24` |
| `img2vid` | Image to video animation | `node src/index.js img2vid photo.jpg --prompt "movement"` |
| `2img2vid` | Two images to video transition | `node src/index.js 2img2vid img1.png img2.png` |
| `imagescale` | AI super-resolution upscale | `node src/index.js imagescale photo.jpg --size 4k` |
| `batch` | Batch execution from JSON file | `node src/index.js batch tasks.json` |
| `run` | Run custom workflow by name | `node src/index.js run <workflow> --prompt <text>` |

## Common Options (All Commands)

| Option | Description |
|--------|-------------|
| `--output <dir>` | Output directory (default: `$COMFY_PROJECT_ROOT/output`) |
| `--seed <num>` | Random seed |
| `--upload` | Upload to server (default: true) |
| `--no-upload` | Skip uploading |
| `--project <name>` | Project name for organized output |
| `--category <type>` | Resource category (characters/scenes/props/videos/upscale) |
| `--name <name>` | Resource name for filename |

## Available Workflows

| Workflow | Type | Description |
|----------|------|-------------|
| zimageturbot2i | txt2img | Default text-to-image |
| qwen2511i2i | img2img | Single image (auto-selected) |
| qwen2511i2i2 | 2img2img | Dual image (auto-selected) |
| qwen2511i2i3 | 3img2img | Triple image (auto-selected) |
| qwen2511i2i4 | 4img2img | Quad image (auto-selected) |
| want2v | txt2vid | Text-to-video |
| wani2v | img2vid | Image-to-video |
| ltx2img2vid | 2img2vid | Two-image transition |
| qwen2511angle | img2img | Angle-specific generation |
| zimageupscale | imagescale | AI super-resolution |

## Configuration

Workflow definitions are in `config/comfy_config.json`. Upload config in `upload` section:
- `server` - dufs server address
- `share_url` - Public URL for sharing

## Output

Files saved locally + auto-uploaded to dufs server. Share URLs displayed in console.

## Progressive Loading Guide

When executing specific functions, read the corresponding module for full parameters and examples:

| Usage Scenario | Module File | Content |
|---------------|-------------|---------|
| Text to image | modules/txt2img.md | Full txt2img params, project output organization |
| Image to image | modules/img2img.md | Multi-image input, workflow auto-matching |
| Video generation | modules/video.md | txt2vid, img2vid, 2img2vid full params |
| Image upscale | modules/imagescale.md | Super-resolution parameters |
| Batch execution | modules/batch.md | JSON format, progress persistence |
| Angle generation | modules/angle.md | 12 angle groups x 8 viewpoints = 96 prompts |
| Workflow config | modules/workflows.md | Full workflow list, configuration details |
