# Image Angle Generation

Generate images from different camera angles and distances based on an input image. Uses the `qwen2511angle` workflow to produce angle-specific variations of a source image.

## Command Format

```bash
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js img2img <input_image> "<prompt>" --workflow qwen2511angle [options]
```

## Single Image Generation

```bash
# Generate a high-angle close-up front view
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js img2img ./photo.jpg "<sks> front view high-angle shot close-up" --workflow qwen2511angle

# Generate a low-angle wide shot back view
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js img2img ./photo.jpg "<sks> back view low-angle shot wide shot" --workflow qwen2511angle --seed 42
```

## Parameters

| Parameter | Description |
|-----------|-------------|
| `<input_image>` | Source image path or URL |
| `<prompt>` | Angle prompt in format: `<sks> {viewpoint} {camera_angle} {shot_distance}` |
| `--workflow qwen2511angle` | Required: specifies the angle generation workflow |
| `--seed <num>` | Random seed for reproducibility |
| `--strength <num>` | Denoise strength (0-1) |
| `--output <dir>` | Output directory |

## Angle Group Definitions

Angle groups are defined by combining camera angle and shot distance codes.

**Naming Rule:** `{camera_angle_code}{shot_distance_code}`

- **Camera Angle Codes:** h=high-angle, e=elevated, n=eye-level(normal), l=low-angle
- **Shot Distance Codes:** c=close-up, m=medium shot, w=wide shot

| Code | Camera Angle | Shot Distance | Description |
|------|-------------|---------------|-------------|
| hc | high-angle shot | close-up | High-angle close-up |
| ec | elevated shot | close-up | Elevated close-up |
| nc | eye-level shot | close-up | Eye-level close-up |
| lc | low-angle shot | close-up | Low-angle close-up |
| hm | high-angle shot | medium shot | High-angle medium shot |
| em | elevated shot | medium shot | Elevated medium shot |
| nm | eye-level shot | medium shot | Eye-level medium shot |
| lm | low-angle shot | medium shot | Low-angle medium shot |
| hw | high-angle shot | wide shot | High-angle wide shot |
| ew | elevated shot | wide shot | Elevated wide shot |
| nw | eye-level shot | wide shot | Eye-level wide shot |
| lw | low-angle shot | wide shot | Low-angle wide shot |

## Viewpoints

Each angle group supports 8 viewpoints (identical across all groups):

1. front view
2. front-right quarter view
3. right side view
4. back-right quarter view
5. back view
6. back-left quarter view
7. left side view
8. front-left quarter view

## Prompt Format

The complete prompt format is: `<sks> {viewpoint} {camera_angle} {shot_distance}`

### Full Prompts by Angle Group

**hc - High-angle Close-up:**
```
<sks> front view high-angle shot close-up
<sks> front-right quarter view high-angle shot close-up
<sks> right side view high-angle shot close-up
<sks> back-right quarter view high-angle shot close-up
<sks> back view high-angle shot close-up
<sks> back-left quarter view high-angle shot close-up
<sks> left side view high-angle shot close-up
<sks> front-left quarter view high-angle shot close-up
```

**ec - Elevated Close-up:**
```
<sks> front view elevated shot close-up
<sks> front-right quarter view elevated shot close-up
<sks> right side view elevated shot close-up
<sks> back-right quarter view elevated shot close-up
<sks> back view elevated shot close-up
<sks> back-left quarter view elevated shot close-up
<sks> left side view elevated shot close-up
<sks> front-left quarter view elevated shot close-up
```

**nc - Eye-level Close-up:**
```
<sks> front view eye-level shot close-up
<sks> front-right quarter view eye-level shot close-up
<sks> right side view eye-level shot close-up
<sks> back-right quarter view eye-level shot close-up
<sks> back view eye-level shot close-up
<sks> back-left quarter view eye-level shot close-up
<sks> left side view eye-level shot close-up
<sks> front-left quarter view eye-level shot close-up
```

**lc - Low-angle Close-up:**
```
<sks> front view low-angle shot close-up
<sks> front-right quarter view low-angle shot close-up
<sks> right side view low-angle shot close-up
<sks> back-right quarter view low-angle shot close-up
<sks> back view low-angle shot close-up
<sks> back-left quarter view low-angle shot close-up
<sks> left side view low-angle shot close-up
<sks> front-left quarter view low-angle shot close-up
```

**hm - High-angle Medium Shot:**
```
<sks> front view high-angle shot medium shot
<sks> front-right quarter view high-angle shot medium shot
<sks> right side view high-angle shot medium shot
<sks> back-right quarter view high-angle shot medium shot
<sks> back view high-angle shot medium shot
<sks> back-left quarter view high-angle shot medium shot
<sks> left side view high-angle shot medium shot
<sks> front-left quarter view high-angle shot medium shot
```

**em - Elevated Medium Shot:**
```
<sks> front view elevated shot medium shot
<sks> front-right quarter view elevated shot medium shot
<sks> right side view elevated shot medium shot
<sks> back-right quarter view elevated shot medium shot
<sks> back view elevated shot medium shot
<sks> back-left quarter view elevated shot medium shot
<sks> left side view elevated shot medium shot
<sks> front-left quarter view elevated shot medium shot
```

**nm - Eye-level Medium Shot:**
```
<sks> front view eye-level shot medium shot
<sks> front-right quarter view eye-level shot medium shot
<sks> right side view eye-level shot medium shot
<sks> back-right quarter view eye-level shot medium shot
<sks> back view eye-level shot medium shot
<sks> back-left quarter view eye-level shot medium shot
<sks> left side view eye-level shot medium shot
<sks> front-left quarter view eye-level shot medium shot
```

**lm - Low-angle Medium Shot:**
```
<sks> front view low-angle shot medium shot
<sks> front-right quarter view low-angle shot medium shot
<sks> right side view low-angle shot medium shot
<sks> back-right quarter view low-angle shot medium shot
<sks> back view low-angle shot medium shot
<sks> back-left quarter view low-angle shot medium shot
<sks> left side view low-angle shot medium shot
<sks> front-left quarter view low-angle shot medium shot
```

**hw - High-angle Wide Shot:**
```
<sks> front view high-angle shot wide shot
<sks> front-right quarter view high-angle shot wide shot
<sks> right side view high-angle shot wide shot
<sks> back-right quarter view high-angle shot wide shot
<sks> back view high-angle shot wide shot
<sks> back-left quarter view high-angle shot wide shot
<sks> left side view high-angle shot wide shot
<sks> front-left quarter view high-angle shot wide shot
```

**ew - Elevated Wide Shot:**
```
<sks> front view elevated shot wide shot
<sks> front-right quarter view elevated shot wide shot
<sks> right side view elevated shot wide shot
<sks> back-right quarter view elevated shot wide shot
<sks> back view elevated shot wide shot
<sks> back-left quarter view elevated shot wide shot
<sks> left side view elevated shot wide shot
<sks> front-left quarter view elevated shot wide shot
```

**nw - Eye-level Wide Shot:**
```
<sks> front view eye-level shot wide shot
<sks> front-right quarter view eye-level shot wide shot
<sks> right side view eye-level shot wide shot
<sks> back-right quarter view eye-level shot wide shot
<sks> back view eye-level shot wide shot
<sks> back-left quarter view eye-level shot wide shot
<sks> left side view eye-level shot wide shot
<sks> front-left quarter view eye-level shot wide shot
```

**lw - Low-angle Wide Shot:**
```
<sks> front view low-angle shot wide shot
<sks> front-right quarter view low-angle shot wide shot
<sks> right side view low-angle shot wide shot
<sks> back-right quarter view low-angle shot wide shot
<sks> back view low-angle shot wide shot
<sks> back-left quarter view low-angle shot wide shot
<sks> left side view low-angle shot wide shot
<sks> front-left quarter view low-angle shot wide shot
```

## Batch Generation Example

Use the batch JSON format to generate all 8 viewpoints for an angle group in one execution:

```json
[
  {
    "type": "img2img",
    "image": "./photo.jpg",
    "prompt": "<sks> front view high-angle shot close-up",
    "workflow": "qwen2511angle",
    "seed": 100,
    "output": "./output/angle_hc"
  },
  {
    "type": "img2img",
    "image": "./photo.jpg",
    "prompt": "<sks> front-right quarter view high-angle shot close-up",
    "workflow": "qwen2511angle",
    "seed": 101,
    "output": "./output/angle_hc"
  },
  {
    "type": "img2img",
    "image": "./photo.jpg",
    "prompt": "<sks> right side view high-angle shot close-up",
    "workflow": "qwen2511angle",
    "seed": 102,
    "output": "./output/angle_hc"
  },
  {
    "type": "img2img",
    "image": "./photo.jpg",
    "prompt": "<sks> back-right quarter view high-angle shot close-up",
    "workflow": "qwen2511angle",
    "seed": 103,
    "output": "./output/angle_hc"
  },
  {
    "type": "img2img",
    "image": "./photo.jpg",
    "prompt": "<sks> back view high-angle shot close-up",
    "workflow": "qwen2511angle",
    "seed": 104,
    "output": "./output/angle_hc"
  },
  {
    "type": "img2img",
    "image": "./photo.jpg",
    "prompt": "<sks> back-left quarter view high-angle shot close-up",
    "workflow": "qwen2511angle",
    "seed": 105,
    "output": "./output/angle_hc"
  },
  {
    "type": "img2img",
    "image": "./photo.jpg",
    "prompt": "<sks> left side view high-angle shot close-up",
    "workflow": "qwen2511angle",
    "seed": 106,
    "output": "./output/angle_hc"
  },
  {
    "type": "img2img",
    "image": "./photo.jpg",
    "prompt": "<sks> front-left quarter view high-angle shot close-up",
    "workflow": "qwen2511angle",
    "seed": 107,
    "output": "./output/angle_hc"
  }
]
```

Save the JSON to a file (e.g., `batch_hc.json`) and execute:

```bash
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js batch batch_hc.json
```

> **Tip:** Total combinations across all 12 angle groups x 8 viewpoints = 96 unique prompts. To generate all angles, create one batch JSON file per angle group (12 files total), each containing 8 tasks.
