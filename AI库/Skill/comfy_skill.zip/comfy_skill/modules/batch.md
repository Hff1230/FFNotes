# Batch Execution

Execute multiple commands sequentially from a JSON file. Supports progress persistence and resume from interruption.

## Command

```bash
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js batch <file.json> [options]
```

## Options

| Option | Description |
|--------|-------------|
| `-c, --config <path>` | Path to configuration file |
| `--continue-on-error` | Continue executing remaining tasks when one fails |
| `--dry-run` | Validate JSON file without executing |
| `--restart` | Force restart from beginning, ignore progress file |
| `--clean` | Delete progress file and exit |
| `-o, --output <path>` | Default output directory (overridden by task-level) |
| `--no-upload` | Skip uploading for all tasks |

## JSON File Format

The JSON file should contain an array of task objects. Each task must have a `type` field and the corresponding parameters:

```json
[
  {
    "type": "txt2img",
    "prompt": "武松打虎，正面全身照",
    "negative": "low quality, blurry",
    "output": "./output",
    "workflow": "zimageturbot2i",
    "steps": 20,
    "cfg": 7,
    "seed": 12345,
    "width": 1024,
    "height": 768,
    "size": "high",
    "orientation": "0",
    "upload": true,
    "project": "wusong",
    "category": "characters",
    "name": "C01_武松_正面全身"
  },
  {
    "type": "img2img",
    "image": "photo1.jpg,photo2.jpg",
    "prompt": "合并为一张图",
    "negative": "low quality",
    "strength": 0.8,
    "output": "./output",
    "project": "wusong",
    "category": "scenes",
    "name": "S01_景阳岗"
  },
  {
    "type": "imagescale",
    "image": "input.png",
    "size": "4k",
    "orientation": "0",
    "output": "./output"
  }
]
```

## Supported Task Types and Parameters

| Type | Required Fields | Optional Fields |
|------|----------------|-----------------|
| `txt2img` | `prompt` | `negative`, `output`, `workflow`, `steps`, `cfg`, `seed`, `width`, `height`, `size`, `orientation`, `upload`, `project`, `category`, `name` |
| `img2img` | `image`, `prompt` | `negative`, `output`, `workflow`, `strength`, `steps`, `cfg`, `seed`, `width`, `height`, `size`, `orientation`, `upload` |
| `txt2vid` | `prompt` | `negative`, `output`, `workflow`, `format`, `fps`, `frames`, `steps`, `cfg`, `seed`, `width`, `height`, `size`, `orientation`, `upload` |
| `img2vid` | `image` | `prompt`, `negative`, `output`, `workflow`, `format`, `fps`, `frames`, `steps`, `cfg`, `seed`, `width`, `height`, `size`, `orientation`, `motion`, `upload` |
| `2img2video` | `image1`, `image2` | `prompt`, `negative`, `output`, `workflow`, `format`, `fps`, `frames`, `seed`, `width`, `height`, `size`, `orientation`, `upload` |
| `imagescale` | `image` | `output`, `workflow`, `size`, `orientation`, `width`, `height`, `seed`, `upload` |

## Progress Persistence

A `.p` progress file is automatically created alongside the JSON file. It tracks:
- Completed tasks and their results
- Current execution position for resume

If execution is interrupted, running the same command again will resume from where it stopped.

## Examples

```bash
# Execute all tasks in a batch file
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js batch tasks.json

# Validate batch file without executing
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js batch tasks.json --dry-run

# Continue on error (skip failed tasks)
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js batch tasks.json --continue-on-error

# Force restart from beginning
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js batch tasks.json --restart

# Delete progress file
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js batch tasks.json --clean

# Override output directory for all tasks
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js batch tasks.json --output ./my_output
```
