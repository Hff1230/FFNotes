# Video Generation

## Text to Video (txt2vid)

### Command
```bash
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js txt2vid "<prompt>" [options]
```

Generate videos from text descriptions.

### Options
| Option | Description |
|--------|-------------|
| `<prompt>` | (Required) Text description prompt |
| `--negative <text>` | Negative prompt |
| `--output <dir>` | Output directory |
| `--workflow <name>` | Workflow name (default: want2v) |
| `--format <mp4\|gif>` | Output format (default: mp4) |
| `--fps <num>` | Frames per second |
| `--frames <num>` | Total frames |
| `--width <num>` | Video width |
| `--height <num>` | Video height |
| `--size <alias>` | Size preset alias (low/mid/high) |
| `--orientation <0\|1>` | Orientation: 0=landscape, 1=portrait (default: 0). Used with `--size`. |
| `--upload` | Upload to server (default: true) |
| `--no-upload` | Skip uploading |

> **Resolution priority:** `--width`/`--height` > `--size` > workflow default values.

### Example
```bash
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js txt2vid "a cat walking in a park" --format mp4 --fps 24
```

---

## Image to Video (img2vid)

### Command
```bash
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js img2vid <input> [options]
```

Generate videos from images.

> **URL Support:** Input can be a local file path or HTTP/HTTPS URL. URLs are automatically downloaded to `./tmp` directory.

### Options
| Option | Description |
|--------|-------------|
| `<input>` | (Required) Input image path or URL |
| `--prompt <text>` | Text prompt |
| `--negative <text>` | Negative prompt |
| `--output <dir>` | Output directory |
| `--workflow <name>` | Workflow name (default: wani2v) |
| `--format <mp4\|gif>` | Output format (default: mp4) |
| `--fps <num>` | Frames per second |
| `--frames <num>` | Total frames |
| `--motion <num>` | Motion bucket strength (1-255) |
| `--width <num>` | Video width |
| `--height <num>` | Video height |
| `--size <alias>` | Size preset alias (low/mid/high) |
| `--orientation <0\|1>` | Orientation: 0=landscape, 1=portrait (default: 0). Used with `--size`. |
| `--upload` | Upload to server (default: true) |
| `--no-upload` | Skip uploading |

> **Resolution priority:** `--width`/`--height` > `--size` > workflow default values.

### Example
```bash
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js img2vid ./portrait.jpg --prompt "gentle movement" --frames 60
```

---

## 2 Image to Video (2img2vid)

### Command
```bash
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js 2img2vid <image1> <image2> [options]
```

Generate video from two images (first frame + last frame transition).

### Options
| Option | Description |
|--------|-------------|
| `<image1>` | (Required) First frame image path |
| `<image2>` | (Required) Last frame image path |
| `-p, --prompt <text>` | Text prompt for video generation |
| `-n, --negative <text>` | Negative prompt text |
| `-o, --output <dir>` | Output directory (default: ./output) |
| `-w, --workflow <name>` | Workflow name (default: ltx2img2vid) |
| `-f, --format <mp4\|gif>` | Output format (default: mp4) |
| `--fps <number>` | Frame rate |
| `--frames <number>` | Total frames |
| `--seed <number>` | Random seed (default: random) |
| `--width <number>` | Video width |
| `--height <number>` | Video height |
| `-S, --size <alias>` | Size preset alias |
| `--orientation <0\|1>` | Orientation (default: 0) |
| `--upload` | Upload to server (default: true) |
| `--no-upload` | Skip uploading |

### Examples
```bash
# Basic usage
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js 2img2vid ./input/first_frame.png ./input/last_frame.png -p "smooth transition"

# Custom settings
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js 2img2vid img1.png img2.png --fps 24 --frames 60 --format mp4
```
