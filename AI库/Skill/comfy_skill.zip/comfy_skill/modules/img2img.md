# Image to Image (img2img)

## Command

```bash
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js img2img <input> "<prompt>" [options]
```

Transform existing images with text guidance. Supports single or multiple image inputs.

> **URL Support:** Input can be a local file path or HTTP/HTTPS URL. URLs are automatically downloaded to `./tmp` directory before processing.

## Input Formats

### Single Image
```bash
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js img2img <image_path> "<prompt>"
```

### Multiple Images (2-4)
Supports processing 2-4 images simultaneously with automatic workflow matching.

1. **Comma-separated paths** (recommended):
```bash
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js img2img "photo1.jpg,photo2.jpg,photo3.jpg" "prompt"
```

2. **Using --images option**:
```bash
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js img2img photo1.jpg "prompt" --images photo2.jpg --images photo3.jpg
```

3. **Backward compatible single image**:
```bash
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js img2img photo.jpg "prompt"
```

## Automatic Workflow Matching

| Image Count | Default Workflow | Type | Description |
|-------------|------------------|------|-------------|
| 1 | qwen2511i2i | img2img | Single image input |
| 2 | qwen2511i2i2 | 2img2img | Dual image input |
| 3 | qwen2511i2i3 | 3img2img | Triple image input |
| 4 | qwen2511i2i4 | 4img2img | Quad image input |

## Options

| Option | Description |
|--------|-------------|
| `<input>` | (Required) Input image path or URL |
| `<prompt>` | (Required) Text prompt |
| `--negative <text>` | Negative prompt |
| `--output <dir>` | Output directory |
| `--workflow <name>` | Workflow name (auto-selected based on image count if not specified) |
| `--strength <num>` | Denoise strength (0-1) |
| `--steps <num>` | Sampling steps |
| `--cfg <num>` | CFG scale |
| `--seed <num>` | Random seed |
| `--images <path>` | Additional image paths (can be used multiple times) |
| `--width <num>` | Image width |
| `--height <num>` | Image height |
| `--size <alias>` | Size preset alias (low/mid/high) |
| `--orientation <0\|1>` | Orientation: 0=landscape, 1=portrait (default: 0). Used with `--size`. |
| `--upload` | Upload to server (default: true) |
| `--no-upload` | Skip uploading |

> **Resolution priority:** `--width`/`--height` > `--size` > workflow default values.

## Examples

```bash
# Single image transform
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js img2img ./photo.jpg "oil painting style" --strength 0.8

# Dual image merge
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js img2img "photo1.jpg,photo2.jpg" "merge these images into a fantasy landscape"

# Triple image combine
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js img2img "img1.png,img2.png,img3.png" "combine elements from all images"

# Quad image collage
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js img2img photo1.jpg "create a collage style artwork" --images photo2.jpg --images photo3.jpg --images photo4.jpg

# Custom workflow
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js img2img "portrait.jpg,landscape.jpg" "artistic blend" --workflow custom_i2i2
```
