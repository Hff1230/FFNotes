# Image Scale / Super-Resolution (imagescale)

## Command

```bash
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js imagescale <image> [options]
```

Upscale image resolution using AI-powered super-resolution models. Supports common image formats (PNG, JPG, JPEG, WebP).

> **URL Support:** Input can be a local file path or HTTP/HTTPS URL. URLs are automatically downloaded to `./tmp` directory before processing.

## Options

| Option | Description |
|--------|-------------|
| `<image>` | (Required) Input image path or URL |
| `--size <alias>` | Resolution preset alias (2k/4k/8k). Determines the target output resolution. |
| `--orientation <0\|1>` | Orientation: 0=landscape, 1=portrait (default: 0). Used together with `--size`. |
| `--width <number>` | Custom target width (overrides preset) |
| `--height <number>` | Custom target height (overrides preset) |
| `--output <dir>` | Output directory (default: ./output) |
| `--config <path>` | Path to configuration file |
| `--workflow <name>` | Workflow name (default: zimageupscale) |
| `--seed <number>` | Random seed (default: random) |
| `--upload` | Upload to server (default: true) |
| `--no-upload` | Skip uploading |

> **Resolution priority:** `--width`/`--height` > `--size` > default preset (2k landscape).

## Examples

```bash
# Upscale to 2K
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js imagescale photo.jpg --size 2k

# Upscale to 4K portrait
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js imagescale photo.jpg --size 4k --orientation 1

# Custom dimensions
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js imagescale photo.jpg --width 3840 --height 2160

# 8K with specific seed
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js imagescale photo.jpg --size 8k --seed 12345
```
