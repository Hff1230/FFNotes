# Workflows & Configuration

## Available Workflows

### Text to Image Workflows
| Workflow | Description |
|----------|-------------|
| zimageturbot2i | Default text-to-image generation |

### Image to Image Workflows
| Workflow | Type | Description |
|----------|------|-------------|
| qwen2511i2i | img2img | Single image transformation |
| qwen2511i2i2 | 2img2img | Dual image processing |
| qwen2511i2i3 | 3img2img | Triple image processing |
| qwen2511i2i4 | 4img2img | Quad image processing |

### Video Workflows
| Workflow | Type | Description |
|----------|------|-------------|
| want2v | txt2video | Text-to-video generation |
| wani2v | img2video | Image-to-video animation |
| ltx2img2vid | 2img2video | Two-image to video (first + last frame transition) |

### Image Angle Generation Workflows
| Workflow | Type | Description |
|----------|------|-------------|
| qwen2511angle | img2img | Generate images from specified camera angles based on an input image |

### Image Scale Workflows
| Workflow | Description |
|----------|-------------|
| zimageupscale | AI-powered image super-resolution upscaling (default) |

> **Note:** The img2img command automatically selects the appropriate workflow based on the number of input images. You can override this by explicitly specifying `--workflow`.

## Configuration

The skill uses `config/comfy_config.json` for workflow definitions. New workflows can be added by updating this file.

### Upload Configuration

The `upload` section in `comfy_config.json` configures automatic file uploading to a dufs server:

```json
{
  "upload": {
    "server": "192.168.0.92:9998",
    "user": "admin",
    "pwd": "password",
    "dir": "comfy",
    "share_url": "http://47.109.205.195:10020"
  }
}
```

| Field | Description |
|-------|-------------|
| `server` | dufs server address (LAN IP:port) |
| `user` | Username for authentication |
| `pwd` | Password for authentication |
| `dir` | Base directory on server (e.g., "comfy") |
| `share_url` | Public URL for sharing (replaces LAN address in output) |

Files are uploaded to: `{dir}/{YYYY-M-D}/` (e.g., `comfy/2026-3-30/`)

When `share_url` is configured, output links use the share URL instead of the LAN address.

## Run Custom Workflow

```bash
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js run <workflow> --prompt <text> [options]
```

Run any configured workflow by name.
