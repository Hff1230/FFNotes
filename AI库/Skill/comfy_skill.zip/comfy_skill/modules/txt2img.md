# Text to Image (txt2img)

## Command

```bash
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js txt2img "<prompt>" [options]
```

Generate images from text descriptions.

## Options

| Option | Description |
|--------|-------------|
| `<prompt>` | (Required) Text description prompt |
| `--negative <text>` | Negative prompt |
| `--output <dir>` | Output directory (default: ./output) |
| `--workflow <name>` | Workflow name (default: zimageturbot2i) |
| `--steps <num>` | Sampling steps |
| `--cfg <num>` | CFG scale |
| `--seed <num>` | Random seed |
| `--width <num>` | Image width |
| `--height <num>` | Image height |
| `--size <alias>` | Size preset alias (low/mid/high) |
| `--orientation <0\|1>` | Orientation: 0=landscape, 1=portrait (default: 0). Used with `--size`. |
| `--upload` | Upload to server (default: true) |
| `--no-upload` | Skip uploading |
| `--project <name>` | Project name for organized output |
| `--category <type>` | Resource category (characters/scenes/props/videos/upscale) |
| `--name <name>` | Resource name for filename |

> **Resolution priority:** `--width`/`--height` > `--size` > workflow default values.

## Project-Based Output Organization

When using `--project` and `--category` options, output files are organized in a structured directory:

**Directory Structure:**
```
output/
└── {project}/
    └── resources/
        └── {category}/
            └── {filename}.png
```

**File Naming Rules:**
| Parameters | Filename Format | Example |
|------------|-----------------|---------|
| `--project` + `--category` + `--name` | `{name}.png` | `C01_武松_正面全身.png` |
| `--project` + `--category` (no `--name`) | `{project}_{category}_{timestamp}.png` | `wusong_scenes_20260401_112440.png` |

## Examples

```bash
# Basic generation
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js txt2img "a beautiful sunset over mountains" --output ./my_images

# No upload
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js txt2img "a beautiful sunset" --no-upload

# Size preset
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js txt2img "a beautiful sunset" --size mid

# High resolution portrait
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js txt2img "a sunset" --size high --orientation 1

# Project output with custom filename
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js txt2img "a warrior" --project wusong --category characters --name C01_武松_正面全身

# Project output with auto-generated filename
export COMFY_PROJECT_ROOT=$(pwd) && cd scripts/comfycli && node src/index.js txt2img "a mountain scene" --project wusong --category scenes
```
