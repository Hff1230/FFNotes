/**
 * TEST-006: Batch Angle Generation E2E Test
 * Validates batch JSON format and batch execution for angle groups
 */
import { jest, describe, test, expect, beforeAll } from '@jest/globals';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import ConfigManager from '../../src/utils/config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECT_ROOT = path.resolve(__dirname, '../../');
const CONFIG_PATH = path.join(PROJECT_ROOT, 'config', 'comfy_config.json');
const FIXTURES_DIR = path.join(PROJECT_ROOT, 'tests', 'fixtures');

// hc group batch JSON - 8 viewpoints
const HC_BATCH_JSON = [
  { type: 'img2img', image: './test_angle_input.jpg', prompt: '<sks> front view high-angle shot close-up', workflow: 'qwen2511angle', seed: 100, output: './output/angle_hc' },
  { type: 'img2img', image: './test_angle_input.jpg', prompt: '<sks> front-right quarter view high-angle shot close-up', workflow: 'qwen2511angle', seed: 101, output: './output/angle_hc' },
  { type: 'img2img', image: './test_angle_input.jpg', prompt: '<sks> right side view high-angle shot close-up', workflow: 'qwen2511angle', seed: 102, output: './output/angle_hc' },
  { type: 'img2img', image: './test_angle_input.jpg', prompt: '<sks> back-right quarter view high-angle shot close-up', workflow: 'qwen2511angle', seed: 103, output: './output/angle_hc' },
  { type: 'img2img', image: './test_angle_input.jpg', prompt: '<sks> back view high-angle shot close-up', workflow: 'qwen2511angle', seed: 104, output: './output/angle_hc' },
  { type: 'img2img', image: './test_angle_input.jpg', prompt: '<sks> back-left quarter view high-angle shot close-up', workflow: 'qwen2511angle', seed: 105, output: './output/angle_hc' },
  { type: 'img2img', image: './test_angle_input.jpg', prompt: '<sks> left side view high-angle shot close-up', workflow: 'qwen2511angle', seed: 106, output: './output/angle_hc' },
  { type: 'img2img', image: './test_angle_input.jpg', prompt: '<sks> front-left quarter view high-angle shot close-up', workflow: 'qwen2511angle', seed: 107, output: './output/angle_hc' }
];

let cm;

beforeAll(() => {
  cm = new ConfigManager(CONFIG_PATH);
  cm.load();

  // Create fixtures directory if needed
  if (!fs.existsSync(FIXTURES_DIR)) {
    fs.mkdirSync(FIXTURES_DIR, { recursive: true });
  }

  // Write batch JSON fixture
  fs.writeFileSync(
    path.join(FIXTURES_DIR, 'batch_hc.json'),
    JSON.stringify(HC_BATCH_JSON, null, 2),
    'utf-8'
  );
});

describe('TEST-006: Batch Angle Generation E2E', () => {
  test('TC-406-01: hc group batch JSON format is valid', () => {
    const batchPath = path.join(FIXTURES_DIR, 'batch_hc.json');
    const content = fs.readFileSync(batchPath, 'utf-8');
    expect(() => JSON.parse(content)).not.toThrow();
  });

  test('TC-406-02: hc group contains 8 img2img tasks', () => {
    const batchPath = path.join(FIXTURES_DIR, 'batch_hc.json');
    const tasks = JSON.parse(fs.readFileSync(batchPath, 'utf-8'));
    expect(tasks.length).toBe(8);
    tasks.forEach(task => {
      expect(task.type).toBe('img2img');
    });
  });

  test('TC-406-03: All tasks use qwen2511angle workflow', () => {
    const batchPath = path.join(FIXTURES_DIR, 'batch_hc.json');
    const tasks = JSON.parse(fs.readFileSync(batchPath, 'utf-8'));
    tasks.forEach(task => {
      expect(task.workflow).toBe('qwen2511angle');
    });
  });

  test('TC-406-04: 8 tasks use different viewpoints (no duplicates)', () => {
    const batchPath = path.join(FIXTURES_DIR, 'batch_hc.json');
    const tasks = JSON.parse(fs.readFileSync(batchPath, 'utf-8'));
    const prompts = tasks.map(t => t.prompt);
    const uniquePrompts = new Set(prompts);
    expect(uniquePrompts.size).toBe(8);
  });

  test('TC-406-05: batch JSON can be validated by ConfigManager', () => {
    // Verify the workflow referenced in batch exists in config
    const wf = cm.getWorkflow('qwen2511angle');
    expect(wf).not.toBeNull();
    expect(wf.type).toBe('img2img');
  });

  test('TC-406-06: batch tasks have sequential seeds', () => {
    const batchPath = path.join(FIXTURES_DIR, 'batch_hc.json');
    const tasks = JSON.parse(fs.readFileSync(batchPath, 'utf-8'));
    const seeds = tasks.map(t => t.seed);
    for (let i = 0; i < seeds.length - 1; i++) {
      expect(seeds[i + 1]).toBe(seeds[i] + 1);
    }
  });

  test('TC-406-07: batch JSON file was created successfully', () => {
    const batchPath = path.join(FIXTURES_DIR, 'batch_hc.json');
    expect(fs.existsSync(batchPath)).toBe(true);
    const stat = fs.statSync(batchPath);
    expect(stat.size).toBeGreaterThan(0);
  });
});
