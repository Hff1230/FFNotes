/**
 * TEST-005: img2img Angle Generation End-to-End Test
 * E2E validation of using img2img + qwen2511angle workflow
 *
 * NOTE: Tests requiring ComfyUI server will be skipped if server is unavailable.
 */
import { jest, describe, test, expect, beforeAll } from '@jest/globals';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import ConfigManager from '../../src/utils/config.js';
import { replaceVariables, mergeWorkflowParams } from '../../src/core/workflow.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECT_ROOT = path.resolve(__dirname, '../../');
const CONFIG_PATH = path.join(PROJECT_ROOT, 'config', 'comfy_config.json');

let cm;
let angleConfig;
let workflowApi;
let serverAvailable = false;

// Test prompts from different angle groups
const TEST_PROMPTS = {
  hc_front: '<sks> front view high-angle shot close-up',
  lw_back: '<sks> back view low-angle shot wide shot',
  nm_right: '<sks> right side view eye-level shot medium shot'
};

beforeAll(async () => {
  cm = new ConfigManager(CONFIG_PATH);
  cm.load();
  angleConfig = cm.getWorkflow('qwen2511angle');

  // Load the API workflow file
  const apiPath = path.resolve(path.dirname(CONFIG_PATH), angleConfig.api);
  workflowApi = JSON.parse(fs.readFileSync(apiPath, 'utf-8'));

  // Check server availability
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3000);
    const resp = await fetch(`http://${cm.getServerConfig().host}:${cm.getServerConfig().port}/system_stats`, {
      signal: controller.signal
    });
    clearTimeout(timeout);
    serverAvailable = resp.ok;
  } catch {
    serverAvailable = false;
  }
});

describe('TEST-005: img2img Angle Generation E2E', () => {
  test('TC-405-01: hc group front view prompt generates valid workflow params', () => {
    const values = {
      active_prompt: TEST_PROMPTS.hc_front,
      sample_image: 'test_angle_input.jpg',
      width: '1328',
      height: '768'
    };

    const result = replaceVariables(workflowApi, angleConfig.data, values);
    expect(result['111'].inputs.prompt).toContain('<sks> front view high-angle shot close-up');
    expect(result['78'].inputs.image).toBe('test_angle_input.jpg');
    expect(result['112'].inputs.width).toBe('1328');
    expect(result['112'].inputs.height).toBe('768');
  });

  test('TC-405-02: lw group back view prompt generates valid workflow params', () => {
    const values = {
      active_prompt: TEST_PROMPTS.lw_back,
      sample_image: 'test_angle_input.jpg',
      width: '1328',
      height: '768'
    };

    const result = replaceVariables(workflowApi, angleConfig.data, values);
    expect(result['111'].inputs.prompt).toContain('<sks> back view low-angle shot wide shot');
    expect(result['78'].inputs.image).toBe('test_angle_input.jpg');
  });

  test('TC-405-03: nm group right side view prompt generates valid workflow params', () => {
    const values = {
      active_prompt: TEST_PROMPTS.nm_right,
      sample_image: 'test_angle_input.jpg',
      width: '1328',
      height: '768'
    };

    const result = replaceVariables(workflowApi, angleConfig.data, values);
    expect(result['111'].inputs.prompt).toContain('<sks> right side view eye-level shot medium shot');
    expect(result['78'].inputs.image).toBe('test_angle_input.jpg');
  });

  test('TC-405-04: Full <sks> format prompt is preserved in node 111', () => {
    const values = {
      active_prompt: '<sks> front view high-angle shot close-up',
      sample_image: 'test.jpg',
      width: '1328',
      height: '768'
    };

    const result = replaceVariables(workflowApi, angleConfig.data, values);
    expect(result['111'].inputs.prompt).toMatch(/^<sks> front view high-angle shot close-up/);
  });

  test('TC-405-05: Specified seed is correctly applied via mergeWorkflowParams', () => {
    const seed = 42;
    const result = mergeWorkflowParams(workflowApi, { seed });
    expect(result['3'].inputs.seed).toBe(seed);
  });
});
