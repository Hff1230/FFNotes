/**
 * E2E Tests: Regression - Existing commands still work after batch addition
 *
 * Ensures that adding the batch command did not break any previously
 * existing CLI commands. Uses child_process to spawn actual Node.js
 * processes for testing.
 *
 * Test Cases:
 * - TC-401-04: txt2img --help shows help
 * - TC-401-05: img2img --help shows help
 * - TC-401-06: txt2vid --help shows help
 * - TC-401-07: img2vid --help shows help
 * - TC-401-08: imagescale --help shows help
 * - TC-401-09: txt2img (no args) exits with non-zero code
 * - TC-401-10: img2img (no args) exits with non-zero code
 * - TC-401-11: imagescale (no args) exits with non-zero code
 * - TC-401-12: list command works
 * - TC-401-13: validate command works
 */
import { describe, it, expect } from '@jest/globals';
import { execSync } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CLI_PATH = path.resolve(__dirname, '../../src/index.js');
const PROJECT_ROOT = path.resolve(__dirname, '../../');

/**
 * Run the CLI as a child process and return stdout.
 * Throws on non-zero exit code.
 */
function runCLI(args, options = {}) {
  const cmd = `node "${CLI_PATH}" ${args}`;
  return execSync(cmd, {
    cwd: PROJECT_ROOT,
    encoding: 'utf-8',
    timeout: 10000,
    ...options,
  });
}

/**
 * Run the CLI expecting it to fail. Returns the caught error object.
 */
function runCLIExpectFailure(args) {
  let error;
  try {
    runCLI(args);
  } catch (e) {
    error = e;
  }
  return error;
}

// ============================================================
// TC-401-04 through TC-401-08: --help for each command
// ============================================================
describe('TC-401-04 - txt2img --help', () => {
  it('should output help text containing command description and options', () => {
    const output = runCLI('txt2img --help');
    expect(output).toContain('Generate image from text prompt');
    expect(output).toMatch(/--negative/);
    expect(output).toMatch(/--output/);
    expect(output).toMatch(/--workflow/);
  });
});

describe('TC-401-05 - img2img --help', () => {
  it('should output help text containing command description and options', () => {
    const output = runCLI('img2img --help');
    expect(output).toContain('Transform image using text prompt');
    expect(output).toMatch(/--negative/);
    expect(output).toMatch(/--output/);
  });
});

describe('TC-401-06 - txt2vid --help', () => {
  it('should output help text containing command description and options', () => {
    const output = runCLI('txt2vid --help');
    expect(output).toContain('Generate video from text prompt');
    expect(output).toMatch(/--output/);
    expect(output).toMatch(/--format/);
  });
});

describe('TC-401-07 - img2vid --help', () => {
  it('should output help text containing command description and options', () => {
    const output = runCLI('img2vid --help');
    expect(output).toContain('Generate video from image');
    expect(output).toMatch(/--output/);
    expect(output).toMatch(/--workflow/);
  });
});

describe('TC-401-08 - imagescale --help', () => {
  it('should output help text containing command description and options', () => {
    const output = runCLI('imagescale --help');
    expect(output).toContain('Upscale image resolution');
    expect(output).toMatch(/--output/);
    expect(output).toMatch(/--workflow/);
  });
});

// ============================================================
// TC-401-09 through TC-401-11: missing required arguments
// ============================================================
describe('TC-401-09 - txt2img without arguments', () => {
  it('should exit with non-zero code indicating missing required argument', () => {
    const error = runCLIExpectFailure('txt2img');
    expect(error).toBeDefined();
    expect(error.status).not.toBe(0);
  });
});

describe('TC-401-10 - img2img without arguments', () => {
  it('should exit with non-zero code indicating missing required argument', () => {
    const error = runCLIExpectFailure('img2img');
    expect(error).toBeDefined();
    expect(error.status).not.toBe(0);
  });
});

describe('TC-401-11 - imagescale without arguments', () => {
  it('should exit with non-zero code indicating missing required argument', () => {
    const error = runCLIExpectFailure('imagescale');
    expect(error).toBeDefined();
    expect(error.status).not.toBe(0);
  });
});

// ============================================================
// TC-401-12: list command
// ============================================================
describe('TC-401-12 - list command', () => {
  it('should run the list command and output workflow information', () => {
    const output = runCLI('list');
    // list command reads the default config and outputs Available Workflows header
    expect(output).toMatch(/Available Workflows|No workflows found/);
  });
});

// ============================================================
// TC-401-13: validate command
// ============================================================
describe('TC-401-13 - validate command', () => {
  it('should run the validate command and report configuration validity', () => {
    let output;
    let error;
    try {
      output = runCLI('validate');
    } catch (e) {
      // validate calls process.exit(1) on failure which causes execSync to throw
      error = e;
      output = (e.stdout || '') + (e.stderr || '');
    }
    // Either valid or invalid - both are acceptable for a regression test.
    // We just verify the command ran and produced output about validation.
    expect(output).toMatch(/valid|Configuration|failed/i);
  });
});
