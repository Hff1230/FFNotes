/**
 * E2E Tests: Batch CLI Command
 *
 * Tests the batch command registration and CLI invocation using
 * child_process to spawn actual Node.js processes (avoids ESM mocking issues).
 *
 * Test Cases:
 * - TC-401-01: batch --help outputs correct help info (3 sub-tests)
 * - TC-401-02: batch with no arguments shows error
 * - TC-401-03: batch <file> --dry-run with valid JSON file executes dry run
 */
import { describe, it, expect, afterEach } from '@jest/globals';
import { execSync } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import os from 'os';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CLI_PATH = path.resolve(__dirname, '../../src/index.js');
const PROJECT_ROOT = path.resolve(__dirname, '../../');

/**
 * Run the CLI as a child process and return stdout.
 * Throws on non-zero exit code (catch in tests that expect failure).
 */
function runCLI(args, options = {}) {
  const cmd = `node "${CLI_PATH}" ${args}`;
  return execSync(cmd, {
    cwd: PROJECT_ROOT,
    encoding: 'utf-8',
    timeout: 10000,
    ...options,
  });
}

// Track temp files for cleanup
const tmpFiles = [];

afterEach(() => {
  for (const f of tmpFiles) {
    try { fs.unlinkSync(f); } catch { /* ignore */ }
  }
  tmpFiles.length = 0;
});

// ============================================================
// TC-401-01: batch --help outputs correct help info
// ============================================================
describe('TC-401-01 - batch --help', () => {
  it('should output description mentioning JSON file execution', () => {
    const output = runCLI('batch --help');
    expect(output).toContain('Execute multiple commands from a JSON file');
  });

  it('should list --continue-on-error, --dry-run, --restart, and --clean options', () => {
    const output = runCLI('batch --help');
    expect(output).toContain('--continue-on-error');
    expect(output).toContain('--dry-run');
    expect(output).toContain('--restart');
    expect(output).toContain('--clean');
  });

  it('should show <file> as a required argument', () => {
    const output = runCLI('batch --help');
    expect(output).toMatch(/<file>/);
  });
});

// ============================================================
// TC-401-02: batch with no arguments shows error
// ============================================================
describe('TC-401-02 - batch without arguments', () => {
  it('should exit with non-zero code and show an error about missing file argument', () => {
    let error;
    try {
      runCLI('batch');
    } catch (e) {
      error = e;
    }
    expect(error).toBeDefined();
    expect(error.status).not.toBe(0);
    const combined = (error.stderr || '') + (error.stdout || '');
    expect(combined).toMatch(/error/i);
  });
});

// ============================================================
// TC-401-03: batch <file> --dry-run with valid JSON file
// ============================================================
describe('TC-401-03 - batch <file> --dry-run', () => {
  it('should validate a valid JSON tasks file and report dry run success', () => {
    const tmpFile = path.join(os.tmpdir(), 'batch-test-dryrun-' + Date.now() + '.json');
    const tasks = [
      { type: 'txt2img', prompt: 'a test prompt for dry run' },
      { type: 'imagescale', image: '/tmp/test.png' },
    ];
    fs.writeFileSync(tmpFile, JSON.stringify(tasks, null, 2));
    tmpFiles.push(tmpFile);

    const output = runCLI(`batch "${tmpFile}" --dry-run`);
    expect(output).toContain('Dry run');
    expect(output).toContain('validation passed');
    expect(output).toContain('2 tasks');
  });

  it('should list each task type in dry-run output', () => {
    const tmpFile = path.join(os.tmpdir(), 'batch-test-dryrun-list-' + Date.now() + '.json');
    const tasks = [
      { type: 'txt2img', prompt: 'first task' },
      { type: 'img2img', image: 'a.png', prompt: 'second task' },
      { type: 'txt2vid', prompt: 'third task' },
    ];
    fs.writeFileSync(tmpFile, JSON.stringify(tasks, null, 2));
    tmpFiles.push(tmpFile);

    const output = runCLI(`batch "${tmpFile}" --dry-run`);
    expect(output).toContain('txt2img');
    expect(output).toContain('img2img');
    expect(output).toContain('txt2vid');
  });

  it('should report task count for a single-task file', () => {
    const tmpFile = path.join(os.tmpdir(), 'batch-test-dryrun-single-' + Date.now() + '.json');
    const tasks = [{ type: 'txt2img', prompt: 'solo task' }];
    fs.writeFileSync(tmpFile, JSON.stringify(tasks, null, 2));
    tmpFiles.push(tmpFile);

    const output = runCLI(`batch "${tmpFile}" --dry-run`);
    expect(output).toContain('1 tasks');
    expect(output).toContain('txt2img');
  });

  it('should report task count for an empty tasks array', () => {
    const tmpFile = path.join(os.tmpdir(), 'batch-test-dryrun-empty-' + Date.now() + '.json');
    fs.writeFileSync(tmpFile, JSON.stringify([], null, 2));
    tmpFiles.push(tmpFile);

    const output = runCLI(`batch "${tmpFile}" --dry-run`);
    expect(output).toContain('0 tasks');
  });

  it('should fail with non-zero exit for an invalid (non-array) JSON file', () => {
    const tmpFile = path.join(os.tmpdir(), 'batch-test-dryrun-invalid-' + Date.now() + '.json');
    fs.writeFileSync(tmpFile, JSON.stringify({ not: 'an array' }));
    tmpFiles.push(tmpFile);

    let error;
    try {
      runCLI(`batch "${tmpFile}" --dry-run`);
    } catch (e) {
      error = e;
    }
    expect(error).toBeDefined();
    expect(error.status).not.toBe(0);
    const combined = (error.stderr || '') + (error.stdout || '');
    expect(combined).toMatch(/error|invalid|array/i);
  });

  it('should fail for a JSON file with unsupported task type', () => {
    const tmpFile = path.join(os.tmpdir(), 'batch-test-dryrun-badtype-' + Date.now() + '.json');
    const tasks = [{ type: 'nonexistent', prompt: 'bad type' }];
    fs.writeFileSync(tmpFile, JSON.stringify(tasks, null, 2));
    tmpFiles.push(tmpFile);

    let error;
    try {
      runCLI(`batch "${tmpFile}" --dry-run`);
    } catch (e) {
      error = e;
    }
    expect(error).toBeDefined();
    expect(error.status).not.toBe(0);
    const combined = (error.stderr || '') + (error.stdout || '');
    expect(combined).toMatch(/error|unsupported|invalid/i);
  });

  it('should fail for a non-existent file path', () => {
    const fakePath = path.join(os.tmpdir(), 'batch-test-no-such-file-' + Date.now() + '.json');

    let error;
    try {
      runCLI(`batch "${fakePath}" --dry-run`);
    } catch (e) {
      error = e;
    }
    expect(error).toBeDefined();
    expect(error.status).not.toBe(0);
    const combined = (error.stderr || '') + (error.stdout || '');
    expect(combined).toMatch(/not found|error/i);
  });
});
