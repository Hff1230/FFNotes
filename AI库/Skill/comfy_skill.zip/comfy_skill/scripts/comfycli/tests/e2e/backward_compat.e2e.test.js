/**
 * E2E Tests: Backward Compatibility
 *
 * Ensures that URL download feature doesn't break existing local file workflows.
 * All inputs are local paths - no downloads should occur.
 *
 * Test Cases:
 * - C001: img2img with local path (P0)
 * - C002: img2vid with local path (P0)
 * - C003: imagescale with local path (P0)
 * - C004: Multiple local images in img2img (P0)
 */
import { describe, it, expect, beforeEach, afterEach, jest } from '@jest/globals';
import fs from 'fs';
import path from 'path';
import sinon from 'sinon';

// Store original fetch for restoration
const originalFetch = global.fetch;

// Test constants
const TEST_TMP_DIR = './tests/fixtures/tmp-bc-test';
const TEST_LOCAL_DIR = './tests/fixtures/local-bc-images';

// ============================================================
// Test Helpers
// ============================================================

/**
 * Create mock PNG image data
 */
function createMockPngData() {
  return Buffer.from([
    0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, // PNG signature
    0x00, 0x00, 0x00, 0x0D, // IHDR length
    0x49, 0x48, 0x44, 0x52, // IHDR
    0x00, 0x00, 0x00, 0x01, // width: 1
    0x00, 0x00, 0x00, 0x01, // height: 1
    0x08, 0x02, // bit depth, color type
    0x00, 0x00, 0x00, // compression, filter, interlace
    0x90, 0x77, 0x53, 0xDE, // CRC
    0x00, 0x00, 0x00, 0x00, // IEND length
    0x49, 0x45, 0x4E, 0x44, // IEND
    0xAE, 0x42, 0x60, 0x82  // CRC
  ]);
}

/**
 * Create mock JPEG image data
 */
function createMockJpegData() {
  return Buffer.from([
    0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46,
    0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01,
    0x00, 0x01, 0x00, 0x00, 0xFF, 0xD9
  ]);
}

/**
 * Cleanup directory helper
 */
function cleanupDir(dirPath) {
  if (fs.existsSync(dirPath)) {
    const files = fs.readdirSync(dirPath);
    for (const file of files) {
      const filePath = path.join(dirPath, file);
      if (fs.lstatSync(filePath).isDirectory()) {
        cleanupDir(filePath);
      } else {
        fs.unlinkSync(filePath);
      }
    }
    fs.rmdirSync(dirPath);
  }
}

/**
 * Create local test image file
 */
function createLocalTestImage(filename, data = createMockPngData()) {
  if (!fs.existsSync(TEST_LOCAL_DIR)) {
    fs.mkdirSync(TEST_LOCAL_DIR, { recursive: true });
  }
  const filePath = path.join(TEST_LOCAL_DIR, filename);
  fs.writeFileSync(filePath, data);
  return filePath;
}

/**
 * Check if ./tmp directory exists
 */
function tmpDirectoryExists() {
  return fs.existsSync('./tmp');
}

/**
 * Get files in ./tmp directory
 */
function getTmpFiles() {
  if (!fs.existsSync('./tmp')) {
    return [];
  }
  return fs.readdirSync('./tmp');
}

// ============================================================
// Test Setup / Teardown
// ============================================================
beforeEach(() => {
  // Ensure clean state
  cleanupDir(TEST_TMP_DIR);
  cleanupDir(TEST_LOCAL_DIR);

  // Create local test directory
  if (!fs.existsSync(TEST_LOCAL_DIR)) {
    fs.mkdirSync(TEST_LOCAL_DIR, { recursive: true });
  }

  // Ensure ./tmp doesn't exist before tests
  cleanupDir('./tmp');
});

afterEach(() => {
  // Cleanup after each test
  cleanupDir(TEST_TMP_DIR);
  cleanupDir(TEST_LOCAL_DIR);

  // Clean up ./tmp if created during tests (backward compat tests should NOT create this)
  cleanupDir('./tmp');

  // Restore original fetch
  global.fetch = originalFetch;
});

// ============================================================
// C001: img2img with local path (P0)
// ============================================================
describe('C001 - img2img with local path - no tmp directory creation', () => {
  it('should not trigger download for local path', async () => {
    const localImage = createLocalTestImage('photo.jpg', createMockJpegData());

    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    // Process local path
    const result = await ResourceDownloader.resolveInputResource(localImage);

    // Should return unchanged local path
    expect(result.localPath).toBe(localImage);
    expect(result.wasDownloaded).toBe(false);

    // ./tmp directory should NOT exist
    expect(tmpDirectoryExists()).toBe(false);
  });

  it('should not create ./tmp directory for relative path', async () => {
    const relativePath = './tests/fixtures/local-bc-images/test.png';
    createLocalTestImage('test.png');

    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    const result = await ResourceDownloader.resolveInputResource(relativePath);

    expect(result.localPath).toBe(relativePath);
    expect(result.wasDownloaded).toBe(false);

    // ./tmp should not exist
    expect(tmpDirectoryExists()).toBe(false);
  });

  it('should handle absolute Windows path without download', async () => {
    // This test is for Windows paths
    const winPath = 'C:\\Users\\test\\images\\photo.png';

    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    const result = await ResourceDownloader.resolveInputResource(winPath);

    expect(result.localPath).toBe(winPath);
    expect(result.wasDownloaded).toBe(false);

    // ./tmp should not exist
    expect(tmpDirectoryExists()).toBe(false);
  });

  it('should handle Unix absolute path without download', async () => {
    const unixPath = '/home/user/images/photo.png';

    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    const result = await ResourceDownloader.resolveInputResource(unixPath);

    expect(result.localPath).toBe(unixPath);
    expect(result.wasDownloaded).toBe(false);

    // ./tmp should not exist
    expect(tmpDirectoryExists()).toBe(false);
  });
});

// ============================================================
// C002: img2vid with local path (P0)
// ============================================================
describe('C002 - img2vid with local path - no tmp directory creation', () => {
  it('should not trigger download for local path', async () => {
    const localImage = createLocalTestImage('video-frame.png');

    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    const result = await ResourceDownloader.resolveInputResource(localImage);

    expect(result.localPath).toBe(localImage);
    expect(result.wasDownloaded).toBe(false);

    // ./tmp directory should NOT exist
    expect(tmpDirectoryExists()).toBe(false);
  });

  it('should not create ./tmp directory for various local image formats', async () => {
    const testImages = [
      'frame.png',
      'frame.jpg',
      'frame.jpeg',
      'frame.webp'
    ];

    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    for (const filename of testImages) {
      const localPath = createLocalTestImage(filename);
      const result = await ResourceDownloader.resolveInputResource(localPath);

      expect(result.localPath).toBe(localPath);
      expect(result.wasDownloaded).toBe(false);
    }

    // ./tmp should not exist after all operations
    expect(tmpDirectoryExists()).toBe(false);
  });
});

// ============================================================
// C003: imagescale with local path (P0)
// ============================================================
describe('C003 - imagescale with local path - no tmp directory creation', () => {
  it('should not trigger download for local path', async () => {
    const localImage = createLocalTestImage('upscale-source.jpg');

    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    const result = await ResourceDownloader.resolveInputResource(localImage);

    expect(result.localPath).toBe(localImage);
    expect(result.wasDownloaded).toBe(false);

    // ./tmp directory should NOT exist
    expect(tmpDirectoryExists()).toBe(false);
  });

  it('should not create ./tmp for different local path formats', async () => {
    const paths = [
      './tests/fixtures/local-bc-images/scale.png',
      './tests/fixtures/local-bc-images/scale.jpg'
    ];

    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    for (const relPath of paths) {
      createLocalTestImage(path.basename(relPath));
      const result = await ResourceDownloader.resolveInputResource(relPath);

      expect(result.localPath).toBe(relPath);
      expect(result.wasDownloaded).toBe(false);
    }

    // ./tmp should not exist
    expect(tmpDirectoryExists()).toBe(false);
  });
});

// ============================================================
// C004: Multiple local images in img2img (P0)
// ============================================================
describe('C004 - Multiple local images in img2img - no tmp directory creation', () => {
  it('should not trigger any downloads for multiple local paths', async () => {
    const localImages = [
      createLocalTestImage('multi1.jpg'),
      createLocalTestImage('multi2.jpg'),
      createLocalTestImage('multi3.jpg'),
      createLocalTestImage('multi4.jpg')
    ];

    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    const result = await ResourceDownloader.resolveInputResources(localImages);

    // All should be local paths, no downloads
    expect(result.localPaths).toHaveLength(4);
    expect(result.downloaded).toHaveLength(0);

    // All paths should be unchanged
    result.localPaths.forEach((localPath, index) => {
      expect(localPath).toBe(localImages[index]);
    });

    // ./tmp directory should NOT exist
    expect(tmpDirectoryExists()).toBe(false);
  });

  it('should handle 2 local images without creating tmp', async () => {
    const localImages = [
      createLocalTestImage('pair1.png'),
      createLocalTestImage('pair2.png')
    ];

    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    const result = await ResourceDownloader.resolveInputResources(localImages);

    expect(result.localPaths).toHaveLength(2);
    expect(result.downloaded).toHaveLength(0);

    // ./tmp should not exist
    expect(tmpDirectoryExists()).toBe(false);
  });

  it('should handle 3 local images without creating tmp', async () => {
    const localImages = [
      createLocalTestImage('triple1.jpg'),
      createLocalTestImage('triple2.jpg'),
      createLocalTestImage('triple3.jpg')
    ];

    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    const result = await ResourceDownloader.resolveInputResources(localImages);

    expect(result.localPaths).toHaveLength(3);
    expect(result.downloaded).toHaveLength(0);

    // ./tmp should not exist
    expect(tmpDirectoryExists()).toBe(false);
  });

  it('should preserve exact behavior with comma-separated local paths', async () => {
    // Simulate the parseInputImages behavior
    const input = './tests/fixtures/local-bc-images/a.jpg,./tests/fixtures/local-bc-images/b.jpg';
    const parsedPaths = input.split(',').map(p => p.trim());

    // Create the test files
    createLocalTestImage('a.jpg');
    createLocalTestImage('b.jpg');

    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    const result = await ResourceDownloader.resolveInputResources(parsedPaths);

    expect(result.localPaths).toHaveLength(2);
    expect(result.downloaded).toHaveLength(0);

    // ./tmp should not exist
    expect(tmpDirectoryExists()).toBe(false);
  });
});

// ============================================================
// Edge Cases: Mixed inputs (should trigger download for URLs)
// ============================================================
describe('Edge Cases - Mixed URL and local inputs', () => {
  /**
   * Create mock fetch response
   */
  function createMockResponse(data, status = 200) {
    return {
      ok: status >= 200 && status < 300,
      status,
      arrayBuffer: async () => {
        if (Buffer.isBuffer(data)) {
          return data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
        }
        return Buffer.from(data).buffer;
      }
    };
  }

  beforeEach(() => {
    // Setup mock fetch
    global.fetch = async (url) => {
      if (url === 'http://example.com/remote.jpg') {
        return createMockResponse(createMockJpegData());
      }
      return createMockResponse('Not Found', 404);
    };
  });

  afterEach(() => {
    global.fetch = originalFetch;
  });

  it('should only download URL inputs, keep local paths unchanged', async () => {
    const localImage = createLocalTestImage('local-only.jpg');
    const remoteUrl = 'http://example.com/remote.jpg';

    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    const result = await ResourceDownloader.resolveInputResources([localImage, remoteUrl]);

    expect(result.localPaths).toHaveLength(2);
    expect(result.downloaded).toHaveLength(1);

    // Local path should be unchanged
    expect(result.localPaths[0]).toBe(localImage);

    // Remote path should be downloaded (and tmp created)
    expect(result.downloaded[0]).toContain('remote.jpg');
    expect(fs.existsSync(result.downloaded[0])).toBe(true);

    // ./tmp should exist now (because we had a URL)
    expect(tmpDirectoryExists()).toBe(true);
  });
});

// ============================================================
// Validation: Behavior consistency checks
// ============================================================
describe('Behavior consistency - local paths work exactly as before URL feature', () => {
  it('should not call fetch for local paths', async () => {
    const localImage = createLocalTestImage('no-fetch-test.png');
    let fetchCalled = false;

    global.fetch = async () => {
      fetchCalled = true;
      return { ok: true, arrayBuffer: async () => Buffer.from('').buffer };
    };

    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    await ResourceDownloader.resolveInputResource(localImage);

    expect(fetchCalled).toBe(false);

    global.fetch = originalFetch;
  });

  it('should not modify local path strings in any way', async () => {
    const paths = [
      './relative/path.jpg',
      '../parent/dir.png',
      'simple.png',
      './nested/deep/path/to/image.webp'
    ];

    // Create all test files
    paths.forEach(p => {
      const filename = path.basename(p);
      createLocalTestImage(filename);
    });

    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    for (const testPath of paths) {
      const result = await ResourceDownloader.resolveInputResource(testPath);
      expect(result.localPath).toBe(testPath);
      expect(result.wasDownloaded).toBe(false);
    }
  });

  it('should handle empty string input gracefully', async () => {
    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    const result = await ResourceDownloader.resolveInputResource('');

    expect(result.localPath).toBe('');
    expect(result.wasDownloaded).toBe(false);
  });

  it('should handle null input gracefully', async () => {
    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    const result = await ResourceDownloader.resolveInputResource(null);

    expect(result.localPath).toBe(null);
    expect(result.wasDownloaded).toBe(false);
  });

  it('should handle undefined input gracefully', async () => {
    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    const result = await ResourceDownloader.resolveInputResource(undefined);

    expect(result.localPath).toBe(undefined);
    expect(result.wasDownloaded).toBe(false);
  });

  it('should handle empty array input', async () => {
    const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

    const result = await ResourceDownloader.resolveInputResources([]);

    expect(result.localPaths).toEqual([]);
    expect(result.downloaded).toEqual([]);
  });
});
