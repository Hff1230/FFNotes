/**
 * E2E Tests: URL Download Feature
 *
 * Tests complete CLI command flows with URL inputs.
 * All external dependencies (ComfyUI server, network) are mocked.
 *
 * Test Cases:
 * - E001: img2img with URL input (P0)
 * - E002: img2vid with URL input (P0)
 * - E003: imagescale with URL input (P0)
 * - E004: URL download failure handling (P0)
 */
import { describe, it, expect, beforeEach, afterEach, jest } from '@jest/globals';
import fs from 'fs';
import path from 'path';
import sinon from 'sinon';

// Store original fetch for restoration
const originalFetch = global.fetch;

// Test constants
const TEST_TMP_DIR = './tests/fixtures/tmp-e2e-url-test';
const TEST_LOCAL_DIR = './tests/fixtures/local-e2e-images';

// ============================================================
// Test Helpers
// ============================================================

/**
 * Create mock PNG image data
 */
function createMockPngData() {
  return Buffer.from([
    0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, // PNG signature
    0x00, 0x00, 0x00, 0x0D, // IHDR length
    0x49, 0x48, 0x44, 0x52, // IHDR
    0x00, 0x00, 0x00, 0x01, // width: 1
    0x00, 0x00, 0x00, 0x01, // height: 1
    0x08, 0x02, // bit depth, color type
    0x00, 0x00, 0x00, // compression, filter, interlace
    0x90, 0x77, 0x53, 0xDE, // CRC
    0x00, 0x00, 0x00, 0x00, // IEND length
    0x49, 0x45, 0x4E, 0x44, // IEND
    0xAE, 0x42, 0x60, 0x82  // CRC
  ]);
}

/**
 * Create mock JPEG image data
 */
function createMockJpegData() {
  return Buffer.from([
    0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46,
    0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01,
    0x00, 0x01, 0x00, 0x00, 0xFF, 0xD9
  ]);
}

/**
 * Create mock fetch response
 */
function createMockResponse(data, status = 200, statusText = 'OK') {
  return {
    ok: status >= 200 && status < 300,
    status,
    statusText,
    arrayBuffer: async () => {
      if (Buffer.isBuffer(data)) {
        return data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
      }
      return Buffer.from(data).buffer;
    }
  };
}

// Mock fetch responses map
let mockResponses = new Map();

/**
 * Setup mock fetch for a specific URL
 */
function setupMockFetch(url, response) {
  mockResponses.set(url, response);
  global.fetch = async (requestUrl) => {
    const response = mockResponses.get(requestUrl);
    if (response) return response;
    return createMockResponse('Not Found', 404, 'Not Found');
  };
}

/**
 * Setup multiple mock fetch responses
 */
function setupMultipleMockFetches(urlResponseMap) {
  for (const [url, response] of Object.entries(urlResponseMap)) {
    mockResponses.set(url, response);
  }
  global.fetch = async (requestUrl) => {
    const response = mockResponses.get(requestUrl);
    if (response) return response;
    return createMockResponse('Not Found', 404, 'Not Found');
  };
}

/**
 * Restore original fetch
 */
function restoreFetch() {
  global.fetch = originalFetch;
  mockResponses.clear();
}

/**
 * Cleanup directory helper
 */
function cleanupDir(dirPath) {
  if (fs.existsSync(dirPath)) {
    const files = fs.readdirSync(dirPath);
    for (const file of files) {
      const filePath = path.join(dirPath, file);
      if (fs.lstatSync(filePath).isDirectory()) {
        cleanupDir(filePath);
      } else {
        fs.unlinkSync(filePath);
      }
    }
    fs.rmdirSync(dirPath);
  }
}

/**
 * Create local test image file
 */
function createLocalTestImage(filename, data = createMockPngData()) {
  if (!fs.existsSync(TEST_LOCAL_DIR)) {
    fs.mkdirSync(TEST_LOCAL_DIR, { recursive: true });
  }
  const filePath = path.join(TEST_LOCAL_DIR, filename);
  fs.writeFileSync(filePath, data);
  return filePath;
}

/**
 * Create mock ComfyHelper for testing command execution
 */
function createMockComfyHelper() {
  return {
    connect: sinon.stub().resolves(),
    disconnect: sinon.stub().resolves(),
    uploadImage: sinon.stub().resolves({ name: 'uploaded_test_image.png' }),
    queuePrompt: sinon.stub().resolves({ prompt_id: 'test-prompt-123' }),
    getHistory: sinon.stub().resolves({
      'test-prompt-123': {
        outputs: {
          '2': {
            images: [
              { filename: 'output.png', subfolder: '', type: 'output' }
            ]
          }
        }
      }
    }),
    downloadOutput: sinon.stub().resolves(true),
    getVideo: sinon.stub().resolves(Buffer.from('mock video data'))
  };
}

/**
 * Create mock ConfigManager
 */
function createMockConfigManager() {
  return {
    load: sinon.stub().returns(true),
    getWorkflow: sinon.stub().returns({
      type: 'img2img',
      description: 'Test img2img workflow',
      api: './tests/fixtures/mock-api.json',
      data: []
    }),
    getServerConfig: sinon.stub().returns({
      host: '127.0.0.1',
      port: 8188,
      apiKey: ''
    }),
    getUploadConfig: sinon.stub().returns(null), // Disable upload by default
    loadApiFile: sinon.stub().returns({
      '1': { class_type: 'KSampler', inputs: { seed: 1 } },
      '2': { class_type: 'LoadImage', inputs: { image: '{{sample_image}}' } },
      '3': { class_type: 'SaveImage', inputs: {} }
    }),
    getDefaultWorkflowName: sinon.stub().returns('test-workflow'),
    listWorkflows: sinon.stub().returns([
      { name: 'test-workflow', type: 'img2img', description: 'Test' }
    ]),
    resolveResolution: sinon.stub().returns({ width: 512, height: 512 })
  };
}

// ============================================================
// E2E Tests
// ============================================================

describe('E2E: URL Download Feature', () => {
  beforeEach(() => {
    // Ensure clean state
    cleanupDir(TEST_TMP_DIR);
    cleanupDir(TEST_LOCAL_DIR);
    mockResponses.clear();

    // Create test directories
    if (!fs.existsSync(TEST_LOCAL_DIR)) {
      fs.mkdirSync(TEST_LOCAL_DIR, { recursive: true });
    }
  });

  afterEach(() => {
    // Cleanup after each test
    restoreFetch();
    cleanupDir(TEST_TMP_DIR);
    cleanupDir(TEST_LOCAL_DIR);

    // Clean up ./tmp directory that may be created by commands
    cleanupDir('./tmp');
  });

  // ============================================================
  // E001: img2img with URL input (P0)
  // ============================================================
  describe('E001 - img2img with URL input', () => {
    it('should download URL and process image successfully', async () => {
      const url = 'http://example.com/images/photo.jpg';
      const mockData = createMockJpegData();

      setupMockFetch(url, createMockResponse(mockData));

      // Import ResourceDownloader to test URL resolution
      const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

      // Test URL resolution (the core of URL download feature)
      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      // Verify download was successful
      expect(result.wasDownloaded).toBe(true);
      expect(result.localPath).toContain('photo.jpg');
      expect(fs.existsSync(result.localPath)).toBe(true);

      // Verify file content
      const downloadedData = fs.readFileSync(result.localPath);
      expect(downloadedData.equals(mockData)).toBe(true);
    });

    it('should handle multiple URL inputs for img2img', async () => {
      const urls = [
        'http://example.com/images/img1.jpg',
        'http://example.com/images/img2.png'
      ];
      const mockJpeg = createMockJpegData();
      const mockPng = createMockPngData();

      setupMultipleMockFetches({
        'http://example.com/images/img1.jpg': createMockResponse(mockJpeg),
        'http://example.com/images/img2.png': createMockResponse(mockPng)
      });

      const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

      // Test batch URL resolution
      const result = await ResourceDownloader.resolveInputResources(urls, TEST_TMP_DIR);

      // Verify all downloads were successful
      expect(result.localPaths).toHaveLength(2);
      expect(result.downloaded).toHaveLength(2);

      // Verify both files exist
      result.localPaths.forEach(localPath => {
        expect(fs.existsSync(localPath)).toBe(true);
      });
    });

    it('should handle mixed URL and local file inputs', async () => {
      const localFile = createLocalTestImage('local.png');
      const url = 'http://example.com/images/remote.jpg';

      setupMockFetch(url, createMockResponse(createMockJpegData()));

      const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

      const inputs = [localFile, url];
      const result = await ResourceDownloader.resolveInputResources(inputs, TEST_TMP_DIR);

      // Verify both paths are resolved
      expect(result.localPaths).toHaveLength(2);

      // Local file should not be downloaded
      expect(result.localPaths[0]).toBe(localFile);

      // URL should be downloaded
      expect(result.downloaded).toHaveLength(1);
      expect(fs.existsSync(result.localPaths[1])).toBe(true);
    });

    it('should correctly detect URL vs local path in img2img context', async () => {
      const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;
      const { isUrl } = ResourceDownloader;

      // URL inputs
      expect(isUrl('http://example.com/image.jpg')).toBe(true);
      expect(isUrl('https://example.com/image.png')).toBe(true);

      // Local path inputs
      expect(isUrl('./photo.jpg')).toBe(false);
      expect(isUrl('/absolute/path/photo.jpg')).toBe(false);
      expect(isUrl('C:\\Windows\\photo.jpg')).toBe(false);
      expect(isUrl('photo.jpg')).toBe(false);
    });
  });

  // ============================================================
  // E002: img2vid with URL input (P0)
  // ============================================================
  describe('E002 - img2vid with URL input', () => {
    it('should download URL and prepare image for video generation', async () => {
      const url = 'http://example.com/video-source/frame.png';
      const mockData = createMockPngData();

      setupMockFetch(url, createMockResponse(mockData));

      const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

      // Test URL resolution (simulates img2vid URL handling)
      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      // Verify download was successful
      expect(result.wasDownloaded).toBe(true);
      expect(result.localPath).toContain('frame.png');
      expect(fs.existsSync(result.localPath)).toBe(true);

      // Verify the downloaded file is a valid image
      const ext = path.extname(result.localPath).toLowerCase();
      expect(['.png', '.jpg', '.jpeg', '.webp']).toContain(ext);
    });

    it('should handle img2vid URL with various image formats', async () => {
      const testCases = [
        { url: 'http://example.com/test.png', format: 'png' },
        { url: 'http://example.com/test.jpg', format: 'jpg' },
        { url: 'http://example.com/test.webp', format: 'webp' }
      ];

      const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

      for (const { url, format } of testCases) {
        const mockData = format === 'png' ? createMockPngData() : createMockJpegData();
        setupMockFetch(url, createMockResponse(mockData));

        const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

        expect(result.wasDownloaded).toBe(true);
        expect(result.localPath).toContain(`.${format}`);
        expect(fs.existsSync(result.localPath)).toBe(true);
      }
    });
  });

  // ============================================================
  // E003: imagescale with URL input (P0)
  // ============================================================
  describe('E003 - imagescale with URL input', () => {
    it('should download URL and prepare image for upscaling', async () => {
      const url = 'http://example.com/upscale/low-res.png';
      const mockData = createMockPngData();

      setupMockFetch(url, createMockResponse(mockData));

      const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

      // Test URL resolution (simulates imagescale URL handling)
      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      // Verify download was successful
      expect(result.wasDownloaded).toBe(true);
      expect(result.localPath).toContain('low-res.png');
      expect(fs.existsSync(result.localPath)).toBe(true);

      // Verify file size (should have content)
      const stats = fs.statSync(result.localPath);
      expect(stats.size).toBeGreaterThan(0);
    });

    it('should handle imagescale URL with query parameters', async () => {
      const url = 'http://example.com/api/image?id=123&format=png';
      const mockData = createMockPngData();

      setupMockFetch(url, createMockResponse(mockData));

      const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
      expect(fs.existsSync(result.localPath)).toBe(true);
    });
  });

  // ============================================================
  // E004: URL download failure handling (P0)
  // ============================================================
  describe('E004 - URL download failure handling', () => {
    it('should throw error with HTTP status on 404', async () => {
      const url = 'http://example.com/notfound.jpg';

      setupMockFetch(url, createMockResponse('Not Found', 404, 'Not Found'));

      const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

      await expect(ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR))
        .rejects.toThrow('Failed to download resource: HTTP 404');
    });

    it('should throw error on HTTP 403 Forbidden', async () => {
      const url = 'http://example.com/forbidden.jpg';

      setupMockFetch(url, createMockResponse('Forbidden', 403, 'Forbidden'));

      const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

      await expect(ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR))
        .rejects.toThrow('Failed to download resource: HTTP 403');
    });

    it('should throw error on HTTP 500 Internal Server Error', async () => {
      const url = 'http://example.com/server-error.jpg';

      setupMockFetch(url, createMockResponse('Internal Server Error', 500, 'Internal Server Error'));

      const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

      await expect(ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR))
        .rejects.toThrow('Failed to download resource: HTTP 500');
    });

    it('should handle network error gracefully', async () => {
      const url = 'http://example.com/network-error.jpg';

      global.fetch = async () => {
        throw new Error('Network error: connection refused');
      };

      const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

      await expect(ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR))
        .rejects.toThrow('Network error');
    });

    it('should handle timeout error gracefully', async () => {
      const url = 'http://example.com/timeout.jpg';

      global.fetch = async () => {
        throw new Error('Request timeout');
      };

      const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

      await expect(ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR))
        .rejects.toThrow('timeout');
    });

    it('should not create tmp directory on download failure', async () => {
      const url = 'http://example.com/notfound.jpg';
      const customTmpDir = './tests/fixtures/tmp-should-not-exist';

      setupMockFetch(url, createMockResponse('Not Found', 404, 'Not Found'));

      const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

      try {
        await ResourceDownloader.resolveInputResource(url, customTmpDir);
      } catch (e) {
        // Expected error
      }

      // Directory may or may not exist depending on when error occurs
      // The key point is no files should be left
      if (fs.existsSync(customTmpDir)) {
        const files = fs.readdirSync(customTmpDir);
        expect(files.length).toBe(0);
        cleanupDir(customTmpDir);
      }
    });
  });

  // ============================================================
  // Additional E2E scenarios
  // ============================================================
  describe('Additional E2E scenarios', () => {
    it('should handle URL with special characters in filename', async () => {
      const url = 'http://example.com/images/my%20test%20image.png';
      const mockData = createMockPngData();

      setupMockFetch(url, createMockResponse(mockData));

      const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
      expect(fs.existsSync(result.localPath)).toBe(true);
    });

    it('should handle URL without file extension', async () => {
      const url = 'http://example.com/api/generate-image';
      const mockData = createMockPngData();

      setupMockFetch(url, createMockResponse(mockData));

      const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
      expect(result.localPath).toContain('download_');
      expect(fs.existsSync(result.localPath)).toBe(true);
    });

    it('should handle concurrent URL downloads', async () => {
      const urls = [
        'http://example.com/concurrent/1.jpg',
        'http://example.com/concurrent/2.jpg',
        'http://example.com/concurrent/3.jpg'
      ];

      setupMultipleMockFetches({
        'http://example.com/concurrent/1.jpg': createMockResponse(createMockJpegData()),
        'http://example.com/concurrent/2.jpg': createMockResponse(createMockJpegData()),
        'http://example.com/concurrent/3.jpg': createMockResponse(createMockJpegData())
      });

      const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

      // Download all concurrently
      const results = await Promise.all(
        urls.map(url => ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR))
      );

      expect(results).toHaveLength(3);
      results.forEach(result => {
        expect(result.wasDownloaded).toBe(true);
        expect(fs.existsSync(result.localPath)).toBe(true);
      });
    });

    it('should handle large file download simulation', async () => {
      const url = 'http://example.com/large-image.png';
      // Create a larger mock data (1KB)
      const mockData = Buffer.alloc(1024, 0xFF);

      setupMockFetch(url, createMockResponse(mockData));

      const ResourceDownloader = (await import('../../src/utils/resource_downloader.js')).default;

      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
      const stats = fs.statSync(result.localPath);
      expect(stats.size).toBe(1024);
    });
  });
});
