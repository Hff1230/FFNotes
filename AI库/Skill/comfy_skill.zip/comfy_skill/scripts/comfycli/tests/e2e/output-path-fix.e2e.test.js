/**
 * E2E tests for output path fix — 7 real-world scenarios
 * Tests: TC-045 through TC-051
 *
 * Simulates real usage scenarios to verify files land in correct directories.
 * Uses real path functions with temporary directories.
 */
import { jest, describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import { Command } from 'commander';
import path from 'path';
import os from 'os';
import fs from 'fs';
import { generateOutputPath, generateOutputFilename } from '../../src/core/workflow.js';

/**
 * Creates a Commander program with dynamic DEFAULT_OUTPUT_PATH
 */
function createRealProgram(envRoot, cwdValue) {
  const DEFAULT_OUTPUT_PATH = envRoot
    ? path.join(envRoot, 'output')
    : path.join(cwdValue, 'output');

  const program = new Command();
  program
    .name('comfycli')
    .version('1.0.0');

  program
    .command('txt2img')
    .argument('<prompt>', 'Text prompt')
    .option('-o, --output <path>', 'Output dir', DEFAULT_OUTPUT_PATH)
    .option('--project <name>', 'Project name')
    .option('--category <type>', 'Category')
    .option('--name <name>', 'Name')
    .action(() => {});

  return program;
}

describe('E2E: Output path fix — real-world scenarios', () => {
  let tmpDir;

  beforeEach(() => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'comfycli-test-'));
  });

  afterEach(() => {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  // ── TC-045: Standard usage — COMFY_PROJECT_ROOT=$(pwd) + txt2img ──
  it('TC-045: standard usage → files in {project_root}/output/', async () => {
    const projectRoot = tmpDir;
    const cwd = path.join(tmpDir, '.claude', 'skills', 'comfycli');

    const program = createRealProgram(projectRoot, cwd);
    await program.parseAsync(['node', 'comfycli', 'txt2img', 'a sunset'], { from: 'node' });

    const options = program.commands[0].opts();
    const outputDir = options.output;

    expect(outputDir).toBe(path.join(projectRoot, 'output'));

    // Simulate file creation
    fs.mkdirSync(outputDir, { recursive: true });
    const testFile = path.join(outputDir, 'test.png');
    fs.writeFileSync(testFile, 'test');

    expect(fs.existsSync(path.join(projectRoot, 'output', 'test.png'))).toBe(true);
    // File should NOT be in the comfycli directory
    expect(fs.existsSync(path.join(cwd, 'output', 'test.png'))).toBe(false);
  });

  // ── TC-046: Project organized — + --project --category ──
  it('TC-046: project organized → files in {root}/output/project/resources/category/', async () => {
    const projectRoot = tmpDir;

    const program = createRealProgram(projectRoot, '/cwd');
    await program.parseAsync(
      ['node', 'comfycli', 'txt2img', 'a scene', '--project', 'demo', '--category', 'scenes'],
      { from: 'node' }
    );

    const options = program.commands[0].opts();
    const baseOutput = options.output;
    const outputDir = generateOutputPath(baseOutput, {
      project: options.project,
      category: options.category
    });

    expect(outputDir).toBe(path.join(projectRoot, 'output', 'demo', 'resources', 'scenes'));

    // Simulate file creation
    fs.mkdirSync(outputDir, { recursive: true });
    const filename = generateOutputFilename('workflow', '.png', {
      project: 'demo', category: 'scenes', name: 'scene01'
    });
    const testFile = path.join(outputDir, filename);
    fs.writeFileSync(testFile, 'test');

    expect(fs.existsSync(path.join(projectRoot, 'output', 'demo', 'resources', 'scenes', 'scene01.png'))).toBe(true);
  });

  // ── TC-047: Batch processing ──
  it('TC-047: batch with ENV → all tasks output under project root', () => {
    const projectRoot = tmpDir;
    const envOutput = path.join(projectRoot, 'output');

    // Simulate batch with 3 tasks
    const tasks = [
      { type: 'txt2img', prompt: 'task 1' },
      { type: 'txt2img', prompt: 'task 2' },
      { type: 'txt2img', prompt: 'task 3' },
    ];

    const outputDirs = tasks.map(() => envOutput);

    // All should output to project root
    for (const dir of outputDirs) {
      expect(dir).toBe(path.join(projectRoot, 'output'));
    }

    // Verify they're NOT in the comfycli skill directory
    const skillDir = path.join(projectRoot, '.claude', 'skills', 'comfycli');
    for (const dir of outputDirs) {
      expect(dir).not.toBe(path.join(skillDir, 'output'));
    }
  });

  // ── TC-048: Custom relative path ──
  it('TC-048: custom relative path → files in {cwd}/custom_out/', async () => {
    const program = createRealProgram('/env/root', tmpDir);
    await program.parseAsync(
      ['node', 'comfycli', 'txt2img', 'a sunset', '--output', './custom_out'],
      { from: 'node' }
    );

    const options = program.commands[0].opts();
    // Explicit output overrides default
    expect(options.output).toBe('./custom_out');
  });

  // ── TC-049: Absolute path ──
  it('TC-049: absolute path → files at exact specified location', async () => {
    const customOutput = path.join(tmpDir, 'temp', 'output');

    const program = createRealProgram('/env/root', '/cwd');
    await program.parseAsync(
      ['node', 'comfycli', 'txt2img', 'a sunset', '--output', customOutput],
      { from: 'node' }
    );

    const options = program.commands[0].opts();
    expect(options.output).toBe(customOutput);

    // Verify file can be created at that location
    fs.mkdirSync(customOutput, { recursive: true });
    const testFile = path.join(customOutput, 'output.png');
    fs.writeFileSync(testFile, 'test');
    expect(fs.existsSync(testFile)).toBe(true);
  });

  // ── TC-050: No ENV variable ──
  it('TC-050: no ENV → files in {cwd}/output/', async () => {
    const cwdValue = tmpDir;

    const program = createRealProgram(undefined, cwdValue);
    await program.parseAsync(['node', 'comfycli', 'txt2img', 'a sunset'], { from: 'node' });

    const options = program.commands[0].opts();
    expect(options.output).toBe(path.join(cwdValue, 'output'));
  });

  // ── TC-051: Global skill scenario ──
  it('TC-051: global skill install → ENV ensures correct output', () => {
    // Skill is in ~/.claude/skills/, but project is in /my/project/
    const skillDir = path.join(os.homedir(), '.claude', 'skills', 'comfy_skill', 'scripts', 'comfycli');
    const projectDir = path.join(tmpDir, 'my-project');

    // With COMFY_PROJECT_ROOT set to the project directory
    const envRoot = projectDir;
    const defaultOutput = envRoot
      ? path.join(envRoot, 'output')
      : path.join(skillDir, 'output');

    // Output should go to project directory, NOT skill directory
    expect(defaultOutput).toBe(path.join(projectDir, 'output'));
    expect(defaultOutput).not.toContain('.claude/skills');
  });
});
