import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import fs from 'fs';
import path from 'path';
import os from 'os';
import ConfigManager from '../../src/utils/config.js';

describe('Dual Config E2E - Complete Flow', () => {
  let tmpDir;
  let fixturesDir;

  beforeEach(() => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'comfycli-e2e-'));
    // Resolve the project fixtures directory for the mock API file
    fixturesDir = path.resolve(
      path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Z]:)/, '$1')),
      '..', 'fixtures'
    );
  });

  afterEach(() => {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  // Create a full test config environment with a real API file
  function setupFullConfig() {
    const mockApiRelPath = path.relative(tmpDir, path.join(fixturesDir, 'mock-api.json'));
    const comfyConfig = {
      prompts: {
        'e2e-workflow': {
          description: 'E2E Test Workflow',
          type: 'txt2img',
          api: mockApiRelPath,
          data: [
            { 'active##1##inputs##prompt': '##active_prompt##' }
          ]
        }
      },
      resolution: {
        pic_gen: {
          '0': [{ name: 'low', width: 512, height: 512 }],
          '1': [{ name: 'low', width: 512, height: 768 }]
        }
      }
    };
    const serverConfig = {
      host: 'e2e-server.example.com',
      port: 9100,
      api_key: 'e2e-test-key',
      upload: {
        server: 'e2e-upload.example.com:9998',
        user: 'e2e-user',
        pwd: 'e2e-pwd',
        dir: 'comfy',
        share_url: 'http://e2e-share.example.com'
      }
    };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify(serverConfig));
    return { comfyConfig, serverConfig };
  }

  // 301-1: Standard txt2img flow
  it('should complete standard txt2img flow with full config', () => {
    setupFullConfig();

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );

    // Step 1: Load
    expect(cm.load()).toBe(true);
    expect(cm.isLoaded()).toBe(true);

    // Step 2: Get server config
    const server = cm.getServerConfig();
    expect(server.host).toBe('e2e-server.example.com');
    expect(server.port).toBe(9100);
    expect(server.apiKey).toBe('e2e-test-key');

    // Step 3: Get workflow
    const workflow = cm.getWorkflow('e2e-workflow');
    expect(workflow).not.toBeNull();
    expect(workflow.type).toBe('txt2img');

    // Step 4: Resolve resolution
    const res = cm.resolveResolution('low', '0', 'pic_gen');
    expect(res).toEqual({ width: 512, height: 512 });

    // Step 5: Get upload config
    const upload = cm.getUploadConfig();
    expect(upload).not.toBeNull();
    expect(upload.server).toBe('e2e-upload.example.com:9998');
    expect(upload.share_url).toBe('http://e2e-share.example.com');
  });

  // 301-2: No upload config
  it('should skip upload gracefully when upload is not configured', () => {
    // Copy mock-api.json into tmpDir so validate() can find it
    const mockApiContent = fs.readFileSync(path.join(fixturesDir, 'mock-api.json'), 'utf-8');
    fs.writeFileSync(path.join(tmpDir, 'mock-api.json'), mockApiContent);

    const comfyConfig = {
      prompts: {
        'e2e-workflow': {
          description: 'E2E Test',
          type: 'txt2img',
          api: 'mock-api.json',
          data: []
        }
      }
    };
    const serverConfig = {
      host: 'e2e-server.example.com',
      port: 9100
    };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify(serverConfig));

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();

    const server = cm.getServerConfig();
    expect(server.host).toBe('e2e-server.example.com');

    const upload = cm.getUploadConfig();
    expect(upload).toBeNull();
  });

  // 301-3: No server_config, fall back to defaults
  it('should fall back to defaults when server_config is missing', () => {
    // Copy mock-api.json into tmpDir
    const mockApiContent = fs.readFileSync(path.join(fixturesDir, 'mock-api.json'), 'utf-8');
    fs.writeFileSync(path.join(tmpDir, 'mock-api.json'), mockApiContent);

    const comfyConfig = {
      prompts: {
        'e2e-workflow': {
          description: 'E2E Test',
          type: 'txt2img',
          api: 'mock-api.json',
          data: []
        }
      }
    };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));
    // Do not create server_config.json

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();

    expect(cm.serverConfig).toBeNull();

    const server = cm.getServerConfig();
    expect(server.host).toBe('127.0.0.1');
    expect(server.port).toBe(8188);
    expect(server.apiKey).toBe('');

    const upload = cm.getUploadConfig();
    expect(upload).toBeNull();
  });

  // 301-4: Validate end-to-end
  it('should validate correctly without host/port errors', () => {
    setupFullConfig();

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();

    // validate() should NOT check host/port (those belong to server_config)
    const result = cm.validate();
    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);

    // host/port should not appear in errors
    const hasHostPortError = result.errors.some(e =>
      e.toLowerCase().includes('host') || e.toLowerCase().includes('port')
    );
    expect(hasHostPortError).toBe(false);

    // validateServerConfig() should check server_config
    const serverValidation = cm.validateServerConfig();
    expect(serverValidation.valid).toBe(true);
  });
});
