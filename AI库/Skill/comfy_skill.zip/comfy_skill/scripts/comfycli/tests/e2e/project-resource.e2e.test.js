import { describe, it, expect } from '@jest/globals';
import sinon from 'sinon';
import { Command } from 'commander';
import { generateOutputPath, generateOutputFilename } from '../../src/core/workflow.js';
import DufsUploader from '../../src/utils/uploader.js';
import { createMockUploader } from '../helpers/mock-factory.js';

/**
 * End-to-end tests: Project-based resource management full pipeline
 *
 * Validates the complete chain from CLI input to final output:
 *   CLI parsing (Commander.js)
 *     -> directory generation (generateOutputPath)
 *       -> filename generation (generateOutputFilename)
 *         -> upload path (getProjectRemotePath)
 *           -> share URL (getProjectShareUrl)
 *
 * Uses real function calls (only HTTP/network deps are mocked).
 */

// Uploader config matching mock-factory defaults
const UPLOADER_CONFIG = {
  server: '192.168.0.92:9998',
  user: 'testuser',
  pwd: 'testpwd',
  dir: 'comfy',
  share_url: 'http://47.109.205.195:10020'
};

describe('End-to-end: Project-based resource management full pipeline', () => {

  // ---------------------------------------------------------------
  // 1. Full project mode end-to-end
  // ---------------------------------------------------------------
  describe('Full project mode: txt2img --project wusong --category characters --name C01_武松', () => {

    it('should complete the entire CLI-to-URL chain correctly', async () => {
      // === Step 1: CLI parsing ===
      const program = new Command();
      program
        .command('txt2img')
        .argument('<prompt>', 'Text prompt')
        .option('--project <name>', 'Project name')
        .option('--category <type>', 'Resource category')
        .option('--name <name>', 'Resource name')
        .option('-o, --output <path>', 'Output dir', './output')
        .action(() => {});

      program.parse(['node', 'test', 'txt2img', 'a warrior hero', '--project', 'wusong', '--category', 'characters', '--name', 'C01_武松']);

      const options = program.commands[0].opts();
      expect(options.project).toBe('wusong');
      expect(options.category).toBe('characters');
      expect(options.name).toBe('C01_武松');

      // === Step 2: Directory generation ===
      const outputDir = generateOutputPath('./output', {
        project: options.project,
        category: options.category
      });
      expect(outputDir).toMatch(/wusong[\/\\]resources[\/\\]characters/);
      expect(outputDir).toContain('wusong');
      expect(outputDir).toContain('characters');

      // === Step 3: Filename generation ===
      const filename = generateOutputFilename('workflow', '.png', {
        project: options.project,
        category: options.category,
        name: options.name
      });
      expect(filename).toBe('C01_武松.png');

      // Metadata filename follows same naming convention with .json extension
      const metaFilename = generateOutputFilename('workflow', '.json', {
        project: options.project,
        category: options.category,
        name: options.name
      });
      expect(metaFilename).toBe('C01_武松.json');

      // === Step 4: Upload path (using real DufsUploader instance) ===
      const uploader = new DufsUploader(UPLOADER_CONFIG);
      const remotePath = uploader.getProjectRemotePath(filename, options.project, options.category);
      expect(remotePath).toBe('/projects/wusong/characters/C01_武松.png');

      // Metadata remote path
      const metaRemotePath = uploader.getProjectRemotePath(metaFilename, options.project, options.category);
      expect(metaRemotePath).toBe('/projects/wusong/characters/C01_武松.json');

      // === Step 5: Share URL ===
      const shareUrl = uploader.getProjectShareUrl(filename, options.project, options.category);
      expect(shareUrl).toBe('http://47.109.205.195:10020/projects/wusong/characters/C01_武松.png');

      // Metadata share URL
      const metaShareUrl = uploader.getProjectShareUrl(metaFilename, options.project, options.category);
      expect(metaShareUrl).toBe('http://47.109.205.195:10020/projects/wusong/characters/C01_武松.json');
    });
  });

  // ---------------------------------------------------------------
  // 2. Backward-compatible mode (no project params)
  // ---------------------------------------------------------------
  describe('Backward-compatible mode: txt2img "prompt" --output /tmp/test', () => {

    it('should use default naming when no project params provided', async () => {
      // === Step 1: CLI parsing (no project/category/name) ===
      const program = new Command();
      program
        .command('txt2img')
        .argument('<prompt>', 'Text prompt')
        .option('-o, --output <path>', 'Output dir', './output')
        .option('--project <name>', 'Project name')
        .option('--category <type>', 'Resource category')
        .option('--name <name>', 'Resource name')
        .action(() => {});

      program.parse(['node', 'test', 'txt2img', 'a beautiful landscape', '--output', '/tmp/test']);

      const options = program.commands[0].opts();
      expect(options.project).toBeUndefined();
      expect(options.category).toBeUndefined();
      expect(options.name).toBeUndefined();
      expect(options.output).toBe('/tmp/test');

      // === Step 2: Directory generation (falls back to base) ===
      const outputDir = generateOutputPath(options.output, {
        project: options.project,
        category: options.category
      });
      expect(outputDir).toBe('/tmp/test');

      // === Step 3: Filename generation (workflowName + timestamp) ===
      const filename = generateOutputFilename('myworkflow', '.png', {
        project: options.project,
        category: options.category,
        name: options.name
      });
      // Should match pattern: myworkflow_YYYYMMDD_HHMMSS.png
      expect(filename).toMatch(/^myworkflow_\d{8}_\d{6}\.png$/);

      // === Step 4: Upload path (non-project, uses date-based path) ===
      const uploader = new DufsUploader(UPLOADER_CONFIG);
      const remotePath = uploader.getRemotePath(filename);
      // Should follow pattern: /comfy/YYYY-M-D/filename
      expect(remotePath).toMatch(/^\/comfy\/\d{4}-\d{1,2}-\d{1,2}\/myworkflow_\d{8}_\d{6}\.png$/);

      // === Step 5: Share URL (non-project) ===
      const shareUrl = uploader.getShareUrl(filename);
      // shareUrl prefix + date-based remote path
      expect(shareUrl).toMatch(
        /^http:\/\/47\.109\.205\.195:10020\/comfy\/\d{4}-\d{1,2}-\d{1,2}\/myworkflow_\d{8}_\d{6}\.png$/
      );
    });
  });

  // ---------------------------------------------------------------
  // 3. Partial parameters: project + category (no name)
  // ---------------------------------------------------------------
  describe('Partial params: txt2img "prompt" --project wusong --category scenes', () => {

    it('should use project_category_timestamp naming when name is omitted', async () => {
      // === Step 1: CLI parsing ===
      const program = new Command();
      program
        .command('txt2img')
        .argument('<prompt>', 'Text prompt')
        .option('-o, --output <path>', 'Output dir', './output')
        .option('--project <name>', 'Project name')
        .option('--category <type>', 'Resource category')
        .option('--name <name>', 'Resource name')
        .action(() => {});

      program.parse(['node', 'test', 'txt2img', 'battle scene', '--project', 'wusong', '--category', 'scenes']);

      const options = program.commands[0].opts();
      expect(options.project).toBe('wusong');
      expect(options.category).toBe('scenes');
      expect(options.name).toBeUndefined();

      // === Step 2: Directory generation ===
      const outputDir = generateOutputPath('./output', {
        project: options.project,
        category: options.category
      });
      expect(outputDir).toMatch(/wusong[\/\\]resources[\/\\]scenes/);

      // === Step 3: Filename generation (project_category_timestamp) ===
      const filename = generateOutputFilename('workflow', '.png', {
        project: options.project,
        category: options.category,
        name: options.name
      });
      // Should match pattern: wusong_scenes_YYYYMMDD_HHMMSS.png
      expect(filename).toMatch(/^wusong_scenes_\d{8}_\d{6}\.png$/);

      // === Step 4: Upload path ===
      const uploader = new DufsUploader(UPLOADER_CONFIG);
      const remotePath = uploader.getProjectRemotePath(filename, options.project, options.category);
      // The path contains the timestamped filename under the project/category dir
      expect(remotePath).toMatch(/^\/projects\/wusong\/scenes\/wusong_scenes_\d{8}_\d{6}\.png$/);

      // === Step 5: Share URL ===
      const shareUrl = uploader.getProjectShareUrl(filename, options.project, options.category);
      expect(shareUrl).toMatch(
        /^http:\/\/47\.109\.205\.195:10020\/projects\/wusong\/scenes\/wusong_scenes_\d{8}_\d{6}\.png$/
      );
    });
  });

  // ---------------------------------------------------------------
  // 4. Multi-file output
  // ---------------------------------------------------------------
  describe('Multi-file output: all files uploaded to correct project path', () => {

    it('should generate correct paths for multiple output files', async () => {
      const project = 'wusong';
      const category = 'characters';
      const name = 'C01_武松';

      // Simulate multiple output files with different extensions
      const extensions = ['.png', '.json'];
      const uploader = new DufsUploader(UPLOADER_CONFIG);

      const results = extensions.map(ext => {
        const filename = generateOutputFilename('workflow', ext, { project, category, name });
        const outputDir = generateOutputPath('./output', { project, category });
        const remotePath = uploader.getProjectRemotePath(filename, project, category);
        const shareUrl = uploader.getProjectShareUrl(filename, project, category);
        return { filename, outputDir, remotePath, shareUrl };
      });

      // PNG file
      expect(results[0].filename).toBe('C01_武松.png');
      expect(results[0].remotePath).toBe('/projects/wusong/characters/C01_武松.png');
      expect(results[0].shareUrl).toBe('http://47.109.205.195:10020/projects/wusong/characters/C01_武松.png');

      // JSON metadata
      expect(results[1].filename).toBe('C01_武松.json');
      expect(results[1].remotePath).toBe('/projects/wusong/characters/C01_武松.json');
      expect(results[1].shareUrl).toBe('http://47.109.205.195:10020/projects/wusong/characters/C01_武松.json');

      // Both files share the same output directory
      expect(results[0].outputDir).toBe(results[1].outputDir);

      // All remote paths are under the same project/category prefix
      results.forEach(r => {
        expect(r.remotePath).toMatch(/^\/projects\/wusong\/characters\//);
        expect(r.shareUrl).toMatch(/^http:\/\/47\.109\.205\.195:10020\/projects\/wusong\/characters\//);
      });
    });

    it('should handle multiple images with mock uploader batch upload', async () => {
      const mockUploader = createMockUploader();
      const project = 'wusong';
      const category = 'scenes';
      const filenames = ['scene_001.png', 'scene_002.png', 'scene_003.png'];

      // Generate remote paths and share URLs for each file
      const uploadResults = filenames.map(fn => {
        const remotePath = mockUploader.getProjectRemotePath(fn, project, category);
        const shareUrl = mockUploader.getProjectShareUrl(fn, project, category);
        return { filename: fn, remotePath, shareUrl };
      });

      expect(uploadResults).toHaveLength(3);
      uploadResults.forEach((r, i) => {
        expect(r.remotePath).toBe(`/projects/wusong/scenes/${filenames[i]}`);
        expect(r.shareUrl).toBe(`http://47.109.205.195:10020/projects/wusong/scenes/${filenames[i]}`);
      });

      // Simulate batch upload returning success for all files
      mockUploader.uploadFiles.resolves({
        success: true,
        results: filenames.map(fn => ({
          local: `/tmp/${fn}`,
          success: true,
          url: `http://47.109.205.195:10020/projects/wusong/scenes/${fn}`
        }))
      });

      const batchResult = await mockUploader.uploadFiles(
        filenames.map(fn => `/tmp/${fn}`),
        { project, category }
      );
      expect(batchResult.success).toBe(true);
      expect(batchResult.results).toHaveLength(3);
      batchResult.results.forEach(r => expect(r.success).toBe(true));
    });
  });

  // ---------------------------------------------------------------
  // 5. Upload failure scenario
  // ---------------------------------------------------------------
  describe('Upload failure: local files unaffected', () => {

    it('should keep local paths correct even when upload fails', async () => {
      const project = 'wusong';
      const category = 'characters';
      const name = 'C01_武松';

      // === Local path generation (always succeeds) ===
      const outputDir = generateOutputPath('./output', { project, category });
      const filename = generateOutputFilename('workflow', '.png', { project, category, name });

      // Local file path assertions (these should always work regardless of upload)
      expect(outputDir).toMatch(/wusong[\/\\]resources[\/\\]characters/);
      expect(filename).toBe('C01_武松.png');

      // === Simulate upload failure using mock ===
      const mockUploader = createMockUploader({
        uploadFile: sinon.stub().resolves({
          success: false,
          error: 'Connection refused: server unreachable'
        })
      });

      const uploadResult = await mockUploader.uploadFile('/tmp/test.png');
      expect(uploadResult.success).toBe(false);

      // Local directory and filename remain correct despite upload failure
      expect(outputDir).toMatch(/wusong[\/\\]resources[\/\\]characters/);
      expect(filename).toBe('C01_武松.png');
    });

    it('should handle partial upload failures in batch', async () => {
      const mockUploader = createMockUploader({
        uploadFiles: (() => {
          // Use a stub-like approach
          const fn = () => Promise.resolve({
            success: false,
            results: [
              { local: '/tmp/a.png', success: true, url: 'http://test/a.png' },
              { local: '/tmp/b.png', success: false, error: 'Network timeout' }
            ]
          });
          fn.resolves = (val) => { fn._resolved = val; return fn; };
          return fn;
        })()
      });

      const result = await mockUploader.uploadFiles(['/tmp/a.png', '/tmp/b.png']);
      expect(result.success).toBe(false);
      expect(result.results[0].success).toBe(true);
      expect(result.results[1].success).toBe(false);
    });
  });

  // ---------------------------------------------------------------
  // 6. Special characters / Chinese filenames
  // ---------------------------------------------------------------
  describe('Special characters: Chinese filenames end-to-end', () => {

    it('should handle Chinese name with underscores through entire chain', async () => {
      const project = 'wusong';
      const category = 'characters';
      const name = 'C01_武松_正面全身';

      // CLI parsing
      const program = new Command();
      program
        .command('txt2img')
        .argument('<prompt>')
        .option('--project <name>')
        .option('--category <type>')
        .option('--name <name>')
        .action(() => {});
      program.parse(['node', 'test', 'txt2img', 'prompt', '--project', project, '--category', category, '--name', name]);

      const opts = program.commands[0].opts();
      expect(opts.name).toBe('C01_武松_正面全身');

      // Directory generation
      const outputDir = generateOutputPath('./output', { project, category });
      expect(outputDir).toContain('wusong');

      // Filename generation
      const filename = generateOutputFilename('workflow', '.png', { project, category, name });
      expect(filename).toBe('C01_武松_正面全身.png');

      // Upload path
      const uploader = new DufsUploader(UPLOADER_CONFIG);
      const remotePath = uploader.getProjectRemotePath(filename, project, category);
      expect(remotePath).toBe('/projects/wusong/characters/C01_武松_正面全身.png');

      // Share URL
      const shareUrl = uploader.getProjectShareUrl(filename, project, category);
      expect(shareUrl).toBe('http://47.109.205.195:10020/projects/wusong/characters/C01_武松_正面全身.png');
    });

    it('should handle Chinese category names through entire chain', async () => {
      const project = '三国演义';
      const category = '人物';
      const name = '刘备_全身像';

      const outputDir = generateOutputPath('./output', { project, category });
      expect(outputDir).toMatch(/三国演义[\/\\]resources[\/\\]人物/);

      const filename = generateOutputFilename('workflow', '.png', { project, category, name });
      expect(filename).toBe('刘备_全身像.png');

      const uploader = new DufsUploader(UPLOADER_CONFIG);
      const remotePath = uploader.getProjectRemotePath(filename, project, category);
      expect(remotePath).toBe('/projects/三国演义/人物/刘备_全身像.png');

      const shareUrl = uploader.getProjectShareUrl(filename, project, category);
      expect(shareUrl).toBe('http://47.109.205.195:10020/projects/三国演义/人物/刘备_全身像.png');
    });

    it('should handle special characters in project/category/name', async () => {
      const project = 'project-1';
      const category = 'cat_a';
      const name = 'C01_武松(正面)';

      const filename = generateOutputFilename('workflow', '.png', { project, category, name });
      expect(filename).toBe('C01_武松(正面).png');

      const uploader = new DufsUploader(UPLOADER_CONFIG);
      const remotePath = uploader.getProjectRemotePath(filename, project, category);
      expect(remotePath).toBe('/projects/project-1/cat_a/C01_武松(正面).png');

      const shareUrl = uploader.getProjectShareUrl(filename, project, category);
      expect(shareUrl).toBe('http://47.109.205.195:10020/projects/project-1/cat_a/C01_武松(正面).png');
    });
  });

  // ---------------------------------------------------------------
  // Cross-cutting: verify path consistency across chain
  // ---------------------------------------------------------------
  describe('Chain consistency: output dir matches upload path structure', () => {

    it('should produce consistent local and remote directory structure', () => {
      const project = 'wusong';
      const category = 'characters';
      const name = 'C01_武松';

      const outputDir = generateOutputPath('./output', { project, category });
      const filename = generateOutputFilename('workflow', '.png', { project, category, name });

      const uploader = new DufsUploader(UPLOADER_CONFIG);
      const remotePath = uploader.getProjectRemotePath(filename, project, category);
      const shareUrl = uploader.getProjectShareUrl(filename, project, category);

      // Remote path segments must match local directory structure
      // Local: output/wusong/resources/characters/C01_武松.png
      // Remote: /projects/wusong/characters/C01_武松.png
      expect(remotePath).toContain(`/projects/${project}/${category}/${filename}`);
      expect(shareUrl).toContain(`/projects/${project}/${category}/${filename}`);

      // The output directory contains both project and category
      expect(outputDir).toContain(project);
      expect(outputDir).toContain(category);
    });
  });
});
