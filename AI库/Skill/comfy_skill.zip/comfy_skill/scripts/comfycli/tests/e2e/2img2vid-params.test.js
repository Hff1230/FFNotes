/**
 * E2E Tests: 2img2vid Parameter Pipeline
 *
 * Tests the full parameter pipeline for the 2img2vid workflow:
 * CLI options -> promptVars -> replaceVariables(data, values)
 * CLI options -> workflowParams -> mergeWorkflowParams
 *
 * Uses real config files to simulate the complete data flow.
 */
import { describe, it, expect, beforeAll } from '@jest/globals';
import { replaceVariables, mergeWorkflowParams } from '../../src/core/workflow.js';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECT_ROOT = path.resolve(__dirname, '../../');
const CONFIG_PATH = path.join(PROJECT_ROOT, 'config', 'comfy_config.json');
const API_PATH = path.join(PROJECT_ROOT, 'config', 'comfy', 'image2_to_video_ltx2.3_fe_api.json');

// Shared fixtures
let apiData;
let dataConfig;

// Default prompt values that are always provided by the CLI
const defaultPromptVars = {
  active_prompt: 'a beautiful sky transition',
  negative_prompt: 'blurry, low quality',
  sample_image: 'first_frame.png',
  sample_image2: 'last_frame.png',
};

beforeAll(() => {
  const apiRaw = fs.readFileSync(API_PATH, 'utf-8');
  apiData = JSON.parse(apiRaw);

  const configRaw = fs.readFileSync(CONFIG_PATH, 'utf-8');
  const config = JSON.parse(configRaw);
  dataConfig = config.prompts.ltx2img2vid.data;
});
// ============================================================
// TEST-E2E-001: CLI Parameter Scenarios
// ============================================================
describe('TEST-E2E-001: CLI Parameter Scenarios', () => {

  // E2E-P001: Default params -> verify workflow node values are defaults
  it('E2E-P001: default params - video nodes keep original numeric values', () => {
    const values = { ...defaultPromptVars };
    const result = replaceVariables(apiData, dataConfig, values);

    expect(result['113'].inputs.value).toBe(1280);
    expect(result['98'].inputs.value).toBe(720);
    expect(result['102'].inputs.value).toBe(121);
    expect(result['114'].inputs.value).toBe(25);

    expect(result['128'].inputs.text).toBe('a beautiful sky transition');
    expect(result['112'].inputs.text).toBe('blurry, low quality');
    expect(result['31'].inputs.image).toBe('first_frame.png');
    expect(result['39'].inputs.image).toBe('last_frame.png');
  });

  // E2E-P002: --width 960 --height 540 -> verify correct values
  it('E2E-P002: width=960 height=540 - replaces correct nodes', () => {
    const values = {
      ...defaultPromptVars,
      width: '960',
      height: '540',
    };
    const result = replaceVariables(apiData, dataConfig, values);

    expect(result['113'].inputs.value).toBe('960');
    expect(result['98'].inputs.value).toBe('540');
    expect(result['102'].inputs.value).toBe(121);
    expect(result['114'].inputs.value).toBe(25);
  });

  // E2E-P003: --frames 41 --fps 30 -> verify correct values
  it('E2E-P003: frames=41 fps=30 - replaces correct nodes', () => {
    const values = {
      ...defaultPromptVars,
      framelen: '41',
      fps: '30',
    };
    const result = replaceVariables(apiData, dataConfig, values);

    expect(result['102'].inputs.value).toBe('41');
    expect(result['114'].inputs.value).toBe('30');
    expect(result['113'].inputs.value).toBe(1280);
    expect(result['98'].inputs.value).toBe(720);
  });

  // E2E-P004: All params combined -> all correctly set
  it('E2E-P004: all video params combined - all nodes replaced', () => {
    const values = {
      ...defaultPromptVars,
      width: '960',
      height: '540',
      framelen: '41',
      fps: '30',
    };
    const result = replaceVariables(apiData, dataConfig, values);

    expect(result['113'].inputs.value).toBe('960');
    expect(result['98'].inputs.value).toBe('540');
    expect(result['102'].inputs.value).toBe('41');
    expect(result['114'].inputs.value).toBe('30');
  });

  // E2E-P005: Partial params (only --width 1920) -> only width changes
  it('E2E-P005: only width=1920 - only width node changes', () => {
    const values = {
      ...defaultPromptVars,
      width: '1920',
    };
    const result = replaceVariables(apiData, dataConfig, values);

    expect(result['113'].inputs.value).toBe('1920');
    expect(result['98'].inputs.value).toBe(720);
    expect(result['102'].inputs.value).toBe(121);
    expect(result['114'].inputs.value).toBe(25);
  });

  // E2E-P006: --seed 12345 with --width 960 -> both paths work
  it('E2E-P006: seed and width both applied - seed does not match noise_seed key', () => {
    const values = {
      ...defaultPromptVars,
      width: '960',
    };
    let result = replaceVariables(apiData, dataConfig, values);

    result = mergeWorkflowParams(result, { seed: 12345 });

    expect(result['113'].inputs.value).toBe('960');
    expect(result['100'].inputs.noise_seed).toBe(469008696527318);
  });
});
// ============================================================
// TEST-E2E-002: Original Functionality Regression
// ============================================================
describe('TEST-E2E-002: Original Functionality Regression', () => {

  // E2E-R001: Only required params -> normal execution
  it('E2E-R001: only required params - prompt/image nodes replaced, video defaults preserved', () => {
    const values = {
      active_prompt: 'test',
      negative_prompt: 'neg',
      sample_image: 'img1.png',
      sample_image2: 'img2.png',
    };
    const result = replaceVariables(apiData, dataConfig, values);

    expect(result['128'].inputs.text).toBe('test');
    expect(result['112'].inputs.text).toBe('neg');
    expect(result['31'].inputs.image).toBe('img1.png');
    expect(result['39'].inputs.image).toBe('img2.png');

    expect(result['113'].inputs.value).toBe(1280);
    expect(result['98'].inputs.value).toBe(720);
    expect(result['102'].inputs.value).toBe(121);
    expect(result['114'].inputs.value).toBe(25);
  });

  // E2E-R002: prompt and negative -> text correctly passed to nodes 128 and 112
  it('E2E-R002: active_prompt and negative_prompt correctly reach nodes 128 and 112', () => {
    const values = {
      active_prompt: 'sunset over mountains',
      negative_prompt: 'ugly, distorted',
      sample_image: 'a.png',
      sample_image2: 'b.png',
    };
    const result = replaceVariables(apiData, dataConfig, values);

    expect(result['128'].inputs.text).toBe('sunset over mountains');
    expect(result['112'].inputs.text).toBe('ugly, distorted');
  });

  // E2E-R003: Specified seed -> verify mergeWorkflowParams behavior
  it('E2E-R003: seed param does not match noise_seed field - existing behavior preserved', () => {
    const result = mergeWorkflowParams(apiData, { seed: 12345 });

    expect(result['100'].inputs.noise_seed).toBe(469008696527318);
    expect(result['113'].inputs.value).toBe(1280);
    expect(result['98'].inputs.value).toBe(720);
  });

  // E2E-R004: Random seed -> verify generated seed is valid
  it('E2E-R004: random seed generation produces valid positive number', () => {
    const randomSeed = Math.floor(Math.random() * 2147483647) + 1;

    expect(typeof randomSeed).toBe('number');
    expect(randomSeed).toBeGreaterThan(0);
    expect(randomSeed).toBeLessThanOrEqual(2147483648);
    expect(Number.isInteger(randomSeed)).toBe(true);
  });

  // E2E-R005: prompt/negative + new params combined -> all correctly passed
  it('E2E-R005: full prompt vars with all video params - all nodes correctly set', () => {
    const values = {
      active_prompt: 'ocean waves crashing',
      negative_prompt: 'static, blurry',
      sample_image: 'wave_start.png',
      sample_image2: 'wave_end.png',
      width: '1920',
      height: '1080',
      framelen: '81',
      fps: '24',
    };
    const result = replaceVariables(apiData, dataConfig, values);

    expect(result['128'].inputs.text).toBe('ocean waves crashing');
    expect(result['112'].inputs.text).toBe('static, blurry');
    expect(result['31'].inputs.image).toBe('wave_start.png');
    expect(result['39'].inputs.image).toBe('wave_end.png');
    expect(result['113'].inputs.value).toBe('1920');
    expect(result['98'].inputs.value).toBe('1080');
    expect(result['102'].inputs.value).toBe('81');
    expect(result['114'].inputs.value).toBe('24');
  });
});
