/**
 * E2E Tests: 2img2vid CLI Command
 *
 * Tests the 2img2vid CLI registration, help output, and batch integration
 * using child_process to spawn actual Node.js processes.
 *
 * Test Cases:
 * - TC-701: CLI complete execution (help, error handling)
 * - TC-702: Batch CLI batch execution
 */
import { describe, it, expect, afterEach, beforeAll } from '@jest/globals';
import { execSync } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import os from 'os';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CLI_PATH = path.resolve(__dirname, '../../src/index.js');
const PROJECT_ROOT = path.resolve(__dirname, '../../');
const FIXTURES_DIR = path.resolve(__dirname, '../fixtures');

/**
 * Run the CLI as a child process and return stdout.
 */
function runCLI(args, options = {}) {
  const cmd = `node "${CLI_PATH}" ${args}`;
  return execSync(cmd, {
    cwd: PROJECT_ROOT,
    encoding: 'utf-8',
    timeout: 15000,
    ...options,
  });
}

/**
 * Run CLI expecting non-zero exit, return stderr + stdout.
 */
function runCLIExpectFail(args) {
  try {
    runCLI(args);
    return null;
  } catch (e) {
    return {
      exitCode: e.status,
      stdout: e.stdout || '',
      stderr: e.stderr || '',
    };
  }
}

// Track temp files for cleanup
const tmpFiles = [];

afterEach(() => {
  for (const f of tmpFiles) {
    try { fs.unlinkSync(f); } catch { /* ignore */ }
  }
  tmpFiles.length = 0;
});

// ============================================================
// TC-701: 2img2vid CLI complete execution
// ============================================================
describe('TC-701: 2img2vid CLI complete execution', () => {

  it('TC-701-01: --help shows 2img2vid command info', () => {
    const output = runCLI('2img2vid --help');
    expect(output).toContain('Generate video from two images');
    expect(output).toContain('image1');
    expect(output).toContain('image2');
    expect(output).toContain('--prompt');
    expect(output).toContain('--format');
    expect(output).toContain('--workflow');
  });

  it('TC-701-02: --help lists all expected options', () => {
    const output = runCLI('2img2vid --help');
    expect(output).toContain('--negative');
    expect(output).toContain('--output');
    expect(output).toContain('--fps');
    expect(output).toContain('--frames');
    expect(output).toContain('--steps');
    expect(output).toContain('--cfg');
    expect(output).toContain('--seed');
    expect(output).toContain('--width');
    expect(output).toContain('--height');
    expect(output).toContain('--no-upload');
  });

  it('TC-701-03: missing second image causes error', () => {
    const result = runCLIExpectFail('2img2vid img1.png');
    expect(result).not.toBeNull();
    // Commander.js error for missing required argument
    expect(result.stderr).toContain("error: missing required argument 'image2'");
  });

  it('TC-701-04: --no-upload flag is recognized', () => {
    const output = runCLI('2img2vid --help');
    expect(output).toContain('--no-upload');
  });
});

// ============================================================
// TC-702: 2img2video Batch CLI
// ============================================================
describe('TC-702: 2img2video Batch CLI', () => {

  it('TC-702-01: batch --dry-run with 2img2video task validates', () => {
    const tmpFile = path.join(os.tmpdir(), `2img2vid_batch_${Date.now()}.json`);
    const tasks = [
      {
        type: '2img2video',
        image: 'first.png,second.png',
        prompt: 'test transition',
      },
    ];
    fs.writeFileSync(tmpFile, JSON.stringify(tasks, null, 2));
    tmpFiles.push(tmpFile);

    const output = runCLI(`batch "${tmpFile}" --dry-run`);
    expect(output).toContain('Dry run');
    expect(output).toContain('2img2video');
    expect(output).toContain('test transition');
  });

  it('TC-702-02: batch --dry-run with mixed types validates', () => {
    const tmpFile = path.join(os.tmpdir(), `mixed_batch_${Date.now()}.json`);
    const tasks = [
      { type: 'txt2img', prompt: 'text prompt' },
      { type: '2img2video', image: 'a.png,b.png', prompt: 'transition' },
      { type: 'img2vid', image: 'single.png' },
    ];
    fs.writeFileSync(tmpFile, JSON.stringify(tasks, null, 2));
    tmpFiles.push(tmpFile);

    const output = runCLI(`batch "${tmpFile}" --dry-run`);
    expect(output).toContain('Dry run');
    expect(output).toContain('3 tasks');
    expect(output).toContain('2img2video');
  });

  it('TC-702-03: batch with invalid type fails validation', () => {
    const tmpFile = path.join(os.tmpdir(), `invalid_batch_${Date.now()}.json`);
    const tasks = [
      { type: '2img2video', image: 'a.png,b.png' },
      { type: 'unknowntype', image: 'x.png' },
    ];
    fs.writeFileSync(tmpFile, JSON.stringify(tasks, null, 2));
    tmpFiles.push(tmpFile);

    const result = runCLIExpectFail(`batch "${tmpFile}" --dry-run`);
    expect(result).not.toBeNull();
    expect(result.exitCode).not.toBe(0);
  });
});
