/**
 * TEST-007: Existing Workflow Regression Test
 * Validates that adding qwen2511angle did not break existing workflows
 */
import { jest, describe, test, expect, beforeAll } from '@jest/globals';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import ConfigManager from '../../src/utils/config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECT_ROOT = path.resolve(__dirname, '../../');
const CONFIG_PATH = path.join(PROJECT_ROOT, 'config', 'comfy_config.json');

let cm;
let config;

// Expected original workflow configurations (before qwen2511angle was added)
const ORIGINAL_WORKFLOWS = {
  qwen2511t2i: { type: 'txt2img', api: 'comfy/txt_to_image_qwen_image_edit_2511_api.json' },
  qwen2511i2i: { type: 'img2img', api: 'comfy/image_to_image_qwen_image_edit_2511_api.json' },
  qwen2511i2i2: { type: '2img2img', api: 'comfy/image2_to_image_qwen_image_edit_2511_api.json' },
  qwen2511i2i3: { type: '3img2img', api: 'comfy/image3_to_image_qwen_image_edit_2511_api.json' },
  qwen2511i2i4: { type: '4img2img', api: 'comfy/image4_to_image_qwen_image_edit_2511_api.json' },
  zimageturbot2i: { type: 'txt2img', api: 'comfy/txt_to_image_zimage_turbo_api.json' },
  zimageupscale: { type: 'imagescale', api: 'comfy/upscale_z_image_turbo_api.json' }
};

beforeAll(() => {
  cm = new ConfigManager(CONFIG_PATH);
  cm.load();
  config = cm.getConfig();
});

describe('TEST-007: Existing Workflow Regression', () => {
  test('TC-407-01: qwen2511t2i workflow config is unchanged', () => {
    const wf = config.prompts.qwen2511t2i;
    expect(wf).toBeDefined();
    expect(wf.type).toBe(ORIGINAL_WORKFLOWS.qwen2511t2i.type);
    expect(wf.api).toBe(ORIGINAL_WORKFLOWS.qwen2511t2i.api);
  });

  test('TC-407-02: qwen2511i2i workflow config is unchanged', () => {
    const wf = config.prompts.qwen2511i2i;
    expect(wf).toBeDefined();
    expect(wf.type).toBe(ORIGINAL_WORKFLOWS.qwen2511i2i.type);
    expect(wf.api).toBe(ORIGINAL_WORKFLOWS.qwen2511i2i.api);
  });

  test('TC-407-03: zimageupscale workflow config is unchanged', () => {
    const wf = config.prompts.zimageupscale;
    expect(wf).toBeDefined();
    expect(wf.type).toBe(ORIGINAL_WORKFLOWS.zimageupscale.type);
    expect(wf.api).toBe(ORIGINAL_WORKFLOWS.zimageupscale.api);
  });

  test('TC-407-04: list command outputs all original workflows', () => {
    const workflows = cm.listWorkflows();
    const names = workflows.map(w => w.name);

    // All original workflows should still be present
    for (const name of Object.keys(ORIGINAL_WORKFLOWS)) {
      expect(names).toContain(name);
    }

    // Should have at least 7 original + 1 new (qwen2511angle) = 8+
    expect(names.length).toBeGreaterThanOrEqual(8);
  });

  test('TC-407-05: validate command passes for all workflows', () => {
    const result = cm.validate();
    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
  });

  test('TC-407-06: Default img2img workflow is still qwen2511i2i for single image', () => {
    // The default img2img workflow for single image should NOT be qwen2511angle
    // qwen2511i2i should still be the default choice for single image img2img
    const defaultImg2Img = cm.getDefaultWorkflowName('img2img');
    expect(defaultImg2Img).toBe('qwen2511i2i');
  });
});
