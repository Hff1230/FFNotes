/**
 * Unit tests for img2vid command _batchMode behavior
 * Tests: TC-202-06 through TC-202-10
 */
import { jest, describe, test, expect } from '@jest/globals';

const { img2vidCommand } = await import('../../../src/commands/img2vid.js');

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe('img2vid _batchMode', () => {
  const batchOptions = { _batchMode: true };

  test('TC-202-06: Empty input throws Error', async () => {
    await expect(img2vidCommand('', batchOptions)).rejects.toThrow(
      'Input image path is required'
    );
  });

  test('TC-202-07: File not found throws Error', async () => {
    await expect(
      img2vidCommand('/nonexistent/image.jpg', batchOptions)
    ).rejects.toThrow();
  });

  test('TC-202-08: Unsupported image format throws Error', async () => {
    // Create a temp file with unsupported extension
    const fs = await import('fs');
    const os = await import('os');
    const path = await import('path');
    const tmpDir = os.tmpdir();
    const tmpFile = path.join(tmpDir, `test_${Date.now()}.bmp`);
    fs.writeFileSync(tmpFile, 'test');
    try {
      await expect(
        img2vidCommand(tmpFile, batchOptions)
      ).rejects.toThrow('Unsupported image format');
    } finally {
      fs.unlinkSync(tmpFile);
    }
  });

  test('TC-202-09: Unsupported video format throws Error', async () => {
    // Use test fixture image but unsupported format
    const fs = await import('fs');
    const os = await import('os');
    const path = await import('path');
    const tmpDir = os.tmpdir();
    const tmpFile = path.join(tmpDir, `test_${Date.now()}.png`);
    fs.writeFileSync(tmpFile, 'test');
    try {
      await expect(
        img2vidCommand(tmpFile, { ...batchOptions, format: 'avi' })
      ).rejects.toThrow('Unsupported format');
    } finally {
      fs.unlinkSync(tmpFile);
    }
  });

  test('TC-202-10: Config load failure throws Error', async () => {
    const fs = await import('fs');
    const os = await import('os');
    const path = await import('path');
    const tmpDir = os.tmpdir();
    const tmpFile = path.join(tmpDir, `test_${Date.now()}.png`);
    fs.writeFileSync(tmpFile, 'test');
    try {
      await expect(
        img2vidCommand(tmpFile, { ...batchOptions, config: '/nonexistent/config.json' })
      ).rejects.toThrow();
    } finally {
      fs.unlinkSync(tmpFile);
    }
  });
});
