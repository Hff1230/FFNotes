/**
 * Unit tests for imagescale command _batchMode behavior
 * Tests: TC-202-11 through TC-202-15
 */
import { jest, describe, test, expect } from '@jest/globals';

const { imagescaleCommand } = await import('../../../src/commands/imagescale.js');

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe('imagescale _batchMode', () => {
  const batchOptions = { _batchMode: true };

  test('TC-202-11: Empty imagePath throws Error', async () => {
    await expect(imagescaleCommand('', batchOptions)).rejects.toThrow(
      'Input image path is required'
    );
  });

  test('TC-202-12: File not found throws Error', async () => {
    await expect(
      imagescaleCommand('/nonexistent/image.jpg', batchOptions)
    ).rejects.toThrow();
  });

  test('TC-202-13: Unsupported image format throws Error', async () => {
    const fs = await import('fs');
    const os = await import('os');
    const path = await import('path');
    const tmpDir = os.tmpdir();
    const tmpFile = path.join(tmpDir, `test_${Date.now()}.bmp`);
    fs.writeFileSync(tmpFile, 'test');
    try {
      await expect(
        imagescaleCommand(tmpFile, batchOptions)
      ).rejects.toThrow('Unsupported image format');
    } finally {
      fs.unlinkSync(tmpFile);
    }
  });

  test('TC-202-14: Unknown size preset throws Error', async () => {
    const fs = await import('fs');
    const os = await import('os');
    const path = await import('path');
    const tmpDir = os.tmpdir();
    const tmpFile = path.join(tmpDir, `test_${Date.now()}.png`);
    fs.writeFileSync(tmpFile, 'test');
    try {
      await expect(
        imagescaleCommand(tmpFile, { ...batchOptions, size: 'unknown_preset' })
      ).rejects.toThrow();
    } finally {
      fs.unlinkSync(tmpFile);
    }
  });

  test('TC-202-15: Config load failure throws Error', async () => {
    const fs = await import('fs');
    const os = await import('os');
    const path = await import('path');
    const tmpDir = os.tmpdir();
    const tmpFile = path.join(tmpDir, `test_${Date.now()}.png`);
    fs.writeFileSync(tmpFile, 'test');
    try {
      await expect(
        imagescaleCommand(tmpFile, { ...batchOptions, config: '/nonexistent/config.json' })
      ).rejects.toThrow();
    } finally {
      fs.unlinkSync(tmpFile);
    }
  });
});
