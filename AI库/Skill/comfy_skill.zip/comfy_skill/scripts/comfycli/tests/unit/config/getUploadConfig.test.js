import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import fs from 'fs';
import path from 'path';
import os from 'os';
import ConfigManager from '../../../src/utils/config.js';

describe('ConfigManager.getUploadConfig()', () => {
  let tmpDir;

  beforeEach(() => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'comfycli-test-'));
  });

  afterEach(() => {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  // 103-1: server_config 含完整 upload -> 返回完整 upload 对象
  it('should return full upload config when upload field exists', () => {
    const comfyConfig = { prompts: {} };
    const serverConfig = {
      upload: {
        server: 'https://upload.example.com',
        user: 'admin',
        pwd: 'secret',
        dir: '/images',
        share_url: 'https://share.example.com'
      }
    };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify(serverConfig));

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();

    const result = cm.getUploadConfig();

    expect(result).toEqual({
      server: 'https://upload.example.com',
      user: 'admin',
      pwd: 'secret',
      dir: '/images',
      share_url: 'https://share.example.com'
    });
  });

  // 103-2: server_config 无 upload 字段 -> 返回 null
  it('should return null when upload field does not exist', () => {
    const comfyConfig = { prompts: {} };
    const serverConfig = { host: '1.2.3.4', port: 9010 };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify(serverConfig));

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();

    const result = cm.getUploadConfig();

    expect(result).toBeNull();
  });

  // 103-3: upload 字段存在但为 null -> 返回 null
  it('should return null when upload field is null', () => {
    const comfyConfig = { prompts: {} };
    const serverConfig = { upload: null };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify(serverConfig));

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();

    const result = cm.getUploadConfig();

    expect(result).toBeNull();
  });

  // 103-4: server_config 不存在，回退到 comfy_config 的 upload
  it('should fall back to comfy_config upload when server_config does not exist', () => {
    const comfyConfig = {
      prompts: {},
      upload: {
        server: 'https://fallback.example.com',
        user: 'guest',
        pwd: 'pass123',
        dir: '/uploads',
        share_url: 'https://fallback-share.example.com'
      }
    };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();

    const result = cm.getUploadConfig();

    expect(result).toEqual({
      server: 'https://fallback.example.com',
      user: 'guest',
      pwd: 'pass123',
      dir: '/uploads',
      share_url: 'https://fallback-share.example.com'
    });
  });

  // 103-5: 两个配置都没有 upload -> 返回 null
  it('should return null when neither config has upload', () => {
    const comfyConfig = { prompts: {} };
    const serverConfig = { host: '1.2.3.4' };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify(serverConfig));

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();

    const result = cm.getUploadConfig();

    expect(result).toBeNull();
  });
});
