/**
 * Unit tests for batch.js - validateTasks, getProgressFilePath, initProgress,
 * saveProgress, loadProgress
 *
 * TEST-102: Task validation + progress file management tests
 */
import { jest } from '@jest/globals';
import path from 'path';
import fs from 'fs';
import os from 'os';
import {
  validateTasks,
  getProgressFilePath,
  initProgress,
  saveProgress,
  loadProgress
} from '../../../src/commands/batch.js';

// ---------------------------------------------------------------------------
// Helper: temp directory for file-based tests, cleaned up after all tests
// ---------------------------------------------------------------------------
const TMP_DIR = path.join(os.tmpdir(), 'comfycli-test-102');

beforeAll(() => {
  fs.mkdirSync(TMP_DIR, { recursive: true });
});

afterAll(() => {
  fs.rmSync(TMP_DIR, { recursive: true, force: true });
});

// ---------------------------------------------------------------------------
// validateTasks (8 tests)
// ---------------------------------------------------------------------------
describe('validateTasks', () => {
  test('TC-102-01 - Valid task array with all 5 types does not throw', () => {
    const tasks = [
      { type: 'txt2img' },
      { type: 'img2img' },
      { type: 'txt2vid' },
      { type: 'img2vid' },
      { type: 'imagescale' }
    ];
    expect(() => validateTasks(tasks)).not.toThrow();
  });

  test('TC-102-02 - Non-array input throws', () => {
    expect(() => validateTasks('not an array')).toThrow(
      'JSON file must contain an array of tasks'
    );
  });

  test('TC-102-03 - Empty array does not throw', () => {
    expect(() => validateTasks([])).not.toThrow();
  });

  test('TC-102-04 - Missing type field throws at index 0', () => {
    expect(() => validateTasks([{ prompt: 'hello' }])).toThrow(
      'Task at index 0 is missing "type" field'
    );
  });

  test('TC-102-05 - Unsupported type throws with message', () => {
    expect(() => validateTasks([{ type: 'unknown' }])).toThrow(
      'unsupported type "unknown"'
    );
  });

  test('TC-102-06 - Second task missing type references index 1', () => {
    const tasks = [
      { type: 'txt2img' },
      { prompt: 'no type here' }
    ];
    expect(() => validateTasks(tasks)).toThrow('index 1');
  });

  test('TC-102-07 - Single element array does not throw', () => {
    expect(() => validateTasks([{ type: 'txt2img' }])).not.toThrow();
  });

  test('TC-102-08 - imagescale type is supported', () => {
    expect(() => validateTasks([{ type: 'imagescale' }])).not.toThrow();
  });
});

// ---------------------------------------------------------------------------
// getProgressFilePath (6 tests)
// ---------------------------------------------------------------------------
describe('getProgressFilePath', () => {
  test('TC-102-09 - Standard path replaces .json with .p', () => {
    const input = path.normalize('/project/tasks.json');
    const result = getProgressFilePath(input);
    expect(result).toBe(path.normalize('/project/tasks.p'));
  });

  test('TC-102-10 - Windows-style path replaces .json with .p', () => {
    const input = path.normalize('C:/project/tasks.json');
    const result = getProgressFilePath(input);
    expect(result).toBe(path.normalize('C:/project/tasks.p'));
  });

  test('TC-102-11 - No extension appends .p', () => {
    const input = path.normalize('/project/tasks');
    const result = getProgressFilePath(input);
    expect(result).toBe(path.normalize('/project/tasks.p'));
  });

  test('TC-102-12 - Multiple extensions strips last and adds .p', () => {
    const input = path.normalize('/project/tasks.test.json');
    const result = getProgressFilePath(input);
    expect(result).toBe(path.normalize('/project/tasks.test.p'));
  });

  test('TC-102-13 - Chinese path characters preserved', () => {
    const input = path.normalize('/项目/武松/tasks.json');
    const result = getProgressFilePath(input);
    expect(result).toBe(path.normalize('/项目/武松/tasks.p'));
  });

  test('TC-102-14 - Space in path preserved', () => {
    const input = path.normalize('/my project/tasks.json');
    const result = getProgressFilePath(input);
    expect(result).toBe(path.normalize('/my project/tasks.p'));
  });
});

// ---------------------------------------------------------------------------
// initProgress (2 tests)
// ---------------------------------------------------------------------------
describe('initProgress', () => {
  test('TC-102-15 - Normal init with 3 tasks verifies all fields', () => {
    const tasks = [
      { type: 'txt2img' },
      { type: 'img2img' },
      { type: 'txt2vid' }
    ];
    const jsonFilePath = '/project/batch.json';
    const progress = initProgress(tasks, jsonFilePath);

    expect(progress.sourceFile).toBe('batch.json');
    expect(progress.totalTasks).toBe(3);
    expect(progress.nextIndex).toBe(0);
    expect(progress.results).toEqual([]);
    expect(progress.startTime).toBeDefined();
    expect(typeof progress.startTime).toBe('string');
    expect(progress.lastUpdate).toBeDefined();
    expect(typeof progress.lastUpdate).toBe('string');
  });

  test('TC-102-16 - Empty task array sets totalTasks to 0', () => {
    const progress = initProgress([], '/project/empty.json');
    expect(progress.totalTasks).toBe(0);
    expect(progress.nextIndex).toBe(0);
    expect(progress.results).toEqual([]);
  });
});

// ---------------------------------------------------------------------------
// saveProgress + loadProgress (5 tests)
// ---------------------------------------------------------------------------
describe('saveProgress + loadProgress', () => {
  test('TC-102-17 - Save then load produces consistent data', () => {
    const progressPath = path.join(TMP_DIR, 'consistency.p');
    const progress = {
      sourceFile: 'batch.json',
      startTime: '2025-01-01T00:00:00.000Z',
      lastUpdate: '2025-01-01T00:00:01.000Z',
      totalTasks: 2,
      nextIndex: 1,
      results: [{ index: 0, type: 'txt2img', status: 'success' }]
    };

    saveProgress(progressPath, progress);
    const loaded = loadProgress(progressPath);

    expect(loaded).toEqual(progress);

    // Clean up
    fs.unlinkSync(progressPath);
  });

  test('TC-102-18 - Load nonexistent file returns null', () => {
    const progressPath = path.join(TMP_DIR, 'nonexistent.p');
    const result = loadProgress(progressPath);
    expect(result).toBeNull();
  });

  test('TC-102-19 - Load corrupted JSON file returns null', () => {
    const progressPath = path.join(TMP_DIR, 'corrupted.p');
    fs.writeFileSync(progressPath, 'this is not valid json {{{', 'utf-8');

    const result = loadProgress(progressPath);
    expect(result).toBeNull();

    // Clean up
    fs.unlinkSync(progressPath);
  });

  test('TC-102-20 - Update progress after execution (nextIndex=2, results.length=2)', () => {
    const progressPath = path.join(TMP_DIR, 'update.p');
    const progress = {
      sourceFile: 'batch.json',
      startTime: '2025-01-01T00:00:00.000Z',
      lastUpdate: '2025-01-01T00:00:01.000Z',
      totalTasks: 3,
      nextIndex: 1,
      results: [{ index: 0, type: 'txt2img', status: 'success' }]
    };

    // Simulate completing task at index 1
    progress.results.push({
      index: 1,
      type: 'img2img',
      status: 'success'
    });
    progress.nextIndex = 2;
    progress.lastUpdate = new Date().toISOString();

    saveProgress(progressPath, progress);
    const loaded = loadProgress(progressPath);

    expect(loaded.nextIndex).toBe(2);
    expect(loaded.results).toHaveLength(2);
    expect(loaded.results[1].type).toBe('img2img');

    // Clean up
    fs.unlinkSync(progressPath);
  });

  test('TC-102-21 - Chinese content in progress file round-trips correctly', () => {
    const progressPath = path.join(TMP_DIR, 'chinese.p');
    const progress = {
      sourceFile: '批量任务.json',
      startTime: '2025-01-01T00:00:00.000Z',
      lastUpdate: '2025-01-01T00:00:01.000Z',
      totalTasks: 1,
      nextIndex: 1,
      results: [{
        index: 0,
        type: 'txt2img',
        status: 'success',
        files: ['输出/图片01.png', '输出/图片02.png']
      }]
    };

    saveProgress(progressPath, progress);
    const loaded = loadProgress(progressPath);

    expect(loaded.sourceFile).toBe('批量任务.json');
    expect(loaded.results[0].files).toEqual(['输出/图片01.png', '输出/图片02.png']);

    // Clean up
    fs.unlinkSync(progressPath);
  });
});
