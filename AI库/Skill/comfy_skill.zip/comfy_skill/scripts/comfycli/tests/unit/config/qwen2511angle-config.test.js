/**
 * TEST-001: qwen2511angle Configuration Validation
 * Validates the qwen2511angle workflow configuration in comfy_config.json
 */
import { jest, describe, test, expect, beforeAll } from '@jest/globals';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import ConfigManager from '../../../src/utils/config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECT_ROOT = path.resolve(__dirname, '../../../');
const CONFIG_PATH = path.join(PROJECT_ROOT, 'config', 'comfy_config.json');
const API_DIR = path.join(PROJECT_ROOT, 'config', 'comfy');

let configContent;
let config;
let angleConfig;
let apiPath;
let apiContent;

beforeAll(() => {
  configContent = fs.readFileSync(CONFIG_PATH, 'utf-8');
  config = JSON.parse(configContent);
  angleConfig = config.prompts.qwen2511angle;
  apiPath = path.resolve(API_DIR, 'image_angles_qwen_image_edit_2511_api.json');
  apiContent = fs.readFileSync(apiPath, 'utf-8');
});

describe('TEST-001: qwen2511angle Configuration Validation', () => {
  test('TC-401-01: JSON format is valid', () => {
    expect(() => JSON.parse(configContent)).not.toThrow();
  });

  test('TC-401-02: prompts object contains qwen2511angle', () => {
    expect(config.prompts).toBeDefined();
    expect(config.prompts.qwen2511angle).toBeDefined();
  });

  test('TC-401-03: description field exists and is non-empty string', () => {
    expect(typeof angleConfig.description).toBe('string');
    expect(angleConfig.description.length).toBeGreaterThan(0);
  });

  test('TC-401-04: type field equals "img2img"', () => {
    expect(angleConfig.type).toBe('img2img');
  });

  test('TC-401-05: api field is correct path', () => {
    expect(angleConfig.api).toBe('comfy/image_angles_qwen_image_edit_2511_api.json');
  });

  test('TC-401-06: API file exists on disk', () => {
    expect(fs.existsSync(apiPath)).toBe(true);
  });

  test('TC-401-07: API file is valid JSON', () => {
    expect(() => JSON.parse(apiContent)).not.toThrow();
  });

  test('TC-401-08: data field exists and is an array', () => {
    expect(Array.isArray(angleConfig.data)).toBe(true);
  });

  test('TC-401-09: data contains 4 mapping items', () => {
    expect(angleConfig.data.length).toBe(4);
  });

  test('TC-401-10: data[0] maps to node 111 prompt', () => {
    const entry = angleConfig.data[0];
    const key = Object.keys(entry)[0];
    expect(key).toContain('active##111##inputs##prompt');
    expect(entry[key]).toBe('##active_prompt##');
  });

  test('TC-401-11: data[1] maps to node 78 image', () => {
    const entry = angleConfig.data[1];
    const key = Object.keys(entry)[0];
    expect(key).toContain('image##78##inputs##image');
    expect(entry[key]).toBe('##sample_image##');
  });

  test('TC-401-12: data[2] maps to node 112 width', () => {
    const entry = angleConfig.data[2];
    const key = Object.keys(entry)[0];
    expect(key).toContain('width##112##inputs##width');
    expect(entry[key]).toBe('##width##');
  });

  test('TC-401-13: data[3] maps to node 112 height', () => {
    const entry = angleConfig.data[3];
    const key = Object.keys(entry)[0];
    expect(key).toContain('height##112##inputs##height');
    expect(entry[key]).toBe('##height##');
  });

  test('TC-401-14: Variable placeholders format is correct', () => {
    const allValues = angleConfig.data.map(e => Object.values(e)[0]);
    expect(allValues).toContain('##active_prompt##');
    expect(allValues).toContain('##sample_image##');
    expect(allValues).toContain('##width##');
    expect(allValues).toContain('##height##');
  });

  test('TC-401-15: Existing workflow count has not decreased', () => {
    const workflowCount = Object.keys(config.prompts).length;
    expect(workflowCount).toBeGreaterThanOrEqual(8);
  });

  test('TC-401-16: validate command produces no errors', () => {
    const cm = new ConfigManager(CONFIG_PATH);
    const loadResult = cm.load();
    expect(loadResult).toBe(true);
    const validation = cm.validate();
    expect(validation.valid).toBe(true);
    expect(validation.errors).toHaveLength(0);
  });
});
