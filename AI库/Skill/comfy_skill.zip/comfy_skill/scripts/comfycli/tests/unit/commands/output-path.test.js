/**
 * Unit tests for command output path parameter passing
 * Tests: TC-015 through TC-019
 *
 * Verifies that each command correctly uses options.output
 * and does not fall back to hardcoded paths.
 */
import { jest, describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import path from 'path';
import fs from 'fs';

// ── Helper: Check source code of a command for options.output usage ──
function getCommandSource(commandName) {
  const mapping = {
    'txt2img': 'txt2img.js',
    'img2img': 'img2img.js',
    'txt2vid': 'txt2vid.js',
    'batch': 'batch.js',
    'run': 'run.js',
  };
  const fileName = mapping[commandName];
  if (!fileName) return null;
  const filePath = path.join(process.cwd(), 'src', 'commands', fileName);
  return fs.readFileSync(filePath, 'utf-8');
}

describe('Command output path usage', () => {
  // ── TC-015: txt2img uses options.output ──
  it('TC-015: txt2img uses options.output for output directory', () => {
    const source = getCommandSource('txt2img');
    expect(source).toBeTruthy();

    // Should reference options.output
    expect(source).toMatch(/options\.output/);

    // Should NOT have hardcoded fallback to './output'
    expect(source).not.toMatch(/options\.output\s*\|\|\s*['"]\.\//);
    expect(source).not.toMatch(/outputDir\s*=\s*['"]\.\/output['"]/);

    // Should use generateOutputPath with options.output
    expect(source).toMatch(/generateOutputPath\(outputDir/);
  });

  // ── TC-016: img2img uses options.output ──
  it('TC-016: img2img uses options.output for output directory', () => {
    const source = getCommandSource('img2img');
    expect(source).toBeTruthy();

    expect(source).toMatch(/options\.output/);
    expect(source).not.toMatch(/options\.output\s*\|\|\s*['"]\.\//);
    expect(source).not.toMatch(/outputDir\s*=\s*['"]\.\/output['"]/);
  });

  // ── TC-017: txt2vid uses options.output ──
  it('TC-017: txt2vid uses options.output for output directory', () => {
    const source = getCommandSource('txt2vid');
    expect(source).toBeTruthy();

    expect(source).toMatch(/options\.output/);
    expect(source).not.toMatch(/options\.output\s*\|\|\s*['"]\.\//);
    expect(source).not.toMatch(/outputDir\s*=\s*['"]\.\/output['"]/);
  });

  // ── TC-018: batch passes globalOptions.output to tasks ──
  it('TC-018: batch correctly passes globalOptions.output to tasks', () => {
    const source = getCommandSource('batch');
    expect(source).toBeTruthy();

    // Batch should pass globalOptions.output to task mapping functions
    expect(source).toMatch(/globalOptions\.output/);

    // Should NOT have hardcoded output fallback
    expect(source).not.toMatch(/globalOptions\.output\s*\|\|\s*['"]\.\//);
  });

  // ── TC-019: run uses options.output ──
  it('TC-019: run uses options.output for output directory', () => {
    const source = getCommandSource('run');
    expect(source).toBeTruthy();

    expect(source).toMatch(/options\.output/);
    expect(source).not.toMatch(/options\.output\s*\|\|\s*['"]\.\//);
    expect(source).not.toMatch(/outputDir\s*=\s*['"]\.\/output['"]/);
  });
});

// ── Verify batch.js correctly maps output for each task type ──
describe('Batch task output path mapping', () => {
  let batchSource;

  beforeEach(() => {
    batchSource = getCommandSource('batch');
  });

  it('should pass output in txt2img task mapping', () => {
    // mapTxt2ImgArgs should include output: globalOptions.output || task.output
    expect(batchSource).toMatch(/output:\s*globalOptions\.output\s*\|\|\s*task\.output/);
  });

  it('should pass output in img2img task mapping', () => {
    // mapImg2ImgArgs should include output
    expect(batchSource).toContain('mapImg2ImgArgs');
    // Verify output field exists in mapImg2ImgArgs
    const mapFuncMatch = batchSource.match(/function mapImg2ImgArgs[\s\S]*?^}/m);
    expect(mapFuncMatch).toBeTruthy();
    expect(mapFuncMatch[0]).toMatch(/output:\s*globalOptions\.output/);
  });
});
