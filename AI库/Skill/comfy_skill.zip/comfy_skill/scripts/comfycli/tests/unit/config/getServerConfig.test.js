import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import fs from 'fs';
import path from 'path';
import os from 'os';
import ConfigManager from '../../../src/utils/config.js';

describe('ConfigManager.getServerConfig()', () => {
  let tmpDir;

  beforeEach(() => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'comfycli-test-'));
  });

  afterEach(() => {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  // 102-1: server_config 存在 → 返回 server_config 中的值
  it('should return server_config values when server_config exists', () => {
    const comfyConfig = { prompts: {} };
    const serverConfig = { host: '1.2.3.4', port: 9010, api_key: 'test' };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify(serverConfig));

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();

    const result = cm.getServerConfig();
    expect(result).toEqual({ host: '1.2.3.4', port: 9010, apiKey: 'test' });
  });

  // 102-2: server_config 不存在, 回退到 comfy_config
  it('should fall back to comfy_config when server_config does not exist', () => {
    const comfyConfig = { host: '10.0.0.1', port: 5555, api_key: 'fallback', prompts: {} };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();

    const result = cm.getServerConfig();
    expect(result).toEqual({ host: '10.0.0.1', port: 5555, apiKey: 'fallback' });
  });

  // 102-3: 两个配置都没有 host/port → 返回默认值
  it('should return defaults when neither config has host/port', () => {
    const comfyConfig = { prompts: {} };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify({}));

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();

    const result = cm.getServerConfig();
    expect(result).toEqual({ host: '127.0.0.1', port: 8188, apiKey: '' });
  });

  // 102-4: server_config 仅含 host → port 和 apiKey 使用默认值
  it('should use defaults for missing port and apiKey', () => {
    const comfyConfig = { prompts: {} };
    const serverConfig = { host: 'custom.com' };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify(serverConfig));

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();

    const result = cm.getServerConfig();
    expect(result).toEqual({ host: 'custom.com', port: 8188, apiKey: '' });
  });

  // 102-5: load() 未调用且文件不存在 → 返回默认值(不崩溃)
  it('should return defaults when load() was not called and file does not exist', () => {
    const cm = new ConfigManager(
      path.join(tmpDir, 'nonexistent_config.json'),
      path.join(tmpDir, 'nonexistent_server.json')
    );

    // 直接调用 getServerConfig，不先调 load()
    // load() 会被自动调用但因文件不存在而失败
    // this.config 和 this.serverConfig 均为 null
    // source = this.serverConfig || this.config => null
    // source?.host => undefined, || '127.0.0.1'
    const result = cm.getServerConfig();
    expect(result).toEqual({ host: '127.0.0.1', port: 8188, apiKey: '' });
  });
});
