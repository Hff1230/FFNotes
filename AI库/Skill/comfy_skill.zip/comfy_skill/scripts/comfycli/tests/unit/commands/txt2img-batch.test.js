/**
 * Unit tests for txt2img command _batchMode behavior
 * Tests: TC-201-01 through TC-201-06
 */
import { jest, describe, test, expect, beforeEach } from '@jest/globals';

const { txt2imgCommand } = await import('../../../src/commands/txt2img.js');

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe('txt2img _batchMode', () => {
  const batchOptions = { _batchMode: true };

  test('TC-201-01: Empty prompt throws Error "Prompt is required"', async () => {
    await expect(txt2imgCommand('', batchOptions)).rejects.toThrow('Prompt is required');
  });

  test('TC-201-02: Whitespace prompt throws Error "Prompt is required"', async () => {
    await expect(txt2imgCommand('   ', batchOptions)).rejects.toThrow('Prompt is required');
  });

  test('TC-201-03: Config load failure throws Error', async () => {
    await expect(
      txt2imgCommand('a sunset', { ...batchOptions, config: '/nonexistent/config.json' })
    ).rejects.toThrow();
  });

  test('TC-201-04: Workflow not found throws Error', async () => {
    await expect(
      txt2imgCommand('a sunset', batchOptions)
    ).rejects.toThrow();
  });

  test('TC-201-05: Successful execution returns result object', async () => {
    // In batch mode, success returns { success, files, metadata }
    // Full success path requires ComfyUI - tested in integration (TEST-301)
    // Unit level: verify _batchMode causes throw instead of process.exit
    // The real config connects to ComfyUI which nock blocks
    await expect(txt2imgCommand('test', batchOptions)).rejects.toThrow();
  });

  test('TC-201-06: Execution failure throws (not process.exit)', async () => {
    // Verify that in batch mode, errors are thrown not process.exit
    // The config file will fail to load, which should throw in _batchMode
    await expect(
      txt2imgCommand('a sunset', { ...batchOptions, config: '/invalid/path.json' })
    ).rejects.toThrow();
  });
});
