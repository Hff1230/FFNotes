/**
 * Edge case tests for resource_downloader.js
 * Tests: URL special characters, network issues, concurrent downloads, etc.
 */
import { jest } from '@jest/globals';
import fs from 'fs';
import path from 'path';
import os from 'os';
import resourceDownloader from '../../src/utils/resource_downloader.js';

const { isUrl, getFilenameFromUrl, downloadResource, resolveInputResource, resolveInputResources } = resourceDownloader;

// Helper function to create mock fetch response
function createMockResponse(data, status = 200, statusText = 'OK', headers = {}) {
  return {
    ok: status >= 200 && status < 300,
    status,
    statusText,
    headers: new Map(Object.entries(headers)),
    arrayBuffer: async () => {
      if (Buffer.isBuffer(data)) {
        return data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
      }
      return Buffer.from(data).buffer;
    }
  };
}

// Helper to create delayed mock response
function createDelayedMockResponse(data, delayMs, status = 200) {
  return {
    ok: status >= 200 && status < 300,
    status,
    statusText: status === 200 ? 'OK' : 'Error',
    arrayBuffer: async () => {
      await new Promise(resolve => setTimeout(resolve, delayMs));
      if (Buffer.isBuffer(data)) {
        return data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
      }
      return Buffer.from(data).buffer;
    }
  };
}

describe('Edge Cases - resource_downloader', () => {
  let tmpDir;
  let originalFetch;

  beforeEach(() => {
    // Create unique temp directory for each test
    tmpDir = path.join(os.tmpdir(), `resource_downloader_edge_test_${Date.now()}_${Math.random().toString(36).slice(2)}`);
    fs.mkdirSync(tmpDir, { recursive: true });
    originalFetch = global.fetch;
  });

  afterEach(() => {
    // Restore original fetch
    global.fetch = originalFetch;

    // Clean up temp directory
    if (fs.existsSync(tmpDir)) {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    }
  });

  // ========================================
  // E001 - URL Special Characters
  // ========================================
  describe('E001 - URL Special Characters', () => {
    test('URL with spaces (encoded as %20)', async () => {
      const testContent = Buffer.from('test image content');
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(testContent));

      const url = 'http://example.com/images/photo%20name.jpg';
      const result = await downloadResource(url, tmpDir);

      expect(global.fetch).toHaveBeenCalledWith(url);
      expect(fs.existsSync(result)).toBe(true);
      expect(fs.readFileSync(result).toString()).toBe('test image content');
    });

    test('URL with special characters (!@#$%^&*)', async () => {
      const testContent = Buffer.from('special chars test');
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(testContent));

      const url = 'http://example.com/files/test%21%40%23.jpg';
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
    });

    test('URL with plus sign and equals', async () => {
      const testContent = Buffer.from('plus test');
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(testContent));

      const url = 'http://example.com/api?file=test+file.jpg&token=abc=123';
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
    });
  });

  // ========================================
  // E002 - Very Long URL (2000+ characters)
  // ========================================
  describe('E002 - Very Long URL', () => {
    test('URL with 2000+ characters (in query string to avoid path length limits)', async () => {
      const testContent = Buffer.from('long url test');
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(testContent));

      // Create a very long URL with long query string (not in path to avoid Windows path limits)
      const baseUrl = 'http://example.com/img.jpg';
      const longQuery = '?token=' + 'a'.repeat(2000);
      const url = baseUrl + longQuery;

      expect(url.length).toBeGreaterThan(2000);

      const result = await downloadResource(url, tmpDir);

      expect(global.fetch).toHaveBeenCalledWith(url);
      expect(fs.existsSync(result)).toBe(true);
      expect(path.basename(result)).toBe('img.jpg');
    });

    test('URL with very long query string', async () => {
      const testContent = Buffer.from('long query test');
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(testContent));

      const baseUrl = 'http://example.com/image.jpg';
      const longQuery = '?token=' + 'x'.repeat(2500);
      const url = baseUrl + longQuery;

      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
      expect(path.basename(result)).toBe('image.jpg');
    });
  });

  // ========================================
  // E003 - Chinese Filename (URL encoded)
  // ========================================
  describe('E003 - Chinese Filename', () => {
    test('URL encoded Chinese filename', async () => {
      const testContent = Buffer.from('chinese filename test');
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(testContent));

      // Chinese characters URL encoded
      const url = 'http://example.com/%E5%9B%BE%E7%89%87.jpg'; // .jpg
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
      // The decoded filename should contain Chinese characters
      expect(decodeURIComponent(path.basename(result))).toContain('.jpg');
    });

    test('Mixed Chinese and English filename', async () => {
      const testContent = Buffer.from('mixed filename test');
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(testContent));

      const url = 'http://example.com/test%E5%9B%BE%E7%89%87file.jpg';
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
    });
  });

  // ========================================
  // E004 - Network Timeout (simulated)
  // ========================================
  describe('E004 - Network Timeout', () => {
    test('Simulated slow response completes eventually', async () => {
      const testContent = Buffer.from('slow response test');
      // Use a short delay that won't cause actual timeout
      global.fetch = jest.fn().mockResolvedValue(createDelayedMockResponse(testContent, 50));

      const url = 'http://example.com/slow.jpg';
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
    });

    test('Fetch rejection is propagated', async () => {
      global.fetch = jest.fn().mockRejectedValue(new Error('Network error'));

      const url = 'http://example.com/error.jpg';

      await expect(downloadResource(url, tmpDir)).rejects.toThrow('Network error');
    });

    test('Fetch timeout simulation with AbortController', async () => {
      const testContent = Buffer.from('timeout test');
      let wasAborted = false;

      global.fetch = jest.fn().mockImplementation(async (url, options) => {
        // Simulate checking for abort signal
        if (options?.signal) {
          // Simulate a slow response that would be aborted
          await new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
              resolve(createMockResponse(testContent));
            }, 100);

            options.signal?.addEventListener('abort', () => {
              wasAborted = true;
              clearTimeout(timeout);
              reject(new Error('The operation was aborted'));
            });
          });
        }
        return createMockResponse(testContent);
      });

      const controller = new AbortController();

      // Start the fetch and abort immediately
      const fetchPromise = downloadResource('http://example.com/abort.jpg', tmpDir);
      controller.abort();

      // The download should still complete since our implementation doesn't use AbortController
      // This test verifies the mock behavior
      const result = await fetchPromise;
      expect(fs.existsSync(result)).toBe(true);
    });
  });

  // ========================================
  // E005 - HTTP Redirect Behavior
  // ========================================
  describe('E005 - HTTP Redirect Behavior', () => {
    test('HTTP 301 response is treated as error (redirect not followed by default)', async () => {
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(Buffer.from(''), 301, 'Moved Permanently'));

      const url = 'http://example.com/old-path.jpg';

      await expect(downloadResource(url, tmpDir)).rejects.toThrow('HTTP 301');
    });

    test('HTTP 302 response is treated as error', async () => {
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(Buffer.from(''), 302, 'Found'));

      const url = 'http://example.com/redirect.jpg';

      await expect(downloadResource(url, tmpDir)).rejects.toThrow('HTTP 302');
    });

    test('HTTP 307 (Temporary Redirect) is treated as error', async () => {
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(Buffer.from(''), 307, 'Temporary Redirect'));

      const url = 'http://example.com/temp-redirect.jpg';

      await expect(downloadResource(url, tmpDir)).rejects.toThrow('HTTP 307');
    });

    test('HTTP 308 (Permanent Redirect) is treated as error', async () => {
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(Buffer.from(''), 308, 'Permanent Redirect'));

      const url = 'http://example.com/perm-redirect.jpg';

      await expect(downloadResource(url, tmpDir)).rejects.toThrow('HTTP 308');
    });
  });

  // ========================================
  // E006 - Large File Download
  // ========================================
  describe('E006 - Large File Download', () => {
    test('Download 5MB file', async () => {
      // Create 5MB buffer
      const size = 5 * 1024 * 1024;
      const largeContent = Buffer.alloc(size, 'x');
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(largeContent));

      const url = 'http://example.com/large-file.bin';
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
      const stats = fs.statSync(result);
      expect(stats.size).toBe(size);
    });

    test('Download file with exact boundary size (1MB)', async () => {
      const size = 1024 * 1024; // Exactly 1MB
      const content = Buffer.alloc(size, 'a');
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(content));

      const url = 'http://example.com/exact-1mb.bin';
      const result = await downloadResource(url, tmpDir);

      const stats = fs.statSync(result);
      expect(stats.size).toBe(size);
    });
  });

  // ========================================
  // E007 - Chunked Transfer Encoding
  // ========================================
  describe('E007 - Chunked Transfer Encoding', () => {
    test('Simulated chunked response', async () => {
      const chunks = [
        Buffer.from('chunk1'),
        Buffer.from('chunk2'),
        Buffer.from('chunk3')
      ];
      const combinedContent = Buffer.concat(chunks);

      global.fetch = jest.fn().mockResolvedValue(createMockResponse(combinedContent));

      const url = 'http://example.com/chunked.bin';
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
      expect(fs.readFileSync(result).toString()).toBe('chunk1chunk2chunk3');
    });

    test('Response with Transfer-Encoding header', async () => {
      const testContent = Buffer.from('chunked content test');
      global.fetch = jest.fn().mockResolvedValue(
        createMockResponse(testContent, 200, 'OK', { 'transfer-encoding': 'chunked' })
      );

      const url = 'http://example.com/transfer-encoded.bin';
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
    });
  });

  // ========================================
  // E008 - Various Content-Types
  // ========================================
  describe('E008 - Various Content-Types', () => {
    test('Content-Type: image/jpeg', async () => {
      const testContent = Buffer.from('jpeg content');
      global.fetch = jest.fn().mockResolvedValue(
        createMockResponse(testContent, 200, 'OK', { 'content-type': 'image/jpeg' })
      );

      const url = 'http://example.com/image.jpg';
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
    });

    test('Content-Type: application/octet-stream', async () => {
      const testContent = Buffer.from('binary content');
      global.fetch = jest.fn().mockResolvedValue(
        createMockResponse(testContent, 200, 'OK', { 'content-type': 'application/octet-stream' })
      );

      const url = 'http://example.com/file.bin';
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
    });

    test('Content-Type: application/json (still downloads)', async () => {
      const testContent = Buffer.from('{"key": "value"}');
      global.fetch = jest.fn().mockResolvedValue(
        createMockResponse(testContent, 200, 'OK', { 'content-type': 'application/json' })
      );

      const url = 'http://example.com/data.json';
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
      expect(fs.readFileSync(result).toString()).toBe('{"key": "value"}');
    });

    test('Missing Content-Type header', async () => {
      const testContent = Buffer.from('no content type');
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(testContent));

      const url = 'http://example.com/no-content-type.dat';
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
    });

    test('Content-Type with charset', async () => {
      const testContent = Buffer.from('text with charset');
      global.fetch = jest.fn().mockResolvedValue(
        createMockResponse(testContent, 200, 'OK', { 'content-type': 'text/html; charset=utf-8' })
      );

      const url = 'http://example.com/page.html';
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
    });
  });

  // ========================================
  // E009 - Concurrent Downloads
  // ========================================
  describe('E009 - Concurrent Downloads', () => {
    test('Download multiple files concurrently', async () => {
      const files = [
        { url: 'http://example.com/file1.jpg', content: 'content1' },
        { url: 'http://example.com/file2.jpg', content: 'content2' },
        { url: 'http://example.com/file3.jpg', content: 'content3' }
      ];

      global.fetch = jest.fn().mockImplementation(async (url) => {
        const file = files.find(f => f.url === url);
        return createMockResponse(Buffer.from(file.content));
      });

      const promises = files.map(f => downloadResource(f.url, tmpDir));
      const results = await Promise.all(promises);

      expect(results).toHaveLength(3);
      results.forEach((result, index) => {
        expect(fs.existsSync(result)).toBe(true);
        expect(fs.readFileSync(result).toString()).toBe(files[index].content);
      });
    });

    test('resolveInputResources with concurrent downloads', async () => {
      const inputs = [
        'http://example.com/a.jpg',
        'http://example.com/b.jpg',
        'http://example.com/c.jpg'
      ];

      global.fetch = jest.fn().mockResolvedValue(createMockResponse(Buffer.from('test')));

      const result = await resolveInputResources(inputs, tmpDir);

      expect(result.localPaths).toHaveLength(3);
      expect(result.downloaded).toHaveLength(3);
      result.localPaths.forEach(p => {
        expect(fs.existsSync(p)).toBe(true);
      });
    });

    test('Mixed concurrent downloads and local paths', async () => {
      // Create a local file
      const localFile = path.join(tmpDir, 'local.txt');
      fs.writeFileSync(localFile, 'local content');

      const inputs = [
        'http://example.com/remote1.jpg',
        localFile,
        'http://example.com/remote2.jpg'
      ];

      global.fetch = jest.fn().mockResolvedValue(createMockResponse(Buffer.from('remote')));

      const result = await resolveInputResources(inputs, tmpDir);

      expect(result.localPaths).toHaveLength(3);
      expect(result.downloaded).toHaveLength(2); // Only 2 downloads
      expect(result.localPaths[1]).toBe(localFile);
    });

    test('Concurrent downloads with some failures', async () => {
      global.fetch = jest.fn().mockImplementation(async (url) => {
        if (url.includes('fail')) {
          return createMockResponse(Buffer.from(''), 500, 'Internal Server Error');
        }
        return createMockResponse(Buffer.from('success'));
      });

      const inputs = [
        'http://example.com/ok1.jpg',
        'http://example.com/fail.jpg',
        'http://example.com/ok2.jpg'
      ];

      // Use Promise.allSettled to handle partial failures
      const promises = inputs.map(url => resolveInputResource(url, tmpDir));
      const results = await Promise.allSettled(promises);

      expect(results[0].status).toBe('fulfilled');
      expect(results[1].status).toBe('rejected');
      expect(results[2].status).toBe('fulfilled');
    });
  });

  // ========================================
  // E010 - Invalid tmpDir Path
  // ========================================
  describe('E010 - Invalid tmpDir Path', () => {
    test('Creates directory if it does not exist', async () => {
      const nonExistentDir = path.join(tmpDir, 'nonexistent', 'nested', 'dir');
      expect(fs.existsSync(nonExistentDir)).toBe(false);

      global.fetch = jest.fn().mockResolvedValue(createMockResponse(Buffer.from('test')));

      const result = await downloadResource('http://example.com/test.jpg', nonExistentDir);

      expect(fs.existsSync(nonExistentDir)).toBe(true);
      expect(fs.existsSync(result)).toBe(true);
    });

    // Note: Testing read-only directory requires platform-specific setup
    // and may not work consistently across all environments
    test('Handles deeply nested directory creation', async () => {
      const deepPath = path.join(tmpDir, 'a', 'b', 'c', 'd', 'e', 'f', 'g');
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(Buffer.from('test')));

      const result = await downloadResource('http://example.com/test.jpg', deepPath);

      expect(fs.existsSync(deepPath)).toBe(true);
      expect(fs.existsSync(result)).toBe(true);
    });
  });

  // ========================================
  // E011 - Unicode Filename
  // ========================================
  describe('E011 - Unicode Filename', () => {
    test('Japanese filename', async () => {
      const testContent = Buffer.from('japanese test');
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(testContent));

      // .jpg in Japanese
      const url = 'http://example.com/%E7%94%BB%E5%83%8F.jpg';
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
    });

    test('Arabic filename (RTL)', async () => {
      const testContent = Buffer.from('arabic test');
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(testContent));

      // Arabic text URL encoded
      const url = 'http://example.com/%D8%B5%D9%88%D8%B1%D8%A9.jpg';
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
    });

    test('Emoji in filename', async () => {
      const testContent = Buffer.from('emoji test');
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(testContent));

      // Emoji URL encoded (smiley face)
      const url = 'http://example.com/%F0%9F%98%80.jpg';
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
    });

    test('Mixed Unicode characters', async () => {
      const testContent = Buffer.from('mixed unicode test');
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(testContent));

      // Mix of different unicode scripts
      const url = 'http://example.com/test_%E4%B8%AD%E6%96%87_%D1%80%D1%83%D1%81.jpg';
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
    });

    test('isUrl handles Unicode URLs', () => {
      expect(isUrl('http://example.com/%E4%B8%AD%E6%96%87.jpg')).toBe(true);
      expect(isUrl('http://example.com/日本語.jpg')).toBe(true);
    });

    test('getFilenameFromUrl handles Unicode', () => {
      const result = getFilenameFromUrl('http://example.com/%E5%9B%BE%E7%89%87.jpg');
      // URL encoded characters are preserved in pathname
      expect(result).toContain('.jpg');
    });
  });

  // ========================================
  // E012 - Empty File (0 bytes)
  // ========================================
  describe('E012 - Empty File', () => {
    test('Download empty file (0 bytes)', async () => {
      const emptyContent = Buffer.from('');
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(emptyContent));

      const url = 'http://example.com/empty.txt';
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
      const stats = fs.statSync(result);
      expect(stats.size).toBe(0);
    });

    test('resolveInputResource with empty file download', async () => {
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(Buffer.from('')));

      const result = await resolveInputResource('http://example.com/empty.dat', tmpDir);

      expect(result.wasDownloaded).toBe(true);
      expect(fs.existsSync(result.localPath)).toBe(true);
      expect(fs.statSync(result.localPath).size).toBe(0);
    });
  });

  // ========================================
  // Additional Edge Cases
  // ========================================
  describe('Additional Edge Cases', () => {
    test('Filename collision handling', async () => {
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(Buffer.from('test')));

      // Download same URL twice to trigger collision handling
      const url = 'http://example.com/collision.jpg';
      const result1 = await downloadResource(url, tmpDir);
      const result2 = await downloadResource(url, tmpDir);

      expect(result1).not.toBe(result2);
      expect(fs.existsSync(result1)).toBe(true);
      expect(fs.existsSync(result2)).toBe(true);
      expect(path.basename(result2)).toMatch(/collision_1\.jpg/);
    });

    test('Multiple filename collisions', async () => {
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(Buffer.from('test')));

      const url = 'http://example.com/multi.jpg';
      const results = [];

      for (let i = 0; i < 5; i++) {
        results.push(await downloadResource(url, tmpDir));
      }

      // All should have unique paths
      const uniquePaths = new Set(results);
      expect(uniquePaths.size).toBe(5);

      // Check naming pattern
      expect(path.basename(results[0])).toBe('multi.jpg');
      expect(path.basename(results[1])).toBe('multi_1.jpg');
      expect(path.basename(results[2])).toBe('multi_2.jpg');
    });

    test('HTTP 4xx errors are properly reported', async () => {
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(Buffer.from(''), 404, 'Not Found'));

      await expect(downloadResource('http://example.com/notfound.jpg', tmpDir))
        .rejects.toThrow('HTTP 404');
    });

    test('HTTP 5xx errors are properly reported', async () => {
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(Buffer.from(''), 503, 'Service Unavailable'));

      await expect(downloadResource('http://example.com/unavailable.jpg', tmpDir))
        .rejects.toThrow('HTTP 503');
    });

    test('HTTP 401 Unauthorized', async () => {
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(Buffer.from(''), 401, 'Unauthorized'));

      await expect(downloadResource('http://example.com/protected.jpg', tmpDir))
        .rejects.toThrow('HTTP 401');
    });

    test('HTTP 403 Forbidden', async () => {
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(Buffer.from(''), 403, 'Forbidden'));

      await expect(downloadResource('http://example.com/forbidden.jpg', tmpDir))
        .rejects.toThrow('HTTP 403');
    });

    test('URL with no extension generates timestamp filename', async () => {
      const testContent = Buffer.from('no extension');
      global.fetch = jest.fn().mockResolvedValue(createMockResponse(testContent));

      const url = 'http://example.com/path/to/something';
      const result = await downloadResource(url, tmpDir);

      expect(fs.existsSync(result)).toBe(true);
      expect(path.basename(result)).toMatch(/^download_\d+$/);
    });

    test('resolveInputResources with empty array', async () => {
      const result = await resolveInputResources([], tmpDir);

      expect(result.localPaths).toEqual([]);
      expect(result.downloaded).toEqual([]);
    });

    test('Binary content is preserved exactly', async () => {
      // Create buffer with all byte values
      const binaryContent = Buffer.alloc(256);
      for (let i = 0; i < 256; i++) {
        binaryContent[i] = i;
      }

      global.fetch = jest.fn().mockResolvedValue(createMockResponse(binaryContent));

      const url = 'http://example.com/binary.bin';
      const result = await downloadResource(url, tmpDir);

      const savedContent = fs.readFileSync(result);
      expect(savedContent.equals(binaryContent)).toBe(true);
    });
  });
});
