/**
 * Unit tests for batch.js parameter mapping functions
 * Tests: mapTxt2ImgArgs, mapImg2ImgArgs, mapTxt2VidArgs, mapImg2VidArgs, mapImageScaleArgs
 */
import {
  mapTxt2ImgArgs,
  mapImg2ImgArgs,
  mapTxt2VidArgs,
  mapImg2VidArgs,
  mapImageScaleArgs,
} from '../../../src/commands/batch.js';

// ---------------------------------------------------------------------------
// mapTxt2ImgArgs
// ---------------------------------------------------------------------------
describe('mapTxt2ImgArgs', () => {
  test('TC-101-01: Full parameter mapping - all fields present', () => {
    const task = {
      prompt: 'a beautiful sunset',
      negative: 'ugly, blurry',
      output: './out',
      config: 'config.json',
      workflow: 'wf1',
      steps: 30,
      cfg: 7.5,
      seed: 42,
      width: 512,
      height: 768,
      size: 'landscape',
      orientation: 'wide',
      upload: true,
      project: 'test-project',
      category: 'nature',
      name: 'sunset-01',
    };
    const globalOptions = {};

    const result = mapTxt2ImgArgs(task, globalOptions);

    expect(result.positional).toEqual(['a beautiful sunset']);
    expect(result.options.negative).toBe('ugly, blurry');
    expect(result.options.output).toBe('./out');
    expect(result.options.config).toBe('config.json');
    expect(result.options.workflow).toBe('wf1');
    expect(result.options.steps).toBe(30);
    expect(result.options.cfg).toBe(7.5);
    expect(result.options.seed).toBe(42);
    expect(result.options.width).toBe(512);
    expect(result.options.height).toBe(768);
    expect(result.options.size).toBe('landscape');
    expect(result.options.orientation).toBe('wide');
    expect(result.options.upload).toBe(true);
    expect(result.options.project).toBe('test-project');
    expect(result.options.category).toBe('nature');
    expect(result.options.name).toBe('sunset-01');
    expect(result.options._batchMode).toBe(true);
  });

  test('TC-101-02: Minimal params - unspecified fields are undefined', () => {
    const task = { type: 'txt2img', prompt: 'hello' };
    const globalOptions = {};

    const result = mapTxt2ImgArgs(task, globalOptions);

    expect(result.positional).toEqual(['hello']);
    expect(result.options.negative).toBeUndefined();
    expect(result.options.output).toBeUndefined();
    expect(result.options.config).toBeUndefined();
    expect(result.options.workflow).toBeUndefined();
    expect(result.options.steps).toBeUndefined();
    expect(result.options.cfg).toBeUndefined();
    expect(result.options.seed).toBeUndefined();
    expect(result.options.width).toBeUndefined();
    expect(result.options.height).toBeUndefined();
    expect(result.options.size).toBeUndefined();
    expect(result.options.orientation).toBeUndefined();
    expect(result.options.upload).toBeUndefined();
    expect(result.options.project).toBeUndefined();
    expect(result.options.category).toBeUndefined();
    expect(result.options.name).toBeUndefined();
    expect(result.options._batchMode).toBe(true);
  });

  test('TC-101-03: Global output overrides task output', () => {
    const task = { prompt: 'test', output: './task-out' };
    const globalOptions = { output: './global-out' };

    const result = mapTxt2ImgArgs(task, globalOptions);

    expect(result.options.output).toBe('./global-out');
  });

  test('TC-101-04: Task-level output when no global output', () => {
    const task = { prompt: 'test', output: './task-out' };
    const globalOptions = {};

    const result = mapTxt2ImgArgs(task, globalOptions);

    expect(result.options.output).toBe('./task-out');
  });

  test('TC-101-05: Global --no-upload overrides task upload', () => {
    const task = { prompt: 'test', upload: true };
    const globalOptions = { upload: false };

    const result = mapTxt2ImgArgs(task, globalOptions);

    expect(result.options.upload).toBe(false);
  });

  test('TC-101-06: Empty string prompt - positional[0] is empty string', () => {
    const task = { type: 'txt2img', prompt: '' };
    const globalOptions = {};

    const result = mapTxt2ImgArgs(task, globalOptions);

    expect(result.positional[0]).toBe('');
  });
});

// ---------------------------------------------------------------------------
// mapImg2ImgArgs
// ---------------------------------------------------------------------------
describe('mapImg2ImgArgs', () => {
  test('TC-101-07: image + prompt positional mapping', () => {
    const task = { image: 'photo.jpg', prompt: 'make it blue' };
    const globalOptions = {};

    const result = mapImg2ImgArgs(task, globalOptions);

    expect(result.positional).toEqual(['photo.jpg', 'make it blue']);
    expect(result.options._batchMode).toBe(true);
  });

  test('TC-101-08: Multi-image comma-separated - positional[0] preserved', () => {
    const task = { image: 'a.jpg,b.jpg', prompt: 'style transfer' };
    const globalOptions = {};

    const result = mapImg2ImgArgs(task, globalOptions);

    expect(result.positional[0]).toBe('a.jpg,b.jpg');
    expect(result.positional[1]).toBe('style transfer');
  });

  test('TC-101-09: strength parameter mapping', () => {
    const task = { image: 'img.png', prompt: 'test', strength: 0.75 };
    const globalOptions = {};

    const result = mapImg2ImgArgs(task, globalOptions);

    expect(result.options.strength).toBe(0.75);
  });

  test('TC-101-10: Global option override same rules as txt2img', () => {
    const task = {
      image: 'img.png',
      prompt: 'test',
      output: './task-out',
      upload: true,
    };
    const globalOptions = {
      output: './global-out',
      upload: false,
      config: 'global-config.json',
    };

    const result = mapImg2ImgArgs(task, globalOptions);

    expect(result.options.output).toBe('./global-out');
    expect(result.options.upload).toBe(false);
    expect(result.options.config).toBe('global-config.json');
  });
});

// ---------------------------------------------------------------------------
// mapTxt2VidArgs
// ---------------------------------------------------------------------------
describe('mapTxt2VidArgs', () => {
  test('TC-101-11: Video-specific params (format, fps, frames)', () => {
    const task = {
      prompt: 'dancing cat',
      format: 'mp4',
      fps: 24,
      frames: 60,
      steps: 20,
      cfg: 8,
      seed: 99,
    };
    const globalOptions = {};

    const result = mapTxt2VidArgs(task, globalOptions);

    expect(result.positional).toEqual(['dancing cat']);
    expect(result.options.format).toBe('mp4');
    expect(result.options.fps).toBe(24);
    expect(result.options.frames).toBe(60);
    expect(result.options.steps).toBe(20);
    expect(result.options.cfg).toBe(8);
    expect(result.options.seed).toBe(99);
    expect(result.options._batchMode).toBe(true);
  });

  test('TC-101-12: Global option override', () => {
    const task = { prompt: 'test', output: './task-out', upload: true };
    const globalOptions = { output: './global-out', upload: false };

    const result = mapTxt2VidArgs(task, globalOptions);

    expect(result.options.output).toBe('./global-out');
    expect(result.options.upload).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// mapImg2VidArgs
// ---------------------------------------------------------------------------
describe('mapImg2VidArgs', () => {
  test('TC-101-13: img2vid mapping - image positional, prompt in options', () => {
    const task = { image: 'source.png', prompt: 'animate slowly' };
    const globalOptions = {};

    const result = mapImg2VidArgs(task, globalOptions);

    expect(result.positional).toEqual(['source.png']);
    expect(result.options.prompt).toBe('animate slowly');
    expect(result.options._batchMode).toBe(true);
  });

  test('TC-101-14: motion parameter mapping', () => {
    const task = { image: 'src.jpg', motion: 'zoom_in' };
    const globalOptions = {};

    const result = mapImg2VidArgs(task, globalOptions);

    expect(result.options.motion).toBe('zoom_in');
  });
});

// ---------------------------------------------------------------------------
// mapImageScaleArgs
// ---------------------------------------------------------------------------
describe('mapImageScaleArgs', () => {
  test('TC-101-15: imagescale mapping - image positional, no prompt', () => {
    const task = { image: 'small.png', width: 1024, height: 1024 };
    const globalOptions = {};

    const result = mapImageScaleArgs(task, globalOptions);

    expect(result.positional).toEqual(['small.png']);
    expect(result.options.width).toBe(1024);
    expect(result.options.height).toBe(1024);
    expect(result.options._batchMode).toBe(true);
    // Ensure prompt is not part of the result
    expect(result.options.prompt).toBeUndefined();
  });

  test('TC-101-16: Global option override', () => {
    const task = { image: 'img.png', output: './task-out', upload: true };
    const globalOptions = { output: './global-out', upload: false, config: 'cfg.json' };

    const result = mapImageScaleArgs(task, globalOptions);

    expect(result.options.output).toBe('./global-out');
    expect(result.options.upload).toBe(false);
    expect(result.options.config).toBe('cfg.json');
  });
});
