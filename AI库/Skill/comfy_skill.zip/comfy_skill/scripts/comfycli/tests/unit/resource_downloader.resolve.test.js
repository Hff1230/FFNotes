/**
 * Unit tests for resource_downloader.js resolve functions
 * Tests: resolveInputResource, resolveInputResources
 */
import { jest } from '@jest/globals';
import fs from 'fs';
import path from 'path';
import resourceDownloader from '../../src/utils/resource_downloader.js';

const { resolveInputResource, resolveInputResources } = resourceDownloader;

// Store original fetch for restoration
const originalFetch = global.fetch;

// Test fixtures
const TEST_TMP_DIR = './tests/fixtures/tmp-resolve-test';
const CUSTOM_TMP_DIR = './tests/fixtures/custom-tmp';

// Helper to create mock image data
function createMockImageData() {
  // Minimal valid PNG header + data
  return Buffer.from([
    0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, // PNG signature
    0x00, 0x00, 0x00, 0x0D, // IHDR length
    0x49, 0x48, 0x44, 0x52, // IHDR
    0x00, 0x00, 0x00, 0x01, // width: 1
    0x00, 0x00, 0x00, 0x01, // height: 1
    0x08, 0x02, // bit depth, color type
    0x00, 0x00, 0x00, // compression, filter, interlace
    0x90, 0x77, 0x53, 0xDE, // CRC
    0x00, 0x00, 0x00, 0x00, // IEND length
    0x49, 0x45, 0x4E, 0x44, // IEND
    0xAE, 0x42, 0x60, 0x82  // CRC
  ]);
}

// Helper to create mock fetch response
function createMockResponse(data, status = 200, statusText = 'OK') {
  return {
    ok: status >= 200 && status < 300,
    status,
    statusText,
    arrayBuffer: async () => {
      if (Buffer.isBuffer(data)) {
        return data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
      }
      return Buffer.from(data).buffer;
    }
  };
}

// Mock fetch responses map
let mockResponses = new Map();

// Setup mock fetch for a specific URL
function setupMockFetch(url, response) {
  mockResponses.set(url, response);
  global.fetch = async (requestUrl) => {
    const response = mockResponses.get(requestUrl);
    if (response) return response;
    return createMockResponse('Not Found', 404, 'Not Found');
  };
}

// Setup mock fetch that throws
function setupMockFetchError(url, error) {
  mockResponses.set(url, { error });
  global.fetch = async (requestUrl) => {
    const entry = mockResponses.get(requestUrl);
    if (entry && entry.error) throw entry.error;
    return createMockResponse('Not Found', 404, 'Not Found');
  };
}

// Restore original fetch
function restoreFetch() {
  global.fetch = originalFetch;
  mockResponses.clear();
}

// Cleanup helper
function cleanupDir(dirPath) {
  if (fs.existsSync(dirPath)) {
    const files = fs.readdirSync(dirPath);
    for (const file of files) {
      const filePath = path.join(dirPath, file);
      if (fs.lstatSync(filePath).isDirectory()) {
        cleanupDir(filePath);
      } else {
        fs.unlinkSync(filePath);
      }
    }
    fs.rmdirSync(dirPath);
  }
}

describe('resolveInputResource', () => {
  beforeEach(() => {
    // Ensure clean state
    cleanupDir(TEST_TMP_DIR);
    cleanupDir(CUSTOM_TMP_DIR);
    mockResponses.clear();
  });

  afterEach(() => {
    // Cleanup after each test
    restoreFetch();
    cleanupDir(TEST_TMP_DIR);
    cleanupDir(CUSTOM_TMP_DIR);
  });

  // P0 Priority Tests - Core functionality
  describe('P0 - URL inputs trigger download', () => {
    test('R001 - HTTP URL downloads and returns correct result', async () => {
      const url = 'http://example.com/photo.jpg';
      const mockData = createMockImageData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await resolveInputResource(url, TEST_TMP_DIR);

      expect(result).toHaveProperty('localPath');
      expect(result).toHaveProperty('wasDownloaded', true);
      expect(result.localPath).toContain('photo.jpg');
      expect(fs.existsSync(result.localPath)).toBe(true);
    });

    test('R001b - HTTPS URL downloads and returns correct result', async () => {
      const url = 'https://example.com/image.png';
      const mockData = createMockImageData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
      expect(result.localPath).toContain('image.png');
    });
  });

  describe('P0 - Local path inputs return as-is', () => {
    test('R002 - Relative path returns unchanged', async () => {
      const localPath = './local/photo.jpg';

      const result = await resolveInputResource(localPath, TEST_TMP_DIR);

      expect(result).toEqual({
        localPath: localPath,
        wasDownloaded: false
      });
    });

    test('R003 - Absolute path returns unchanged', async () => {
      const absPath = '/abs/path/photo.jpg';

      const result = await resolveInputResource(absPath, TEST_TMP_DIR);

      expect(result).toEqual({
        localPath: absPath,
        wasDownloaded: false
      });
    });

    test('R003b - Windows absolute path returns unchanged', async () => {
      const winPath = 'C:\\Users\\test\\photo.jpg';

      const result = await resolveInputResource(winPath, TEST_TMP_DIR);

      expect(result).toEqual({
        localPath: winPath,
        wasDownloaded: false
      });
    });

    test('Local filename only returns unchanged', async () => {
      const filename = 'photo.jpg';

      const result = await resolveInputResource(filename, TEST_TMP_DIR);

      expect(result).toEqual({
        localPath: filename,
        wasDownloaded: false
      });
    });
  });

  // P1 Priority Tests - Error handling and custom options
  describe('P1 - Error handling for failed downloads', () => {
    test('R004 - HTTP 404 throws error', async () => {
      const url = 'http://example.com/notfound.jpg';

      setupMockFetch(url, createMockResponse('Not Found', 404, 'Not Found'));

      await expect(resolveInputResource(url, TEST_TMP_DIR))
        .rejects.toThrow('Failed to download resource: HTTP 404');
    });

    test('R004b - HTTP 500 throws error', async () => {
      const url = 'http://example.com/server-error.jpg';

      setupMockFetch(url, createMockResponse('Internal Server Error', 500, 'Internal Server Error'));

      await expect(resolveInputResource(url, TEST_TMP_DIR))
        .rejects.toThrow('Failed to download resource: HTTP 500');
    });

    test('R004c - HTTP 403 throws error', async () => {
      const url = 'http://example.com/forbidden.jpg';

      setupMockFetch(url, createMockResponse('Forbidden', 403, 'Forbidden'));

      await expect(resolveInputResource(url, TEST_TMP_DIR))
        .rejects.toThrow('Failed to download resource: HTTP 403');
    });
  });

  describe('P1 - Custom tmpDir option', () => {
    test('R005 - Custom tmpDir is used for downloads', async () => {
      const url = 'http://example.com/custom-dir-test.jpg';
      const mockData = createMockImageData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await resolveInputResource(url, CUSTOM_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
      // Normalize paths for cross-platform comparison (Windows uses backslashes)
      expect(result.localPath.replace(/\\/g, '/')).toContain('custom-tmp');
      expect(fs.existsSync(result.localPath)).toBe(true);
    });

    test('R005b - Default tmpDir is ./tmp', async () => {
      const url = 'http://example.com/default-tmp.jpg';
      const mockData = createMockImageData();

      setupMockFetch(url, createMockResponse(mockData));

      // Call without tmpDir argument to test default
      const result = await resolveInputResource(url);

      expect(result.wasDownloaded).toBe(true);
      expect(result.localPath).toContain('tmp');

      // Cleanup the default tmp dir file
      if (fs.existsSync(result.localPath)) {
        fs.unlinkSync(result.localPath);
      }
    });
  });

  // Additional edge cases
  describe('Edge cases', () => {
    test('URL with query parameters downloads correctly', async () => {
      const url = 'http://example.com/image.jpg?token=abc&size=large';
      const mockData = createMockImageData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
      expect(result.localPath).toContain('image.jpg');
    });

    test('URL with special characters in filename', async () => {
      const url = 'http://example.com/my%20image%20file.jpg';
      const mockData = createMockImageData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
    });

    test('Empty string input returns as-is (not a URL)', async () => {
      const result = await resolveInputResource('', TEST_TMP_DIR);

      expect(result).toEqual({
        localPath: '',
        wasDownloaded: false
      });
    });

    test('Null input returns as-is', async () => {
      const result = await resolveInputResource(null, TEST_TMP_DIR);

      expect(result).toEqual({
        localPath: null,
        wasDownloaded: false
      });
    });

    test('URL without file extension generates download filename', async () => {
      const url = 'http://example.com/noextension';
      const mockData = createMockImageData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
      expect(result.localPath).toContain('download_');
    });

    test('URL with trailing slash generates download filename', async () => {
      const url = 'http://example.com/path/';
      const mockData = createMockImageData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
      expect(result.localPath).toContain('download_');
    });

    test('File name conflict resolution with counter', async () => {
      const url = 'http://example.com/conflict.jpg';
      const mockData = createMockImageData();

      // First download
      setupMockFetch(url, createMockResponse(mockData));
      const result1 = await resolveInputResource(url, TEST_TMP_DIR);
      expect(result1.localPath).toContain('conflict.jpg');

      // Second download with same filename - should get _1 suffix
      setupMockFetch(url, createMockResponse(mockData));
      const result2 = await resolveInputResource(url, TEST_TMP_DIR);
      expect(result2.localPath).toContain('conflict_1.jpg');

      // Third download - should get _2 suffix
      setupMockFetch(url, createMockResponse(mockData));
      const result3 = await resolveInputResource(url, TEST_TMP_DIR);
      expect(result3.localPath).toContain('conflict_2.jpg');

      // Verify all files exist
      expect(fs.existsSync(result1.localPath)).toBe(true);
      expect(fs.existsSync(result2.localPath)).toBe(true);
      expect(fs.existsSync(result3.localPath)).toBe(true);
    });
  });
});

describe('resolveInputResources', () => {
  beforeEach(() => {
    cleanupDir(TEST_TMP_DIR);
    cleanupDir(CUSTOM_TMP_DIR);
    mockResponses.clear();
  });

  afterEach(() => {
    restoreFetch();
    cleanupDir(TEST_TMP_DIR);
    cleanupDir(CUSTOM_TMP_DIR);
  });

  // P0 Priority Tests - Core batch functionality
  describe('P0 - All URLs batch download', () => {
    test('B001 - Multiple URLs all download correctly', async () => {
      const urls = ['http://a.com/1.jpg', 'http://b.com/2.jpg'];
      const mockData = createMockImageData();

      setupMockFetch('http://a.com/1.jpg', createMockResponse(mockData));
      setupMockFetch('http://b.com/2.jpg', createMockResponse(mockData));

      const result = await resolveInputResources(urls, TEST_TMP_DIR);

      expect(result.localPaths).toHaveLength(2);
      expect(result.downloaded).toHaveLength(2);
      expect(result.localPaths[0]).toContain('1.jpg');
      expect(result.localPaths[1]).toContain('2.jpg');
      expect(result.downloaded).toEqual(result.localPaths);
    });
  });

  describe('P0 - Mixed local and URL inputs', () => {
    test('B002 - Mixed local path and URL correctly separated', async () => {
      const inputs = ['local.jpg', 'http://a.com/remote.jpg'];
      const mockData = createMockImageData();

      setupMockFetch('http://a.com/remote.jpg', createMockResponse(mockData));

      const result = await resolveInputResources(inputs, TEST_TMP_DIR);

      expect(result.localPaths).toHaveLength(2);
      expect(result.localPaths[0]).toBe('local.jpg');
      expect(result.localPaths[1]).toContain('remote.jpg');
      expect(result.downloaded).toHaveLength(1);
      expect(result.downloaded[0]).toContain('remote.jpg');
    });

    test('B002b - URL first, then local path', async () => {
      const inputs = ['http://example.com/first.png', './second.png'];
      const mockData = createMockImageData();

      setupMockFetch('http://example.com/first.png', createMockResponse(mockData));

      const result = await resolveInputResources(inputs, TEST_TMP_DIR);

      expect(result.localPaths).toHaveLength(2);
      expect(result.localPaths[0]).toContain('first.png');
      expect(result.localPaths[1]).toBe('./second.png');
      expect(result.downloaded).toHaveLength(1);
    });
  });

  describe('P0 - All local paths', () => {
    test('B003 - All local paths return unchanged, no downloads', async () => {
      const inputs = ['local1.jpg', 'local2.jpg'];

      const result = await resolveInputResources(inputs, TEST_TMP_DIR);

      expect(result).toEqual({
        localPaths: ['local1.jpg', 'local2.jpg'],
        downloaded: []
      });
    });

    test('B003b - Mixed absolute and relative paths', async () => {
      const inputs = ['./relative.jpg', '/absolute/path.jpg', 'C:\\windows\\path.jpg'];

      const result = await resolveInputResources(inputs, TEST_TMP_DIR);

      expect(result.localPaths).toEqual(inputs);
      expect(result.downloaded).toEqual([]);
    });
  });

  // P1 Priority Tests - Edge cases and error handling
  describe('P1 - Empty array input', () => {
    test('B004 - Empty array returns empty results', async () => {
      const result = await resolveInputResources([], TEST_TMP_DIR);

      expect(result).toEqual({
        localPaths: [],
        downloaded: []
      });
    });
  });

  describe('P1 - Large mixed batch', () => {
    test('B005 - 3 URLs + 2 local paths correctly processed', async () => {
      const inputs = [
        'http://a.com/1.jpg',
        'http://b.com/2.jpg',
        'local1.jpg',
        'http://c.com/3.jpg',
        'local2.jpg'
      ];
      const mockData = createMockImageData();

      setupMockFetch('http://a.com/1.jpg', createMockResponse(mockData));
      setupMockFetch('http://b.com/2.jpg', createMockResponse(mockData));
      setupMockFetch('http://c.com/3.jpg', createMockResponse(mockData));

      const result = await resolveInputResources(inputs, TEST_TMP_DIR);

      expect(result.localPaths).toHaveLength(5);
      expect(result.downloaded).toHaveLength(3);

      // Check local paths are unchanged
      expect(result.localPaths[2]).toBe('local1.jpg');
      expect(result.localPaths[4]).toBe('local2.jpg');

      // Check downloaded paths contain the URL filenames
      expect(result.downloaded[0]).toContain('1.jpg');
      expect(result.downloaded[1]).toContain('2.jpg');
      expect(result.downloaded[2]).toContain('3.jpg');
    });
  });

  describe('P1 - Partial download failure', () => {
    test('B006 - One URL fails, entire batch throws error', async () => {
      const inputs = ['http://a.com/success.jpg', 'http://b.com/fail.jpg'];
      const mockData = createMockImageData();

      setupMockFetch('http://a.com/success.jpg', createMockResponse(mockData));
      setupMockFetch('http://b.com/fail.jpg', createMockResponse('Not Found', 404, 'Not Found'));

      await expect(resolveInputResources(inputs, TEST_TMP_DIR))
        .rejects.toThrow('Failed to download resource: HTTP 404');
    });

    test('B006b - First URL fails, throws immediately', async () => {
      const inputs = ['http://a.com/fail.jpg', 'http://b.com/success.jpg'];

      setupMockFetch('http://a.com/fail.jpg', createMockResponse('Server Error', 500, 'Server Error'));

      await expect(resolveInputResources(inputs, TEST_TMP_DIR))
        .rejects.toThrow('Failed to download resource: HTTP 500');
    });
  });

  // Additional edge cases
  describe('Edge cases', () => {
    test('Custom tmpDir is used for all downloads', async () => {
      const inputs = ['http://example.com/test.jpg'];
      const mockData = createMockImageData();

      setupMockFetch('http://example.com/test.jpg', createMockResponse(mockData));

      const result = await resolveInputResources(inputs, CUSTOM_TMP_DIR);

      // Normalize paths for cross-platform comparison (Windows uses backslashes)
      expect(result.localPaths[0].replace(/\\/g, '/')).toContain('custom-tmp');
    });

    test('Single item array works correctly', async () => {
      const inputs = ['http://example.com/single.jpg'];
      const mockData = createMockImageData();

      setupMockFetch('http://example.com/single.jpg', createMockResponse(mockData));

      const result = await resolveInputResources(inputs, TEST_TMP_DIR);

      expect(result.localPaths).toHaveLength(1);
      expect(result.downloaded).toHaveLength(1);
    });

    test('Array with null/undefined elements', async () => {
      const inputs = ['local.jpg', null, undefined];

      const result = await resolveInputResources(inputs, TEST_TMP_DIR);

      expect(result.localPaths).toEqual(['local.jpg', null, undefined]);
      expect(result.downloaded).toEqual([]);
    });
  });
});
