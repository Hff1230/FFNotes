/**
 * TEST-003: Variable Replacement Mechanism Unit Test
 * Validates replaceVariables and mergeWorkflowParams for qwen2511angle workflow
 */
import { jest, describe, test, expect, beforeAll } from '@jest/globals';
import { replaceVariables, mergeWorkflowParams } from '../../../src/core/workflow.js';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECT_ROOT = path.resolve(__dirname, '../../../');
const CONFIG_PATH = path.join(PROJECT_ROOT, 'config', 'comfy_config.json');
const API_PATH = path.join(PROJECT_ROOT, 'config', 'comfy', 'image_angles_qwen_image_edit_2511_api.json');

let config;
let angleConfig;
let workflow;

beforeAll(() => {
  const configContent = fs.readFileSync(CONFIG_PATH, 'utf-8');
  config = JSON.parse(configContent);
  angleConfig = config.prompts.qwen2511angle;

  const apiContent = fs.readFileSync(API_PATH, 'utf-8');
  workflow = JSON.parse(apiContent);
});

describe('TEST-003: Variable Replacement for qwen2511angle', () => {
  test('TC-403-01: ##active_prompt## replaces into node 111 prompt', () => {
    const values = {
      active_prompt: '<sks> front view high-angle shot close-up',
      sample_image: 'test_input.jpg',
      width: '1328',
      height: '768'
    };
    const result = replaceVariables(workflow, angleConfig.data, values);
    expect(result['111'].inputs.prompt).toContain('<sks> front view high-angle shot close-up');
  });

  test('TC-403-02: ##sample_image## replaces into node 78 image', () => {
    const values = {
      active_prompt: '<sks> test prompt',
      sample_image: 'uploaded_photo.jpg',
      width: '1328',
      height: '768'
    };
    const result = replaceVariables(workflow, angleConfig.data, values);
    expect(result['78'].inputs.image).toBe('uploaded_photo.jpg');
  });

  test('TC-403-03: ##width## replaces into node 112 width', () => {
    const values = {
      active_prompt: '<sks> test',
      sample_image: 'test.jpg',
      width: '1536',
      height: '864'
    };
    const result = replaceVariables(workflow, angleConfig.data, values);
    expect(result['112'].inputs.width).toBe('1536');
  });

  test('TC-403-04: ##height## replaces into node 112 height', () => {
    const values = {
      active_prompt: '<sks> test',
      sample_image: 'test.jpg',
      width: '1536',
      height: '864'
    };
    const result = replaceVariables(workflow, angleConfig.data, values);
    expect(result['112'].inputs.height).toBe('864');
  });

  test('TC-403-05: Unresolved placeholders preserve original values', () => {
    // Only provide width, leaving other variables unresolved
    const values = { width: '1024' };
    const result = replaceVariables(workflow, angleConfig.data, values);
    // Unresolved placeholders should preserve the original workflow defaults
    expect(result['111'].inputs.prompt).toContain('<sks>');
    expect(result['78'].inputs.image).toBe('0.jpg'); // original default
  });

  test('TC-403-06: Empty prompt value preserves placeholder', () => {
    const values = {
      active_prompt: undefined,
      sample_image: 'test.jpg',
      width: '1328',
      height: '768'
    };
    const result = replaceVariables(workflow, angleConfig.data, values);
    // Since active_prompt is undefined, the original workflow value should be preserved
    expect(result['111'].inputs.prompt).toBeDefined();
  });

  test('TC-403-07: mergeWorkflowParams overrides seed', () => {
    const result = mergeWorkflowParams(workflow, { seed: 12345 });
    // Node 3 (KSampler) has seed
    expect(result['3'].inputs.seed).toBe(12345);
  });

  test('TC-403-08: mergeWorkflowParams overrides steps', () => {
    const result = mergeWorkflowParams(workflow, { steps: 20 });
    expect(result['3'].inputs.steps).toBe(20);
  });

  test('TC-403-09: Angle prompt contains <sks> tag after replacement', () => {
    const values = {
      active_prompt: '<sks> back view low-angle shot wide shot',
      sample_image: 'test.jpg',
      width: '1328',
      height: '768'
    };
    const result = replaceVariables(workflow, angleConfig.data, values);
    expect(result['111'].inputs.prompt).toContain('<sks>');
  });

  test('TC-403-10: All nodes remain intact after replacement', () => {
    const values = {
      active_prompt: '<sks> test prompt',
      sample_image: 'test.jpg',
      width: '1328',
      height: '768'
    };
    const result = replaceVariables(workflow, angleConfig.data, values);
    // Verify key nodes still exist
    expect(result['3']).toBeDefined();
    expect(result['78']).toBeDefined();
    expect(result['110']).toBeDefined();
    expect(result['111']).toBeDefined();
    expect(result['112']).toBeDefined();
    expect(result['60']).toBeDefined();
  });

  test('TC-403-11: Multiple replacements do not modify original workflow', () => {
    const originalPrompt = workflow['111'].inputs.prompt;
    const values1 = { active_prompt: 'prompt1', sample_image: 'img1.jpg', width: '800', height: '600' };
    const values2 = { active_prompt: 'prompt2', sample_image: 'img2.jpg', width: '1024', height: '768' };

    replaceVariables(workflow, angleConfig.data, values1);
    replaceVariables(workflow, angleConfig.data, values2);

    // Original workflow should not be modified
    expect(workflow['111'].inputs.prompt).toBe(originalPrompt);
  });

  test('TC-403-12: Node 110 prompt stays empty (no negative_prompt mapping)', () => {
    const values = {
      active_prompt: '<sks> test prompt',
      sample_image: 'test.jpg',
      width: '1328',
      height: '768'
    };
    const result = replaceVariables(workflow, angleConfig.data, values);
    // Node 110 has no data mapping - should remain as original empty string
    expect(result['110'].inputs.prompt).toBe('');
  });
});
