/**
 * TEST-002: SKILL.md Image Angle Generation Documentation Validation
 * Validates the Image Angle Generation section in SKILL.md
 */
import { jest, describe, test, expect, beforeAll } from '@jest/globals';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SKILL_MD_PATH = path.resolve(__dirname, '../../../../../SKILL.md');

let skillContent;
let angleSection;
let angleSectionStart;
let angleSectionEnd;

// Extract angle prompts from the angle definition sections
let allAnglePrompts = [];

// Camera angle code mapping
const CAMERA_ANGLE_MAP = {
  h: 'high-angle shot',
  e: 'elevated shot',
  n: 'eye-level shot',
  l: 'low-angle shot'
};

// Shot distance code mapping
const SHOT_DISTANCE_MAP = {
  c: 'close-up',
  m: 'medium shot',
  w: 'wide shot'
};

// All 12 angle group codes
const ANGLE_GROUPS = ['hc', 'ec', 'nc', 'lc', 'hm', 'em', 'nm', 'lm', 'hw', 'ew', 'nw', 'lw'];

// 8 viewpoints
const VIEWPOINTS = [
  'front view',
  'front-right quarter view',
  'right side view',
  'back-right quarter view',
  'back view',
  'back-left quarter view',
  'left side view',
  'front-left quarter view'
];

beforeAll(() => {
  skillContent = fs.readFileSync(SKILL_MD_PATH, 'utf-8');

  // Extract the Image Angle Generation section
  const sectionMatch = skillContent.match(/^## Image Angle Generation$/m);
  expect(sectionMatch).not.toBeNull();
  angleSectionStart = sectionMatch.index;

  // Find the end of the section (next ## heading at same level or higher)
  const nextSectionMatch = skillContent.slice(angleSectionStart + 1).match(/^## /m);
  if (nextSectionMatch) {
    angleSectionEnd = angleSectionStart + 1 + nextSectionMatch.index;
  } else {
    angleSectionEnd = skillContent.length;
  }
  angleSection = skillContent.slice(angleSectionStart, angleSectionEnd);

  // Extract all <sks> prompts from the angle definition code blocks
  // Look for prompts in code blocks that contain angle group headers like "**hc - "
  const promptPattern = /<sks>\s+(front(?:-right quarter)?(?: view| side view)|right side view|back(?:-right quarter)?(?: view| side view| view)|left side view|front-left quarter view)\s+(high-angle shot|elevated shot|eye-level shot|low-angle shot)\s+(close-up|medium shot|wide shot)/g;

  // Only extract from the angle definition sections (between the angle group headings and their code blocks)
  // The definitions are in the "Full Prompts by Angle Group" subsection
  const fullPromptsMatch = skillContent.indexOf('#### Full Prompts by Angle Group');
  if (fullPromptsMatch !== -1) {
    const fullPromptsSection = skillContent.slice(fullPromptsMatch, angleSectionEnd);
    let match;
    while ((match = promptPattern.exec(fullPromptsSection)) !== null) {
      allAnglePrompts.push(match[0].trim());
    }
  }
});

describe('TEST-002: SKILL.md Image Angle Generation Documentation Validation', () => {
  test('TC-402-01: SKILL.md file is readable', () => {
    expect(skillContent).toBeDefined();
    expect(typeof skillContent).toBe('string');
    expect(skillContent.length).toBeGreaterThan(0);
  });

  test('TC-402-02: Contains Image Angle Generation section heading', () => {
    expect(skillContent).toMatch(/^## Image Angle Generation$/m);
  });

  test('TC-402-03: Contains qwen2511angle workflow reference', () => {
    expect(angleSection).toContain('qwen2511angle');
  });

  test('TC-402-04: Contains all 12 angle group codes', () => {
    for (const code of ANGLE_GROUPS) {
      expect(angleSection).toContain(code);
    }
  });

  test('TC-402-05: Each angle group contains 8 viewpoints', () => {
    for (const code of ANGLE_GROUPS) {
      const groupHeaderPattern = new RegExp(`\\*\\*${code} -`, 'g');
      const headerMatch = groupHeaderPattern.exec(angleSection);
      expect(headerMatch).not.toBeNull();

      // After the group header, look for the code block and count viewpoints
      const afterHeader = angleSection.slice(headerMatch.index);
      const codeBlockMatch = afterHeader.match(/```\n([\s\S]*?)```/);
      expect(codeBlockMatch).not.toBeNull();

      const codeBlock = codeBlockMatch[1];
      const viewpointCount = VIEWPOINTS.filter(vp => codeBlock.includes(vp)).length;
      expect(viewpointCount).toBe(8);
    }
  });

  test('TC-402-06: Total <sks> tag count is 96 in angle definitions', () => {
    // Count <sks> tags only in the angle definition sections (between group headers and their code blocks)
    // Exclude the Batch Generation Example section which contains 8 additional <sks> tags
    const fullPromptsSection = skillContent.indexOf('#### Full Prompts by Angle Group');
    expect(fullPromptsSection).toBeGreaterThan(-1);

    // End before the Batch Generation Example section
    const batchSection = skillContent.indexOf('### Batch Generation Example', fullPromptsSection);
    const sectionEnd = batchSection > -1 ? batchSection : angleSectionEnd;

    const section = skillContent.slice(fullPromptsSection, sectionEnd);
    const sksMatches = section.match(/<sks>/g);
    expect(sksMatches).not.toBeNull();
    expect(sksMatches.length).toBe(96);
  });

  test('TC-402-07: All prompts follow consistent format', () => {
    const promptPattern = /^<sks> (front view|front-right quarter view|right side view|back-right quarter view|back view|back-left quarter view|left side view|front-left quarter view) (high-angle shot|elevated shot|eye-level shot|low-angle shot) (close-up|medium shot|wide shot)$/;

    for (const prompt of allAnglePrompts) {
      expect(prompt).toMatch(promptPattern);
    }
  });

  test('TC-402-08: Contains batch generation example', () => {
    expect(angleSection).toContain('Batch Generation');
  });

  test('TC-402-09: Batch JSON example is valid JSON', () => {
    // Extract JSON from code block after "Batch Generation Example"
    const batchSectionIdx = angleSection.indexOf('Batch Generation Example');
    expect(batchSectionIdx).toBeGreaterThan(-1);

    const afterBatch = angleSection.slice(batchSectionIdx);
    const jsonMatch = afterBatch.match(/```json\n([\s\S]*?)```/);
    expect(jsonMatch).not.toBeNull();

    const jsonStr = jsonMatch[1];
    expect(() => JSON.parse(jsonStr)).not.toThrow();
  });

  test('TC-402-10: Batch JSON contains img2img type tasks', () => {
    const batchSectionIdx = angleSection.indexOf('Batch Generation Example');
    const afterBatch = angleSection.slice(batchSectionIdx);
    const jsonMatch = afterBatch.match(/```json\n([\s\S]*?)```/);
    const batchData = JSON.parse(jsonMatch[1]);

    const allImg2img = batchData.every(task => task.type === 'img2img');
    expect(allImg2img).toBe(true);
  });

  test('TC-402-11: Batch JSON uses qwen2511angle workflow', () => {
    const batchSectionIdx = angleSection.indexOf('Batch Generation Example');
    const afterBatch = angleSection.slice(batchSectionIdx);
    const jsonMatch = afterBatch.match(/```json\n([\s\S]*?)```/);
    const batchData = JSON.parse(jsonMatch[1]);

    const allAngleWorkflow = batchData.every(task => task.workflow === 'qwen2511angle');
    expect(allAngleWorkflow).toBe(true);
  });

  test('TC-402-12: hc group contains correct 8 viewpoints', () => {
    const hcHeaderIdx = angleSection.indexOf('**hc -');
    expect(hcHeaderIdx).toBeGreaterThan(-1);

    const afterHc = angleSection.slice(hcHeaderIdx);
    const codeBlockMatch = afterHc.match(/```\n([\s\S]*?)```/);
    expect(codeBlockMatch).not.toBeNull();

    const codeBlock = codeBlockMatch[1];
    for (const vp of VIEWPOINTS) {
      expect(codeBlock).toContain(vp);
    }
  });

  test('TC-402-13: Camera angle code mapping is correct', () => {
    for (const [code, expectedAngle] of Object.entries(CAMERA_ANGLE_MAP)) {
      // Verify that angle groups with this code contain the correct camera angle
      const groupsWithCode = ANGLE_GROUPS.filter(g => g[0] === code);
      for (const group of groupsWithCode) {
        const groupHeaderIdx = angleSection.indexOf(`**${group} -`);
        const afterGroup = angleSection.slice(groupHeaderIdx);
        const codeBlockMatch = afterGroup.match(/```\n([\s\S]*?)```/);
        expect(codeBlockMatch).not.toBeNull();
        expect(codeBlockMatch[1]).toContain(expectedAngle);
      }
    }
  });

  test('TC-402-14: Shot distance code mapping is correct', () => {
    for (const [code, expectedDistance] of Object.entries(SHOT_DISTANCE_MAP)) {
      const groupsWithCode = ANGLE_GROUPS.filter(g => g[1] === code);
      for (const group of groupsWithCode) {
        const groupHeaderIdx = angleSection.indexOf(`**${group} -`);
        const afterGroup = angleSection.slice(groupHeaderIdx);
        const codeBlockMatch = afterGroup.match(/```\n([\s\S]*?)```/);
        expect(codeBlockMatch).not.toBeNull();
        expect(codeBlockMatch[1]).toContain(expectedDistance);
      }
    }
  });
});
