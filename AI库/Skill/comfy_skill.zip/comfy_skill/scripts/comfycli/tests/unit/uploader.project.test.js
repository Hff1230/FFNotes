/**
 * Unit tests for DufsUploader project-based resource management
 * Tests: getProjectRemotePath, getProjectShareUrl
 */
import { describe, it, expect, beforeEach } from '@jest/globals';
import DufsUploader from '../../src/utils/uploader.js';

// Test configuration
const uploadConfig = {
  server: '192.168.0.92:9998',
  user: 'testuser',
  pwd: 'testpwd',
  dir: 'comfy',
  share_url: 'http://47.109.205.195:10020'
};

const uploadConfigWithoutShareUrl = {
  server: '192.168.0.92:9998',
  user: 'testuser',
  pwd: 'testpwd',
  dir: 'comfy'
};

describe('DufsUploader - Project-based Resource Management', () => {
  let uploader;
  let uploaderWithoutShareUrl;

  beforeEach(() => {
    uploader = new DufsUploader(uploadConfig);
    uploaderWithoutShareUrl = new DufsUploader(uploadConfigWithoutShareUrl);
  });

  // ============================================================
  // getProjectRemotePath Tests
  // ============================================================
  describe('getProjectRemotePath', () => {
    it('should generate correct project path format /projects/{project}/{category}/{filename}', () => {
      const result = uploader.getProjectRemotePath('C01.png', 'wusong', 'characters');
      expect(result).toBe('/projects/wusong/characters/C01.png');
    });

    it('should handle Chinese filenames', () => {
      const result = uploader.getProjectRemotePath('角色素材.png', 'wusong', 'characters');
      expect(result).toBe('/projects/wusong/characters/角色素材.png');
    });

    it('should handle various category values - tigers', () => {
      const result = uploader.getProjectRemotePath('tiger001.png', 'zoo', 'tigers');
      expect(result).toBe('/projects/zoo/tigers/tiger001.png');
    });

    it('should handle various category values - scenes', () => {
      const result = uploader.getProjectRemotePath('scene01.png', 'movie', 'scenes');
      expect(result).toBe('/projects/movie/scenes/scene01.png');
    });

    it('should handle various category values - props', () => {
      const result = uploader.getProjectRemotePath('prop01.png', 'movie', 'props');
      expect(result).toBe('/projects/movie/props/prop01.png');
    });

    it('should handle various category values - videos', () => {
      const result = uploader.getProjectRemotePath('video001.mp4', 'movie', 'videos');
      expect(result).toBe('/projects/movie/videos/video001.mp4');
    });

    it('should handle various category values - upscale', () => {
      const result = uploader.getProjectRemotePath('upscaled.png', 'movie', 'upscale');
      expect(result).toBe('/projects/movie/upscale/upscaled.png');
    });

    it('should handle filenames with paths (uses filename as-is)', () => {
      const result = uploader.getProjectRemotePath('subdir/file.png', 'project', 'category');
      expect(result).toBe('/projects/project/category/subdir/file.png');
    });

    it('should handle empty project name', () => {
      const result = uploader.getProjectRemotePath('file.png', '', 'category');
      expect(result).toBe('/projects//category/file.png');
    });

    it('should handle empty category', () => {
      const result = uploader.getProjectRemotePath('file.png', 'project', '');
      expect(result).toBe('/projects/project//file.png');
    });

    it('should handle special characters in filename', () => {
      const result = uploader.getProjectRemotePath('file (1)_test.png', 'project', 'category');
      expect(result).toBe('/projects/project/category/file (1)_test.png');
    });
  });

  // ============================================================
  // getProjectShareUrl Tests
  // ============================================================
  describe('getProjectShareUrl', () => {
    it('should use share_url prefix when share_url is configured', () => {
      const result = uploader.getProjectShareUrl('C01.png', 'wusong', 'characters');
      expect(result).toBe('http://47.109.205.195:10020/projects/wusong/characters/C01.png');
    });

    it('should use baseUrl prefix when share_url is not configured', () => {
      const result = uploaderWithoutShareUrl.getProjectShareUrl('C01.png', 'wusong', 'characters');
      expect(result).toBe('http://192.168.0.92:9998/projects/wusong/characters/C01.png');
    });

    it('should correctly handle Chinese filenames in URL generation', () => {
      const result = uploader.getProjectShareUrl('角色素材.png', 'wusong', 'characters');
      expect(result).toBe('http://47.109.205.195:10020/projects/wusong/characters/角色素材.png');
    });

    it('should handle various categories', () => {
      const categories = ['tigers', 'scenes', 'props', 'videos', 'upscale'];
      categories.forEach(category => {
        const result = uploader.getProjectShareUrl('file.png', 'project', category);
        expect(result).toBe(`http://47.109.205.195:10020/projects/project/${category}/file.png`);
      });
    });

    it('should handle Chinese project name', () => {
      const result = uploader.getProjectShareUrl('file.png', '水浒传', 'characters');
      expect(result).toBe('http://47.109.205.195:10020/projects/水浒传/characters/file.png');
    });
  });

  // ============================================================
  // getRemotePath Tests (date path)
  // ============================================================
  describe('getRemotePath', () => {
    it('should generate date path with baseDir', () => {
      const result = uploader.getRemotePath('file.png');
      expect(result).toMatch(/\/comfy\/\d{4}-\d{1,2}-\d{1,2}\/file\.png/);
    });

    it('should generate date path without baseDir', () => {
      const uploaderNoDir = new DufsUploader({
        server: '192.168.0.92:9998',
        user: 'test',
        pwd: 'test'
      });
      const result = uploaderNoDir.getRemotePath('file.png');
      expect(result).toMatch(/\/\d{4}-\d{1,2}-\d{1,2}\/file\.png/);
    });
  });

  // ============================================================
  // getShareUrl Tests (date path)
  // ============================================================
  describe('getShareUrl', () => {
    it('should generate share URL with share_url prefix', () => {
      const result = uploader.getShareUrl('file.png');
      expect(result).toMatch(/http:\/\/47\.109\.205\.195:10020\/comfy\/\d{4}-\d{1,2}-\d{1,2}\/file\.png/);
    });

    it('should generate share URL with baseUrl when no share_url', () => {
      const result = uploaderWithoutShareUrl.getShareUrl('file.png');
      expect(result).toMatch(/http:\/\/192\.168\.0\.92:9998\/comfy\/\d{4}-\d{1,2}-\d{1,2}\/file\.png/);
    });
  });

  // ============================================================
  // Constructor Tests
  // ============================================================
  describe('constructor', () => {
    it('should initialize with all config values', () => {
      expect(uploader.server).toBe('192.168.0.92:9998');
      expect(uploader.user).toBe('testuser');
      expect(uploader.pwd).toBe('testpwd');
      expect(uploader.baseDir).toBe('comfy');
      expect(uploader.baseUrl).toBe('http://192.168.0.92:9998');
      expect(uploader.shareUrl).toBe('http://47.109.205.195:10020');
    });

    it('should handle missing optional config values', () => {
      const minimalUploader = new DufsUploader({
        server: 'localhost:8080',
        user: 'admin',
        pwd: 'pass'
      });
      expect(minimalUploader.baseDir).toBe('');
      expect(minimalUploader.shareUrl).toBe('');
    });
  });

  // ============================================================
  // getAuthHeader Tests
  // ============================================================
  describe('getAuthHeader', () => {
    it('should generate valid Basic auth header', () => {
      const header = uploader.getAuthHeader();
      expect(header).toMatch(/^Basic [A-Za-z0-9+/=]+$/);

      // Decode and verify
      const credentials = Buffer.from(header.replace('Basic ', ''), 'base64').toString();
      expect(credentials).toBe('testuser:testpwd');
    });
  });

  // ============================================================
  // getRemoteDirPath Tests
  // ============================================================
  describe('getRemoteDirPath', () => {
    it('should generate date directory path with baseDir', () => {
      const result = uploader.getRemoteDirPath();
      expect(result).toMatch(/\/comfy\/\d{4}-\d{1,2}-\d{1,2}\/$/);
    });

    it('should generate date directory path without baseDir', () => {
      const uploaderNoDir = new DufsUploader({
        server: '192.168.0.92:9998',
        user: 'test',
        pwd: 'test'
      });
      const result = uploaderNoDir.getRemoteDirPath();
      expect(result).toMatch(/\/\d{4}-\d{1,2}-\d{1,2}\/$/);
    });
  });

  // ============================================================
  // getShareDirUrl Tests
  // ============================================================
  describe('getShareDirUrl', () => {
    it('should generate share directory URL with share_url prefix', () => {
      const result = uploader.getShareDirUrl();
      expect(result).toMatch(/http:\/\/47\.109\.205\.195:10020\/comfy\/\d{4}-\d{1,2}-\d{1,2}\/$/);
    });

    it('should generate share directory URL with baseUrl when no share_url', () => {
      const result = uploaderWithoutShareUrl.getShareDirUrl();
      expect(result).toMatch(/http:\/\/192\.168\.0\.92:9998\/comfy\/\d{4}-\d{1,2}-\d{1,2}\/$/);
    });
  });

  // ============================================================
  // uploadFile Tests (error cases only - no HTTP mocking)
  // ============================================================
  describe('uploadFile error handling', () => {
    it('should return error when local file not found', async () => {
      const result = await uploader.uploadFile('/nonexistent/path/file.png');
      expect(result.success).toBe(false);
      expect(result.error).toContain('Local file not found');
    });

    it('should return error when local file not found with project options', async () => {
      const result = await uploader.uploadFile('/nonexistent/path/file.png', null, {
        project: 'wusong',
        category: 'characters'
      });
      expect(result.success).toBe(false);
      expect(result.error).toContain('Local file not found');
    });
  });

  // ============================================================
  // uploadFiles Tests (error cases only - no HTTP mocking)
  // ============================================================
  describe('uploadFiles error handling', () => {
    it('should return empty results for empty file list', async () => {
      const result = await uploader.uploadFiles([]);
      expect(result.success).toBe(true);
      expect(result.results).toHaveLength(0);
    });

    it('should handle file not found in batch', async () => {
      const result = await uploader.uploadFiles(['/nonexistent/file.png']);
      expect(result.success).toBe(false);
      expect(result.results).toHaveLength(1);
      expect(result.results[0].success).toBe(false);
      expect(result.results[0].error).toContain('Local file not found');
    });
  });
});
