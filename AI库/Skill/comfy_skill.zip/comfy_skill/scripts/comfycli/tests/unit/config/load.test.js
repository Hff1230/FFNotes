import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import fs from 'fs';
import path from 'path';
import os from 'os';
import ConfigManager from '../../../src/utils/config.js';

describe('ConfigManager.load() - 双文件加载', () => {
  let tmpDir;

  beforeEach(() => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'comfycli-test-'));
  });

  afterEach(() => {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  // 101-1: 两个文件都存在
  it('should load both config files when both exist', () => {
    const comfyConfig = { prompts: { test: { type: 'txt2img', description: 'test' } } };
    const serverConfig = { host: '1.2.3.4', port: 9010 };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify(serverConfig));

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    const result = cm.load();

    expect(result).toBe(true);
    expect(cm.config).toEqual(comfyConfig);
    expect(cm.serverConfig).toEqual(serverConfig);
  });

  // 101-2: 仅 comfy_config 存在
  it('should return true with serverConfig=null when only comfy_config exists', () => {
    const comfyConfig = { prompts: { test: { type: 'txt2img' } } };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    const result = cm.load();

    expect(result).toBe(true);
    expect(cm.config).toEqual(comfyConfig);
    expect(cm.serverConfig).toBeNull();
  });

  // 101-3: comfy_config 不存在
  it('should return false when comfy_config does not exist', () => {
    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    const result = cm.load();

    expect(result).toBe(false);
    expect(cm.loaded).toBe(false);
  });

  // 101-4: server_config 格式错误 (优雅降级)
  it('should return true and set serverConfig=null when server_config has invalid JSON', () => {
    const comfyConfig = { prompts: { test: { type: 'txt2img' } } };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), '{invalid json!!!');

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    const result = cm.load();

    expect(result).toBe(true);
    expect(cm.config).toEqual(comfyConfig);
    expect(cm.serverConfig).toBeNull();
  });

  // 101-5: 自定义 serverConfigPath
  it('should load server config from custom serverConfigPath', () => {
    const comfyConfig = { prompts: { test: { type: 'txt2img' } } };
    const serverConfig = { host: 'custom.server.com', port: 9999 };
    const customServerPath = path.join(tmpDir, 'my-custom-server.json');
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));
    fs.writeFileSync(customServerPath, JSON.stringify(serverConfig));

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      customServerPath
    );
    const result = cm.load();

    expect(result).toBe(true);
    expect(cm.serverConfig).toEqual(serverConfig);
    expect(cm.serverConfig.host).toBe('custom.server.com');
  });

  // 101-6: 两个文件都为空 JSON
  it('should handle both files being empty JSON objects', () => {
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), '{}');
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), '{}');

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    const result = cm.load();

    expect(result).toBe(true);
    expect(cm.config).toEqual({});
    expect(cm.serverConfig).toEqual({});
  });
});
