import { describe, it, expect, beforeEach } from '@jest/globals';
import ConfigManager from '../../../src/utils/config.js';

describe('ConfigManager.validateServerConfig()', () => {
  let cm;

  beforeEach(() => {
    cm = new ConfigManager('/nonexistent/config.json');
  });

  // 105-1: 完整合法配置
  it('should return valid=true for complete config with host, port, api_key, upload', () => {
    cm.serverConfig = {
      host: 'test.example.com',
      port: 9010,
      api_key: 'test-key',
      upload: {
        server: 'upload.example.com:9998',
        user: 'admin',
        pwd: 'password',
        dir: 'comfy',
        share_url: 'http://share.example.com'
      }
    };
    cm.config = {};
    cm.loaded = true;
    const result = cm.validateServerConfig();
    expect(result.valid).toBe(true);
    expect(result.errors).toEqual([]);
  });

  // 105-2: 仅必填字段 host, port
  it('should return valid=true with only required fields host and port', () => {
    cm.serverConfig = { host: '1.2.3.4', port: 8188 };
    cm.config = {};
    cm.loaded = true;
    const result = cm.validateServerConfig();
    expect(result.valid).toBe(true);
  });

  // 105-3: 缺少 host
  it('should return valid=false when host is missing', () => {
    cm.serverConfig = { port: 8188 };
    cm.config = {};
    cm.loaded = true;
    const result = cm.validateServerConfig();
    expect(result.valid).toBe(false);
    expect(result.errors).toContain('Missing required field: host');
  });

  // 105-4: 缺少 port
  it('should return valid=false when port is missing', () => {
    cm.serverConfig = { host: 'test.com' };
    cm.config = {};
    cm.loaded = true;
    const result = cm.validateServerConfig();
    expect(result.valid).toBe(false);
    expect(result.errors).toContain('Missing required field: port');
  });

  // 105-5: upload 不完整 (缺少 user/pwd/dir)
  it('should return valid=false when upload section is incomplete', () => {
    cm.serverConfig = {
      host: 'test.com',
      port: 8188,
      upload: { server: 'upload.example.com' }
    };
    cm.config = {};
    cm.loaded = true;
    const result = cm.validateServerConfig();
    expect(result.valid).toBe(false);
    expect(result.errors).toContain('Field "upload.user" is required and must be a string');
    expect(result.errors).toContain('Field "upload.pwd" is required and must be a string');
    expect(result.errors).toContain('Field "upload.dir" is required and must be a string');
  });

  // 105-6: api_key 为空字符串 (api_key 是可选的，空字符串仍为合法 string)
  it('should return valid=true when api_key is empty string', () => {
    cm.serverConfig = { host: 'test.com', port: 8188, api_key: '' };
    cm.config = {};
    cm.loaded = true;
    const result = cm.validateServerConfig();
    expect(result.valid).toBe(true);
  });

  // 105-7: serverConfig 和 config 均为 null
  it('should handle missing server_config gracefully', () => {
    cm.serverConfig = null;
    cm.config = null;
    cm.loaded = true;
    const result = cm.validateServerConfig();
    expect(result.valid).toBe(false);
    expect(result.errors).toContain('No server configuration available (neither server_config.json nor comfy_config.json)');
  });
});
