/**
 * Unit tests for project-based resource management functions in workflow.js
 * Tests: generateOutputFilename and generateOutputPath
 */
import { describe, it, expect, jest, beforeEach, afterEach } from '@jest/globals';
import { generateOutputFilename, generateOutputPath } from '../../src/core/workflow.js';

describe('generateOutputFilename', () => {
  beforeEach(() => {
    jest.useRealTimers();
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  describe('project + category + name mode', () => {
    it('should use name directly when project, category, and name are all provided', () => {
      const options = { project: 'myproject', category: 'characters', name: 'hero' };
      const result = generateOutputFilename('workflow', '.png', options);
      expect(result).toBe('hero.png');
    });

    it('should support different extensions when project, category, and name are provided', () => {
      const options = { project: 'myproject', category: 'videos', name: 'animation' };

      expect(generateOutputFilename('workflow', '.mp4', options)).toBe('animation.mp4');
      expect(generateOutputFilename('workflow', '.jpg', options)).toBe('animation.jpg');
      expect(generateOutputFilename('workflow', '.webp', options)).toBe('animation.webp');
      expect(generateOutputFilename('workflow', '.gif', options)).toBe('animation.gif');
    });

    it('should handle Chinese name correctly', () => {
      const options = { project: 'myproject', category: 'characters', name: '角色名称' };
      const result = generateOutputFilename('workflow', '.png', options);
      expect(result).toBe('角色名称.png');
    });

    it('should handle name with special characters', () => {
      const options = { project: 'myproject', category: 'scenes', name: 'scene_v1_final' };
      const result = generateOutputFilename('workflow', '.png', options);
      expect(result).toBe('scene_v1_final.png');
    });
  });

  describe('project + category mode (without name)', () => {
    it('should generate project_category_timestamp format when only project and category are provided', () => {
      // Mock Date to return a fixed timestamp
      const mockDate = new Date('2026-03-31T14:25:30');
      jest.useFakeTimers().setSystemTime(mockDate);

      const options = { project: 'myproject', category: 'characters' };
      const result = generateOutputFilename('workflow', '.png', options);
      // Timestamp: 20260331_142530
      expect(result).toBe('myproject_characters_20260331_142530.png');

      jest.useRealTimers();
    });

    it('should support different extensions in project_category mode', () => {
      const mockDate = new Date('2026-03-31T14:25:30');
      jest.useFakeTimers().setSystemTime(mockDate);

      const options = { project: 'myproject', category: 'videos' };

      expect(generateOutputFilename('workflow', '.mp4', options)).toBe('myproject_videos_20260331_142530.mp4');
      expect(generateOutputFilename('workflow', '.jpg', options)).toBe('myproject_videos_20260331_142530.jpg');

      jest.useRealTimers();
    });
  });

  describe('default mode (no project/category)', () => {
    it('should use workflowName_timestamp format when options is empty object', () => {
      const mockDate = new Date('2026-03-31T14:25:30');
      jest.useFakeTimers().setSystemTime(mockDate);

      const result = generateOutputFilename('txt2img', '.png', {});
      expect(result).toBe('txt2img_20260331_142530.png');

      jest.useRealTimers();
    });

    it('should use workflowName_timestamp format when options is not provided', () => {
      const mockDate = new Date('2026-03-31T14:25:30');
      jest.useFakeTimers().setSystemTime(mockDate);

      const result = generateOutputFilename('img2img', '.png');
      expect(result).toBe('img2img_20260331_142530.png');

      jest.useRealTimers();
    });

    it('should use workflowName_timestamp format when only project is provided', () => {
      const mockDate = new Date('2026-03-31T14:25:30');
      jest.useFakeTimers().setSystemTime(mockDate);

      const options = { project: 'myproject' };
      const result = generateOutputFilename('txt2img', '.png', options);
      expect(result).toBe('txt2img_20260331_142530.png');

      jest.useRealTimers();
    });

    it('should use workflowName_timestamp format when only category is provided', () => {
      const mockDate = new Date('2026-03-31T14:25:30');
      jest.useFakeTimers().setSystemTime(mockDate);

      const options = { category: 'characters' };
      const result = generateOutputFilename('txt2img', '.png', options);
      expect(result).toBe('txt2img_20260331_142530.png');

      jest.useRealTimers();
    });

    it('should use workflowName_timestamp format when only name is provided', () => {
      const mockDate = new Date('2026-03-31T14:25:30');
      jest.useFakeTimers().setSystemTime(mockDate);

      const options = { name: 'hero' };
      const result = generateOutputFilename('txt2img', '.png', options);
      expect(result).toBe('txt2img_20260331_142530.png');

      jest.useRealTimers();
    });
  });

  describe('default extension', () => {
    it('should default to .png extension', () => {
      const options = { project: 'myproject', category: 'characters', name: 'hero' };
      // Call with extension = undefined to test default
      const result = generateOutputFilename('workflow', undefined, options);
      expect(result).toBe('hero.png');
    });

    it('should use .png as default in default mode', () => {
      const mockDate = new Date('2026-03-31T14:25:30');
      jest.useFakeTimers().setSystemTime(mockDate);

      const result = generateOutputFilename('txt2img', undefined, {});
      expect(result).toBe('txt2img_20260331_142530.png');

      jest.useRealTimers();
    });
  });

  describe('edge cases', () => {
    it('should handle empty string workflowName', () => {
      const mockDate = new Date('2026-03-31T14:25:30');
      jest.useFakeTimers().setSystemTime(mockDate);

      const result = generateOutputFilename('', '.png', {});
      expect(result).toBe('_20260331_142530.png');

      jest.useRealTimers();
    });

    it('should handle empty string extension', () => {
      const options = { project: 'myproject', category: 'characters', name: 'hero' };
      const result = generateOutputFilename('workflow', '', options);
      expect(result).toBe('hero');
    });

    it('should handle empty string project in project+category mode', () => {
      const mockDate = new Date('2026-03-31T14:25:30');
      jest.useFakeTimers().setSystemTime(mockDate);

      const options = { project: '', category: 'characters' };
      const result = generateOutputFilename('workflow', '.png', options);
      // Empty project is falsy, so should use default mode
      expect(result).toBe('workflow_20260331_142530.png');

      jest.useRealTimers();
    });

    it('should handle empty string category in project+category mode', () => {
      const mockDate = new Date('2026-03-31T14:25:30');
      jest.useFakeTimers().setSystemTime(mockDate);

      const options = { project: 'myproject', category: '' };
      const result = generateOutputFilename('workflow', '.png', options);
      // Empty category is falsy, so should use default mode
      expect(result).toBe('workflow_20260331_142530.png');

      jest.useRealTimers();
    });

    it('should handle empty string name in project+category+name mode', () => {
      const mockDate = new Date('2026-03-31T14:25:30');
      jest.useFakeTimers().setSystemTime(mockDate);

      const options = { project: 'myproject', category: 'characters', name: '' };
      const result = generateOutputFilename('workflow', '.png', options);
      // Empty name is falsy, so should use project_category_timestamp mode
      expect(result).toBe('myproject_characters_20260331_142530.png');

      jest.useRealTimers();
    });
  });

  describe('various category values', () => {
    it('should handle characters category', () => {
      const options = { project: 'game', category: 'characters', name: 'npc1' };
      expect(generateOutputFilename('workflow', '.png', options)).toBe('npc1.png');
    });

    it('should handle tigers category', () => {
      const options = { project: 'game', category: 'tigers', name: 'tiger1' };
      expect(generateOutputFilename('workflow', '.png', options)).toBe('tiger1.png');
    });

    it('should handle scenes category', () => {
      const options = { project: 'game', category: 'scenes', name: 'forest' };
      expect(generateOutputFilename('workflow', '.png', options)).toBe('forest.png');
    });

    it('should handle props category', () => {
      const options = { project: 'game', category: 'props', name: 'sword' };
      expect(generateOutputFilename('workflow', '.png', options)).toBe('sword.png');
    });

    it('should handle videos category', () => {
      const options = { project: 'game', category: 'videos', name: 'intro' };
      expect(generateOutputFilename('workflow', '.mp4', options)).toBe('intro.mp4');
    });

    it('should handle upscale category', () => {
      const options = { project: 'game', category: 'upscale', name: 'hd_version' };
      expect(generateOutputFilename('workflow', '.png', options)).toBe('hd_version.png');
    });
  });

  describe('timestamp format', () => {
    it('should generate correct timestamp format for single-digit month/day', () => {
      // Set to January 5th, 2025 at 09:05:03
      const singleDigitDate = new Date('2025-01-05T09:05:03');
      jest.useFakeTimers().setSystemTime(singleDigitDate);

      const result = generateOutputFilename('workflow', '.png', {});
      expect(result).toBe('workflow_20250105_090503.png');

      jest.useRealTimers();
    });

    it('should generate correct timestamp format for double-digit values', () => {
      // Set to December 31st, 2025 at 23:59:59
      const doubleDigitDate = new Date('2025-12-31T23:59:59');
      jest.useFakeTimers().setSystemTime(doubleDigitDate);

      const result = generateOutputFilename('workflow', '.png', {});
      expect(result).toBe('workflow_20251231_235959.png');

      jest.useRealTimers();
    });
  });
});

describe('generateOutputPath', () => {
  describe('project + category mode', () => {
    it('should generate project/resources/category directory structure', () => {
      const result = generateOutputPath('/output', { project: 'myproject', category: 'characters' });
      // Use normalizePath for cross-platform compatibility
      expect(result).toMatch(/myproject[\/\\]resources[\/\\]characters$/);
      expect(result).toContain('myproject');
      expect(result).toContain('resources');
      expect(result).toContain('characters');
    });

    it('should generate scenes directory correctly', () => {
      const result = generateOutputPath('/output', { project: 'myproject', category: 'scenes' });
      expect(result).toContain('scenes');
      expect(result).toMatch(/myproject[\/\\]resources[\/\\]scenes$/);
    });

    it('should handle videos category', () => {
      const result = generateOutputPath('/output', { project: 'myproject', category: 'videos' });
      expect(result).toContain('videos');
      expect(result).toMatch(/myproject[\/\\]resources[\/\\]videos$/);
    });
  });

  describe('default mode (no project/category)', () => {
    it('should return original directory when options is empty object', () => {
      const result = generateOutputPath('/output', {});
      expect(result).toBe('/output');
    });

    it('should return original directory when options is not provided', () => {
      const result = generateOutputPath('/output');
      expect(result).toBe('/output');
    });

    it('should return original directory when only project is provided', () => {
      const result = generateOutputPath('/output', { project: 'myproject' });
      expect(result).toBe('/output');
    });

    it('should return original directory when only category is provided', () => {
      const result = generateOutputPath('/output', { category: 'characters' });
      expect(result).toBe('/output');
    });
  });

  describe('path handling', () => {
    it('should handle paths with spaces', () => {
      const result = generateOutputPath('/output folder/my project', { project: 'my project', category: 'characters' });
      expect(result).toContain('my project');
      expect(result).toContain('characters');
    });

    it('should handle absolute paths', () => {
      const result = generateOutputPath('C:/Users/test/output', { project: 'myproject', category: 'characters' });
      expect(result).toContain('myproject');
      expect(result).toContain('characters');
    });

    it('should handle relative paths', () => {
      const result = generateOutputPath('./output', { project: 'myproject', category: 'characters' });
      // path.join normalizes './output' to 'output' on most systems
      expect(result).toMatch(/output[\/\\]myproject[\/\\]resources[\/\\]characters$/);
    });

    it('should handle nested relative paths', () => {
      const result = generateOutputPath('../output/images', { project: 'myproject', category: 'scenes' });
      expect(result).toContain('myproject');
      expect(result).toContain('scenes');
    });
  });

  describe('various category values', () => {
    const categories = ['characters', 'tigers', 'scenes', 'props', 'videos', 'upscale'];

    categories.forEach(category => {
      it(`should handle ${category} category correctly`, () => {
        const result = generateOutputPath('/output', { project: 'game', category });
        expect(result).toContain(category);
        expect(result).toMatch(new RegExp(`game[\/\\\\]resources[\/\\\\]${category}$`));
      });
    });
  });

  describe('edge cases', () => {
    it('should handle empty string baseOutputDir', () => {
      const result = generateOutputPath('', { project: 'myproject', category: 'characters' });
      expect(result).toMatch(/myproject[\/\\]resources[\/\\]characters$/);
    });

    it('should handle empty string project', () => {
      const result = generateOutputPath('/output', { project: '', category: 'characters' });
      // Empty project is falsy, so should return original directory
      expect(result).toBe('/output');
    });

    it('should handle empty string category', () => {
      const result = generateOutputPath('/output', { project: 'myproject', category: '' });
      // Empty category is falsy, so should return original directory
      expect(result).toBe('/output');
    });

    it('should handle undefined options gracefully', () => {
      const result = generateOutputPath('/output', undefined);
      expect(result).toBe('/output');
    });
  });

  describe('path structure validation', () => {
    it('should always include resources folder between project and category', () => {
      const result = generateOutputPath('/output', { project: 'game', category: 'characters' });
      // Check that 'resources' comes between project and category
      const pathParts = result.split(/[/\\]/);
      const projectIndex = pathParts.indexOf('game');
      const resourcesIndex = pathParts.indexOf('resources');
      const categoryIndex = pathParts.indexOf('characters');

      expect(projectIndex).toBeLessThan(resourcesIndex);
      expect(resourcesIndex).toBeLessThan(categoryIndex);
    });
  });
});
