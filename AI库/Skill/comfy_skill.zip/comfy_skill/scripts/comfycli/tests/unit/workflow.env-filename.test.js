/**
 * Unit tests for generateOutputFilename with env variable context
 * Tests: TC-025 through TC-029
 *
 * Validates that filename generation logic is unaffected by the
 * COMFY_PROJECT_ROOT fix and produces correct filenames in all modes.
 */
import { jest, describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import { generateOutputFilename } from '../../src/core/workflow.js';

describe('generateOutputFilename environment variable interaction', () => {
  beforeEach(() => {
    jest.useFakeTimers().setSystemTime(new Date('2026-04-20T12:30:45'));
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  // ── TC-025: project + category + name → uses name directly ──
  it('TC-025: project+category+name → uses explicit name', () => {
    const result = generateOutputFilename('wf', '.png', {
      project: 'w',
      category: 'c',
      name: 'N01'
    });
    expect(result).toBe('N01.png');
  });

  // ── TC-026: project + category without name → timestamp pattern ──
  it('TC-026: project+category without name → p_c_timestamp pattern', () => {
    const result = generateOutputFilename('wf', '.png', {
      project: 'w',
      category: 'c'
    });
    expect(result).toBe('w_c_20260420_123045.png');
  });

  // ── TC-027: default mode → workflow_timestamp ──
  it('TC-027: default mode (no project/category) → workflow_timestamp', () => {
    const result = generateOutputFilename('wf', '.png', {});
    expect(result).toBe('wf_20260420_123045.png');
  });

  // ── TC-028: video extension ──
  it('TC-028: video extension → correct .mp4 filename', () => {
    const result = generateOutputFilename('wf', '.mp4', {});
    expect(result).toBe('wf_20260420_123045.mp4');
  });

  // ── TC-029: Chinese name ──
  it('TC-029: Chinese name → preserved correctly', () => {
    const result = generateOutputFilename('wf', '.png', {
      project: 'w',
      category: 'c',
      name: '武松_正面'
    });
    expect(result).toBe('武松_正面.png');
  });
});

// ── Additional: Verify filename is independent of env var state ──
describe('generateOutputFilename is env-independent', () => {
  beforeEach(() => {
    jest.useFakeTimers().setSystemTime(new Date('2026-04-20T12:30:45'));
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  it('produces same filename regardless of COMFY_PROJECT_ROOT state', () => {
    // Filenames should be identical whether env var is set or not
    const opts = { project: 'test', category: 'scenes', name: 'scene01' };

    const result1 = generateOutputFilename('wf', '.png', opts);
    const result2 = generateOutputFilename('wf', '.png', opts);

    expect(result1).toBe(result2);
    expect(result1).toBe('scene01.png');
  });

  it('produces same timestamp filename in both contexts', () => {
    const result1 = generateOutputFilename('txt2img', '.png', {});
    const result2 = generateOutputFilename('txt2img', '.png', {});

    expect(result1).toBe(result2);
    expect(result1).toBe('txt2img_20260420_123045.png');
  });
});
