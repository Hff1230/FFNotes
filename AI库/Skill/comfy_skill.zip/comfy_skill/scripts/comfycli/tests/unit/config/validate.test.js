import { describe, it, expect, beforeEach } from '@jest/globals';
import ConfigManager from '../../../src/utils/config.js';

describe('ConfigManager.validate()', () => {
  let cm;

  beforeEach(() => {
    cm = new ConfigManager('/nonexistent/config.json');
  });

  // 104-1: 合法配置，无 host/port → comfy_config 含 prompts → validate() 返回 {valid: true}
  it('should return valid=true for config with prompts and no host/port', () => {
    cm.config = { prompts: {} };
    cm.loaded = true;
    const result = cm.validate();
    expect(result.valid).toBe(true);
    expect(result.errors).toEqual([]);
  });

  // 104-2: 合法配置，含 host/port → 同时包含 prompts 和 host/port → validate() 返回 {valid: true}（不报错）
  it('should not report errors for host/port fields when they are present', () => {
    cm.config = { prompts: {}, host: '1.2.3.4', port: 9010 };
    cm.loaded = true;
    const result = cm.validate();
    expect(result.valid).toBe(true);
    expect(result.errors).toEqual([]);
  });

  // 104-3: 缺少 prompts 字段 → comfy_config 无 prompts → validate() 返回 {valid: false}，错误含 prompts
  it('should return valid=false when prompts field is missing', () => {
    cm.config = { resolution: {} };
    cm.loaded = true;
    const result = cm.validate();
    expect(result.valid).toBe(false);
    expect(result.errors).toEqual(expect.arrayContaining([
      expect.stringContaining('prompts')
    ]));
  });

  // 104-4: prompts 为空对象 → prompts: {} → validate() 返回 {valid: true} (循环不执行，errors 保持空)
  it('should return valid=true for empty prompts object', () => {
    cm.config = { prompts: {} };
    cm.loaded = true;
    const result = cm.validate();
    expect(result.valid).toBe(true);
  });

  // 104-5: 合法配置含 resolution → 含 prompts 和 resolution → validate() 返回 {valid: true}
  it('should return valid=true for config with prompts and resolution', () => {
    cm.config = { prompts: {}, resolution: { pic_gen: {} } };
    cm.loaded = true;
    const result = cm.validate();
    expect(result.valid).toBe(true);
  });
});
