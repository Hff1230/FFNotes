/**
 * Unit tests for generateOutputPath environment variable linkage
 * Tests: TC-020 through TC-024
 *
 * Validates that generateOutputPath correctly works with the
 * DEFAULT_OUTPUT_PATH computed from COMFY_PROJECT_ROOT.
 */
import { jest, describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import path from 'path';
import { generateOutputPath } from '../../src/core/workflow.js';

/**
 * Replicates DEFAULT_OUTPUT_PATH calculation from cli.js
 * to test the linkage between env var and generateOutputPath
 */
function computeDefaultOutputPath(envValue, cwdValue) {
  const root = envValue || undefined;
  return root
    ? path.join(root, 'output')
    : path.join(cwdValue, 'output');
}

describe('generateOutputPath environment variable linkage', () => {
  // ── TC-020: ENV + no project/category → returns base path ──
  it('TC-020: ENV set, no project/category → returns ENV base path', () => {
    const baseOutput = computeDefaultOutputPath('/proj', '/cwd');
    expect(baseOutput).toBe(path.normalize('/proj/output'));

    const result = generateOutputPath(baseOutput, {});
    expect(result).toBe(baseOutput);
  });

  // ── TC-021: ENV + project + category → full path ──
  it('TC-021: ENV + project + category → full subdirectory path', () => {
    const baseOutput = computeDefaultOutputPath('/proj', '/cwd');
    const result = generateOutputPath(baseOutput, { project: 'w', category: 'c' });

    expect(result).toMatch(/w[\/\\]resources[\/\\]c$/);
    expect(result).toContain('proj');
    expect(result).toContain('output');
    expect(result).toContain('w');
    expect(result).toContain('resources');
    expect(result).toContain('c');
  });

  // ── TC-022: ENV + project only → no change (returns base) ──
  it('TC-022: ENV + project without category → returns base path unchanged', () => {
    const baseOutput = computeDefaultOutputPath('/proj', '/cwd');
    const result = generateOutputPath(baseOutput, { project: 'w' });

    expect(result).toBe(baseOutput);
  });

  // ── TC-023: CWD fallback + project + category → full path ──
  it('TC-023: CWD fallback + project + category → correct subdirectory', () => {
    const baseOutput = computeDefaultOutputPath(undefined, '/cwd/dir');
    expect(baseOutput).toBe(path.normalize('/cwd/dir/output'));

    const result = generateOutputPath(baseOutput, { project: 'w', category: 'c' });
    expect(result).toMatch(/w[\/\\]resources[\/\\]c$/);
    expect(result).toContain('output');
  });

  // ── TC-024: Absolute path output + project + category ──
  it('TC-024: explicit absolute output + project + category → correct subdirectory', () => {
    const customOutput = '/custom';
    const result = generateOutputPath(customOutput, { project: 'w', category: 'c' });

    expect(result).toMatch(/custom[\/\\]w[\/\\]resources[\/\\]c$/);
  });
});

// ── Integration: full flow from env → DEFAULT_OUTPUT_PATH → generateOutputPath ──
describe('Full env → output path flow', () => {
  it('should compute correct path: COMFY_PROJECT_ROOT → output → project/resources/category', () => {
    const envBase = computeDefaultOutputPath('/my/project', '/fallback');
    expect(envBase).toBe(path.normalize('/my/project/output'));

    const finalPath = generateOutputPath(envBase, { project: 'wusong', category: 'characters' });
    const normalized = path.normalize(finalPath);

    expect(normalized).toBe(path.normalize('/my/project/output/wusong/resources/characters'));
  });

  it('should handle relative --output with project/category', () => {
    const relativeOutput = './my-output';
    const result = generateOutputPath(relativeOutput, { project: 'demo', category: 'scenes' });

    expect(result).toContain('demo');
    expect(result).toContain('resources');
    expect(result).toContain('scenes');
  });
});
