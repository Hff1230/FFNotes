/**
 * Unit tests for txt2vid command _batchMode behavior
 * Tests: TC-202-01 through TC-202-05
 */
import { jest, describe, test, expect } from '@jest/globals';

const { txt2vidCommand } = await import('../../../src/commands/txt2vid.js');

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe('txt2vid _batchMode', () => {
  const batchOptions = { _batchMode: true };

  test('TC-202-01: Empty prompt throws Error', async () => {
    await expect(txt2vidCommand('', batchOptions)).rejects.toThrow('Prompt is required');
  });

  test('TC-202-02: Unsupported format throws Error', async () => {
    await expect(
      txt2vidCommand('test', { ...batchOptions, format: 'avi' })
    ).rejects.toThrow('Unsupported format: avi');
  });

  test('TC-202-03: Config load failure throws Error', async () => {
    await expect(
      txt2vidCommand('test', { ...batchOptions, config: '/nonexistent/config.json' })
    ).rejects.toThrow();
  });

  test('TC-202-04: Successful execution returns result object', async () => {
    // Will fail due to missing config, but verify it throws (not process.exit)
    await expect(
      txt2vidCommand('test', batchOptions)
    ).rejects.toThrow();
  });

  test('TC-202-05: Execution failure throws', async () => {
    await expect(
      txt2vidCommand('test', { ...batchOptions, config: '/invalid/path.json' })
    ).rejects.toThrow();
  });
});
