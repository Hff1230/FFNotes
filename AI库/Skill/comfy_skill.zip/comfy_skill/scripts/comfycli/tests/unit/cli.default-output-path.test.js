/**
 * Unit tests for DEFAULT_OUTPUT_PATH calculation logic in cli.js
 * Tests: TC-001 through TC-010
 *
 * Validates the COMFY_PROJECT_ROOT environment variable integration:
 * Priority chain: explicit --output > COMFY_PROJECT_ROOT > process.cwd()
 */
import { jest, describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import path from 'path';

// The DEFAULT_OUTPUT_PATH logic replicated for isolated testing
// (cli.js does not export this constant)
function computeDefaultOutputPath(envValue, cwdValue) {
  const root = envValue || undefined;
  return root
    ? path.join(root, 'output')
    : path.join(cwdValue, 'output');
}

describe('DEFAULT_OUTPUT_PATH calculation', () => {
  let originalEnv;
  let cwdSpy;

  beforeEach(() => {
    originalEnv = { ...process.env };
    delete process.env.COMFY_PROJECT_ROOT;
    cwdSpy = jest.spyOn(process, 'cwd');
  });

  afterEach(() => {
    process.env = { ...originalEnv };
    cwdSpy.mockRestore();
  });

  // ── TC-001: ENV set → path correct ──
  it('TC-001: uses COMFY_PROJECT_ROOT when set', () => {
    process.env.COMFY_PROJECT_ROOT = '/tmp/project';
    cwdSpy.mockReturnValue('/some/cwd');

    const result = computeDefaultOutputPath(process.env.COMFY_PROJECT_ROOT, process.cwd());
    expect(result).toBe(path.normalize('/tmp/project/output'));
  });

  // ── TC-002: ENV unset → fallback to cwd ──
  it('TC-002: falls back to process.cwd() when ENV unset', () => {
    delete process.env.COMFY_PROJECT_ROOT;
    cwdSpy.mockReturnValue('/current/working/dir');

    const result = computeDefaultOutputPath(process.env.COMFY_PROJECT_ROOT, process.cwd());
    expect(result).toBe(path.normalize('/current/working/dir/output'));
  });

  // ── TC-003: ENV with trailing slash ──
  it('TC-003: handles trailing slash in COMFY_PROJECT_ROOT', () => {
    process.env.COMFY_PROJECT_ROOT = '/tmp/proj/';
    cwdSpy.mockReturnValue('/some/cwd');

    const result = computeDefaultOutputPath(process.env.COMFY_PROJECT_ROOT, process.cwd());
    // path.join normalizes trailing slashes
    expect(result).toBe(path.normalize('/tmp/proj/output'));
  });

  // ── TC-004: ENV empty string → treated as unset ──
  it('TC-004: treats empty string COMFY_PROJECT_ROOT as unset', () => {
    process.env.COMFY_PROJECT_ROOT = '';
    cwdSpy.mockReturnValue('/fallback/cwd');

    const result = computeDefaultOutputPath(process.env.COMFY_PROJECT_ROOT, process.cwd());
    // Empty string is falsy, so should fallback to cwd
    expect(result).toBe(path.normalize('/fallback/cwd/output'));
  });

  // ── TC-005: Windows path ──
  it('TC-005: handles Windows-style paths', () => {
    process.env.COMFY_PROJECT_ROOT = 'D:\\project';
    cwdSpy.mockReturnValue('C:\\Users\\test');

    const result = computeDefaultOutputPath(process.env.COMFY_PROJECT_ROOT, process.cwd());
    expect(result).toBe(path.join('D:\\project', 'output'));
  });

  // ── TC-006: Path with spaces ──
  it('TC-006: handles paths with spaces', () => {
    process.env.COMFY_PROJECT_ROOT = '/tmp/my project';
    cwdSpy.mockReturnValue('/some/cwd');

    const result = computeDefaultOutputPath(process.env.COMFY_PROJECT_ROOT, process.cwd());
    expect(result).toBe(path.normalize('/tmp/my project/output'));
  });

  // ── TC-007: Path with Chinese characters ──
  it('TC-007: handles paths with Chinese characters', () => {
    process.env.COMFY_PROJECT_ROOT = '/tmp/项目目录';
    cwdSpy.mockReturnValue('/some/cwd');

    const result = computeDefaultOutputPath(process.env.COMFY_PROJECT_ROOT, process.cwd());
    expect(result).toBe(path.normalize('/tmp/项目目录/output'));
  });

  // ── TC-008: UNC network path ──
  it('TC-008: handles UNC network paths', () => {
    process.env.COMFY_PROJECT_ROOT = '\\\\server\\share';
    cwdSpy.mockReturnValue('C:\\local');

    const result = computeDefaultOutputPath(process.env.COMFY_PROJECT_ROOT, process.cwd());
    expect(result).toBe(path.join('\\\\server\\share', 'output'));
  });

  // ── TC-009: ENV set but explicit --output overrides ──
  it('TC-009: explicit --output overrides COMFY_PROJECT_ROOT', () => {
    process.env.COMFY_PROJECT_ROOT = '/proj/env';
    cwdSpy.mockReturnValue('/some/cwd');

    // When user provides --output, that value is used directly
    // The DEFAULT_OUTPUT_PATH is only the default for --output option
    const explicitOutput = '/custom/path';
    const result = explicitOutput || computeDefaultOutputPath(process.env.COMFY_PROJECT_ROOT, process.cwd());
    expect(result).toBe('/custom/path');
    // Verify ENV-based default would be different
    const defaultPath = computeDefaultOutputPath(process.env.COMFY_PROJECT_ROOT, process.cwd());
    expect(defaultPath).not.toBe('/custom/path');
  });

  // ── TC-010: No ENV + explicit --output ──
  it('TC-010: explicit --output works without COMFY_PROJECT_ROOT', () => {
    delete process.env.COMFY_PROJECT_ROOT;
    cwdSpy.mockReturnValue('/some/cwd');

    const explicitOutput = './out';
    const result = explicitOutput || computeDefaultOutputPath(process.env.COMFY_PROJECT_ROOT, process.cwd());
    expect(result).toBe('./out');
  });
});

// ── Verify the actual cli.js logic matches our test logic ──
describe('cli.js DEFAULT_OUTPUT_PATH implementation verification', () => {
  it('should contain COMFY_PROJECT_ROOT in source code', async () => {
    const fs = await import('fs');
    const cliSource = fs.readFileSync(
      path.join(process.cwd(), 'src/cli.js'), 'utf-8'
    );
    expect(cliSource).toContain('COMFY_PROJECT_ROOT');
    expect(cliSource).toContain("path.join(process.env.COMFY_PROJECT_ROOT, 'output')");
    expect(cliSource).toContain("path.join(process.cwd(), 'output')");
  });

  it('should use conditional expression for DEFAULT_OUTPUT_PATH', async () => {
    const fs = await import('fs');
    const cliSource = fs.readFileSync(
      path.join(process.cwd(), 'src/cli.js'), 'utf-8'
    );
    // Verify the ternary pattern exists
    expect(cliSource).toMatch(/process\.env\.COMFY_PROJECT_ROOT\s*\?\s*path\.join/);
  });
});
