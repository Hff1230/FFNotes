/**
 * Unit tests for img2img command _batchMode behavior
 * Tests: TC-201-07 through TC-201-12
 */
import { jest, describe, test, expect } from '@jest/globals';

const { img2imgCommand } = await import('../../../src/commands/img2img.js');

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe('img2img _batchMode', () => {
  const batchOptions = { _batchMode: true };

  test('TC-201-07: Empty image throws Error "At least one input image path is required"', async () => {
    await expect(img2imgCommand('', 'test prompt', batchOptions)).rejects.toThrow(
      'At least one input image path is required'
    );
  });

  test('TC-201-08: Empty prompt throws Error "Prompt is required"', async () => {
    await expect(img2imgCommand('photo.jpg', '', batchOptions)).rejects.toThrow(
      'Prompt is required'
    );
  });

  test('TC-201-09: Too many images (>4) throws Error', async () => {
    await expect(
      img2imgCommand('a.jpg,b.jpg,c.jpg,d.jpg,e.jpg', 'test', batchOptions)
    ).rejects.toThrow('Too many images provided');
  });

  test('TC-201-10: Invalid strength throws Error', async () => {
    // Use test fixture image so image validation passes, then strength check fails
    const path = await import('path');
    const fixtureImage = path.resolve('./tests/fixtures/images/test.png');
    await expect(
      img2imgCommand(fixtureImage, 'test', { ...batchOptions, strength: 5.0 })
    ).rejects.toThrow('Strength must be a number between 0 and 1');
  });

  test('TC-201-11: Image validation failure throws Error', async () => {
    await expect(
      img2imgCommand('nonexistent_file_xyz.jpg', 'test prompt', batchOptions)
    ).rejects.toThrow();
  });

  test('TC-201-12: Execution failure throws (not process.exit)', async () => {
    await expect(
      img2imgCommand('test.jpg', 'test prompt', batchOptions)
    ).rejects.toThrow();
  });
});
