/**
 * Unit tests for downloadResource function
 * Tests: HTTP download, error handling, file naming conflicts, custom directories
 *
 * Test Cases:
 * - D001: Normal download (HTTP 200)
 * - D002: 404 error handling
 * - D003: 403 error handling
 * - D004: 500 error handling
 * - D005: File name conflict (first conflict)
 * - D006: Multiple conflicts
 * - D007: Custom tmpDir
 * - D008: Directory auto-creation
 * - D009: PNG download
 * - D010: WebP download
 */
import { describe, it, expect, beforeEach, afterEach, jest } from '@jest/globals';
import fs from 'fs';
import path from 'path';
import resourceDownloader from '../../src/utils/resource_downloader.js';

const { downloadResource } = resourceDownloader;

// Store original fetch for restoration
const originalFetch = global.fetch;

// Test constants
const TEST_TMP_DIR = './test_tmp_download';
const CUSTOM_TMP_DIR = './custom_tmp_download';

// Helper to clean up directories
function cleanupDirectory(dirPath) {
  if (fs.existsSync(dirPath)) {
    fs.rmSync(dirPath, { recursive: true, force: true });
  }
}

// Helper to check if file exists
function fileExists(filePath) {
  return fs.existsSync(filePath);
}

// Helper to read file content
function readFileContent(filePath) {
  return fs.readFileSync(filePath);
}

// Helper to create mock fetch response
function createMockResponse(buffer, status = 200) {
  const ok = status >= 200 && status < 300;
  return {
    ok,
    status,
    statusText: ok ? 'OK' : 'Error',
    arrayBuffer: async () => {
      if (Buffer.isBuffer(buffer)) {
        return buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
      }
      return new ArrayBuffer(0);
    }
  };
}

// Helper to mock fetch for a URL
function mockFetch(url, response) {
  global.fetch = jest.fn().mockImplementation((requestUrl) => {
    if (requestUrl === url) {
      return Promise.resolve(response);
    }
    return Promise.reject(new Error(`Unexpected URL: ${requestUrl}`));
  });
}

// Helper to restore original fetch
function restoreFetch() {
  global.fetch = originalFetch;
}

describe('downloadResource', () => {
  beforeEach(() => {
    // Clean up test directories before each test
    cleanupDirectory(TEST_TMP_DIR);
    cleanupDirectory(CUSTOM_TMP_DIR);
  });

  afterEach(() => {
    // Restore original fetch after each test
    restoreFetch();
    // Clean up test directories after each test
    cleanupDirectory(TEST_TMP_DIR);
    cleanupDirectory(CUSTOM_TMP_DIR);
  });

  // ============================================================
  // D001: Normal download (P0)
  // ============================================================
  describe('D001 - Normal download', () => {
    it('should download file successfully and return correct path', async () => {
      const url = 'http://example.com/photo.jpg';
      const imageData = Buffer.from('fake-jpeg-data');

      mockFetch(url, createMockResponse(imageData, 200));

      const result = await downloadResource(url, TEST_TMP_DIR);

      // Verify returned path
      expect(result).toBe(path.join(TEST_TMP_DIR, 'photo.jpg'));

      // Verify file exists
      expect(fileExists(result)).toBe(true);

      // Verify file content
      const content = readFileContent(result);
      expect(content).toEqual(imageData);
    });
  });

  // ============================================================
  // D002: 404 error (P0)
  // ============================================================
  describe('D002 - 404 error', () => {
    it('should throw error with HTTP 404 status', async () => {
      const url = 'http://example.com/notfound.jpg';

      mockFetch(url, createMockResponse(Buffer.from(''), 404));

      await expect(downloadResource(url, TEST_TMP_DIR))
        .rejects.toThrow('Failed to download resource: HTTP 404');
    });
  });

  // ============================================================
  // D003: 403 error (P0)
  // ============================================================
  describe('D003 - 403 error', () => {
    it('should throw error with HTTP 403 status', async () => {
      const url = 'http://example.com/forbidden.jpg';

      mockFetch(url, createMockResponse(Buffer.from(''), 403));

      await expect(downloadResource(url, TEST_TMP_DIR))
        .rejects.toThrow('Failed to download resource: HTTP 403');
    });
  });

  // ============================================================
  // D004: 500 error (P1)
  // ============================================================
  describe('D004 - 500 error', () => {
    it('should throw error with HTTP 500 status', async () => {
      const url = 'http://example.com/error.jpg';

      mockFetch(url, createMockResponse(Buffer.from(''), 500));

      await expect(downloadResource(url, TEST_TMP_DIR))
        .rejects.toThrow('Failed to download resource: HTTP 500');
    });
  });

  // ============================================================
  // D005: File name conflict - first conflict (P0)
  // ============================================================
  describe('D005 - File name conflict', () => {
    it('should append _1 suffix when file already exists', async () => {
      const url = 'http://example.com/photo.jpg';
      const imageData1 = Buffer.from('first-download');
      const imageData2 = Buffer.from('second-download');

      // First download
      mockFetch(url, createMockResponse(imageData1, 200));
      const result1 = await downloadResource(url, TEST_TMP_DIR);
      expect(result1).toBe(path.join(TEST_TMP_DIR, 'photo.jpg'));
      expect(fileExists(result1)).toBe(true);

      // Second download - should get _1 suffix
      restoreFetch();
      mockFetch(url, createMockResponse(imageData2, 200));
      const result2 = await downloadResource(url, TEST_TMP_DIR);
      expect(result2).toBe(path.join(TEST_TMP_DIR, 'photo_1.jpg'));
      expect(fileExists(result2)).toBe(true);

      // Verify both files exist with correct content
      expect(readFileContent(result1)).toEqual(imageData1);
      expect(readFileContent(result2)).toEqual(imageData2);
    });
  });

  // ============================================================
  // D006: Multiple conflicts (P1)
  // ============================================================
  describe('D006 - Multiple conflicts', () => {
    it('should append _2 suffix on third download of same filename', async () => {
      const url = 'http://example.com/photo.jpg';
      const imageData1 = Buffer.from('first-download');
      const imageData2 = Buffer.from('second-download');
      const imageData3 = Buffer.from('third-download');

      // First download
      mockFetch(url, createMockResponse(imageData1, 200));
      const result1 = await downloadResource(url, TEST_TMP_DIR);
      expect(result1).toBe(path.join(TEST_TMP_DIR, 'photo.jpg'));

      // Second download
      restoreFetch();
      mockFetch(url, createMockResponse(imageData2, 200));
      const result2 = await downloadResource(url, TEST_TMP_DIR);
      expect(result2).toBe(path.join(TEST_TMP_DIR, 'photo_1.jpg'));

      // Third download - should get _2 suffix
      restoreFetch();
      mockFetch(url, createMockResponse(imageData3, 200));
      const result3 = await downloadResource(url, TEST_TMP_DIR);
      expect(result3).toBe(path.join(TEST_TMP_DIR, 'photo_2.jpg'));

      // Verify all three files exist
      expect(fileExists(result1)).toBe(true);
      expect(fileExists(result2)).toBe(true);
      expect(fileExists(result3)).toBe(true);

      // Verify correct content
      expect(readFileContent(result1)).toEqual(imageData1);
      expect(readFileContent(result2)).toEqual(imageData2);
      expect(readFileContent(result3)).toEqual(imageData3);
    });
  });

  // ============================================================
  // D007: Custom tmpDir (P1)
  // ============================================================
  describe('D007 - Custom tmpDir', () => {
    it('should save file to custom directory', async () => {
      const url = 'http://example.com/test.jpg';
      const imageData = Buffer.from('test-image-data');

      mockFetch(url, createMockResponse(imageData, 200));

      const result = await downloadResource(url, CUSTOM_TMP_DIR);

      // Verify path uses custom directory
      expect(result).toBe(path.join(CUSTOM_TMP_DIR, 'test.jpg'));
      expect(fileExists(result)).toBe(true);

      // Verify custom directory was created
      expect(fs.existsSync(CUSTOM_TMP_DIR)).toBe(true);
    });
  });

  // ============================================================
  // D008: Directory auto-creation (P1)
  // ============================================================
  describe('D008 - Directory auto-creation', () => {
    it('should create tmpDir automatically when it does not exist', async () => {
      const url = 'http://example.com/test.jpg';
      const imageData = Buffer.from('test-image-data');
      const newDir = './auto_created_dir';

      // Ensure directory does not exist
      cleanupDirectory(newDir);
      expect(fs.existsSync(newDir)).toBe(false);

      mockFetch(url, createMockResponse(imageData, 200));

      const result = await downloadResource(url, newDir);

      // Verify directory was created
      expect(fs.existsSync(newDir)).toBe(true);
      expect(fileExists(result)).toBe(true);

      // Cleanup
      cleanupDirectory(newDir);
    });

    it('should create nested directories with recursive option', async () => {
      const url = 'http://example.com/test.jpg';
      const imageData = Buffer.from('test-image-data');
      const nestedDir = './nested/dir/structure';

      // Ensure directory does not exist
      cleanupDirectory('./nested');

      mockFetch(url, createMockResponse(imageData, 200));

      const result = await downloadResource(url, nestedDir);

      // Verify nested directories were created
      expect(fs.existsSync(nestedDir)).toBe(true);
      expect(fileExists(result)).toBe(true);

      // Cleanup
      cleanupDirectory('./nested');
    });
  });

  // ============================================================
  // D009: PNG download (P0)
  // ============================================================
  describe('D009 - PNG download', () => {
    it('should download and save PNG file correctly', async () => {
      const url = 'http://example.com/test.png';
      // Minimal PNG header-like data for testing
      const pngData = Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00, 0x00]);

      mockFetch(url, createMockResponse(pngData, 200));

      const result = await downloadResource(url, TEST_TMP_DIR);

      expect(result).toBe(path.join(TEST_TMP_DIR, 'test.png'));
      expect(fileExists(result)).toBe(true);

      const content = readFileContent(result);
      expect(content).toEqual(pngData);
    });
  });

  // ============================================================
  // D010: WebP download (P1)
  // ============================================================
  describe('D010 - WebP download', () => {
    it('should download and save WebP file correctly', async () => {
      const url = 'http://example.com/test.webp';
      // WebP header-like data for testing
      const webpData = Buffer.from('RIFF....WEBP');

      mockFetch(url, createMockResponse(webpData, 200));

      const result = await downloadResource(url, TEST_TMP_DIR);

      expect(result).toBe(path.join(TEST_TMP_DIR, 'test.webp'));
      expect(fileExists(result)).toBe(true);

      const content = readFileContent(result);
      expect(content).toEqual(webpData);
    });
  });

  // ============================================================
  // Additional coverage tests
  // ============================================================
  describe('Additional coverage', () => {
    it('should handle various HTTP error codes', async () => {
      const errorCodes = [400, 401, 408, 429, 502, 503, 504];

      for (const code of errorCodes) {
        const url = `http://example.com/error${code}.jpg`;

        mockFetch(url, createMockResponse(Buffer.from(''), code));

        await expect(downloadResource(url, TEST_TMP_DIR))
          .rejects.toThrow(`Failed to download resource: HTTP ${code}`);

        restoreFetch();
      }
    });

    it('should use default tmpDir when not specified', async () => {
      const url = 'http://example.com/default.jpg';
      const imageData = Buffer.from('default-test');

      mockFetch(url, createMockResponse(imageData, 200));

      // Use default directory
      const result = await downloadResource(url);

      // Should use ./tmp as default
      expect(result).toBe(path.join('./tmp', 'default.jpg'));
      expect(fileExists(result)).toBe(true);

      // Cleanup default tmp
      cleanupDirectory('./tmp');
    });

    it('should handle URLs with query parameters', async () => {
      const url = 'http://example.com/image.jpg?v=1&t=123';
      const imageData = Buffer.from('query-param-test');

      mockFetch(url, createMockResponse(imageData, 200));

      const result = await downloadResource(url, TEST_TMP_DIR);

      // Should extract filename without query params
      expect(result).toBe(path.join(TEST_TMP_DIR, 'image.jpg'));
      expect(fileExists(result)).toBe(true);
    });

    it('should handle filenames with special characters', async () => {
      const url = 'http://example.com/my-image_test(1).jpg';
      const imageData = Buffer.from('special-chars-test');

      mockFetch(url, createMockResponse(imageData, 200));

      const result = await downloadResource(url, TEST_TMP_DIR);

      expect(result).toBe(path.join(TEST_TMP_DIR, 'my-image_test(1).jpg'));
      expect(fileExists(result)).toBe(true);
    });

    it('should handle binary data correctly', async () => {
      const url = 'http://example.com/binary.bin';
      // Create buffer with all byte values
      const binaryData = Buffer.alloc(256);
      for (let i = 0; i < 256; i++) {
        binaryData[i] = i;
      }

      mockFetch(url, createMockResponse(binaryData, 200));

      const result = await downloadResource(url, TEST_TMP_DIR);
      const content = readFileContent(result);

      expect(content).toEqual(binaryData);
    });

    it('should handle large file conflict numbers', async () => {
      const url = 'http://example.com/conflict.jpg';
      const filename = 'conflict.jpg';
      const filepath = path.join(TEST_TMP_DIR, filename);

      // Create directory
      fs.mkdirSync(TEST_TMP_DIR, { recursive: true });

      // Pre-create files to simulate conflicts up to _5
      fs.writeFileSync(filepath, Buffer.from('original'));
      fs.writeFileSync(path.join(TEST_TMP_DIR, 'conflict_1.jpg'), Buffer.from('1'));
      fs.writeFileSync(path.join(TEST_TMP_DIR, 'conflict_2.jpg'), Buffer.from('2'));
      fs.writeFileSync(path.join(TEST_TMP_DIR, 'conflict_3.jpg'), Buffer.from('3'));
      fs.writeFileSync(path.join(TEST_TMP_DIR, 'conflict_4.jpg'), Buffer.from('4'));
      fs.writeFileSync(path.join(TEST_TMP_DIR, 'conflict_5.jpg'), Buffer.from('5'));

      const imageData = Buffer.from('new-download');

      mockFetch(url, createMockResponse(imageData, 200));

      const result = await downloadResource(url, TEST_TMP_DIR);

      // Should get _6 since 0-5 are taken
      expect(result).toBe(path.join(TEST_TMP_DIR, 'conflict_6.jpg'));
      expect(fileExists(result)).toBe(true);
    });
  });
});
