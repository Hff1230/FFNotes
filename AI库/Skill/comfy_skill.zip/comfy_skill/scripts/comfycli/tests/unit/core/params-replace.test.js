/**
 * Unit tests for params replacement in 2img2video workflow
 * Tests: TC-UT-001 (replaceVariables), TC-UT-002 (mergeWorkflowParams + promptVars)
 */
import { jest, describe, test, expect, beforeAll } from '@jest/globals';
import { replaceVariables, mergeWorkflowParams } from '../../../src/core/workflow.js';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECT_ROOT = path.resolve(__dirname, '../../../');
const CONFIG_PATH = path.join(PROJECT_ROOT, 'config', 'comfy_config.json');

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

/** Minimal workflow containing only the video-parameter nodes */
const minimalWorkflow = {
  '98': { inputs: { value: 720 }, class_type: 'PrimitiveInt', _meta: { title: 'HEIGHT' } },
  '100': { inputs: { noise_seed: 469008696527318 }, class_type: 'RandomNoise', _meta: { title: '随机噪波' } },
  '102': { inputs: { value: 121 }, class_type: 'PrimitiveInt', _meta: { title: 'Length' } },
  '113': { inputs: { value: 1280 }, class_type: 'PrimitiveInt', _meta: { title: 'WIDTH' } },
  '114': { inputs: { value: 25 }, class_type: 'PrimitiveInt', _meta: { title: 'Frame Rate(int)' } },
};

/** Video params data array (matches ltx2img2vid data entries 4-7) */
const videoParamsData = [
  { 'width##113##inputs##value': '##width##' },
  { 'height##98##inputs##value': '##height##' },
  { 'framelen##102##inputs##value': '##framelen##' },
  { 'fps##114##inputs##value': '##fps##' },
];

/**
 * Simulates promptVars construction from src/commands/2img2vid.js
 * @param {object} options - CLI options (width, height, frames, fps)
 * @param {string} prompt - Active prompt text
 * @param {string} negative - Negative prompt text
 * @param {string} img1 - First uploaded filename
 * @param {string} img2 - Second uploaded filename
 * @returns {object} promptVars object
 */
function buildPromptVars(options = {}, prompt = 'test', negative = 'neg', img1 = 'img1.png', img2 = 'img2.png') {
  const vars = {
    active_prompt: prompt,
    negative_prompt: negative,
    sample_image: img1,
    sample_image2: img2,
  };
  if (options.width !== undefined) vars.width = String(options.width);
  if (options.height !== undefined) vars.height = String(options.height);
  if (options.frames !== undefined) vars.framelen = String(options.frames);
  if (options.fps !== undefined) vars.fps = String(options.fps);
  return vars;
}

// ---------------------------------------------------------------------------
// TEST-UT-001: replaceVariables Variable Replacement
// ---------------------------------------------------------------------------
describe('TEST-UT-001: replaceVariables - Video Param Replacement', () => {

  // ---- Width tests (node 113) ----
  describe('Width replacement (node 113)', () => {
    test('UT-W001: width="960" replaces node 113.inputs.value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, { width: '960' });
      expect(result['113'].inputs.value).toBe('960');
      expect(typeof result['113'].inputs.value).toBe('string');
    });

    test('UT-W002: width="1280" replaces node 113.inputs.value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, { width: '1280' });
      expect(result['113'].inputs.value).toBe('1280');
    });

    test('UT-W003: width="1920" replaces node 113.inputs.value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, { width: '1920' });
      expect(result['113'].inputs.value).toBe('1920');
    });

    test('UT-W004: width="0" replaces node 113.inputs.value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, { width: '0' });
      expect(result['113'].inputs.value).toBe('0');
    });
  });

  // ---- Height tests (node 98) ----
  describe('Height replacement (node 98)', () => {
    test('UT-H001: height="540" replaces node 98.inputs.value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, { height: '540' });
      expect(result['98'].inputs.value).toBe('540');
      expect(typeof result['98'].inputs.value).toBe('string');
    });

    test('UT-H002: height="720" replaces node 98.inputs.value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, { height: '720' });
      expect(result['98'].inputs.value).toBe('720');
    });

    test('UT-H003: height="1080" replaces node 98.inputs.value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, { height: '1080' });
      expect(result['98'].inputs.value).toBe('1080');
    });

    test('UT-H004: height="0" replaces node 98.inputs.value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, { height: '0' });
      expect(result['98'].inputs.value).toBe('0');
    });
  });

  // ---- Framelen tests (node 102) ----
  describe('Framelen replacement (node 102)', () => {
    test('UT-F001: framelen="81" replaces node 102.inputs.value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, { framelen: '81' });
      expect(result['102'].inputs.value).toBe('81');
      expect(typeof result['102'].inputs.value).toBe('string');
    });

    test('UT-F002: framelen="41" replaces node 102.inputs.value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, { framelen: '41' });
      expect(result['102'].inputs.value).toBe('41');
    });

    test('UT-F003: framelen="121" replaces node 102.inputs.value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, { framelen: '121' });
      expect(result['102'].inputs.value).toBe('121');
    });

    test('UT-F004: framelen="0" replaces node 102.inputs.value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, { framelen: '0' });
      expect(result['102'].inputs.value).toBe('0');
    });
  });

  // ---- FPS tests (node 114) ----
  describe('FPS replacement (node 114)', () => {
    test('UT-P001: fps="30" replaces node 114.inputs.value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, { fps: '30' });
      expect(result['114'].inputs.value).toBe('30');
      expect(typeof result['114'].inputs.value).toBe('string');
    });

    test('UT-P002: fps="25" replaces node 114.inputs.value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, { fps: '25' });
      expect(result['114'].inputs.value).toBe('25');
    });

    test('UT-P003: fps="15" replaces node 114.inputs.value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, { fps: '15' });
      expect(result['114'].inputs.value).toBe('15');
    });

    test('UT-P004: fps="0" replaces node 114.inputs.value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, { fps: '0' });
      expect(result['114'].inputs.value).toBe('0');
    });
  });

  // ---- Default value preservation ----
  describe('Default value preservation', () => {
    test('UT-D001: No width in values preserves node 113 original value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, {});
      // width placeholder ##width## remains unresolved, so original number value is kept
      expect(result['113'].inputs.value).toBe(1280);
      expect(typeof result['113'].inputs.value).toBe('number');
    });

    test('UT-D002: No height in values preserves node 98 original value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, {});
      expect(result['98'].inputs.value).toBe(720);
      expect(typeof result['98'].inputs.value).toBe('number');
    });

    test('UT-D003: No framelen in values preserves node 102 original value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, {});
      expect(result['102'].inputs.value).toBe(121);
      expect(typeof result['102'].inputs.value).toBe('number');
    });

    test('UT-D004: No fps in values preserves node 114 original value', () => {
      const result = replaceVariables(minimalWorkflow, videoParamsData, {});
      expect(result['114'].inputs.value).toBe(25);
      expect(typeof result['114'].inputs.value).toBe('number');
    });
  });

  // ---- Multi-param combinations ----
  describe('Multi-param combinations', () => {
    test('UT-M001: All 4 params replace all nodes correctly', () => {
      const values = { width: '960', height: '540', framelen: '81', fps: '30' };
      const result = replaceVariables(minimalWorkflow, videoParamsData, values);

      expect(result['113'].inputs.value).toBe('960');
      expect(result['98'].inputs.value).toBe('540');
      expect(result['102'].inputs.value).toBe('81');
      expect(result['114'].inputs.value).toBe('30');
    });

    test('UT-M002: Only width provided - only node 113 changes, others stay default', () => {
      const values = { width: '1920' };
      const result = replaceVariables(minimalWorkflow, videoParamsData, values);

      expect(result['113'].inputs.value).toBe('1920');
      // Others preserve original numeric defaults (unresolved placeholders)
      expect(result['98'].inputs.value).toBe(720);
      expect(result['102'].inputs.value).toBe(121);
      expect(result['114'].inputs.value).toBe(25);
    });

    test('UT-M003: Only fps provided - only node 114 changes, others stay default', () => {
      const values = { fps: '15' };
      const result = replaceVariables(minimalWorkflow, videoParamsData, values);

      expect(result['114'].inputs.value).toBe('15');
      // Others preserve original numeric defaults (unresolved placeholders)
      expect(result['113'].inputs.value).toBe(1280);
      expect(result['98'].inputs.value).toBe(720);
      expect(result['102'].inputs.value).toBe(121);
    });
  });
});

// ---------------------------------------------------------------------------
// TEST-UT-002: mergeWorkflowParams + promptVars
// ---------------------------------------------------------------------------
describe('TEST-UT-002: mergeWorkflowParams and promptVars', () => {

  // ---- Seed handling via mergeWorkflowParams ----
  describe('Seed handling via mergeWorkflowParams', () => {
    test('UT-S001: mergeWorkflowParams with seed=12345 does NOT update noise_seed', () => {
      // mergeWorkflowParams uses hasOwnProperty('seed') to find matching inputs.
      // Node 100 has inputs.noise_seed, NOT inputs.seed, so the param will not be applied.
      const result = mergeWorkflowParams(minimalWorkflow, { seed: 12345 });
      // NOTE: Node 100 has noise_seed, not seed - so mergeWorkflowParams cannot match it.
      // The original value is preserved because no node has inputs.seed.
      expect(result['100'].inputs.noise_seed).toBe(469008696527318);
    });

    test('UT-S002: mergeWorkflowParams with seed=0 does NOT update noise_seed', () => {
      const result = mergeWorkflowParams(minimalWorkflow, { seed: 0 });
      expect(result['100'].inputs.noise_seed).toBe(469008696527318);
    });

    test('UT-S003: mergeWorkflowParams with empty params preserves all values', () => {
      const result = mergeWorkflowParams(minimalWorkflow, {});
      expect(result['98'].inputs.value).toBe(720);
      expect(result['100'].inputs.noise_seed).toBe(469008696527318);
      expect(result['102'].inputs.value).toBe(121);
      expect(result['113'].inputs.value).toBe(1280);
      expect(result['114'].inputs.value).toBe(25);
    });

    test('UT-S004: mergeWorkflowParams creates deep copy - original workflow not modified', () => {
      const workflowSnapshot = JSON.parse(JSON.stringify(minimalWorkflow));
      mergeWorkflowParams(minimalWorkflow, { seed: 99999 });

      // Verify original was not mutated
      expect(minimalWorkflow['100'].inputs.noise_seed).toBe(workflowSnapshot['100'].inputs.noise_seed);
      expect(minimalWorkflow['113'].inputs.value).toBe(workflowSnapshot['113'].inputs.value);
      expect(minimalWorkflow['98'].inputs.value).toBe(workflowSnapshot['98'].inputs.value);
    });
  });

  // ---- promptVars construction logic ----
  describe('promptVars construction logic', () => {
    test('UT-PV001: empty options produces only base prompt vars, no video params', () => {
      const vars = buildPromptVars({});
      const keys = Object.keys(vars);

      expect(vars).toHaveProperty('active_prompt', 'test');
      expect(vars).toHaveProperty('negative_prompt', 'neg');
      expect(vars).toHaveProperty('sample_image', 'img1.png');
      expect(vars).toHaveProperty('sample_image2', 'img2.png');

      // No video params
      expect(vars).not.toHaveProperty('width');
      expect(vars).not.toHaveProperty('height');
      expect(vars).not.toHaveProperty('framelen');
      expect(vars).not.toHaveProperty('fps');
      expect(keys.length).toBe(4);
    });

    test('UT-PV002: options with only width adds width as string, no other video params', () => {
      const vars = buildPromptVars({ width: 960 });

      expect(vars).toHaveProperty('width', '960');
      expect(typeof vars.width).toBe('string');
      expect(vars).not.toHaveProperty('height');
      expect(vars).not.toHaveProperty('framelen');
      expect(vars).not.toHaveProperty('fps');
      expect(Object.keys(vars).length).toBe(5);
    });

    test('UT-PV003: options with all video params adds all as strings', () => {
      const vars = buildPromptVars({ width: 960, height: 540, frames: 81, fps: 30 });

      expect(vars).toHaveProperty('width', '960');
      expect(vars).toHaveProperty('height', '540');
      expect(vars).toHaveProperty('framelen', '81');
      expect(vars).toHaveProperty('fps', '30');
      expect(typeof vars.width).toBe('string');
      expect(typeof vars.height).toBe('string');
      expect(typeof vars.framelen).toBe('string');
      expect(typeof vars.fps).toBe('string');
      expect(Object.keys(vars).length).toBe(8);
    });
  });
});
