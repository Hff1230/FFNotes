import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import fs from 'fs';
import path from 'path';
import os from 'os';
import ConfigManager from '../../../src/utils/config.js';

describe('ConfigManager - Edge Cases and Error Handling', () => {
  let tmpDir;

  beforeEach(() => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'comfycli-test-'));
  });

  afterEach(() => {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  // 106-1: server_config 为空 JSON {}
  it('should return defaults when server_config is empty JSON', () => {
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify({ prompts: {} }));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), '{}');
    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();
    const result = cm.getServerConfig();
    expect(result.host).toBe('127.0.0.1');
    expect(result.port).toBe(8188);
  });

  // 106-2: port 为非数字字符串 "abc"
  it('should handle non-numeric port gracefully', () => {
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify({ prompts: {} }));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify({ host: '1.2.3.4', port: 'abc' }));
    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();
    const result = cm.getServerConfig();
    // port='abc' is truthy so it won't fallback to 8188, it returns 'abc'
    // This tests current behavior - port is 'abc' string
    expect(result.host).toBe('1.2.3.4');
    // port will be 'abc' (truthy, so no fallback) - this is current behavior
    expect(result.port).toBe('abc');
  });

  // 106-3: host 为空字符串
  it('should use default host when host is empty string', () => {
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify({ prompts: {} }));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify({ host: '', port: 9010 }));
    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();
    const result = cm.getServerConfig();
    // host='' is falsy, so it falls back to '127.0.0.1'
    expect(result.host).toBe('127.0.0.1');
  });

  // 106-4: upload.server 为空字符串
  it('should return upload config with empty server when server is empty string', () => {
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify({ prompts: {} }));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify({
      host: 'test.com', port: 8188,
      upload: { server: '', user: 'u', pwd: 'p', dir: 'd' }
    }));
    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();
    const result = cm.getUploadConfig();
    expect(result).not.toBeNull();
    expect(result.server).toBe('');
  });

  // 106-5: 两个文件同时为空 JSON
  it('should not crash when both files are empty JSON', () => {
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), '{}');
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), '{}');
    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    expect(cm.load()).toBe(true);
    const server = cm.getServerConfig();
    expect(server.host).toBe('127.0.0.1');
    expect(server.port).toBe(8188);
  });

  // 106-6: 构造函数路径为相对路径
  it('should correctly resolve relative config paths', () => {
    const cm = new ConfigManager('./config/comfy_config.json');
    expect(cm.configPath).toBe('./config/comfy_config.json');
    expect(cm.configDir).toBe(path.dirname(path.resolve('./config/comfy_config.json')));
    expect(cm.serverConfigPath).toContain('server_config.json');
  });

  // 106-7: 构造函数路径为绝对路径
  it('should correctly handle absolute config paths', () => {
    const absPath = path.join(tmpDir, 'my_config.json');
    const cm = new ConfigManager(absPath);
    expect(cm.configPath).toBe(absPath);
    expect(cm.serverConfigPath).toBe(path.join(tmpDir, 'server_config.json'));
  });

  // 106-8: JSON 解析错误含特殊字符 (BOM)
  it('should handle JSON files with BOM gracefully', () => {
    // Write BOM + invalid JSON
    const bomContent = '\uFEFF{not valid json';
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), bomContent);
    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    expect(cm.load()).toBe(false);
    expect(cm.loaded).toBe(false);
  });
});
