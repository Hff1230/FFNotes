/**
 * Unit tests for 2img2vid command and map2Img2VideoArgs parameter mapping
 * Tests: TC-301 (img2vid2Command validation) and TC-302 (map2Img2VideoArgs mapping)
 */
import { jest, describe, test, expect } from '@jest/globals';
import fs from 'fs';
import os from 'os';
import path from 'path';

const { img2vid2Command } = await import('../../../src/commands/2img2vid.js');
const { map2Img2VideoArgs } = await import('../../../src/commands/batch.js');
// ----------------------------------------------------------------
// Helper: create a real temp file with the given extension
// ---------------------------------------------------------------
function createTempFile(ext = '.png', content = 'test-image-data') {
  const tmpDir = os.tmpdir();
  const tmpFile = path.join(tmpDir, '2img2vid_test_' + Date.now() + '_' + Math.random().toString(36).slice(2) + ext);
  fs.writeFileSync(tmpFile, content);
  return tmpFile;
}

function removeTempFile(filePath) {
  try {
    if (filePath && fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  } catch (_) {
    // ignore cleanup errors
  }
}
// ----------------------------------------------------------------
// TC-301: 2img2vid command input validation (8 tests)
// ----------------------------------------------------------------
describe('TC-301: 2img2vid command input validation', () => {
  const batchOptions = { _batchMode: true };

  test('TC-301-01: image1 is empty throws Error with message containing First input image path is required', async () => {
    await expect(img2vid2Command('', 'image2.png', batchOptions)).rejects.toThrow(
      'First input image path is required'
    );
  });

  test('TC-301-02: image2 is empty throws Error with message containing Second input image path is required', async () => {
    await expect(img2vid2Command('image1.png', '', batchOptions)).rejects.toThrow(
      'Second input image path is required'
    );
  });
  test('TC-301-03: image1 does not exist throws Error', async () => {
    const nonexistentPath = path.join(os.tmpdir(), 'nonexistent_' + Date.now() + '.png');
    const realFile = createTempFile('.png');
    try {
      await expect(
        img2vid2Command(nonexistentPath, realFile, batchOptions)
      ).rejects.toThrow('First input image not found');
    } finally {
      removeTempFile(realFile);
    }
  });

  test('TC-301-04: image2 does not exist throws Error', async () => {
    const realFile = createTempFile('.png');
    const nonexistentPath = path.join(os.tmpdir(), 'nonexistent_' + Date.now() + '.png');
    try {
      await expect(
        img2vid2Command(realFile, nonexistentPath, batchOptions)
      ).rejects.toThrow('Second input image not found');
    } finally {
      removeTempFile(realFile);
    }
  });

  test('TC-301-05: Unsupported image format (.bmp) throws Error', async () => {
    const bmpFile1 = createTempFile('.bmp');
    const bmpFile2 = createTempFile('.bmp');
    try {
      await expect(
        img2vid2Command(bmpFile1, bmpFile2, batchOptions)
      ).rejects.toThrow('Unsupported image format');
    } finally {
      removeTempFile(bmpFile1);
      removeTempFile(bmpFile2);
    }
  });

  test('TC-301-06: Supported formats pass validation (png/jpg/jpeg/webp)', async () => {
    // Create temp files with supported extensions
    const pngFile = createTempFile('.png');
    const jpgFile = createTempFile('.jpg');
    try {
      await expect(
        img2vid2Command(pngFile, jpgFile, batchOptions)
      ).rejects.toThrow();
    } finally {
      removeTempFile(pngFile);
      removeTempFile(jpgFile);
    }
  });
  test('TC-301-07: Both images can be URL inputs', async () => {
    // URLs pass empty-validation and proceed to download handling.
    // With nock blocking network, download will fail
    await expect(
      img2vid2Command('https://example.com/img1.png', 'https://example.com/img2.png', batchOptions)
    ).rejects.toThrow(/download/i);
  });

  test('TC-301-08: URL download failure throws Error', async () => {
    await expect(
      img2vid2Command('https://example.com/nonexistent.png', 'https://example.com/missing.png', batchOptions)
    ).rejects.toThrow(/Failed to download first image/i);
  });
});

// ----------------------------------------------------------------
// TC-302: map2Img2VideoArgs parameter mapping (10 tests)
// ----------------------------------------------------------------
describe('TC-302: map2Img2VideoArgs parameter mapping', () => {

  test('TC-302-01: Comma-separated image paths correctly split', () => {
    const task = { image: 'start.png,end.png' };
    const globalOptions = {};

    const result = map2Img2VideoArgs(task, globalOptions);

    expect(result.positional).toEqual(['start.png', 'end.png']);
  });

  test('TC-302-02: Comma-separated with spaces correctly trimmed', () => {
    const task = { image: '  start.png, end.png  ' };
    const globalOptions = {};

    const result = map2Img2VideoArgs(task, globalOptions);

    expect(result.positional).toEqual(['start.png', 'end.png']);
  });

  test('TC-302-03: Single image results in empty img2', () => {
    const task = { image: 'only_one.png' };
    const globalOptions = {};

    const result = map2Img2VideoArgs(task, globalOptions);

    expect(result.positional).toEqual(['only_one.png', '']);
  });

  test('TC-302-04: Empty image field results in both empty', () => {
    const task = {};
    const globalOptions = {};

    const result = map2Img2VideoArgs(task, globalOptions);

    expect(result.positional).toEqual(['', '']);
  });

  test('TC-302-05: prompt correctly mapped to options', () => {
    const task = { image: 'a.png,b.png', prompt: 'animate from a to b' };
    const globalOptions = {};

    const result = map2Img2VideoArgs(task, globalOptions);

    expect(result.options.prompt).toBe('animate from a to b');
  });

  test('TC-302-06: negative correctly mapped', () => {
    const task = { image: 'a.png,b.png', negative: 'blurry, low quality' };
    const globalOptions = {};

    const result = map2Img2VideoArgs(task, globalOptions);

    expect(result.options.negative).toBe('blurry, low quality');
  });

  test('TC-302-07: format/fps/frames video options mapped', () => {
    const task = {
      image: 'a.png,b.png',
      format: 'gif',
      fps: 30,
      frames: 120,
    };
    const globalOptions = {};

    const result = map2Img2VideoArgs(task, globalOptions);

    expect(result.options.format).toBe('gif');
    expect(result.options.fps).toBe(30);
    expect(result.options.frames).toBe(120);
  });

  test('TC-302-08: _batchMode is always true', () => {
    const task = { image: 'a.png,b.png' };
    const globalOptions = {};

    const result = map2Img2VideoArgs(task, globalOptions);

    expect(result.options._batchMode).toBe(true);
  });

  test('TC-302-09: Global options override task options (output)', () => {
    const task = {
      image: 'a.png,b.png',
      output: './task-output',
      config: './task-config.json',
    };
    const globalOptions = {
      output: './global-output',
    };

    const result = map2Img2VideoArgs(task, globalOptions);

    expect(result.options.output).toBe('./global-output');
    expect(result.options.config).toBe('./task-config.json');
  });

  test('TC-302-10: Global options override task options (upload)', () => {
    const task = {
      image: 'a.png,b.png',
      upload: true,
    };
    const globalOptions = {
      upload: false,
    };

    const result = map2Img2VideoArgs(task, globalOptions);

    expect(result.options.upload).toBe(false);
  });
});
