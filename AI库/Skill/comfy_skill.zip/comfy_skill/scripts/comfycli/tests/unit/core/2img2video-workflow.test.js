/**
 * Unit tests for 2img2video config and core workflow functions
 * Tests: TC-501~504 (Config loading, API file, variable replacement, type lookup)
 */
import { jest, describe, test, expect, beforeAll } from '@jest/globals';
import {
  replaceVariables,
  find2Img2VideoWorkflows,
  findDefaultWorkflow,
} from '../../../src/core/workflow.js';
import workflowModule from '../../../src/core/workflow.js';
import ConfigManager from '../../../src/utils/config.js';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECT_ROOT = path.resolve(__dirname, '../../../');
const CONFIG_PATH = path.join(PROJECT_ROOT, 'config', 'comfy_config.json');
const API_PATH = path.join(PROJECT_ROOT, 'config', 'comfy', 'image2_to_video_ltx2.3_fe_api.json');

// ---------------------------------------------------------------------------
// TC-501: ltx2img2vid 配置加载
// ---------------------------------------------------------------------------
describe('TC-501: ltx2img2vid 配置加载', () => {
  let config;
  let ltx2img2vid;

  beforeAll(() => {
    const raw = fs.readFileSync(CONFIG_PATH, 'utf-8');
    config = JSON.parse(raw);
    ltx2img2vid = config.prompts?.ltx2img2vid;
  });

  test('TC-501-01: ltx2img2vid 条目存在于 comfy_config.json', () => {
    expect(ltx2img2vid).toBeDefined();
    expect(typeof ltx2img2vid).toBe('object');
  });

  test('TC-501-02: type 字段为 "2img2video"', () => {
    expect(ltx2img2vid.type).toBe('2img2video');
  });

  test('TC-501-03: api 路径指向正确文件', () => {
    expect(ltx2img2vid.api).toBe('config/comfy/image2_to_video_ltx2.3_fe_api.json');
  });

  test('TC-501-04: data 数组包含 8 个变量映射 (4 原始 + 4 视频参数)', () => {
    expect(Array.isArray(ltx2img2vid.data)).toBe(true);
    expect(ltx2img2vid.data.length).toBe(8);
  });

  test('TC-501-05: 节点 ID 正确 (31, 39, 98, 102, 112, 113, 114, 128)', () => {
    const nodeIds = ltx2img2vid.data.map(entry => {
      const key = Object.keys(entry)[0];
      const parts = key.split('##');
      return parts[1];
    });
    expect(nodeIds).toContain('31');
    expect(nodeIds).toContain('39');
    expect(nodeIds).toContain('128');
    expect(nodeIds).toContain('112');
    // 视频参数节点
    expect(nodeIds).toContain('113');
    expect(nodeIds).toContain('98');
    expect(nodeIds).toContain('102');
    expect(nodeIds).toContain('114');
  });
});

// ---------------------------------------------------------------------------
// TC-502: API 文件加载与验证
// ---------------------------------------------------------------------------
describe('TC-502: API 文件加载与验证', () => {
  let apiData;

  beforeAll(() => {
    const raw = fs.readFileSync(API_PATH, 'utf-8');
    apiData = JSON.parse(raw);
  });

  test('TC-502-01: API JSON 成功加载', () => {
    expect(apiData).toBeDefined();
    expect(typeof apiData).toBe('object');
    expect(Object.keys(apiData).length).toBeGreaterThan(0);
  });

  test('TC-502-02: 节点 31 (LoadImage) 存在且正确', () => {
    expect(apiData['31']).toBeDefined();
    expect(apiData['31'].class_type).toBe('LoadImage');
    expect(apiData['31']._meta.title).toContain('First');
  });

  test('TC-502-03: 节点 39 (LoadImage) 存在且正确', () => {
    expect(apiData['39']).toBeDefined();
    expect(apiData['39'].class_type).toBe('LoadImage');
    expect(apiData['39']._meta.title).toContain('Last');
  });

  test('TC-502-04: 节点 128 (CLIPTextEncode) 存在', () => {
    expect(apiData['128']).toBeDefined();
    expect(apiData['128'].class_type).toBe('CLIPTextEncode');
  });

  test('TC-502-05: 节点 112 (CLIPTextEncode) 存在', () => {
    expect(apiData['112']).toBeDefined();
    expect(apiData['112'].class_type).toBe('CLIPTextEncode');
  });
});

// ---------------------------------------------------------------------------
// TC-503: 变量替换
// ---------------------------------------------------------------------------
describe('TC-503: 变量替换', () => {
  let apiData;
  let dataConfig;

  beforeAll(() => {
    const raw = fs.readFileSync(API_PATH, 'utf-8');
    apiData = JSON.parse(raw);

    const configRaw = fs.readFileSync(CONFIG_PATH, 'utf-8');
    const config = JSON.parse(configRaw);
    dataConfig = config.prompts.ltx2img2vid.data;
  });

  test('TC-503-01: sample_image 替换节点 31 inputs.image', () => {
    const values = { sample_image: 'uploaded_file1.png' };
    const result = replaceVariables(apiData, dataConfig, values);
    expect(result['31'].inputs.image).toBe('uploaded_file1.png');
  });

  test('TC-503-02: sample_image2 替换节点 39 inputs.image', () => {
    const values = { sample_image2: 'uploaded_file2.png' };
    const result = replaceVariables(apiData, dataConfig, values);
    expect(result['39'].inputs.image).toBe('uploaded_file2.png');
  });

  test('TC-503-03: active_prompt 替换节点 128 inputs.text', () => {
    const values = { active_prompt: 'test prompt' };
    const result = replaceVariables(apiData, dataConfig, values);
    expect(result['128'].inputs.text).toBe('test prompt');
  });

  test('TC-503-04: negative_prompt 替换节点 112 inputs.text', () => {
    const values = { negative_prompt: 'test negative' };
    const result = replaceVariables(apiData, dataConfig, values);
    expect(result['112'].inputs.text).toBe('test negative');
  });

  test('TC-503-05: 其他节点不被修改', () => {
    const values = { sample_image: 'file.png' };
    const result = replaceVariables(apiData, dataConfig, values);
    // Node 68 should keep its original values
    expect(result['68'].inputs.filename_prefix).toBe(apiData['68'].inputs.filename_prefix);
  });

  test('TC-503-06: 缺少变量时保留原值', () => {
    const values = {};
    const result = replaceVariables(apiData, dataConfig, values);
    // With empty values, the placeholders remain unresolved so original values are preserved
    expect(result['31'].inputs.image).toBe(apiData['31'].inputs.image);
    expect(result['39'].inputs.image).toBe(apiData['39'].inputs.image);
  });

  test('TC-503-07: 深拷贝不影响原始 workflow', () => {
    const originalNode31Image = apiData['31'].inputs.image;
    const values = { sample_image: 'new_image.png' };
    replaceVariables(apiData, dataConfig, values);
    // Original should not be modified
    expect(apiData['31'].inputs.image).toBe(originalNode31Image);
  });
});

// ---------------------------------------------------------------------------
// TC-504: 类型查找
// ---------------------------------------------------------------------------
describe('TC-504: 类型查找', () => {
  const mockWorkflows = [
    { name: 'txt2img_test', type: 'txt2img', description: 'Test txt2img' },
    { name: 'img2vid_test', type: 'img2vid', description: 'Test img2vid' },
    { name: 'ltx2img2vid', type: '2img2video', description: 'LTX 2.3 Two Image to Video' },
    { name: 'ltx2img2vid_v2', type: '2img2video', description: 'LTX 2.3 v2', default: true },
  ];

  test('TC-504-01: TYPE_FAMILIES 包含 2img2video', () => {
    // TYPE_FAMILIES is not exported, verify through findDefaultWorkflow behavior
    // If TYPE_FAMILIES['2img2video'] didn't exist, findDefaultWorkflow would only match exact type
    const workflows = [{ name: 'test', type: '2img2video' }];
    const result = findDefaultWorkflow(workflows, '2img2video');
    expect(result).toBeDefined();
    expect(result.type).toBe('2img2video');
  });

  test('TC-504-02: find2Img2VideoWorkflows 返回正确工作流', () => {
    const result = find2Img2VideoWorkflows(mockWorkflows);
    expect(result.length).toBe(2);
    expect(result.every(w => w.type === '2img2video')).toBe(true);
  });

  test('TC-504-03: findDefaultWorkflow 对 2img2video 类型正确', () => {
    const result = findDefaultWorkflow(mockWorkflows, '2img2video');
    expect(result).toBeDefined();
    expect(result.name).toBe('ltx2img2vid_v2');
    expect(result.default).toBe(true);
  });

  test('TC-504-04: 无匹配时返回 null/空数组', () => {
    const emptyWorkflows = [
      { name: 'txt2img_test', type: 'txt2img', description: 'Test' },
    ];
    const defaultResult = findDefaultWorkflow(emptyWorkflows, '2img2video');
    expect(defaultResult).toBeNull();

    const filteredResult = find2Img2VideoWorkflows(emptyWorkflows);
    expect(filteredResult).toEqual([]);
  });
});
