/**
 * Unit tests for resource_downloader.js utility functions
 * Tests: isUrl, getFilenameFromUrl
 */
import { jest } from '@jest/globals';
import resourceDownloader from '../../src/utils/resource_downloader.js';

const { isUrl, getFilenameFromUrl } = resourceDownloader;

describe('isUrl', () => {
  // P0 Priority Tests - Core functionality
  describe('P0 - HTTP/HTTPS URLs return true', () => {
    test('U001 - HTTP URL with .jpg extension', () => {
      expect(isUrl('http://example.com/photo.jpg')).toBe(true);
    });

    test('U002 - HTTPS URL with .jpg extension', () => {
      expect(isUrl('https://example.com/photo.jpg')).toBe(true);
    });

    test('U003 - HTTPS URL with credentials', () => {
      expect(isUrl('https://user:pass@example.com/photo.jpg')).toBe(true);
    });
  });

  describe('P0 - Local paths return false', () => {
    test('U004 - Relative path', () => {
      expect(isUrl('./local/photo.jpg')).toBe(false);
    });

    test('U005 - Absolute path (Unix style)', () => {
      expect(isUrl('/absolute/path/photo.jpg')).toBe(false);
    });

    test('U006 - Windows path', () => {
      expect(isUrl('C:\\Windows\\photo.jpg')).toBe(false);
    });

    test('U007 - Filename only', () => {
      expect(isUrl('photo.jpg')).toBe(false);
    });

    test('U008 - Empty string', () => {
      expect(isUrl('')).toBe(false);
    });

    test('U009 - null value', () => {
      expect(isUrl(null)).toBe(false);
    });
  });

  // P1 Priority Tests - Edge cases
  describe('P1 - Edge cases return false', () => {
    test('U010 - undefined value', () => {
      expect(isUrl(undefined)).toBe(false);
    });

    test('U011 - FTP protocol (non-HTTP)', () => {
      expect(isUrl('ftp://example.com/file')).toBe(false);
    });

    test('U012 - File protocol', () => {
      expect(isUrl('file:///local/file.jpg')).toBe(false);
    });

    test('U013 - HTTP URL without host', () => {
      expect(isUrl('http://')).toBe(false);
    });

    test('U014 - Plain text (not a URL)', () => {
      expect(isUrl('not a url at all')).toBe(false);
    });
  });

  // P2 Priority Tests - Type safety
  describe('P2 - Non-string types return false', () => {
    test('U015 - Number input', () => {
      expect(isUrl(123)).toBe(false);
    });

    test('Non-string: array', () => {
      expect(isUrl(['http://example.com'])).toBe(false);
    });

    test('Non-string: object', () => {
      expect(isUrl({ url: 'http://example.com' })).toBe(false);
    });

    test('Non-string: boolean', () => {
      expect(isUrl(true)).toBe(false);
    });
  });
});

describe('getFilenameFromUrl', () => {
  // P0 Priority Tests - Core functionality
  describe('P0 - Valid URLs with file extensions', () => {
    test('G001 - Simple HTTP URL with .jpg', () => {
      expect(getFilenameFromUrl('http://example.com/photo.jpg')).toBe('photo.jpg');
    });

    test('G002 - HTTPS URL with query parameters', () => {
      expect(getFilenameFromUrl('https://cdn.com/images/test.png?token=abc')).toBe('test.png');
    });

    test('G003 - HTTP URL in subdirectory with .webp', () => {
      expect(getFilenameFromUrl('http://example.com/dir/file.webp')).toBe('file.webp');
    });

    test('URL with multiple path segments', () => {
      expect(getFilenameFromUrl('https://example.com/a/b/c/document.pdf')).toBe('document.pdf');
    });

    test('URL with port number', () => {
      expect(getFilenameFromUrl('http://example.com:8080/image.gif')).toBe('image.gif');
    });
  });

  // P1 Priority Tests - URLs without valid filenames
  describe('P1 - URLs without valid filenames generate timestamp-based names', () => {
    beforeEach(() => {
      jest.useFakeTimers();
    });

    afterEach(() => {
      jest.useRealTimers();
    });

    test('G004 - URL without filename (root path)', () => {
      const mockTimestamp = 1700000000000;
      jest.setSystemTime(mockTimestamp);

      const result = getFilenameFromUrl('http://example.com/');
      expect(result).toBe(`download_${mockTimestamp}`);
    });

    test('G005 - URL with filename but no extension', () => {
      const mockTimestamp = 1700000000000;
      jest.setSystemTime(mockTimestamp);

      const result = getFilenameFromUrl('http://example.com/noext');
      expect(result).toBe(`download_${mockTimestamp}`);
    });

    test('URL ending with directory (trailing slash)', () => {
      const mockTimestamp = 1700000000000;
      jest.setSystemTime(mockTimestamp);

      const result = getFilenameFromUrl('http://example.com/path/to/dir/');
      expect(result).toBe(`download_${mockTimestamp}`);
    });
  });

  // P2 Priority Tests - Invalid URLs
  describe('P2 - Invalid URLs generate timestamp-based names', () => {
    beforeEach(() => {
      jest.useFakeTimers();
    });

    afterEach(() => {
      jest.useRealTimers();
    });

    test('G006 - Invalid URL string', () => {
      const mockTimestamp = 1700000000000;
      jest.setSystemTime(mockTimestamp);

      const result = getFilenameFromUrl('not-a-valid-url');
      expect(result).toBe(`download_${mockTimestamp}`);
    });

    test('Empty string input', () => {
      const mockTimestamp = 1700000000000;
      jest.setSystemTime(mockTimestamp);

      const result = getFilenameFromUrl('');
      expect(result).toBe(`download_${mockTimestamp}`);
    });

    test('Null input', () => {
      const mockTimestamp = 1700000000000;
      jest.setSystemTime(mockTimestamp);

      const result = getFilenameFromUrl(null);
      expect(result).toBe(`download_${mockTimestamp}`);
    });

    test('Undefined input', () => {
      const mockTimestamp = 1700000000000;
      jest.setSystemTime(mockTimestamp);

      const result = getFilenameFromUrl(undefined);
      expect(result).toBe(`download_${mockTimestamp}`);
    });
  });

  // Additional edge cases for complete coverage
  describe('Edge cases for extension detection', () => {
    beforeEach(() => {
      jest.useFakeTimers();
    });

    afterEach(() => {
      jest.useRealTimers();
    });

    test('Filename with single dot at end (empty extension)', () => {
      const mockTimestamp = 1700000000000;
      jest.setSystemTime(mockTimestamp);
      // path.extname returns '.' for 'file.', which has length 1
      // Since ext.length > 1 is false, it generates timestamp
      const result = getFilenameFromUrl('http://example.com/file.');
      expect(result).toBe(`download_${mockTimestamp}`);
    });

    test('Filename with multiple dots', () => {
      expect(getFilenameFromUrl('http://example.com/archive.tar.gz')).toBe('archive.tar.gz');
    });

    test('URL with hash fragment', () => {
      expect(getFilenameFromUrl('http://example.com/file.jpg#section')).toBe('file.jpg');
    });
  });
});
