/**
 * Unit tests for hardcoded output path detection in source files
 * Tests: TC-011 through TC-014
 *
 * Ensures no hardcoded './output' paths remain in src/ after the fix.
 * All output paths should come from DEFAULT_OUTPUT_PATH or options.output.
 */
import { jest, describe, it, expect, beforeEach } from '@jest/globals';
import fs from 'fs';
import path from 'path';

/**
 * Recursively collect all .js files in a directory
 */
function getSourceFiles(dir, fileList = []) {
  if (!fs.existsSync(dir)) return fileList;
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      getSourceFiles(fullPath, fileList);
    } else if (entry.name.endsWith('.js')) {
      fileList.push(fullPath);
    }
  }
  return fileList;
}

describe('Hardcoded output path detection', () => {
  let sourceFiles;
  let sourceContents;

  beforeEach(() => {
    const srcDir = path.join(process.cwd(), 'src');
    sourceFiles = getSourceFiles(srcDir);
    sourceContents = new Map();
    for (const file of sourceFiles) {
      sourceContents.set(file, fs.readFileSync(file, 'utf-8'));
    }
  });

  // ── TC-011: No './output' hardcoded string in source ──
  it('TC-011: no hardcoded "./output" string in source files', () => {
    const matches = [];
    for (const [file, content] of sourceContents) {
      const lines = content.split('\n');
      lines.forEach((line, idx) => {
        // Skip JSDoc comments (lines starting with * or containing @param)
        if (/^\s*\*\s*@param/.test(line)) return;
        // Skip default parameter values in helper methods (legitimate fallback defaults)
        if (/=\s*['"]\.\/output['"]/.test(line) && /helper\.js/.test(file)) return;

        // Match './output' as a string literal (single or double quotes, template literal)
        if (/'\.\/output'/.test(line) || /"\.\/output"/.test(line) || /`\.\/output`/.test(line)) {
          matches.push({ file: path.relative(process.cwd(), file), line: idx + 1, content: line.trim() });
        }
      });
    }
    if (matches.length > 0) {
      console.error('Hardcoded "./output" found:', matches);
    }
    expect(matches).toHaveLength(0);
  });

  // ── TC-012: No path.join('.', 'output') in source ──
  it('TC-012: no path.join(".", "output") in source files', () => {
    const matches = [];
    for (const [file, content] of sourceContents) {
      const lines = content.split('\n');
      lines.forEach((line, idx) => {
        if (/path\.join\s*\(\s*['"]\.['"]\s*,\s*['"]output['"]\s*\)/.test(line)) {
          matches.push({ file: path.relative(process.cwd(), file), line: idx + 1, content: line.trim() });
        }
      });
    }
    if (matches.length > 0) {
      console.error('path.join(".", "output") found:', matches);
    }
    expect(matches).toHaveLength(0);
  });

  // ── TC-013: cli.js uses COMFY_PROJECT_ROOT ──
  it('TC-013: cli.js contains COMFY_PROJECT_ROOT for DEFAULT_OUTPUT_PATH', () => {
    const cliPath = path.join(process.cwd(), 'src', 'cli.js');
    const cliContent = fs.readFileSync(cliPath, 'utf-8');

    expect(cliContent).toContain('COMFY_PROJECT_ROOT');
    expect(cliContent).toMatch(/process\.env\.COMFY_PROJECT_ROOT/);
    expect(cliContent).toMatch(/DEFAULT_OUTPUT_PATH/);
  });

  // ── TC-014: All command files use options.output, no hardcoded paths ──
  it('TC-014: command files use options.output without hardcoded fallback', () => {
    const commandsDir = path.join(process.cwd(), 'src', 'commands');
    const commandFiles = getSourceFiles(commandsDir);

    const violations = [];
    for (const file of commandFiles) {
      const content = fs.readFileSync(file, 'utf-8');
      const basename = path.basename(file);

      // Skip non-command files (like _build2img2vid.cjs)
      if (!basename.endsWith('.js') || basename.startsWith('_')) continue;

      // Commands should reference options.output or outputDir derived from it
      // They should NOT have hardcoded fallback like: output || './output' or output || 'output'
      const lines = content.split('\n');
      lines.forEach((line, idx) => {
        // Check for hardcoded output fallback patterns
        if (/output\s*\|\|\s*['"]\.\/output['"]/.test(line) ||
            /output\s*\|\|\s*['"]output['"]/.test(line) ||
            /outputDir\s*=\s*['"]\.\/output['"]/.test(line) ||
            /outputDir\s*=\s*['"]output['"]/.test(line)) {
          violations.push({
            file: path.relative(process.cwd(), file),
            line: idx + 1,
            content: line.trim()
          });
        }
      });
    }

    if (violations.length > 0) {
      console.error('Hardcoded output path fallbacks found:', violations);
    }
    expect(violations).toHaveLength(0);
  });
});
