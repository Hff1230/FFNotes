/**
 * Integration tests for imagescale command URL handling
 * Tests URL download and processing logic
 */
import { describe, it, expect, beforeEach, afterEach, jest } from '@jest/globals';
import fs from 'fs';
import path from 'path';
import ResourceDownloader from '../../src/utils/resource_downloader.js';

// Store original fetch for restoration
const originalFetch = global.fetch;

// Test fixtures directory
const TEST_TMP_DIR = './tests/fixtures/tmp-imagescale-test';
const TEST_IMAGES_DIR = './tests/fixtures/images';

// Supported formats constant (matching imagescale.js)
const SUPPORTED_FORMATS = ['.png', '.jpg', '.jpeg', '.webp'];

// Helper to create mock PNG image data
function createMockPngData() {
  // Minimal valid PNG header + data
  return Buffer.from([
    0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, // PNG signature
    0x00, 0x00, 0x00, 0x0D, // IHDR length
    0x49, 0x48, 0x44, 0x52, // IHDR
    0x00, 0x00, 0x00, 0x01, // width: 1
    0x00, 0x00, 0x00, 0x01, // height: 1
    0x08, 0x02, // bit depth, color type
    0x00, 0x00, 0x00, // compression, filter, interlace
    0x90, 0x77, 0x53, 0xDE, // CRC
    0x00, 0x00, 0x00, 0x00, // IEND length
    0x49, 0x45, 0x4E, 0x44, // IEND
    0xAE, 0x42, 0x60, 0x82  // CRC
  ]);
}

// Helper to create mock fetch response
function createMockResponse(data, status = 200, statusText = 'OK') {
  return {
    ok: status >= 200 && status < 300,
    status,
    statusText,
    arrayBuffer: async () => {
      if (Buffer.isBuffer(data)) {
        return data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
      }
      return Buffer.from(data).buffer;
    }
  };
}

// Mock fetch responses map
let mockResponses = new Map();

// Setup mock fetch for a specific URL
function setupMockFetch(url, response) {
  mockResponses.set(url, response);
  global.fetch = async (requestUrl) => {
    const response = mockResponses.get(requestUrl);
    if (response) return response;
    return createMockResponse('Not Found', 404, 'Not Found');
  };
}

// Restore original fetch
function restoreFetch() {
  global.fetch = originalFetch;
  mockResponses.clear();
}

// Cleanup helper
function cleanupDir(dirPath) {
  if (fs.existsSync(dirPath)) {
    const files = fs.readdirSync(dirPath);
    for (const file of files) {
      const filePath = path.join(dirPath, file);
      if (fs.lstatSync(filePath).isDirectory()) {
        cleanupDir(filePath);
      } else {
        fs.unlinkSync(filePath);
      }
    }
    fs.rmdirSync(dirPath);
  }
}

// Create test images directory with sample images
function setupTestImages() {
  if (!fs.existsSync(TEST_IMAGES_DIR)) {
    fs.mkdirSync(TEST_IMAGES_DIR, { recursive: true });
  }

  // Create test images in supported formats
  const formats = ['png', 'jpg', 'jpeg', 'webp'];
  for (const format of formats) {
    const testFile = path.join(TEST_IMAGES_DIR, `test.${format}`);
    if (!fs.existsSync(testFile)) {
      fs.writeFileSync(testFile, createMockPngData());
    }
  }
}

describe('imagescale Command URL Handling Integration Tests', () => {
  beforeEach(() => {
    // Ensure clean state
    cleanupDir(TEST_TMP_DIR);
    mockResponses.clear();

    // Setup test images
    setupTestImages();
  });

  afterEach(() => {
    // Cleanup after each test
    restoreFetch();
    cleanupDir(TEST_TMP_DIR);
  });

  describe('P0 - S001: Single URL input triggers download', () => {
    it('should download image from URL and return local path', async () => {
      const url = 'https://example.com/images/photo.png';
      const mockData = createMockPngData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      expect(result).toHaveProperty('localPath');
      expect(result).toHaveProperty('wasDownloaded', true);
      expect(result.localPath).toContain('photo.png');
      expect(fs.existsSync(result.localPath)).toBe(true);
    });

    it('should download JPG image from URL', async () => {
      const url = 'https://example.com/images/picture.jpg';
      const mockData = createMockPngData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
      expect(result.localPath).toContain('picture.jpg');
    });

    it('should download WebP image from URL', async () => {
      const url = 'https://example.com/images/image.webp';
      const mockData = createMockPngData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
      expect(result.localPath).toContain('image.webp');
    });

    it('should download image with query parameters', async () => {
      const url = 'https://example.com/images/scale.png?version=2&quality=high';
      const mockData = createMockPngData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
      expect(result.localPath).toContain('scale.png');
    });
  });

  describe('P0 - S002: URL download failure handling', () => {
    it('should throw error with HTTP status on 404', async () => {
      const url = 'https://example.com/notfound.png';

      setupMockFetch(url, createMockResponse('Not Found', 404, 'Not Found'));

      await expect(ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR))
        .rejects.toThrow('Failed to download resource: HTTP 404');
    });

    it('should throw error on HTTP 500', async () => {
      const url = 'https://example.com/server-error.png';

      setupMockFetch(url, createMockResponse('Internal Server Error', 500, 'Internal Server Error'));

      await expect(ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR))
        .rejects.toThrow('Failed to download resource: HTTP 500');
    });

    it('should throw error on HTTP 403 Forbidden', async () => {
      const url = 'https://example.com/forbidden.png';

      setupMockFetch(url, createMockResponse('Forbidden', 403, 'Forbidden'));

      await expect(ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR))
        .rejects.toThrow('Failed to download resource: HTTP 403');
    });

    it('should throw error on network failure', async () => {
      const url = 'https://example.com/network-error.png';

      global.fetch = async () => {
        throw new Error('Network error: connection refused');
      };

      await expect(ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR))
        .rejects.toThrow();
    });

    it('should throw error on HTTP 401 Unauthorized', async () => {
      const url = 'https://example.com/unauthorized.png';

      setupMockFetch(url, createMockResponse('Unauthorized', 401, 'Unauthorized'));

      await expect(ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR))
        .rejects.toThrow('Failed to download resource: HTTP 401');
    });
  });

  describe('P0 - S003: Local path does not trigger download', () => {
    it('should return local path unchanged for relative path', async () => {
      const localPath = './tests/fixtures/images/test.png';

      const result = await ResourceDownloader.resolveInputResource(localPath, TEST_TMP_DIR);

      expect(result).toEqual({
        localPath: localPath,
        wasDownloaded: false
      });
    });

    it('should return local path unchanged for absolute path', async () => {
      const absPath = path.resolve('./tests/fixtures/images/test.png');

      const result = await ResourceDownloader.resolveInputResource(absPath, TEST_TMP_DIR);

      expect(result).toEqual({
        localPath: absPath,
        wasDownloaded: false
      });
    });

    it('should return path unchanged for Windows-style path', async () => {
      const winPath = 'C:\\Users\\test\\images\\photo.png';

      const result = await ResourceDownloader.resolveInputResource(winPath, TEST_TMP_DIR);

      expect(result).toEqual({
        localPath: winPath,
        wasDownloaded: false
      });
    });

    it('should not call fetch for local paths', async () => {
      const localPath = './tests/fixtures/images/test.png';
      let fetchCalled = false;

      global.fetch = async () => {
        fetchCalled = true;
        return createMockResponse('', 200);
      };

      await ResourceDownloader.resolveInputResource(localPath, TEST_TMP_DIR);

      expect(fetchCalled).toBe(false);
    });

    it('should handle filename without path', async () => {
      const filename = 'test.png';

      const result = await ResourceDownloader.resolveInputResource(filename, TEST_TMP_DIR);

      expect(result).toEqual({
        localPath: filename,
        wasDownloaded: false
      });
    });
  });

  describe('P1 - S004: Unsupported format validation', () => {
    it('should reject BMP format', () => {
      const ext = '.bmp';
      expect(SUPPORTED_FORMATS.includes(ext)).toBe(false);
    });

    it('should reject GIF format', () => {
      const ext = '.gif';
      expect(SUPPORTED_FORMATS.includes(ext)).toBe(false);
    });

    it('should reject TIFF format', () => {
      const ext = '.tiff';
      expect(SUPPORTED_FORMATS.includes(ext)).toBe(false);
    });

    it('should reject RAW format', () => {
      const ext = '.raw';
      expect(SUPPORTED_FORMATS.includes(ext)).toBe(false);
    });

    it('should accept all supported formats', () => {
      expect(SUPPORTED_FORMATS.includes('.png')).toBe(true);
      expect(SUPPORTED_FORMATS.includes('.jpg')).toBe(true);
      expect(SUPPORTED_FORMATS.includes('.jpeg')).toBe(true);
      expect(SUPPORTED_FORMATS.includes('.webp')).toBe(true);
    });

    it('should download URL with unsupported format (validation happens later in command)', async () => {
      const url = 'https://example.com/images/test.tiff';
      const mockData = Buffer.from('TIFF data');

      setupMockFetch(url, createMockResponse(mockData));

      // ResourceDownloader doesn't validate format - it just downloads
      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
      expect(result.localPath).toContain('test.tiff');
    });
  });

  describe('URL Detection', () => {
    it('should correctly identify HTTP URL', () => {
      expect(ResourceDownloader.isUrl('http://example.com/image.png')).toBe(true);
    });

    it('should correctly identify HTTPS URL', () => {
      expect(ResourceDownloader.isUrl('https://example.com/image.png')).toBe(true);
    });

    it('should reject FTP URL', () => {
      expect(ResourceDownloader.isUrl('ftp://example.com/image.png')).toBe(false);
    });

    it('should reject file:// URL', () => {
      expect(ResourceDownloader.isUrl('file:///path/to/image.png')).toBe(false);
    });

    it('should reject local path', () => {
      expect(ResourceDownloader.isUrl('./images/test.png')).toBe(false);
    });

    it('should reject absolute path', () => {
      expect(ResourceDownloader.isUrl('/absolute/path/test.png')).toBe(false);
    });

    it('should reject malformed URL', () => {
      expect(ResourceDownloader.isUrl('not-a-url')).toBe(false);
    });

    it('should reject empty string', () => {
      expect(ResourceDownloader.isUrl('')).toBe(false);
    });

    it('should reject null', () => {
      expect(ResourceDownloader.isUrl(null)).toBe(false);
    });

    it('should reject undefined', () => {
      expect(ResourceDownloader.isUrl(undefined)).toBe(false);
    });
  });

  describe('Edge Cases', () => {
    it('should handle URL with port number', async () => {
      const url = 'https://example.com:8443/images/test.png';
      const mockData = createMockPngData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
    });

    it('should handle URL with subdomain', async () => {
      const url = 'https://cdn.example.com/images/test.png';
      const mockData = createMockPngData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
    });

    it('should handle URL without file extension', async () => {
      const url = 'https://example.com/api/generate-image';
      const mockData = createMockPngData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
      expect(result.localPath).toContain('download_');
    });

    it('should handle URL with encoded characters', async () => {
      const url = 'https://example.com/images/high%20resolution%20photo.png';
      const mockData = createMockPngData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
    });

    it('should handle filename conflict by adding counter', async () => {
      const url = 'https://example.com/images/upscale.png';
      const mockData = createMockPngData();

      // First download
      setupMockFetch(url, createMockResponse(mockData));
      const result1 = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);
      expect(result1.localPath).toContain('upscale.png');

      // Second download with same filename
      setupMockFetch(url, createMockResponse(mockData));
      const result2 = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);
      expect(result2.localPath).toContain('upscale_1.png');

      // Third download
      setupMockFetch(url, createMockResponse(mockData));
      const result3 = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);
      expect(result3.localPath).toContain('upscale_2.png');
    });

    it('should handle very long URL', async () => {
      const url = 'https://example.com/images/' + 'a'.repeat(100) + '.png';
      const mockData = createMockPngData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
    });

    it('should handle URL with multiple query parameters', async () => {
      const url = 'https://example.com/api/image?width=1920&height=1080&format=png&quality=100';
      const mockData = createMockPngData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
      expect(result.localPath).toContain('image');
    });

    it('should handle URL with hash fragment', async () => {
      const url = 'https://example.com/images/test.png#section';
      const mockData = createMockPngData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      expect(result.wasDownloaded).toBe(true);
    });
  });

  describe('Integration with imagescale workflow', () => {
    it('should provide correct local path after download for subsequent processing', async () => {
      const url = 'https://example.com/images/4k-source.png';
      const mockData = createMockPngData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      // Verify the local path can be resolved
      const resolvedPath = path.resolve(result.localPath);
      expect(fs.existsSync(result.localPath)).toBe(true);

      // Verify extension is preserved
      const ext = path.extname(result.localPath).toLowerCase();
      expect(SUPPORTED_FORMATS).toContain(ext);
    });

    it('should handle case where downloaded file exists', async () => {
      const url = 'https://example.com/images/existing.png';
      const mockData = createMockPngData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await ResourceDownloader.resolveInputResource(url, TEST_TMP_DIR);

      // Verify file was downloaded and exists
      expect(result.wasDownloaded).toBe(true);
      expect(fs.existsSync(result.localPath)).toBe(true);

      // Verify file has content
      const stats = fs.statSync(result.localPath);
      expect(stats.size).toBeGreaterThan(0);
    });
  });
});
