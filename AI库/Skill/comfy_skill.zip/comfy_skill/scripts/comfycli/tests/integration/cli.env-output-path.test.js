/**
 * Integration tests for CLI option parsing + DEFAULT_OUTPUT_PATH
 * Tests: TC-030 through TC-035
 *
 * End-to-end verification of Commander.js CLI option parsing
 * combined with DEFAULT_OUTPUT_PATH calculation from COMFY_PROJECT_ROOT.
 */
import { jest, describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import { Command } from 'commander';
import path from 'path';

/**
 * Creates a test Commander program that mirrors cli.js txt2img command
 * but uses a dynamic DEFAULT_OUTPUT_PATH based on current env state
 */
function createTestProgram(envRoot, cwdValue) {
  const DEFAULT_OUTPUT_PATH = envRoot
    ? path.join(envRoot, 'output')
    : path.join(cwdValue, 'output');

  const program = new Command();
  program
    .name('comfycli')
    .description('CLI tool for ComfyUI workflow management')
    .version('1.0.0');

  program
    .command('txt2img')
    .description('Generate image from text prompt')
    .argument('<prompt>', 'Text prompt for image generation')
    .option('-o, --output <path>', 'Output directory path', DEFAULT_OUTPUT_PATH)
    .option('--project <name>', 'Project name')
    .option('--category <type>', 'Resource category');

  return program;
}

/**
 * Parse args and capture options
 */
async function parseAndCapture(args, envRoot, cwdValue) {
  const program = createTestProgram(envRoot, cwdValue);
  let capturedOptions = null;

  program.commands[0].action((prompt, options) => {
    capturedOptions = options;
  });

  await program.parseAsync(['node', 'comfycli', ...args], { from: 'node' });
  return capturedOptions;
}

describe('CLI env + output path integration', () => {
  let originalEnv;

  beforeEach(() => {
    originalEnv = { ...process.env };
    delete process.env.COMFY_PROJECT_ROOT;
  });

  afterEach(() => {
    process.env = { ...originalEnv };
  });

  // ── TC-030: ENV set → txt2img → options.output = ENV/output ──
  it('TC-030: COMFY_PROJECT_ROOT set → txt2img output = ENV/output', async () => {
    const options = await parseAndCapture(
      ['txt2img', 'a sunset'],
      '/proj',
      '/cwd'
    );

    expect(options.output).toBe(path.normalize('/proj/output'));
  });

  // ── TC-031: ENV unset → fallback to cwd ──
  it('TC-031: COMFY_PROJECT_ROOT unset → output = cwd/output', async () => {
    const options = await parseAndCapture(
      ['txt2img', 'a sunset'],
      undefined,
      '/fallback/dir'
    );

    expect(options.output).toBe(path.normalize('/fallback/dir/output'));
  });

  // ── TC-032: ENV + explicit --output → ignore ENV ──
  it('TC-032: ENV set + explicit --output → uses explicit output', async () => {
    const options = await parseAndCapture(
      ['txt2img', 'a sunset', '--output', '/custom'],
      '/proj',
      '/cwd'
    );

    expect(options.output).toBe('/custom');
  });

  // ── TC-033: ENV + project + category → full path via generateOutputPath ──
  it('TC-033: ENV + project + category → final path includes all segments', async () => {
    const { generateOutputPath } = await import('../../src/core/workflow.js');
    const options = await parseAndCapture(
      ['txt2img', 'a sunset', '--project', 'w', '--category', 'c'],
      '/proj',
      '/cwd'
    );

    const baseOutput = options.output;
    expect(baseOutput).toBe(path.normalize('/proj/output'));

    const finalPath = generateOutputPath(baseOutput, {
      project: options.project,
      category: options.category
    });
    expect(finalPath).toMatch(/proj[\/\\]output[\/\\]w[\/\\]resources[\/\\]c$/);
  });

  // ── TC-034: ENV + explicit output + project + category ──
  it('TC-034: explicit output + project + category → uses explicit base', async () => {
    const { generateOutputPath } = await import('../../src/core/workflow.js');
    const options = await parseAndCapture(
      ['txt2img', 'a sunset', '--output', '/custom', '--project', 'w', '--category', 'c'],
      '/proj',
      '/cwd'
    );

    expect(options.output).toBe('/custom');

    const finalPath = generateOutputPath(options.output, {
      project: options.project,
      category: options.category
    });
    expect(finalPath).toMatch(/custom[\/\\]w[\/\\]resources[\/\\]c$/);
  });

  // ── TC-035: No ENV + relative output ──
  it('TC-035: no ENV + relative --output → path is relative', async () => {
    const options = await parseAndCapture(
      ['txt2img', 'a sunset', '--output', './out'],
      undefined,
      '/cwd'
    );

    expect(options.output).toBe('./out');
  });
});
