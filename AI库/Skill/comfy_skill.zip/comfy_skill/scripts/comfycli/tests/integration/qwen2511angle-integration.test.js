/**
 * TEST-004: ConfigManager and Command Integration Test
 * Validates ConfigManager loading + list/validate command handling for qwen2511angle
 */
import { jest, describe, test, expect, beforeAll, afterEach } from '@jest/globals';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import ConfigManager from '../../src/utils/config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECT_ROOT = path.resolve(__dirname, '../../');
const CONFIG_PATH = path.join(PROJECT_ROOT, 'config', 'comfy_config.json');

let cm;

beforeAll(() => {
  cm = new ConfigManager(CONFIG_PATH);
});

describe('TEST-004: ConfigManager and Command Integration for qwen2511angle', () => {
  test('TC-404-01: ConfigManager.load() succeeds', () => {
    const result = cm.load();
    expect(result).toBe(true);
  });

  test('TC-404-02: getWorkflow("qwen2511angle") returns config', () => {
    cm.load();
    const wf = cm.getWorkflow('qwen2511angle');
    expect(wf).not.toBeNull();
    expect(wf.description).toBeDefined();
    expect(wf.type).toBeDefined();
    expect(wf.api).toBeDefined();
    expect(wf.data).toBeDefined();
  });

  test('TC-404-03: getWorkflow returns correct type', () => {
    cm.load();
    const wf = cm.getWorkflow('qwen2511angle');
    expect(wf.type).toBe('img2img');
  });

  test('TC-404-04: getWorkflow returns correct api path', () => {
    cm.load();
    const wf = cm.getWorkflow('qwen2511angle');
    expect(wf.api).toContain('image_angles');
  });

  test('TC-404-05: listWorkflows() includes qwen2511angle', () => {
    cm.load();
    const workflows = cm.listWorkflows();
    const angleWf = workflows.find(w => w.name === 'qwen2511angle');
    expect(angleWf).toBeDefined();
    expect(angleWf.description).toBe('Qwen Image Edit 2511 Image Angle Generation');
  });

  test('TC-404-06: validate() returns valid: true', () => {
    cm.load();
    const result = cm.validate();
    expect(result.valid).toBe(true);
  });

  test('TC-404-07: list command output includes qwen2511angle', () => {
    cm.load();
    const workflows = cm.listWorkflows();
    const names = workflows.map(w => w.name);

    // Capture console output
    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

    // Simulate list command output
    for (const wf of workflows) {
      console.log(`${wf.name} | ${wf.type} | ${wf.description}`);
    }

    // Verify qwen2511angle was in the output
    const calls = consoleSpy.mock.calls.map(call => call[0]);
    const angleOutput = calls.find(c => c.includes('qwen2511angle'));
    expect(angleOutput).toBeDefined();

    consoleSpy.mockRestore();
  });

  test('TC-404-08: validate command produces no errors for qwen2511angle', () => {
    cm.load();
    const result = cm.validate();

    // Filter errors related to qwen2511angle
    const angleErrors = result.errors.filter(e => e.includes('qwen2511angle'));
    expect(angleErrors).toHaveLength(0);
  });

  test('TC-404-09: img2img command accepts --workflow qwen2511angle', () => {
    cm.load();
    const wf = cm.getWorkflow('qwen2511angle');

    // Verify the workflow can be found by name (simulating what img2img command does)
    expect(wf).not.toBeNull();
    expect(wf.type).toBe('img2img');
  });

  test('TC-404-10: Other workflows still load correctly', () => {
    cm.load();

    // Check other workflows are unaffected
    const qwen2511i2i = cm.getWorkflow('qwen2511i2i');
    expect(qwen2511i2i).not.toBeNull();
    expect(qwen2511i2i.type).toBe('img2img');

    const qwen2511t2i = cm.getWorkflow('qwen2511t2i');
    expect(qwen2511t2i).not.toBeNull();
    expect(qwen2511t2i.type).toBe('txt2img');

    const zimageupscale = cm.getWorkflow('zimageupscale');
    expect(zimageupscale).not.toBeNull();
    expect(zimageupscale.type).toBe('imagescale');
  });
});
