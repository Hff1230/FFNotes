/**
 * Integration tests for batch.js core flow
 * TEST-301: batch.js core flow integration tests (16 test cases)
 */
import { jest } from '@jest/globals';
import path from 'path';
import fs from 'fs';
import os from 'os';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const TMP_DIR = path.join(os.tmpdir(), 'comfycli-test-301');
const FIXTURES_DIR = path.resolve(__dirname, '../../fixtures');
const PROJECT_ROOT = path.resolve(__dirname, '../../../');
const SRC = (rel) => path.resolve(PROJECT_ROOT, 'src', rel);

function fixturePath(name) {
  return path.join(FIXTURES_DIR, name);
}

function writeTempFile(filename, content) {
  const filePath = path.join(TMP_DIR, filename);
  fs.writeFileSync(filePath, content, 'utf-8');
  return filePath;
}

function removeIfExists(filePath) {
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
}

// ---------------------------------------------------------------------------
// Setup / teardown
// ---------------------------------------------------------------------------
beforeAll(() => {
  fs.mkdirSync(TMP_DIR, { recursive: true });
});

afterAll(() => {
  fs.rmSync(TMP_DIR, { recursive: true, force: true });
});

// ============================================================================
// JSON Reading & Parsing
// ============================================================================
describe('TC-301 JSON Reading & Parsing', () => {
  let mockExit;
  let batchCommand;

  beforeEach(async () => {
    mockExit = jest.spyOn(process, 'exit').mockImplementation((code) => {
      throw new Error(`process.exit(${code})`);
    });
    const mod = await import('../../../src/commands/batch.js');
    batchCommand = mod.batchCommand;
  });

  afterEach(() => {
    mockExit.mockRestore();
  });

  test('TC-301-01 - Valid JSON file with dryRun succeeds', async () => {
    const tasks = [
      { type: 'txt2img', prompt: 'a beautiful sunset' },
      { type: 'txt2img', prompt: 'a mountain landscape' }
    ];
    const filePath = writeTempFile('valid.json', JSON.stringify(tasks));
    await batchCommand(filePath, { dryRun: true });
    expect(mockExit).not.toHaveBeenCalled();
  });

  test('TC-301-02 - Nonexistent file causes process.exit(1)', async () => {
    const filePath = path.join(TMP_DIR, 'nonexistent-file.json');
    await expect(batchCommand(filePath, { dryRun: true })).rejects.toThrow('process.exit(1)');
    expect(mockExit).toHaveBeenCalledWith(1);
  });

  test('TC-301-03 - Invalid JSON content causes process.exit(1)', async () => {
    const filePath = writeTempFile('bad-json.txt', 'not json {{{');
    await expect(batchCommand(filePath, { dryRun: true })).rejects.toThrow('process.exit(1)');
    expect(mockExit).toHaveBeenCalledWith(1);
  });

  test('TC-301-04 - Invalid tasks (no type field) causes process.exit(1)', async () => {
    const filePath = fixturePath('invalid-no-type.json');
    await expect(batchCommand(filePath, { dryRun: true })).rejects.toThrow('process.exit(1)');
    expect(mockExit).toHaveBeenCalledWith(1);
  });
});

// ============================================================================
// dryRun Mode
// ============================================================================
describe('TC-301 dryRun Mode', () => {
  let consoleSpy;
  let batchCommand;

  beforeEach(async () => {
    consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
    const mod = await import('../../../src/commands/batch.js');
    batchCommand = mod.batchCommand;
  });

  afterEach(() => {
    consoleSpy.mockRestore();
  });

  test('TC-301-09 - dryRun does not execute tasks, outputs "Dry run"', async () => {
    const tasks = [{ type: 'txt2img', prompt: 'test prompt' }];
    const filePath = writeTempFile('dryrun-basic.json', JSON.stringify(tasks));
    await batchCommand(filePath, { dryRun: true });
    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');
    expect(output).toContain('Dry run');
    expect(output).toContain('validation passed');
  });

  test('TC-301-10 - dryRun shows task count and types', async () => {
    const filePath = fixturePath('txt2img-tasks.json');
    await batchCommand(filePath, { dryRun: true });
    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');
    expect(output).toContain('3 tasks');
    expect(output).toContain('txt2img');
  });
});

// ============================================================================
// clean Option
// ============================================================================
describe('TC-301 clean Option', () => {
  let consoleSpy;
  let batchCommand;
  let getProgressFilePath;

  beforeEach(async () => {
    consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
    const mod = await import('../../../src/commands/batch.js');
    batchCommand = mod.batchCommand;
    getProgressFilePath = mod.getProgressFilePath;
  });

  afterEach(() => {
    consoleSpy.mockRestore();
  });

  test('TC-301-13 - --clean deletes existing progress file', async () => {
    const tasks = [{ type: 'txt2img', prompt: 'test' }];
    const jsonPath = writeTempFile('clean-exists.json', JSON.stringify(tasks));
    const progressPath = getProgressFilePath(path.resolve(jsonPath));
    fs.writeFileSync(progressPath, JSON.stringify({ totalTasks: 1 }), 'utf-8');
    expect(fs.existsSync(progressPath)).toBe(true);
    await batchCommand(jsonPath, { clean: true });
    expect(fs.existsSync(progressPath)).toBe(false);
  });

  test('TC-301-14 - --clean with no progress file does not error', async () => {
    const tasks = [{ type: 'txt2img', prompt: 'test' }];
    const jsonPath = writeTempFile('clean-absent.json', JSON.stringify(tasks));
    const progressPath = getProgressFilePath(path.resolve(jsonPath));
    removeIfExists(progressPath);
    await batchCommand(jsonPath, { clean: true });
    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');
    expect(output).toContain('No progress file found');
  });
});

// ============================================================================
// Global Option Override
// ============================================================================
describe('TC-301 Global Option Override', () => {
  let consoleSpy;
  let batchCommand;

  beforeEach(async () => {
    consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
    const mod = await import('../../../src/commands/batch.js');
    batchCommand = mod.batchCommand;
  });

  afterEach(() => {
    consoleSpy.mockRestore();
  });

  test('TC-301-11 - --output global override accepted in dryRun', async () => {
    const tasks = [{ type: 'txt2img', prompt: 'test output override', output: '/original/path' }];
    const filePath = writeTempFile('output-override.json', JSON.stringify(tasks));
    await batchCommand(filePath, { dryRun: true, output: '/override/path' });
    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');
    expect(output).toContain('Dry run');
  });

  test('TC-301-12 - --no-upload override accepted in dryRun', async () => {
    const tasks = [{ type: 'txt2img', prompt: 'test no upload', upload: true }];
    const filePath = writeTempFile('no-upload.json', JSON.stringify(tasks));
    await batchCommand(filePath, { dryRun: true, upload: false });
    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');
    expect(output).toContain('Dry run');
  });
});

// ============================================================================
// Task Execution (using unstable_mockModule for ESM)
// ============================================================================
describe('TC-301 Task Execution', () => {
  let consoleSpy;
  let mockExit;
  let getProgressFilePath;
  let txt2imgMock, img2imgMock, imagescaleMock;

  beforeEach(async () => {
    jest.resetModules();
    consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
    mockExit = jest.spyOn(process, 'exit').mockImplementation((code) => {
      throw new Error(`process.exit(${code})`);
    });

    // Set up mocks before importing batch
    txt2imgMock = jest.fn().mockResolvedValue({ files: ['/tmp/out.png'] });
    img2imgMock = jest.fn().mockResolvedValue({ files: ['/tmp/out.png'] });
    imagescaleMock = jest.fn().mockResolvedValue({ files: ['/tmp/out.png'] });

    jest.unstable_mockModule(SRC('commands/txt2img.js'), () => ({
      txt2imgCommand: txt2imgMock,
      default: txt2imgMock,
    }));
    jest.unstable_mockModule(SRC('commands/img2img.js'), () => ({
      img2imgCommand: img2imgMock,
      default: img2imgMock,
    }));
    jest.unstable_mockModule(SRC('commands/imagescale.js'), () => ({
      imagescaleCommand: imagescaleMock,
      default: imagescaleMock,
    }));
    jest.unstable_mockModule(SRC('commands/txt2vid.js'), () => ({
      txt2vidCommand: jest.fn().mockResolvedValue({ files: [] }),
      default: jest.fn().mockResolvedValue({ files: [] }),
    }));
    jest.unstable_mockModule(SRC('commands/img2vid.js'), () => ({
      img2vidCommand: jest.fn().mockResolvedValue({ files: [] }),
      default: jest.fn().mockResolvedValue({ files: [] }),
    }));

    const mod = await import(SRC('commands/batch.js'));
    getProgressFilePath = mod.getProgressFilePath;
  });

  afterEach(() => {
    consoleSpy.mockRestore();
    mockExit.mockRestore();
    jest.restoreAllMocks();
    jest.resetModules();
  });

  test('TC-301-05 - Sequential execution calls tasks in order', async () => {
    const { batchCommand } = await import('../../../src/commands/batch.js');
    const tasks = [
      { type: 'txt2img', prompt: 'first' },
      { type: 'txt2img', prompt: 'second' },
      { type: 'txt2img', prompt: 'third' }
    ];
    const filePath = writeTempFile('sequential.json', JSON.stringify(tasks));
    await batchCommand(filePath, { restart: true });
    expect(txt2imgMock).toHaveBeenCalledTimes(3);
    removeIfExists(getProgressFilePath(path.resolve(filePath)));
  });

  test('TC-301-06 - Mixed type routing dispatches correctly', async () => {
    const { batchCommand } = await import('../../../src/commands/batch.js');
    const filePath = fixturePath('mixed-tasks.json');
    await batchCommand(filePath, { restart: true });
    expect(txt2imgMock).toHaveBeenCalledTimes(1);
    expect(img2imgMock).toHaveBeenCalledTimes(1);
    expect(imagescaleMock).toHaveBeenCalledTimes(1);
    removeIfExists(getProgressFilePath(path.resolve(filePath)));
  });

  test('TC-301-07 - Stop on error halts execution', async () => {
    jest.resetModules();
    const failMock = jest.fn()
      .mockResolvedValueOnce({ files: [] })
      .mockRejectedValueOnce(new Error('Simulated failure'));

    jest.unstable_mockModule(SRC('commands/txt2img.js'), () => ({
      txt2imgCommand: failMock,
      default: failMock,
    }));
    jest.unstable_mockModule(SRC('commands/img2img.js'), () => ({
      img2imgCommand: jest.fn().mockResolvedValue({ files: [] }),
      default: jest.fn().mockResolvedValue({ files: [] }),
    }));
    jest.unstable_mockModule(SRC('commands/txt2vid.js'), () => ({
      txt2vidCommand: jest.fn().mockResolvedValue({ files: [] }),
      default: jest.fn().mockResolvedValue({ files: [] }),
    }));
    jest.unstable_mockModule(SRC('commands/img2vid.js'), () => ({
      img2vidCommand: jest.fn().mockResolvedValue({ files: [] }),
      default: jest.fn().mockResolvedValue({ files: [] }),
    }));
    jest.unstable_mockModule(SRC('commands/imagescale.js'), () => ({
      imagescaleCommand: jest.fn().mockResolvedValue({ files: [] }),
      default: jest.fn().mockResolvedValue({ files: [] }),
    }));

    const { batchCommand, getProgressFilePath: gpf } = await import(SRC('commands/batch.js'));
    const tasks = [
      { type: 'txt2img', prompt: 'succeed' },
      { type: 'txt2img', prompt: 'fail' },
      { type: 'txt2img', prompt: 'should not run' }
    ];
    const filePath = writeTempFile('stop-on-error.json', JSON.stringify(tasks));
    await expect(batchCommand(filePath, { restart: true })).rejects.toThrow('process.exit(1)');
    expect(failMock).toHaveBeenCalledTimes(2); // Only first 2 called
    removeIfExists(gpf(path.resolve(filePath)));
  });

  test('TC-301-08 - Continue on error executes all tasks', async () => {
    jest.resetModules();
    let callCount = 0;
    const contMock = jest.fn().mockImplementation(async () => {
      callCount++;
      if (callCount === 2) throw new Error('Task B failed');
      return { files: [] };
    });

    jest.unstable_mockModule(SRC('commands/txt2img.js'), () => ({
      txt2imgCommand: contMock,
      default: contMock,
    }));
    jest.unstable_mockModule(SRC('commands/img2img.js'), () => ({
      img2imgCommand: jest.fn().mockResolvedValue({ files: [] }),
      default: jest.fn().mockResolvedValue({ files: [] }),
    }));
    jest.unstable_mockModule(SRC('commands/txt2vid.js'), () => ({
      txt2vidCommand: jest.fn().mockResolvedValue({ files: [] }),
      default: jest.fn().mockResolvedValue({ files: [] }),
    }));
    jest.unstable_mockModule(SRC('commands/img2vid.js'), () => ({
      img2vidCommand: jest.fn().mockResolvedValue({ files: [] }),
      default: jest.fn().mockResolvedValue({ files: [] }),
    }));
    jest.unstable_mockModule(SRC('commands/imagescale.js'), () => ({
      imagescaleCommand: jest.fn().mockResolvedValue({ files: [] }),
      default: jest.fn().mockResolvedValue({ files: [] }),
    }));

    const { batchCommand, getProgressFilePath: gpf } = await import(SRC('commands/batch.js'));
    const tasks = [
      { type: 'txt2img', prompt: 'A' },
      { type: 'txt2img', prompt: 'B' },
      { type: 'txt2img', prompt: 'C' }
    ];
    const filePath = writeTempFile('continue-on-error.json', JSON.stringify(tasks));
    await batchCommand(filePath, { restart: true, continueOnError: true });
    expect(callCount).toBe(3);
    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');
    expect(output).toContain('Successful: 2');
    expect(output).toContain('Failed: 1');
    removeIfExists(gpf(path.resolve(filePath)));
  });
});

// ============================================================================
// Summary Report (reuses mock setup from Task Execution)
// ============================================================================
describe('TC-301 Summary Report', () => {
  let consoleSpy;

  beforeEach(async () => {
    consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
  });

  afterEach(() => {
    consoleSpy.mockRestore();
    jest.restoreAllMocks();
    jest.resetModules();
  });

  test('TC-301-15 - All success report', async () => {
    const okMock = jest.fn().mockResolvedValue({ files: ['/tmp/out.png'] });
    jest.unstable_mockModule(SRC('commands/txt2img.js'), () => ({
      txt2imgCommand: okMock,
      default: okMock,
    }));
    jest.unstable_mockModule(SRC('commands/img2img.js'), () => ({
      img2imgCommand: jest.fn(), default: jest.fn(),
    }));
    jest.unstable_mockModule(SRC('commands/txt2vid.js'), () => ({
      txt2vidCommand: jest.fn(), default: jest.fn(),
    }));
    jest.unstable_mockModule(SRC('commands/img2vid.js'), () => ({
      img2vidCommand: jest.fn(), default: jest.fn(),
    }));
    jest.unstable_mockModule(SRC('commands/imagescale.js'), () => ({
      imagescaleCommand: jest.fn(), default: jest.fn(),
    }));

    const { batchCommand, getProgressFilePath } = await import('../../../src/commands/batch.js');
    const tasks = [
      { type: 'txt2img', prompt: 's1' },
      { type: 'txt2img', prompt: 's2' }
    ];
    const filePath = writeTempFile('all-success.json', JSON.stringify(tasks));
    await batchCommand(filePath, { restart: true });
    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');
    expect(output).toContain('Successful: 2');
    removeIfExists(getProgressFilePath(path.resolve(filePath)));
  });

  test('TC-301-16 - Partial failure report', async () => {
    let callCount = 0;
    const partialMock = jest.fn().mockImplementation(async () => {
      callCount++;
      if (callCount === 2) throw new Error('Task failed');
      return { files: [] };
    });
    jest.unstable_mockModule(SRC('commands/txt2img.js'), () => ({
      txt2imgCommand: partialMock,
      default: partialMock,
    }));
    jest.unstable_mockModule(SRC('commands/img2img.js'), () => ({
      img2imgCommand: jest.fn(), default: jest.fn(),
    }));
    jest.unstable_mockModule(SRC('commands/txt2vid.js'), () => ({
      txt2vidCommand: jest.fn(), default: jest.fn(),
    }));
    jest.unstable_mockModule(SRC('commands/img2vid.js'), () => ({
      img2vidCommand: jest.fn(), default: jest.fn(),
    }));
    jest.unstable_mockModule(SRC('commands/imagescale.js'), () => ({
      imagescaleCommand: jest.fn(), default: jest.fn(),
    }));

    const { batchCommand, getProgressFilePath } = await import('../../../src/commands/batch.js');
    const tasks = [
      { type: 'txt2img', prompt: 'ok' },
      { type: 'txt2img', prompt: 'fail' }
    ];
    const filePath = writeTempFile('partial-fail.json', JSON.stringify(tasks));
    await batchCommand(filePath, { restart: true, continueOnError: true });
    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');
    expect(output).toContain('Successful: 1');
    expect(output).toContain('Failed: 1');
    removeIfExists(getProgressFilePath(path.resolve(filePath)));
  });
});
