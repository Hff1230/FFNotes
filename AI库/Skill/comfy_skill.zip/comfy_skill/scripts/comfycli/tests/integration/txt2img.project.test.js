/**
 * Integration tests for txt2img command project-based workflow
 * Tests the correct integration of generateOutputPath, generateOutputFilename,
 * and uploader methods in the txt2img command flow
 */
import { describe, it, expect, jest, beforeEach, afterEach } from '@jest/globals';
import path from 'path';
import {
  generateOutputFilename,
  generateOutputPath
} from '../../src/core/workflow.js';
import {
  createMockConfigManager,
  createMockComfyHelper,
  createMockProgressMonitor,
  createMockUploader
} from '../helpers/mock-factory.js';

describe('txt2img Flow Integration Tests - Project Mode', () => {
  let mockConfigManager;
  let mockComfyHelper;
  let mockProgressMonitor;
  let mockUploader;

  beforeEach(() => {
    jest.useRealTimers();
    mockConfigManager = createMockConfigManager();
    mockComfyHelper = createMockComfyHelper();
    mockProgressMonitor = createMockProgressMonitor();
    mockUploader = createMockUploader();
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  describe('Directory Generation', () => {
    it('should generate correct output directory for project mode', () => {
      const baseDir = '/tmp';
      const options = { project: 'wusong', category: 'characters' };

      const outputDir = generateOutputPath(baseDir, options);

      expect(outputDir).toContain('wusong');
      expect(outputDir).toContain('resources');
      expect(outputDir).toContain('characters');
      expect(outputDir).toMatch(/wusong[\/\\]resources[\/\\]characters$/);
    });

    it('should generate correct output directory for scenes category', () => {
      const baseDir = '/tmp';
      const options = { project: 'wusong', category: 'scenes' };

      const outputDir = generateOutputPath(baseDir, options);

      expect(outputDir).toContain('wusong');
      expect(outputDir).toContain('resources');
      expect(outputDir).toContain('scenes');
    });

    it('should return base directory for non-project mode', () => {
      const baseDir = '/tmp';
      const options = {};

      const outputDir = generateOutputPath(baseDir, options);

      expect(outputDir).toBe('/tmp');
    });

    it('should return base directory when only project is provided', () => {
      const baseDir = '/tmp';
      const options = { project: 'wusong' };

      const outputDir = generateOutputPath(baseDir, options);

      expect(outputDir).toBe('/tmp');
    });

    it('should return base directory when only category is provided', () => {
      const baseDir = '/tmp';
      const options = { category: 'characters' };

      const outputDir = generateOutputPath(baseDir, options);

      expect(outputDir).toBe('/tmp');
    });
  });

  describe('Filename Generation', () => {
    it('should use name directly when project, category, and name are all provided', () => {
      const workflowName = 'txt2img';
      const extension = '.png';
      const options = { project: 'wusong', category: 'characters', name: 'C01_武松' };

      const filename = generateOutputFilename(workflowName, extension, options);

      expect(filename).toBe('C01_武松.png');
    });

    it('should generate timestamp filename when only project and category are provided', () => {
      const mockDate = new Date('2026-03-31T14:25:30');
      jest.useFakeTimers().setSystemTime(mockDate);

      const workflowName = 'txt2img';
      const extension = '.png';
      const options = { project: 'wusong', category: 'scenes' };

      const filename = generateOutputFilename(workflowName, extension, options);

      expect(filename).toBe('wusong_scenes_20260331_142530.png');

      jest.useRealTimers();
    });

    it('should generate default timestamp filename for non-project mode', () => {
      const mockDate = new Date('2026-03-31T14:25:30');
      jest.useFakeTimers().setSystemTime(mockDate);

      const workflowName = 'txt2img';
      const extension = '.png';
      const options = {};

      const filename = generateOutputFilename(workflowName, extension, options);

      expect(filename).toBe('txt2img_20260331_142530.png');

      jest.useRealTimers();
    });

    it('should support different extensions', () => {
      const options = { project: 'wusong', category: 'characters', name: 'C01_武松' };

      expect(generateOutputFilename('workflow', '.jpg', options)).toBe('C01_武松.jpg');
      expect(generateOutputFilename('workflow', '.webp', options)).toBe('C01_武松.webp');
      expect(generateOutputFilename('workflow', '.mp4', options)).toBe('C01_武松.mp4');
    });
  });

  describe('Upload Options Integration', () => {
    it('should pass project/category options to uploadFiles in project mode', async () => {
      const options = { project: 'wusong', category: 'characters', name: 'C01_武松' };
      const files = ['/tmp/wusong/resources/characters/C01_武松.png'];

      // Simulate the upload options construction from txt2img.js
      const uploadOptions = {};
      if (options.project && options.category) {
        uploadOptions.project = options.project;
        uploadOptions.category = options.category;
      }

      const uploadResult = await mockUploader.uploadFiles(files, uploadOptions);

      expect(mockUploader.uploadFiles.calledOnce).toBe(true);
      expect(mockUploader.uploadFiles.firstCall.args[1]).toEqual({
        project: 'wusong',
        category: 'characters'
      });
      expect(uploadResult.success).toBe(true);
    });

    it('should not pass project/category options in non-project mode', async () => {
      const options = {};
      const files = ['/tmp/output.png'];

      const uploadOptions = {};
      if (options.project && options.category) {
        uploadOptions.project = options.project;
        uploadOptions.category = options.category;
      }

      await mockUploader.uploadFiles(files, uploadOptions);

      expect(mockUploader.uploadFiles.firstCall.args[1]).toEqual({});
    });

    it('should use getProjectShareUrl in project mode', () => {
      const options = { project: 'wusong', category: 'characters' };
      const filename = 'C01_武松.png';

      let shareUrl;
      if (options.project && options.category) {
        shareUrl = mockUploader.getProjectShareUrl(filename, options.project, options.category);
      } else {
        shareUrl = mockUploader.getShareUrl(filename);
      }

      expect(shareUrl).toBe('http://47.109.205.195:10020/projects/wusong/characters/C01_武松.png');
      expect(mockUploader.getProjectShareUrl.calledOnce).toBe(true);
    });

    it('should use getShareUrl in non-project mode', () => {
      const options = {};
      const filename = 'output.png';

      let shareUrl;
      if (options.project && options.category) {
        shareUrl = mockUploader.getProjectShareUrl(filename, options.project, options.category);
      } else {
        shareUrl = mockUploader.getShareUrl(filename);
      }

      expect(shareUrl).toBe('http://192.168.0.92:9998/comfy/2026-3-31/output.png');
      expect(mockUploader.getShareUrl.calledOnce).toBe(true);
    });
  });

  describe('Complete Flow Simulation - Project Mode', () => {
    it('should generate correct output path and filename for project workflow', () => {
      // Simulate complete project mode options
      const options = {
        project: 'wusong',
        category: 'characters',
        name: 'C01_武松',
        output: '/tmp'
      };
      const workflowName = 'txt2img';

      // Step 1: Generate output directory
      let outputDir = options.output || './output';
      if (options.project && options.category) {
        outputDir = generateOutputPath(outputDir, {
          project: options.project,
          category: options.category
        });
      }

      // Step 2: Generate output filename
      const outputFilename = generateOutputFilename(workflowName, '.png', {
        project: options.project,
        category: options.category,
        name: options.name
      });

      // Step 3: Full output path
      const outputPath = path.join(outputDir, outputFilename);

      // Verify results
      expect(outputDir).toMatch(/wusong[\/\\]resources[\/\\]characters$/);
      expect(outputFilename).toBe('C01_武松.png');
      expect(outputPath).toMatch(/wusong[\/\\]resources[\/\\]characters[\/\\]C01_武松\.png$/);
    });

    it('should generate correct output path and filename for partial project options', () => {
      const mockDate = new Date('2026-03-31T14:25:30');
      jest.useFakeTimers().setSystemTime(mockDate);

      // Simulate partial project mode (no name)
      const options = {
        project: 'wusong',
        category: 'scenes',
        output: '/tmp'
      };
      const workflowName = 'txt2img';

      // Step 1: Generate output directory
      let outputDir = options.output || './output';
      if (options.project && options.category) {
        outputDir = generateOutputPath(outputDir, {
          project: options.project,
          category: options.category
        });
      }

      // Step 2: Generate output filename
      const outputFilename = generateOutputFilename(workflowName, '.png', {
        project: options.project,
        category: options.category,
        name: options.name
      });

      // Verify results
      expect(outputDir).toMatch(/wusong[\/\\]resources[\/\\]scenes$/);
      expect(outputFilename).toBe('wusong_scenes_20260331_142530.png');

      jest.useRealTimers();
    });
  });

  describe('Complete Flow Simulation - Backward Compatibility Mode', () => {
    it('should use default directory and timestamp filename without project options', () => {
      const mockDate = new Date('2026-03-31T14:25:30');
      jest.useFakeTimers().setSystemTime(mockDate);

      const options = { output: '/tmp' };
      const workflowName = 'txt2img';

      // Step 1: Generate output directory
      let outputDir = options.output || './output';
      if (options.project && options.category) {
        outputDir = generateOutputPath(outputDir, {
          project: options.project,
          category: options.category
        });
      }

      // Step 2: Generate output filename
      const outputFilename = generateOutputFilename(workflowName, '.png', {
        project: options.project,
        category: options.category,
        name: options.name
      });

      // Verify results
      expect(outputDir).toBe('/tmp');
      expect(outputFilename).toBe('txt2img_20260331_142530.png');

      jest.useRealTimers();
    });

    it('should use getShareUrl for non-project uploads', async () => {
      const options = { output: '/tmp' };
      const files = ['/tmp/txt2img_20260331_142530.png'];

      // Construct upload options (should be empty for non-project mode)
      const uploadOptions = {};
      if (options.project && options.category) {
        uploadOptions.project = options.project;
        uploadOptions.category = options.category;
      }

      await mockUploader.uploadFiles(files, uploadOptions);

      // Generate share URL
      const filename = 'txt2img_20260331_142530.png';
      let shareUrl;
      if (options.project && options.category) {
        shareUrl = mockUploader.getProjectShareUrl(filename, options.project, options.category);
      } else {
        shareUrl = mockUploader.getShareUrl(filename);
      }

      expect(uploadOptions).toEqual({});
      expect(shareUrl).toBe('http://192.168.0.92:9998/comfy/2026-3-31/txt2img_20260331_142530.png');
    });
  });

  describe('No-Upload Option', () => {
    it('should skip upload when --no-upload is set but still save files locally', () => {
      const options = {
        project: 'wusong',
        category: 'characters',
        name: 'C01_武松',
        output: '/tmp',
        upload: false
      };

      // Generate paths as normal
      let outputDir = options.output || './output';
      if (options.project && options.category) {
        outputDir = generateOutputPath(outputDir, {
          project: options.project,
          category: options.category
        });
      }

      const outputFilename = generateOutputFilename('txt2img', '.png', {
        project: options.project,
        category: options.category,
        name: options.name
      });

      const outputPath = path.join(outputDir, outputFilename);

      // Verify paths are generated correctly even when upload is disabled
      expect(outputDir).toMatch(/wusong[\/\\]resources[\/\\]characters$/);
      expect(outputFilename).toBe('C01_武松.png');

      // Verify upload would be skipped (options.upload === false)
      const shouldUpload = options.upload !== false;
      expect(shouldUpload).toBe(false);
    });
  });

  describe('Metadata and Image in Same Directory', () => {
    it('should save metadata in the same directory as the image', () => {
      const options = {
        project: 'wusong',
        category: 'characters',
        name: 'C01_武松',
        output: '/tmp'
      };

      // Generate output directory
      let outputDir = options.output || './output';
      if (options.project && options.category) {
        outputDir = generateOutputPath(outputDir, {
          project: options.project,
          category: options.category
        });
      }

      // Generate output filename
      const imageFilename = generateOutputFilename('txt2img', '.png', {
        project: options.project,
        category: options.category,
        name: options.name
      });

      // Generate metadata filename (replace extension with .json)
      const jsonFilename = imageFilename.replace(/\.[^.]+$/, '.json');
      const imagePath = path.join(outputDir, imageFilename);
      const metadataPath = path.join(outputDir, jsonFilename);

      // Verify both are in the same directory
      expect(path.dirname(imagePath)).toBe(path.dirname(metadataPath));
      expect(jsonFilename).toBe('C01_武松.json');
      expect(imagePath).toMatch(/wusong[\/\\]resources[\/\\]characters[\/\\]C01_武松\.png$/);
      expect(metadataPath).toMatch(/wusong[\/\\]resources[\/\\]characters[\/\\]C01_武松\.json$/);
    });

    it('should save metadata in same directory for default mode', () => {
      const mockDate = new Date('2026-03-31T14:25:30');
      jest.useFakeTimers().setSystemTime(mockDate);

      const options = { output: '/tmp' };

      let outputDir = options.output || './output';
      if (options.project && options.category) {
        outputDir = generateOutputPath(outputDir, {
          project: options.project,
          category: options.category
        });
      }

      const imageFilename = generateOutputFilename('txt2img', '.png', {
        project: options.project,
        category: options.category,
        name: options.name
      });

      const jsonFilename = imageFilename.replace(/\.[^.]+$/, '.json');
      const imagePath = path.join(outputDir, imageFilename);
      const metadataPath = path.join(outputDir, jsonFilename);

      expect(path.dirname(imagePath)).toBe(path.dirname(metadataPath));
      // Cross-platform: use path.join for expected paths (backslash on Windows)
      expect(imagePath).toBe(path.join('/tmp', 'txt2img_20260331_142530.png'));
      expect(metadataPath).toBe(path.join('/tmp', 'txt2img_20260331_142530.json'));

      jest.useRealTimers();
    });
  });

  describe('Multiple Files Upload Integration', () => {
    it('should upload both image and metadata files with project options', async () => {
      const options = {
        project: 'wusong',
        category: 'characters',
        name: 'C01_武松'
      };

      // Simulate generated files
      const downloadedFiles = ['/tmp/wusong/resources/characters/C01_武松.png'];
      const metadataPaths = ['/tmp/wusong/resources/characters/C01_武松.json'];
      const allFilesToUpload = [...downloadedFiles, ...metadataPaths];

      // Construct upload options
      const uploadOptions = {};
      if (options.project && options.category) {
        uploadOptions.project = options.project;
        uploadOptions.category = options.category;
      }

      const uploadResult = await mockUploader.uploadFiles(allFilesToUpload, uploadOptions);

      expect(mockUploader.uploadFiles.calledOnce).toBe(true);
      expect(mockUploader.uploadFiles.firstCall.args[0]).toHaveLength(2);
      expect(uploadResult.success).toBe(true);
    });

    it('should generate correct share URLs for all uploaded files', () => {
      const options = {
        project: 'wusong',
        category: 'characters'
      };

      const files = [
        { local: '/tmp/wusong/resources/characters/C01_武松.png', success: true },
        { local: '/tmp/wusong/resources/characters/C01_武松.json', success: true }
      ];

      const shareUrls = files.map(r => {
        const filename = path.basename(r.local);
        if (options.project && options.category) {
          return mockUploader.getProjectShareUrl(filename, options.project, options.category);
        }
        return mockUploader.getShareUrl(filename);
      });

      expect(shareUrls).toContain('http://47.109.205.195:10020/projects/wusong/characters/C01_武松.png');
      expect(shareUrls).toContain('http://47.109.205.195:10020/projects/wusong/characters/C01_武松.json');
    });
  });

  describe('Edge Cases', () => {
    it('should handle project with special characters', () => {
      const options = {
        project: 'my-project_v2',
        category: 'characters',
        name: 'hero',
        output: '/tmp'
      };

      let outputDir = options.output || './output';
      if (options.project && options.category) {
        outputDir = generateOutputPath(outputDir, {
          project: options.project,
          category: options.category
        });
      }

      const filename = generateOutputFilename('txt2img', '.png', {
        project: options.project,
        category: options.category,
        name: options.name
      });

      expect(outputDir).toContain('my-project_v2');
      expect(filename).toBe('hero.png');
    });

    it('should handle Chinese project and category names', () => {
      const options = {
        project: '水浒传',
        category: '人物',
        name: '武松',
        output: '/tmp'
      };

      let outputDir = options.output || './output';
      if (options.project && options.category) {
        outputDir = generateOutputPath(outputDir, {
          project: options.project,
          category: options.category
        });
      }

      const filename = generateOutputFilename('txt2img', '.png', {
        project: options.project,
        category: options.category,
        name: options.name
      });

      expect(outputDir).toContain('水浒传');
      expect(outputDir).toContain('人物');
      expect(filename).toBe('武松.png');
    });

    it('should handle relative output path with project options', () => {
      const options = {
        project: 'wusong',
        category: 'characters',
        name: 'C01_武松',
        output: './output'
      };

      let outputDir = options.output || './output';
      if (options.project && options.category) {
        outputDir = generateOutputPath(outputDir, {
          project: options.project,
          category: options.category
        });
      }

      expect(outputDir).toMatch(/output[\/\\]wusong[\/\\]resources[\/\\]characters$/);
    });
  });
});
