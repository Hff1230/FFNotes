import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import fs from 'fs';
import path from 'path';
import os from 'os';
import ConfigManager from '../../src/utils/config.js';

describe('img2img Integration - ConfigManager Interaction', () => {
  let tmpDir;

  beforeEach(() => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'comfycli-test-'));
  });

  afterEach(() => {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  // 202-1: 标准流程, 配置完整
  it('should load and provide server/upload config for img2img', () => {
    const comfyConfig = {
      prompts: {
        'test-i2i': {
          description: 'Test img2img',
          type: 'img2img',
          api: 'tests/fixtures/mock-api.json',
          data: []
        }
      }
    };
    const serverConfig = {
      host: 'img2img-server.com',
      port: 9020,
      api_key: 'img2img-key',
      upload: {
        server: 'upload.com:9998',
        user: 'admin',
        pwd: 'pass',
        dir: 'comfy'
      }
    };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify(serverConfig));

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    expect(cm.load()).toBe(true);

    const server = cm.getServerConfig();
    expect(server.host).toBe('img2img-server.com');
    expect(server.port).toBe(9020);

    const upload = cm.getUploadConfig();
    expect(upload).not.toBeNull();
    expect(upload.server).toBe('upload.com:9998');
  });

  // 202-2: 上传未配置, 优雅跳过
  it('should gracefully skip upload when not configured', () => {
    const comfyConfig = { prompts: {} };
    const serverConfig = { host: 'test.com', port: 8188 };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify(serverConfig));

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();

    const upload = cm.getUploadConfig();
    expect(upload).toBeNull();
  });

  // 202-3: 配置正确加载不影响图片处理
  it('should load config without affecting image processing parameters', () => {
    const comfyConfig = {
      prompts: {
        'test-i2i': {
          description: 'Test',
          type: 'img2img',
          api: 'tests/fixtures/mock-api.json',
          data: []
        }
      },
      resolution: {
        pic_gen: {
          '0': [{ name: 'low', width: 512, height: 512 }],
          '1': [{ name: 'low', width: 512, height: 768 }]
        }
      }
    };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));

    const cm = new ConfigManager(path.join(tmpDir, 'comfy_config.json'));
    cm.load();

    // Resolution should still work
    const res = cm.resolveResolution('low', '0', 'pic_gen');
    expect(res).toEqual({ width: 512, height: 512 });

    // Workflow should still be available
    const workflow = cm.getWorkflow('test-i2i');
    expect(workflow).not.toBeNull();
    expect(workflow.type).toBe('img2img');
  });
});
