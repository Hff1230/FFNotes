import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import fs from 'fs';
import path from 'path';
import os from 'os';
import ConfigManager from '../../src/utils/config.js';

describe('batch Integration - ConfigManager Interaction', () => {
  let tmpDir;

  beforeEach(() => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'comfycli-test-'));
  });

  afterEach(() => {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  // 204-1: 批量 txt2img 任务, 子命令正确接收配置
  it('should provide correct config for batch txt2img tasks', () => {
    const comfyConfig = {
      prompts: {
        'test-t2i': {
          description: 'Test txt2img',
          type: 'txt2img',
          api: 'tests/fixtures/mock-api.json',
          data: []
        }
      }
    };
    const serverConfig = {
      host: 'batch-server.com',
      port: 9030,
      api_key: 'batch-key',
      upload: {
        server: 'upload.com:9998',
        user: 'admin',
        pwd: 'pass',
        dir: 'comfy'
      }
    };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify(serverConfig));

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();

    // 验证子命令能获取正确的配置
    const server = cm.getServerConfig();
    expect(server.host).toBe('batch-server.com');
    expect(server.port).toBe(9030);
    expect(server.apiKey).toBe('batch-key');

    const upload = cm.getUploadConfig();
    expect(upload.server).toBe('upload.com:9998');
  });

  // 204-2: 混合命令类型, 不同命令正确使用各自的配置
  it('should support mixed command types with same config source', () => {
    const comfyConfig = {
      prompts: {
        'test-t2i': {
          description: 'Test txt2img',
          type: 'txt2img',
          api: 'tests/fixtures/mock-api.json',
          data: []
        },
        'test-i2i': {
          description: 'Test img2img',
          type: 'img2img',
          api: 'tests/fixtures/mock-api.json',
          data: []
        }
      }
    };
    const serverConfig = {
      host: 'mixed-server.com',
      port: 9040
    };
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(comfyConfig));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify(serverConfig));

    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();

    // txt2img workflow
    const t2i = cm.getWorkflow('test-t2i');
    expect(t2i.type).toBe('txt2img');

    // img2img workflow
    const i2i = cm.getWorkflow('test-i2i');
    expect(i2i.type).toBe('img2img');

    // Both use same server config
    const server = cm.getServerConfig();
    expect(server.host).toBe('mixed-server.com');

    // Both have no upload (server_config has no upload)
    const upload = cm.getUploadConfig();
    expect(upload).toBeNull();
  });
});
