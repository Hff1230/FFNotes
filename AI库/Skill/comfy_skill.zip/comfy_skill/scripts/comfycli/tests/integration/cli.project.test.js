/**
 * Integration tests for Commander.js CLI option parsing
 * Tests: --project, --category, --name options for txt2img command
 */
import { describe, it, expect, beforeEach } from '@jest/globals';
import { Command } from 'commander';

/**
 * Creates a test Commander program with txt2img command definition
 * Matches the definition in src/cli.js
 * @returns {Command} Configured Commander program
 */
function createTestProgram() {
  const program = new Command();

  program
    .name('comfycli')
    .description('CLI tool for ComfyUI workflow management')
    .version('1.0.0');

  // Text to Image command - matches src/cli.js definition
  program
    .command('txt2img')
    .description('Generate image from text prompt')
    .argument('<prompt>', 'Text prompt for image generation')
    .option('-n, --negative <text>', 'Negative prompt text')
    .option('-o, --output <path>', 'Output directory path', './output')
    .option('-c, --config <path>', 'Path to configuration file', './config/comfy_config.json')
    .option('-w, --workflow <name>', 'Workflow name (default: zimageturbot2i)', 'zimageturbot2i')
    .option('-s, --steps <number>', 'Sampling steps')
    .option('--cfg <number>', 'CFG scale')
    .option('--seed <number>', 'Random seed (default: random)')
    .option('--width <number>', 'Image width')
    .option('--height <number>', 'Image height')
    .option('-S, --size <alias>', 'Size preset alias (e.g. low/mid/high)')
    .option('--orientation <0|1>', 'Orientation: 0=landscape, 1=portrait (default: 0)', '0')
    .option('--upload', 'Upload generated files to dufs server (default: true)', true)
    .option('--no-upload', 'Skip uploading to dufs server', false)
    .option('--project <name>', 'Project name for organized output (e.g. wusong)')
    .option('--category <type>', 'Resource category (characters/tigers/scenes/props/videos/upscale)')
    .option('--name <name>', 'Resource name for filename (e.g. C01_武松_正面全身)');

  return program;
}

/**
 * Parses CLI arguments and returns captured action handler arguments
 * @param {string[]} args - CLI arguments to parse
 * @returns {Promise<{prompt: string, options: object}>} Captured arguments
 */
async function parseAndCapture(args) {
  const program = createTestProgram();
  let capturedPrompt = null;
  let capturedOptions = null;

  // Set up action handler to capture arguments
  program.commands[0].action((prompt, options) => {
    capturedPrompt = prompt;
    capturedOptions = options;
  });

  // Parse arguments using from:'node' since we provide [node, script, ...args]
  await program.parseAsync(['node', 'comfycli', ...args], { from: 'node' });

  return { prompt: capturedPrompt, options: capturedOptions };
}

describe('CLI txt2img project options parsing', () => {
  describe('complete options: --project --category --name', () => {
    it('should parse all project options correctly', async () => {
      const args = ['txt2img', 'a beautiful landscape', '--project', 'wusong', '--category', 'characters', '--name', 'C01_武松_正面全身'];
      const { prompt, options } = await parseAndCapture(args);

      expect(prompt).toBe('a beautiful landscape');
      expect(options.project).toBe('wusong');
      expect(options.category).toBe('characters');
      expect(options.name).toBe('C01_武松_正面全身');
    });

    it('should return string type for all project options', async () => {
      const args = ['txt2img', 'prompt', '--project', 'myproject', '--category', 'scenes', '--name', 'test'];
      const { options } = await parseAndCapture(args);

      expect(typeof options.project).toBe('string');
      expect(typeof options.category).toBe('string');
      expect(typeof options.name).toBe('string');
    });

    it('should handle various category values', async () => {
      const categories = ['characters', 'tigers', 'scenes', 'props', 'videos', 'upscale'];

      for (const category of categories) {
        const args = ['txt2img', 'prompt', '--project', 'game', '--category', category, '--name', 'resource1'];
        const { options } = await parseAndCapture(args);
        expect(options.category).toBe(category);
      }
    });
  });

  describe('partial options: --project --category (without --name)', () => {
    it('should parse project and category, name should be undefined', async () => {
      const args = ['txt2img', 'prompt', '--project', 'wusong', '--category', 'scenes'];
      const { prompt, options } = await parseAndCapture(args);

      expect(prompt).toBe('prompt');
      expect(options.project).toBe('wusong');
      expect(options.category).toBe('scenes');
      expect(options.name).toBeUndefined();
    });
  });

  describe('only project option', () => {
    it('should parse project only, category and name should be undefined', async () => {
      const args = ['txt2img', 'prompt', '--project', 'wusong'];
      const { prompt, options } = await parseAndCapture(args);

      expect(prompt).toBe('prompt');
      expect(options.project).toBe('wusong');
      expect(options.category).toBeUndefined();
      expect(options.name).toBeUndefined();
    });
  });

  describe('no project options', () => {
    it('should have undefined project/category/name when not provided', async () => {
      const args = ['txt2img', 'prompt'];
      const { prompt, options } = await parseAndCapture(args);

      expect(prompt).toBe('prompt');
      expect(options.project).toBeUndefined();
      expect(options.category).toBeUndefined();
      expect(options.name).toBeUndefined();
    });

    it('should have default values for other options', async () => {
      const args = ['txt2img', 'prompt'];
      const { options } = await parseAndCapture(args);

      expect(options.output).toBe('./output');
      expect(options.config).toBe('./config/comfy_config.json');
      expect(options.workflow).toBe('zimageturbot2i');
      expect(options.orientation).toBe('0');
    });
  });

  describe('Chinese name support', () => {
    it('should handle Chinese characters in name option', async () => {
      const args = ['txt2img', 'prompt', '--name', 'C01_武松_正面全身'];
      const { options } = await parseAndCapture(args);

      expect(options.name).toBe('C01_武松_正面全身');
    });

    it('should handle full Chinese name', async () => {
      const args = ['txt2img', 'prompt', '--name', '角色名称测试'];
      const { options } = await parseAndCapture(args);

      expect(options.name).toBe('角色名称测试');
    });

    it('should handle Chinese in project/category/name combination', async () => {
      const args = ['txt2img', 'prompt', '--project', '项目名', '--category', 'characters', '--name', '角色_测试'];
      const { options } = await parseAndCapture(args);

      expect(options.project).toBe('项目名');
      expect(options.category).toBe('characters');
      expect(options.name).toBe('角色_测试');
    });
  });

  describe('combined options: project with other options', () => {
    it('should parse --project with --output', async () => {
      const args = ['txt2img', 'prompt', '--project', 'wusong', '--output', '/tmp/test'];
      const { options } = await parseAndCapture(args);

      expect(options.project).toBe('wusong');
      expect(options.output).toBe('/tmp/test');
    });

    it('should parse --project with --workflow', async () => {
      const args = ['txt2img', 'prompt', '--project', 'wusong', '--workflow', 'custom_workflow'];
      const { options } = await parseAndCapture(args);

      expect(options.project).toBe('wusong');
      expect(options.workflow).toBe('custom_workflow');
    });

    it('should parse --project with --steps', async () => {
      const args = ['txt2img', 'prompt', '--project', 'wusong', '--steps', '30'];
      const { options } = await parseAndCapture(args);

      expect(options.project).toBe('wusong');
      expect(options.steps).toBe('30');
    });
  });

  describe('project options with --no-upload', () => {
    it('should parse --project --category --name with --no-upload', async () => {
      const args = ['txt2img', 'prompt', '--project', 'wusong', '--category', 'characters', '--name', 'hero', '--no-upload'];
      const { options } = await parseAndCapture(args);

      expect(options.project).toBe('wusong');
      expect(options.category).toBe('characters');
      expect(options.name).toBe('hero');
      expect(options.upload).toBe(false);
    });

    it('should have upload=true by default', async () => {
      const args = ['txt2img', 'prompt', '--project', 'wusong'];
      const { options } = await parseAndCapture(args);

      expect(options.upload).toBe(true);
    });

    it('should parse --project with --no-upload', async () => {
      const args = ['txt2img', 'prompt', '--project', 'wusong', '--no-upload'];
      const { options } = await parseAndCapture(args);

      expect(options.project).toBe('wusong');
      expect(options.upload).toBe(false);
    });

    it('should parse all project options with --no-upload and other options', async () => {
      const args = ['txt2img', 'prompt', '--project', 'wusong', '--category', 'scenes', '--name', 'scene1', '--no-upload', '--output', '/custom/output'];
      const { options } = await parseAndCapture(args);

      expect(options.project).toBe('wusong');
      expect(options.category).toBe('scenes');
      expect(options.name).toBe('scene1');
      expect(options.upload).toBe(false);
      expect(options.output).toBe('/custom/output');
    });
  });

  describe('option order independence', () => {
    it('should parse options in any order (order 1)', async () => {
      const args = ['txt2img', 'prompt', '--project', 'wusong', '--category', 'characters', '--name', 'hero'];
      const { options } = await parseAndCapture(args);

      expect(options.project).toBe('wusong');
      expect(options.category).toBe('characters');
      expect(options.name).toBe('hero');
    });

    it('should parse options in any order (order 2)', async () => {
      const args = ['txt2img', 'prompt', '--name', 'hero', '--project', 'wusong', '--category', 'characters'];
      const { options } = await parseAndCapture(args);

      expect(options.project).toBe('wusong');
      expect(options.category).toBe('characters');
      expect(options.name).toBe('hero');
    });

    it('should parse options in any order (order 3)', async () => {
      const args = ['txt2img', 'prompt', '--category', 'characters', '--name', 'hero', '--project', 'wusong'];
      const { options } = await parseAndCapture(args);

      expect(options.project).toBe('wusong');
      expect(options.category).toBe('characters');
      expect(options.name).toBe('hero');
    });
  });

  describe('edge cases', () => {
    it('should handle prompt with spaces', async () => {
      const args = ['txt2img', 'a beautiful landscape with mountains', '--project', 'wusong'];
      const { prompt, options } = await parseAndCapture(args);

      expect(prompt).toBe('a beautiful landscape with mountains');
      expect(options.project).toBe('wusong');
    });

    it('should handle special characters in name', async () => {
      const args = ['txt2img', 'prompt', '--name', 'scene_v1_final'];
      const { options } = await parseAndCapture(args);

      expect(options.name).toBe('scene_v1_final');
    });

    it('should handle hyphenated project name', async () => {
      const args = ['txt2img', 'prompt', '--project', 'my-project-name'];
      const { options } = await parseAndCapture(args);

      expect(options.project).toBe('my-project-name');
    });

    it('should handle numeric values in strings', async () => {
      const args = ['txt2img', 'prompt', '--project', 'project2', '--name', 'C01_character'];
      const { options } = await parseAndCapture(args);

      expect(options.project).toBe('project2');
      expect(options.name).toBe('C01_character');
    });
  });

  describe('short option aliases', () => {
    it('should parse -o (output) with project options', async () => {
      const args = ['txt2img', 'prompt', '--project', 'wusong', '-o', '/tmp/out'];
      const { options } = await parseAndCapture(args);

      expect(options.project).toBe('wusong');
      expect(options.output).toBe('/tmp/out');
    });

    it('should parse -c (config) with project options', async () => {
      const args = ['txt2img', 'prompt', '--project', 'wusong', '-c', './custom_config.json'];
      const { options } = await parseAndCapture(args);

      expect(options.project).toBe('wusong');
      expect(options.config).toBe('./custom_config.json');
    });

    it('should parse -w (workflow) with project options', async () => {
      const args = ['txt2img', 'prompt', '--project', 'wusong', '-w', 'custom'];
      const { options } = await parseAndCapture(args);

      expect(options.project).toBe('wusong');
      expect(options.workflow).toBe('custom');
    });

    it('should parse -n (negative) with project options', async () => {
      const args = ['txt2img', 'prompt', '--project', 'wusong', '-n', 'ugly, bad'];
      const { options } = await parseAndCapture(args);

      expect(options.project).toBe('wusong');
      expect(options.negative).toBe('ugly, bad');
    });

    it('should parse -S (size) with project options', async () => {
      const args = ['txt2img', 'prompt', '--project', 'wusong', '-S', 'high'];
      const { options } = await parseAndCapture(args);

      expect(options.project).toBe('wusong');
      expect(options.size).toBe('high');
    });
  });
});
