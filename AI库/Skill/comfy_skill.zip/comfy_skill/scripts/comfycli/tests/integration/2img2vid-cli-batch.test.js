/**
 * Integration tests for CLI + Batch 2img2video functionality
 * TC-601: CLI command registration
 * TC-602: CLI dual-image argument parsing
 * TC-603: Batch 2img2video dispatch
 */
import { describe, it, expect, beforeEach, afterEach, jest } from '@jest/globals';
import { Command } from 'commander';
import { execFile } from 'child_process';
import { promisify } from 'util';
import path from 'path';
import { fileURLToPath } from 'url';

const execFileAsync = promisify(execFile);

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PROJECT_ROOT = path.resolve(__dirname, '../..');
const SRC = (rel) => path.resolve(PROJECT_ROOT, 'src', rel);

// ---------------------------------------------------------------------------
// Helper: create a Commander program matching src/cli.js 2img2vid definition
// ---------------------------------------------------------------------------
function create2Img2VidTestProgram() {
  const program = new Command();
  program
    .name('comfycli')
    .description('CLI tool for ComfyUI workflow management')
    .version('1.0.0');

  program
    .command('2img2vid')
    .description('Generate video from two images (first frame + last frame)')
    .argument('<image1>', 'First input image path (first frame)')
    .argument('<image2>', 'Second input image path (last frame)')
    .option('-p, --prompt <text>', 'Text prompt for video generation')
    .option('-n, --negative <text>', 'Negative prompt text')
    .option('-o, --output <path>', 'Output directory path', './output')
    .option('-c, --config <path>', 'Path to configuration file', './config/comfy_config.json')
    .option('-w, --workflow <name>', 'Workflow name (default: ltx2img2vid)', 'ltx2img2vid')
    .option('-f, --format <format>', 'Output format (mp4/gif)', 'mp4')
    .option('--fps <number>', 'Frame rate')
    .option('--frames <number>', 'Total number of frames')
    .option('--steps <number>', 'Sampling steps')
    .option('--cfg <number>', 'CFG scale')
    .option('--seed <number>', 'Random seed (default: random)')
    .option('--width <number>', 'Video width')
    .option('--height <number>', 'Video height')
    .option('-S, --size <alias>', 'Size preset alias (e.g. low/mid/high)')
    .option('--orientation <0|1>', 'Orientation: 0=landscape, 1=portrait (default: 0)', '0')
    .option('--upload', 'Upload generated files to dufs server (default: true)', true)
    .option('--no-upload', 'Skip uploading to dufs server', false);

  return program;
}

/**
 * Parses 2img2vid CLI arguments and returns captured action handler arguments.
 * @param {string[]} args - Arguments after 'node comfycli' prefix
 * @returns {Promise<{image1: string, image2: string, options: object}>}
 */
async function parse2Img2VidAndCapture(args) {
  const program = create2Img2VidTestProgram();
  let captured = { image1: null, image2: null, options: null };

  program.commands[0].action((image1, image2, options) => {
    captured = { image1, image2, options };
  });

  await program.parseAsync(['node', 'comfycli', ...args], { from: 'node' });
  return captured;
}

// ============================================================================
// TC-601: CLI command registration
// ============================================================================
describe('TC-601: CLI command registration', () => {
  describe('TC-601-01: --help lists 2img2vid command', () => {
    it('should list 2img2vid in top-level --help output', async () => {
      const indexJs = SRC('index.js');
      const { stdout } = await execFileAsync('node', [indexJs, '--help'], {
        timeout: 15000,
      });
      expect(stdout).toContain('2img2vid');
    });
  });

  describe('TC-601-02: 2img2vid --help shows correct options', () => {
    it('should display image1, image2 arguments and key options', async () => {
      const indexJs = SRC('index.js');
      const { stdout } = await execFileAsync('node', [indexJs, '2img2vid', '--help'], {
        timeout: 15000,
      });

      // Positional arguments
      expect(stdout).toContain('image1');
      expect(stdout).toContain('image2');

      // Key options
      expect(stdout).toContain('--prompt');
      expect(stdout).toContain('--format');
      expect(stdout).toContain('--workflow');
      expect(stdout).toContain('--output');
      expect(stdout).toContain('--fps');
      expect(stdout).toContain('--frames');
      expect(stdout).toContain('--steps');
      expect(stdout).toContain('--cfg');
      expect(stdout).toContain('--seed');
      expect(stdout).toContain('--width');
      expect(stdout).toContain('--height');
    });
  });

  describe('TC-601-03: does not contain --motion option', () => {
    it('should not list --motion as an option for 2img2vid', async () => {
      const indexJs = SRC('index.js');
      const { stdout } = await execFileAsync('node', [indexJs, '2img2vid', '--help'], {
        timeout: 15000,
      });

      // --motion is NOT a 2img2vid option (it is only on img2vid)
      expect(stdout).not.toContain('--motion');
    });
  });
});

// ============================================================================
// TC-602: CLI dual-image argument parsing
// ============================================================================
describe('TC-602: CLI dual-image argument parsing', () => {
  describe('TC-602-01: two positional arguments passed correctly', () => {
    it('should capture image1 and image2 as positional arguments', async () => {
      const result = await parse2Img2VidAndCapture([
        '2img2vid', 'img1.png', 'img2.png',
      ]);

      expect(result.image1).toBe('img1.png');
      expect(result.image2).toBe('img2.png');
    });
  });

  describe('TC-602-02: --prompt option is passed', () => {
    it('should capture the --prompt option value', async () => {
      const result = await parse2Img2VidAndCapture([
        '2img2vid', 'img1.png', 'img2.png',
        '--prompt', 'a smooth camera pan',
      ]);

      expect(result.image1).toBe('img1.png');
      expect(result.image2).toBe('img2.png');
      expect(result.options.prompt).toBe('a smooth camera pan');
    });
  });

  describe('TC-602-03: --workflow defaults to ltx2img2vid', () => {
    it('should have workflow default value of ltx2img2vid', async () => {
      const result = await parse2Img2VidAndCapture([
        '2img2vid', 'img1.png', 'img2.png',
      ]);

      expect(result.options.workflow).toBe('ltx2img2vid');
    });
  });

  describe('TC-602-04: --format option is passed', () => {
    it('should capture the --format option value', async () => {
      const result = await parse2Img2VidAndCapture([
        '2img2vid', 'img1.png', 'img2.png',
        '--format', 'gif',
      ]);

      expect(result.options.format).toBe('gif');
    });
  });

  describe('TC-602-05: only one argument causes Commander error', () => {
    it('should throw when only one positional argument is provided', async () => {
      const program = create2Img2VidTestProgram();
      const subCommand = program.commands[0];

      subCommand.action(() => {});
      // exitOverride must be set on both the root program and the sub-command
      // because Commander sub-commands have their own _exit method
      program.exitOverride();
      subCommand.exitOverride();

      await expect(
        program.parseAsync(['node', 'comfycli', '2img2vid', 'only_one.png'], { from: 'node' })
      ).rejects.toThrow('missing required argument');
    });
  });
});

// ============================================================================
// TC-603: Batch 2img2video dispatch
// ============================================================================
describe('TC-603: Batch 2img2video dispatch', () => {
  let batchModule;
  let img2vid2Mock;

  beforeEach(async () => {
    jest.resetModules();

    // Mock all command modules imported by batch.js
    img2vid2Mock = jest.fn().mockResolvedValue({ files: ['/output/video.mp4'] });

    jest.unstable_mockModule(SRC('commands/2img2vid.js'), () => ({
      img2vid2Command: img2vid2Mock,
      default: img2vid2Mock,
    }));
    jest.unstable_mockModule(SRC('commands/txt2img.js'), () => ({
      txt2imgCommand: jest.fn().mockResolvedValue({ files: [] }),
      default: jest.fn().mockResolvedValue({ files: [] }),
    }));
    jest.unstable_mockModule(SRC('commands/img2img.js'), () => ({
      img2imgCommand: jest.fn().mockResolvedValue({ files: [] }),
      default: jest.fn().mockResolvedValue({ files: [] }),
    }));
    jest.unstable_mockModule(SRC('commands/txt2vid.js'), () => ({
      txt2vidCommand: jest.fn().mockResolvedValue({ files: [] }),
      default: jest.fn().mockResolvedValue({ files: [] }),
    }));
    jest.unstable_mockModule(SRC('commands/img2vid.js'), () => ({
      img2vidCommand: jest.fn().mockResolvedValue({ files: [] }),
      default: jest.fn().mockResolvedValue({ files: [] }),
    }));
    jest.unstable_mockModule(SRC('commands/imagescale.js'), () => ({
      imagescaleCommand: jest.fn().mockResolvedValue({ files: [] }),
      default: jest.fn().mockResolvedValue({ files: [] }),
    }));

    batchModule = await import(SRC('commands/batch.js'));
  });

  afterEach(() => {
    jest.restoreAllMocks();
    jest.resetModules();
  });

  describe('TC-603-01: 2img2video type dispatches to img2vid2Command', () => {
    it('should route 2img2video type to img2vid2Command via executeTask', async () => {
      const { executeTask } = batchModule;

      const task = {
        type: '2img2video',
        image: 'first.png, second.png',
        prompt: 'test prompt',
      };
      const globalOptions = { output: '/batch-output' };

      await executeTask(task, globalOptions);

      // Verify img2vid2Command was called (not any other command mock)
      expect(img2vid2Mock).toHaveBeenCalledTimes(1);
      // Verify positional arguments: two images split from comma-separated string
      expect(img2vid2Mock).toHaveBeenCalledWith(
        'first.png',
        'second.png',
        expect.objectContaining({
          prompt: 'test prompt',
          output: '/batch-output',
          _batchMode: true,
        })
      );
    });

    it('should export map2Img2VideoArgs that produces correct positional args', () => {
      const { map2Img2VideoArgs } = batchModule;

      const task = {
        type: '2img2video',
        image: 'a.png,b.png',
        prompt: 'test',
      };
      const globalOptions = {};

      const result = map2Img2VideoArgs(task, globalOptions);

      // Should produce two positional args split from the comma-separated image field
      expect(result.positional).toEqual(['a.png', 'b.png']);
      expect(result.options.prompt).toBe('test');
      expect(result.options._batchMode).toBe(true);
    });
  });

  describe('TC-603-02: comma-separated image paths correctly passed', () => {
    it('should split comma-separated image field into image1 and image2', async () => {
      const { executeTask } = batchModule;

      const task = {
        type: '2img2video',
        image: '  /path/to/img1.jpg  ,  /path/to/img2.jpg  ',
        prompt: 'pan left',
      };
      const globalOptions = {};

      await executeTask(task, globalOptions);

      // map2Img2VideoArgs trims whitespace after splitting
      expect(img2vid2Mock).toHaveBeenCalledWith(
        '/path/to/img1.jpg',
        '/path/to/img2.jpg',
        expect.objectContaining({ prompt: 'pan left' })
      );
    });
  });

  describe('TC-603-03: all options correctly passed', () => {
    it('should pass all supported options from task to command', async () => {
      const { executeTask } = batchModule;

      const task = {
        type: '2img2video',
        image: 'a.png,b.png',
        prompt: 'zoom in',
        negative: 'blurry',
        workflow: 'custom_wf',
        format: 'gif',
        fps: '30',
        frames: '60',
        steps: '20',
        cfg: '7',
        seed: '42',
        width: '512',
        height: '512',
        size: 'mid',
        orientation: '1',
      };
      const globalOptions = { output: '/global-out', config: '/global-cfg.json' };

      await executeTask(task, globalOptions);

      expect(img2vid2Mock).toHaveBeenCalledWith(
        'a.png',
        'b.png',
        expect.objectContaining({
          prompt: 'zoom in',
          negative: 'blurry',
          output: '/global-out',
          config: '/global-cfg.json',
          workflow: 'custom_wf',
          format: 'gif',
          fps: '30',
          frames: '60',
          steps: '20',
          cfg: '7',
          seed: '42',
          width: '512',
          height: '512',
          size: 'mid',
          orientation: '1',
          _batchMode: true,
        })
      );
    });
  });

  describe('TC-603-04: unsupported type causes error', () => {
    it('should throw for an unsupported task type in validateTasks', () => {
      const { validateTasks } = batchModule;

      const tasks = [
        { type: 'unsupported_type', prompt: 'test' },
      ];

      expect(() => validateTasks(tasks)).toThrow('unsupported type "unsupported_type"');
    });

    it('should throw for an unsupported type in executeTask', async () => {
      const { executeTask } = batchModule;

      await expect(
        executeTask({ type: 'bogus' }, {})
      ).rejects.toThrow('Unknown task type: bogus');
    });
  });
});
