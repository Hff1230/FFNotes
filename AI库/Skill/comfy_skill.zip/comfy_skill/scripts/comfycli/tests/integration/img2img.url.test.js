/**
 * Integration tests for img2img.js validateImages function
 * Tests: URL download integration with image validation
 *
 * Test Cases:
 * - I001: Single URL input (P0)
 * - I002: Multiple URL inputs (P0)
 * - I003: Mixed local and URL inputs (P0)
 * - I004: URL download failure (P0)
 * - I005: Unsupported format (P1)
 * - I006: 4 image processing (P1)
 * - I007: More than 4 images (P1)
 * - I008: Console output for URL download (P1)
 */
import { describe, it, expect, beforeEach, afterEach, jest } from '@jest/globals';
import fs from 'fs';
import path from 'path';

// Import the functions we need to test
// Note: We need to extract validateImages from the module
// Since it's not exported, we'll test via the resource_downloader integration

const originalFetch = global.fetch;

// Test constants
const TEST_TMP_DIR = './tests/fixtures/tmp-img2img-test';
const TEST_LOCAL_DIR = './tests/fixtures/local-images';

// Helper to create mock image data (valid PNG)
function createMockImageData() {
  // Minimal valid PNG header + data
  return Buffer.from([
    0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, // PNG signature
    0x00, 0x00, 0x00, 0x0D, // IHDR length
    0x49, 0x48, 0x44, 0x52, // IHDR
    0x00, 0x00, 0x00, 0x01, // width: 1
    0x00, 0x00, 0x00, 0x01, // height: 1
    0x08, 0x02, // bit depth, color type
    0x00, 0x00, 0x00, // compression, filter, interlace
    0x90, 0x77, 0x53, 0xDE, // CRC
    0x00, 0x00, 0x00, 0x00, // IEND length
    0x49, 0x45, 0x4E, 0x44, // IEND
    0xAE, 0x42, 0x60, 0x82  // CRC
  ]);
}

// Helper to create mock JPEG data
function createMockJpegData() {
  // Minimal JPEG header
  return Buffer.from([
    0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46,
    0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01,
    0x00, 0x01, 0x00, 0x00, 0xFF, 0xD9
  ]);
}

// Helper to create mock WebP data
function createMockWebPData() {
  return Buffer.from('RIFF....WEBP');
}

// Helper to create mock GIF data (unsupported)
function createMockGifData() {
  return Buffer.from('GIF89a');
}

// Helper to create mock fetch response
function createMockResponse(data, status = 200, statusText = 'OK') {
  return {
    ok: status >= 200 && status < 300,
    status,
    statusText,
    arrayBuffer: async () => {
      if (Buffer.isBuffer(data)) {
        return data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
      }
      return Buffer.from(data).buffer;
    }
  };
}

// Mock fetch responses map
let mockResponses = new Map();

// Setup mock fetch for a specific URL
function setupMockFetch(url, response) {
  mockResponses.set(url, response);
  global.fetch = async (requestUrl) => {
    const response = mockResponses.get(requestUrl);
    if (response) return response;
    return createMockResponse('Not Found', 404, 'Not Found');
  };
}

// Setup multiple mock responses
function setupMultipleMockFetches(urlResponseMap) {
  for (const [url, response] of Object.entries(urlResponseMap)) {
    mockResponses.set(url, response);
  }
  global.fetch = async (requestUrl) => {
    const response = mockResponses.get(requestUrl);
    if (response) return response;
    return createMockResponse('Not Found', 404, 'Not Found');
  };
}

// Restore original fetch
function restoreFetch() {
  global.fetch = originalFetch;
  mockResponses.clear();
}

// Cleanup helper
function cleanupDir(dirPath) {
  if (fs.existsSync(dirPath)) {
    const files = fs.readdirSync(dirPath);
    for (const file of files) {
      const filePath = path.join(dirPath, file);
      if (fs.lstatSync(filePath).isDirectory()) {
        cleanupDir(filePath);
      } else {
        fs.unlinkSync(filePath);
      }
    }
    fs.rmdirSync(dirPath);
  }
}

// Create local test image files
function createLocalTestImage(filename, data = createMockImageData()) {
  if (!fs.existsSync(TEST_LOCAL_DIR)) {
    fs.mkdirSync(TEST_LOCAL_DIR, { recursive: true });
  }
  const filePath = path.join(TEST_LOCAL_DIR, filename);
  fs.writeFileSync(filePath, data);
  return filePath;
}

// Supported formats (must match img2img.js)
const SUPPORTED_FORMATS = ['.png', '.jpg', '.jpeg', '.webp'];
const MAX_IMAGES = 4;

// Import the validateImages-like function for testing
// Since validateImages is not exported, we'll create a test version
// that replicates the same logic using the exported resource_downloader
async function testValidateImages(imagePaths, tmpDir = TEST_TMP_DIR) {
  const resourceDownloader = await import('../../src/utils/resource_downloader.js');
  const resolveInputResources = resourceDownloader.default.resolveInputResources;

  const errors = [];
  const validPaths = [];
  const missingFiles = [];
  const unsupportedFormats = [];

  // First, resolve any URL inputs by downloading them
  const resolvedInputs = await resolveInputResources(imagePaths, tmpDir);

  for (let i = 0; i < imagePaths.length; i++) {
    const imageInput = imagePaths[i];
    const localPath = resolvedInputs.localPaths[i];
    const resolvedPath = path.resolve(localPath);

    // Check file exists
    if (!fs.existsSync(resolvedPath)) {
      missingFiles.push(imageInput);
      continue;
    }

    // Check format
    const ext = path.extname(resolvedPath).toLowerCase();
    if (!SUPPORTED_FORMATS.includes(ext)) {
      unsupportedFormats.push({ path: imageInput, format: ext });
      continue;
    }

    validPaths.push(resolvedPath);
  }

  // Build error messages
  if (missingFiles.length > 0) {
    errors.push(`Image files not found:\n  ${missingFiles.map(p => `- ${p}`).join('\n  ')}`);
  }

  if (unsupportedFormats.length > 0) {
    errors.push(`Unsupported image formats:\n  ${unsupportedFormats.map(f => `- ${f.path} (${f.format})`).join('\n  ')}\n  Supported formats: ${SUPPORTED_FORMATS.join(', ')}`);
  }

  return {
    valid: errors.length === 0,
    errors,
    validPaths
  };
}

describe('img2img validateImages URL Integration', () => {
  beforeEach(() => {
    // Ensure clean state
    cleanupDir(TEST_TMP_DIR);
    cleanupDir(TEST_LOCAL_DIR);
    mockResponses.clear();

    // Create local test directory
    if (!fs.existsSync(TEST_LOCAL_DIR)) {
      fs.mkdirSync(TEST_LOCAL_DIR, { recursive: true });
    }
  });

  afterEach(() => {
    // Cleanup after each test
    restoreFetch();
    cleanupDir(TEST_TMP_DIR);
    cleanupDir(TEST_LOCAL_DIR);
  });

  // ============================================================
  // I001: Single URL input (P0)
  // ============================================================
  describe('I001 - Single URL input', () => {
    it('should download and validate single URL successfully', async () => {
      const url = 'http://example.com/single.jpg';
      const mockData = createMockJpegData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await testValidateImages([url]);

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
      expect(result.validPaths).toHaveLength(1);
      expect(result.validPaths[0]).toContain('single.jpg');
      expect(fs.existsSync(result.validPaths[0])).toBe(true);
    });

    it('should handle PNG URL download', async () => {
      const url = 'http://example.com/image.png';
      const mockData = createMockImageData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await testValidateImages([url]);

      expect(result.valid).toBe(true);
      expect(result.validPaths[0]).toContain('image.png');
    });

    it('should handle WebP URL download', async () => {
      const url = 'http://example.com/photo.webp';
      const mockData = createMockWebPData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await testValidateImages([url]);

      expect(result.valid).toBe(true);
      expect(result.validPaths[0]).toContain('photo.webp');
    });
  });

  // ============================================================
  // I002: Multiple URL inputs (P0)
  // ============================================================
  describe('I002 - Multiple URL inputs', () => {
    it('should download and validate two URLs successfully', async () => {
      const urls = ['http://a.com/1.jpg', 'http://b.com/2.jpg'];
      const mockData = createMockJpegData();

      setupMultipleMockFetches({
        'http://a.com/1.jpg': createMockResponse(mockData),
        'http://b.com/2.jpg': createMockResponse(mockData)
      });

      const result = await testValidateImages(urls);

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
      expect(result.validPaths).toHaveLength(2);
      expect(result.validPaths[0]).toContain('1.jpg');
      expect(result.validPaths[1]).toContain('2.jpg');
    });

    it('should download and validate three URLs successfully', async () => {
      const urls = [
        'http://example.com/first.png',
        'http://example.com/second.jpg',
        'http://example.com/third.webp'
      ];
      const mockData = createMockImageData();

      setupMultipleMockFetches({
        'http://example.com/first.png': createMockResponse(mockData),
        'http://example.com/second.jpg': createMockResponse(createMockJpegData()),
        'http://example.com/third.webp': createMockResponse(createMockWebPData())
      });

      const result = await testValidateImages(urls);

      expect(result.valid).toBe(true);
      expect(result.validPaths).toHaveLength(3);
    });
  });

  // ============================================================
  // I003: Mixed local and URL inputs (P0)
  // ============================================================
  describe('I003 - Mixed local and URL inputs', () => {
    it('should handle URL and local file combination', async () => {
      const localFile = createLocalTestImage('local.png');
      const url = 'http://example.com/remote.jpg';

      setupMockFetch(url, createMockResponse(createMockJpegData()));

      const result = await testValidateImages([url, localFile]);

      expect(result.valid).toBe(true);
      expect(result.validPaths).toHaveLength(2);
      // First should be downloaded URL
      expect(result.validPaths[0]).toContain('remote.jpg');
      // Second should be local file
      expect(result.validPaths[1]).toContain('local.png');
    });

    it('should handle local file first, then URL', async () => {
      const localFile = createLocalTestImage('first.png');
      const url = 'http://example.com/second.jpg';

      setupMockFetch(url, createMockResponse(createMockJpegData()));

      const result = await testValidateImages([localFile, url]);

      expect(result.valid).toBe(true);
      expect(result.validPaths).toHaveLength(2);
      expect(result.validPaths[0]).toContain('first.png');
      expect(result.validPaths[1]).toContain('second.jpg');
    });

    it('should handle multiple local files and URLs', async () => {
      const localFile1 = createLocalTestImage('local1.jpg');
      const localFile2 = createLocalTestImage('local2.png');
      const url1 = 'http://a.com/remote1.jpg';
      const url2 = 'http://b.com/remote2.png';

      setupMultipleMockFetches({
        'http://a.com/remote1.jpg': createMockResponse(createMockJpegData()),
        'http://b.com/remote2.png': createMockResponse(createMockImageData())
      });

      const result = await testValidateImages([localFile1, url1, localFile2, url2]);

      expect(result.valid).toBe(true);
      expect(result.validPaths).toHaveLength(4);
    });
  });

  // ============================================================
  // I004: URL download failure (P0)
  // ============================================================
  describe('I004 - URL download failure', () => {
    it('should fail validation when URL returns 404', async () => {
      const url = 'http://example.com/notfound.jpg';

      setupMockFetch(url, createMockResponse('Not Found', 404, 'Not Found'));

      // resolveInputResources throws on HTTP errors
      await expect(testValidateImages([url]))
        .rejects.toThrow('Failed to download resource: HTTP 404');
    });

    it('should fail validation when URL returns 403', async () => {
      const url = 'http://example.com/forbidden.jpg';

      setupMockFetch(url, createMockResponse('Forbidden', 403, 'Forbidden'));

      await expect(testValidateImages([url]))
        .rejects.toThrow('Failed to download resource: HTTP 403');
    });

    it('should fail validation when URL returns 500', async () => {
      const url = 'http://example.com/server-error.jpg';

      setupMockFetch(url, createMockResponse('Server Error', 500, 'Internal Server Error'));

      await expect(testValidateImages([url]))
        .rejects.toThrow('Failed to download resource: HTTP 500');
    });

    it('should handle network error', async () => {
      const url = 'http://example.com/network-error.jpg';

      global.fetch = async () => {
        throw new Error('Network error');
      };

      await expect(testValidateImages([url]))
        .rejects.toThrow('Network error');
    });
  });

  // ============================================================
  // I005: Unsupported format (P1)
  // ============================================================
  describe('I005 - Unsupported format', () => {
    it('should fail validation for GIF format', async () => {
      const url = 'http://example.com/animation.gif';
      const mockData = createMockGifData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await testValidateImages([url]);

      expect(result.valid).toBe(false);
      expect(result.errors[0]).toContain('Unsupported image formats');
      expect(result.errors[0]).toContain('.gif');
      expect(result.validPaths).toHaveLength(0);
    });

    it('should fail validation for BMP format', async () => {
      const url = 'http://example.com/image.bmp';
      const mockData = Buffer.from('BM...');

      setupMockFetch(url, createMockResponse(mockData));

      const result = await testValidateImages([url]);

      expect(result.valid).toBe(false);
      expect(result.errors[0]).toContain('.bmp');
    });

    it('should fail validation for TIFF format', async () => {
      const url = 'http://example.com/photo.tiff';
      const mockData = Buffer.from('TIFF...');

      setupMockFetch(url, createMockResponse(mockData));

      const result = await testValidateImages([url]);

      expect(result.valid).toBe(false);
      expect(result.errors[0]).toContain('.tiff');
    });

    it('should handle mixed valid and unsupported formats', async () => {
      const validUrl = 'http://example.com/valid.jpg';
      const invalidUrl = 'http://example.com/invalid.gif';

      setupMultipleMockFetches({
        'http://example.com/valid.jpg': createMockResponse(createMockJpegData()),
        'http://example.com/invalid.gif': createMockResponse(createMockGifData())
      });

      const result = await testValidateImages([validUrl, invalidUrl]);

      expect(result.valid).toBe(false);
      expect(result.validPaths).toHaveLength(1); // Only the valid one
      expect(result.validPaths[0]).toContain('valid.jpg');
      expect(result.errors[0]).toContain('Unsupported');
    });
  });

  // ============================================================
  // I006: 4 image processing (P1)
  // ============================================================
  describe('I006 - 4 image processing', () => {
    it('should successfully process 4 URLs', async () => {
      const urls = [
        'http://a.com/1.jpg',
        'http://b.com/2.jpg',
        'http://c.com/3.jpg',
        'http://d.com/4.jpg'
      ];

      setupMultipleMockFetches({
        'http://a.com/1.jpg': createMockResponse(createMockJpegData()),
        'http://b.com/2.jpg': createMockResponse(createMockJpegData()),
        'http://c.com/3.jpg': createMockResponse(createMockJpegData()),
        'http://d.com/4.jpg': createMockResponse(createMockJpegData())
      });

      const result = await testValidateImages(urls);

      expect(result.valid).toBe(true);
      expect(result.validPaths).toHaveLength(4);
    });

    it('should successfully process 4 mixed inputs (2 local + 2 URL)', async () => {
      const localFile1 = createLocalTestImage('local1.jpg');
      const localFile2 = createLocalTestImage('local2.png');
      const url1 = 'http://a.com/remote1.jpg';
      const url2 = 'http://b.com/remote2.png';

      setupMultipleMockFetches({
        'http://a.com/remote1.jpg': createMockResponse(createMockJpegData()),
        'http://b.com/remote2.png': createMockResponse(createMockImageData())
      });

      const result = await testValidateImages([localFile1, url1, localFile2, url2]);

      expect(result.valid).toBe(true);
      expect(result.validPaths).toHaveLength(4);
    });
  });

  // ============================================================
  // I007: More than 4 images (P1)
  // ============================================================
  describe('I007 - More than 4 images validation', () => {
    it('should validate 5 images successfully (validation logic only)', async () => {
      // Note: validateImages itself doesn't enforce MAX_IMAGES
      // That's handled at the command level
      const urls = [
        'http://a.com/1.jpg',
        'http://b.com/2.jpg',
        'http://c.com/3.jpg',
        'http://d.com/4.jpg',
        'http://e.com/5.jpg'
      ];

      setupMultipleMockFetches({
        'http://a.com/1.jpg': createMockResponse(createMockJpegData()),
        'http://b.com/2.jpg': createMockResponse(createMockJpegData()),
        'http://c.com/3.jpg': createMockResponse(createMockJpegData()),
        'http://d.com/4.jpg': createMockResponse(createMockJpegData()),
        'http://e.com/5.jpg': createMockResponse(createMockJpegData())
      });

      const result = await testValidateImages(urls);

      // validateImages should pass, but command level should reject
      expect(result.valid).toBe(true);
      expect(result.validPaths).toHaveLength(5);
    });
  });

  // ============================================================
  // I008: Console output for URL download (P1)
  // ============================================================
  describe('I008 - Console output for URL download', () => {
    it('should be able to detect URL inputs for console output', async () => {
      const resourceDownloader = await import('../../src/utils/resource_downloader.js');
      const isUrl = resourceDownloader.default.isUrl;

      const url = 'http://example.com/image.jpg';
      expect(isUrl(url)).toBe(true);

      const localPath = './local.jpg';
      expect(isUrl(localPath)).toBe(false);
    });

    it('should filter URL inputs from mixed array', async () => {
      const resourceDownloader = await import('../../src/utils/resource_downloader.js');
      const isUrl = resourceDownloader.default.isUrl;

      const inputs = [
        'http://example.com/remote.jpg',
        './local.jpg',
        'https://another.com/photo.png',
        '/absolute/path.jpg'
      ];

      const urlInputs = inputs.filter(p => isUrl(p));

      expect(urlInputs).toHaveLength(2);
      expect(urlInputs).toContain('http://example.com/remote.jpg');
      expect(urlInputs).toContain('https://another.com/photo.png');
    });
  });

  // ============================================================
  // Additional coverage tests
  // ============================================================
  describe('Additional coverage', () => {
    it('should handle URL with query parameters', async () => {
      const url = 'http://example.com/image.jpg?token=abc&size=large';
      const mockData = createMockJpegData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await testValidateImages([url]);

      expect(result.valid).toBe(true);
      expect(result.validPaths[0]).toContain('image.jpg');
    });

    it('should handle URL with fragment', async () => {
      const url = 'http://example.com/photo.png#section';
      const mockData = createMockImageData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await testValidateImages([url]);

      expect(result.valid).toBe(true);
      expect(result.validPaths[0]).toContain('photo.png');
    });

    it('should handle missing local file', async () => {
      const missingPath = './tests/fixtures/nonexistent.jpg';

      const result = await testValidateImages([missingPath]);

      expect(result.valid).toBe(false);
      expect(result.errors[0]).toContain('not found');
      expect(result.validPaths).toHaveLength(0);
    });

    it('should handle mixed missing local and valid URL', async () => {
      const missingPath = './tests/fixtures/missing.jpg';
      const url = 'http://example.com/valid.jpg';

      setupMockFetch(url, createMockResponse(createMockJpegData()));

      const result = await testValidateImages([missingPath, url]);

      expect(result.valid).toBe(false);
      expect(result.errors[0]).toContain('not found');
      expect(result.validPaths).toHaveLength(1);
      expect(result.validPaths[0]).toContain('valid.jpg');
    });

    it('should handle HTTPS URLs', async () => {
      const url = 'https://secure.example.com/image.png';
      const mockData = createMockImageData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await testValidateImages([url]);

      expect(result.valid).toBe(true);
      expect(result.validPaths[0]).toContain('image.png');
    });

    it('should handle uppercase extensions', async () => {
      const url = 'http://example.com/UPPER.JPG';
      const mockData = createMockJpegData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await testValidateImages([url]);

      expect(result.valid).toBe(true);
    });

    it('should handle .jpeg extension', async () => {
      const url = 'http://example.com/photo.jpeg';
      const mockData = createMockJpegData();

      setupMockFetch(url, createMockResponse(mockData));

      const result = await testValidateImages([url]);

      expect(result.valid).toBe(true);
      expect(result.validPaths[0]).toContain('photo.jpeg');
    });

    it('should handle empty array input', async () => {
      const result = await testValidateImages([]);

      expect(result.valid).toBe(true);
      expect(result.validPaths).toHaveLength(0);
      expect(result.errors).toHaveLength(0);
    });

    it('should accumulate multiple errors', async () => {
      const missingPath = './tests/fixtures/missing.jpg';
      const gifUrl = 'http://example.com/unsupported.gif';

      setupMockFetch(gifUrl, createMockResponse(createMockGifData()));

      const result = await testValidateImages([missingPath, gifUrl]);

      expect(result.valid).toBe(false);
      expect(result.errors).toHaveLength(2);
      expect(result.errors[0]).toContain('not found');
      expect(result.errors[1]).toContain('Unsupported');
    });
  });
});
