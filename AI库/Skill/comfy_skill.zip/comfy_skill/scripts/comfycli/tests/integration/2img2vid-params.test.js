/**
 * Integration tests for 2img2vid parameter passing chain
 * Tests video parameter handling (width, height, framelen, fps) and seed behavior
 *
 * TEST-INT-001: Config Loading + Variable Replacement Integration
 * TEST-INT-002: CLI Params -> promptVars -> Workflow Full Chain
 */
import { describe, it, expect, beforeAll } from '@jest/globals';
import fs from 'fs';
import path from 'path';
import { replaceVariables, mergeWorkflowParams } from '../../src/core/workflow.js';

const CONFIG_PATH = path.resolve('./config/comfy_config.json');
const API_PATH = path.resolve('./config/comfy/image2_to_video_ltx2.3_fe_api.json');

let apiData;
let dataConfig;

// ---------------------------------------------------------------------------
// TEST-INT-001: Config Loading + Variable Replacement Integration
// ---------------------------------------------------------------------------
describe('TEST-INT-001: Config Loading + Variable Replacement Integration', () => {
  beforeAll(() => {
    const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));
    const ltxConfig = config.prompts.ltx2img2vid;
    dataConfig = ltxConfig.data;
    apiData = JSON.parse(fs.readFileSync(API_PATH, 'utf-8'));
  });

  it('IT-C001: should contain 4 video param entries (width, height, framelen, fps) in ltx2img2vid.data', () => {
    const videoParamKeys = dataConfig.filter(entry => {
      const key = Object.keys(entry)[0];
      return key.startsWith('width##') || key.startsWith('height##') ||
             key.startsWith('framelen##') || key.startsWith('fps##');
    });
    expect(videoParamKeys).toHaveLength(4);
    const keyNames = videoParamKeys.map(e => Object.keys(e)[0].split('##')[0]);
    expect(keyNames).toContain('width');
    expect(keyNames).toContain('height');
    expect(keyNames).toContain('framelen');
    expect(keyNames).toContain('fps');
  });

  it('IT-C002: should have correct key format with 4 ##-delimited parts and ##width## placeholder', () => {
    const widthEntry = dataConfig.find(e => Object.keys(e)[0].startsWith('width##'));
    expect(widthEntry).toBeDefined();
    const key = Object.keys(widthEntry)[0];
    const value = Object.values(widthEntry)[0];
    const parts = key.split('##');
    expect(parts).toHaveLength(4);
    expect(parts[0]).toBe('width');
    expect(parts[1]).toBe('113');
    expect(parts[2]).toBe('inputs');
    expect(parts[3]).toBe('value');
    expect(value).toBe('##width##');
  });

  it('IT-C003: should replace width and leave other video params at defaults', () => {
    const values = {
      active_prompt: 'test', negative_prompt: 'neg',
      sample_image: 'img1.png', sample_image2: 'img2.png',
      width: '960'
    };
    const result = replaceVariables(apiData, dataConfig, values);
    expect(result['113'].inputs.value).toBe('960');
    expect(result['98'].inputs.value).toBe(720);
    expect(result['102'].inputs.value).toBe(121);
    expect(result['114'].inputs.value).toBe(25);
  });

  it('IT-C004: should keep all video param defaults when no video params provided', () => {
    const values = {
      active_prompt: 'test', negative_prompt: 'neg',
      sample_image: 'img1.png', sample_image2: 'img2.png'
    };
    const result = replaceVariables(apiData, dataConfig, values);
    expect(result['113'].inputs.value).toBe(1280);
    expect(result['98'].inputs.value).toBe(720);
    expect(result['102'].inputs.value).toBe(121);
    expect(result['114'].inputs.value).toBe(25);
  });

  it('IT-C005: should replace all video params when all provided', () => {
    const values = {
      active_prompt: 'test', negative_prompt: 'neg',
      sample_image: 'img1.png', sample_image2: 'img2.png',
      width: '960', height: '540',
      framelen: '81', fps: '30'
    };
    const result = replaceVariables(apiData, dataConfig, values);
    expect(result['113'].inputs.value).toBe('960');
    expect(result['98'].inputs.value).toBe('540');
    expect(result['102'].inputs.value).toBe('81');
    expect(result['114'].inputs.value).toBe('30');
  });

  it('IT-C006: should verify API JSON default node values match expectations', () => {
    expect(apiData['113'].inputs.value).toBe(1280);
    expect(apiData['98'].inputs.value).toBe(720);
    expect(apiData['102'].inputs.value).toBe(121);
    expect(apiData['114'].inputs.value).toBe(25);
  });
});

// ---------------------------------------------------------------------------
// TEST-INT-002: CLI Params -> promptVars -> Workflow Full Chain
// ---------------------------------------------------------------------------

function buildPromptVars(options) {
  const vars = {
    active_prompt: 'test prompt',
    negative_prompt: 'test negative',
    sample_image: 'image1.png',
    sample_image2: 'image2.png'
  };
  if (options.width !== undefined) vars.width = String(options.width);
  if (options.height !== undefined) vars.height = String(options.height);
  if (options.frames !== undefined) vars.framelen = String(options.frames);
  if (options.fps !== undefined) vars.fps = String(options.fps);
  return vars;
}

describe('TEST-INT-002: CLI Params -> promptVars -> Workflow Full Chain', () => {
  let localApiData;
  let localDataConfig;
  beforeAll(() => {
    const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));
    const ltxConfig = config.prompts.ltx2img2vid;
    localDataConfig = ltxConfig.data;
    localApiData = JSON.parse(fs.readFileSync(API_PATH, 'utf-8'));
  });

  it('IT-F001: options={width:960} -> promptVars has width -> node 113=960', () => {
    const options = { width: 960 };
    const promptVars = buildPromptVars(options);
    expect(promptVars.width).toBe('960');
    const result = replaceVariables(localApiData, localDataConfig, promptVars);
    expect(result['113'].inputs.value).toBe('960');
  });

  it('IT-F002: full params -> all correctly set', () => {
    const options = { width: 960, height: 540, frames: 81, fps: 30 };
    const promptVars = buildPromptVars(options);
    expect(promptVars.width).toBe('960');
    expect(promptVars.height).toBe('540');
    expect(promptVars.framelen).toBe('81');
    expect(promptVars.fps).toBe('30');
    const result = replaceVariables(localApiData, localDataConfig, promptVars);
    expect(result['113'].inputs.value).toBe('960');
    expect(result['98'].inputs.value).toBe('540');
    expect(result['102'].inputs.value).toBe('81');
    expect(result['114'].inputs.value).toBe('30');
  });

  it('IT-F003: seed via mergeWorkflowParams does NOT match noise_seed in node 100', () => {
    const options = { width: 960 };
    const promptVars = buildPromptVars(options);
    const workflowParams = { seed: 12345 };
    const replaced = replaceVariables(localApiData, localDataConfig, promptVars);
    const result = mergeWorkflowParams(replaced, workflowParams);
    expect(result['113'].inputs.value).toBe('960');
    // NOTE: mergeWorkflowParams uses exact key match (hasOwnProperty),
    // but node 100 has noise_seed, not seed. So seed param is NOT applied.
    expect(result['100'].inputs.noise_seed).toBe(469008696527318);
  });

  it('IT-F004: no video params -> all video nodes keep original API JSON values', () => {
    const options = {};
    const promptVars = buildPromptVars(options);
    const result = replaceVariables(localApiData, localDataConfig, promptVars);
    expect(result['113'].inputs.value).toBe(1280);
    expect(result['98'].inputs.value).toBe(720);
    expect(result['102'].inputs.value).toBe(121);
    expect(result['114'].inputs.value).toBe(25);
  });

  it('IT-F005: options={width:960} only -> only width changes, others keep defaults', () => {
    const options = { width: 960 };
    const promptVars = buildPromptVars(options);
    const result = replaceVariables(localApiData, localDataConfig, promptVars);
    expect(result['113'].inputs.value).toBe('960');
    expect(result['98'].inputs.value).toBe(720);
    expect(result['102'].inputs.value).toBe(121);
    expect(result['114'].inputs.value).toBe(25);
  });

  it('IT-F006: options={width:0,height:0} -> replaced with 0 (not skipped)', () => {
    const options = { width: 0, height: 0 };
    const promptVars = buildPromptVars(options);
    expect(promptVars.width).toBe('0');
    expect(promptVars.height).toBe('0');
    const result = replaceVariables(localApiData, localDataConfig, promptVars);
    expect(result['113'].inputs.value).toBe('0');
    expect(result['98'].inputs.value).toBe('0');
  });
});

