import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import fs from 'fs';
import path from 'path';
import os from 'os';
import ConfigManager from '../../src/utils/config.js';

describe('validate Integration - ConfigManager Interaction', () => {
  let tmpDir;

  beforeEach(() => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'comfycli-test-'));
  });

  afterEach(() => {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  // 203-1: comfy_config without host/port, validate returns valid
  it('should validate comfy_config without host/port as valid', () => {
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify({
      prompts: {}
    }));
    const cm = new ConfigManager(path.join(tmpDir, 'comfy_config.json'));
    cm.load();
    const result = cm.validate();
    expect(result.valid).toBe(true);
  });

  // 203-2: comfy_config with host/port, validate does not report errors for them
  it('should not report errors for host/port in comfy_config', () => {
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify({
      prompts: {},
      host: '10.0.0.1',
      port: 9010
    }));
    const cm = new ConfigManager(path.join(tmpDir, 'comfy_config.json'));
    cm.load();
    const result = cm.validate();
    expect(result.valid).toBe(true);
    const hasHostPortError = result.errors.some(e =>
      e.toLowerCase().includes('host') || e.toLowerCase().includes('port')
    );
    expect(hasHostPortError).toBe(false);
  });

  // 203-3: comfy_config missing prompts, validate returns invalid
  it('should return invalid when comfy_config is missing prompts', () => {
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify({
      resolution: {}
    }));
    const cm = new ConfigManager(path.join(tmpDir, 'comfy_config.json'));
    cm.load();
    const result = cm.validate();
    expect(result.valid).toBe(false);
    expect(result.errors.some(e => e.includes('prompts'))).toBe(true);
  });

  // 203-4: validate command references correct config file names
  it('should reference correct config file names in output', () => {
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify({
      prompts: {}
    }));
    fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify({
      host: 'test.com',
      port: 8188
    }));
    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();

    // Validate that getServerConfig reads from server_config
    const serverConfig = cm.getServerConfig();
    expect(serverConfig.host).toBe('test.com');

    // Validate comfy_config structure
    const result = cm.validate();
    expect(result.valid).toBe(true);

    // Verify the config file paths reference correct names
    expect(cm.configPath).toContain('comfy_config.json');
    expect(cm.serverConfigPath).toContain('server_config.json');
  });
});
