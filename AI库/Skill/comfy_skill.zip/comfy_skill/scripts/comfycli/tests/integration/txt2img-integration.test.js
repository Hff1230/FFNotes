import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import fs from 'fs';
import path from 'path';
import os from 'os';
import ConfigManager from '../../src/utils/config.js';

describe('txt2img Integration - ConfigManager Interaction', () => {
  let tmpDir;

  beforeEach(() => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'comfycli-test-'));
  });

  afterEach(() => {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  // Helper: create standard test config files
  function setupConfig(serverConfig = null, comfyConfig = null) {
    const defaultComfy = {
      prompts: {
        'test-t2i': {
          description: 'Test txt2img',
          type: 'txt2img',
          api: 'tests/fixtures/mock-api.json',
          data: []
        }
      },
      resolution: { pic_gen: { '0': [{ name: 'low', width: 512, height: 512 }] } }
    };
    const finalComfy = comfyConfig || defaultComfy;
    fs.writeFileSync(path.join(tmpDir, 'comfy_config.json'), JSON.stringify(finalComfy));
    if (serverConfig !== null) {
      fs.writeFileSync(path.join(tmpDir, 'server_config.json'), JSON.stringify(serverConfig));
    }
  }

  // 201-1: server_config exists, ConfigManager is created and loads correctly
  it('should create ConfigManager and load server_config correctly', () => {
    setupConfig({ host: 'test.server.com', port: 9010, api_key: 'key123' });
    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    expect(cm.load()).toBe(true);
    const server = cm.getServerConfig();
    expect(server.host).toBe('test.server.com');
    expect(server.port).toBe(9010);
    expect(server.apiKey).toBe('key123');
  });

  // 201-2: upload configured, getUploadConfig returns the config
  it('should return upload config when server_config has upload section', () => {
    setupConfig({
      host: 'test.com',
      port: 8188,
      upload: {
        server: 'upload.com:9998',
        user: 'admin',
        pwd: 'pass',
        dir: 'comfy',
        share_url: 'http://share.com'
      }
    });
    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();
    const upload = cm.getUploadConfig();
    expect(upload).not.toBeNull();
    expect(upload.server).toBe('upload.com:9998');
    expect(upload.user).toBe('admin');
  });

  // 201-3: upload not configured, getUploadConfig returns null
  it('should return null when upload is not configured', () => {
    setupConfig({ host: 'test.com', port: 8188 });
    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();
    const upload = cm.getUploadConfig();
    expect(upload).toBeNull();
  });

  // 201-4: server_config does not exist, falls back to defaults
  it('should fall back to defaults when server_config does not exist', () => {
    setupConfig(null); // do not create server_config.json
    const cm = new ConfigManager(
      path.join(tmpDir, 'comfy_config.json'),
      path.join(tmpDir, 'server_config.json')
    );
    cm.load();
    const server = cm.getServerConfig();
    expect(server.host).toBe('127.0.0.1');
    expect(server.port).toBe(8188);
    expect(server.apiKey).toBe('');
  });
});
