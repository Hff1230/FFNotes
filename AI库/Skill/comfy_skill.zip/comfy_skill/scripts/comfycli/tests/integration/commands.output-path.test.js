/**
 * Integration tests for multi-command output path under ENV
 * Tests: TC-040 through TC-044 (command-level integration)
 *
 * Verifies that each command correctly receives and uses options.output
 * when called through the batch mapping or directly.
 */
import { jest, describe, it, expect, beforeEach } from '@jest/globals';
import path from 'path';
import fs from 'fs';

const commandsDir = path.join(process.cwd(), 'src', 'commands');

/**
 * Helper: verify a command source file uses options.output
 * and passes it to generateOutputPath correctly
 */
function assertOutputPathUsage(fileName) {
  const source = fs.readFileSync(path.join(commandsDir, fileName), 'utf-8');
  expect(source).toMatch(/options\.output/);

  // If command supports project/category, should use generateOutputPath
  if (source.includes('generateOutputPath')) {
    expect(source).toMatch(/generateOutputPath\(/);
  }
  return source;
}

describe('Command-level output path integration', () => {
  const envBase = '/my/project';
  const expectedOutput = path.join(envBase, 'output');

  // ── TC-040: txt2vid ──
  it('TC-040: txt2vid correctly handles ENV output path', () => {
    const source = assertOutputPathUsage('txt2vid.js');

    // txt2vid should set outputDir from options.output
    expect(source).toMatch(/options\.output/);

    // Verify it does NOT have any hardcoded './output' fallback
    expect(source).not.toContain("|| './output'");
  });

  // ── TC-041: img2vid ──
  it('TC-041: img2vid correctly handles ENV output path', () => {
    const source = assertOutputPathUsage('img2vid.js');
    expect(source).not.toContain("|| './output'");
  });

  // ── TC-042: 2img2vid ──
  it('TC-042: 2img2vid correctly handles ENV output path', () => {
    const source = assertOutputPathUsage('2img2vid.js');
    expect(source).not.toContain("|| './output'");
  });

  // ── TC-043: imagescale ──
  it('TC-043: imagescale correctly handles ENV output path', () => {
    const source = assertOutputPathUsage('imagescale.js');
    expect(source).not.toContain("|| './output'");
  });

  // ── TC-044: run ──
  it('TC-044: run correctly handles ENV output path', () => {
    const source = assertOutputPathUsage('run.js');
    expect(source).not.toContain("|| './output'");
  });
});

// ── Verify batch.js mapping functions include all commands ──
describe('Batch mapping completeness', () => {
  const batchSource = fs.readFileSync(path.join(commandsDir, 'batch.js'), 'utf-8');

  it('batch supports txt2img type', () => {
    expect(batchSource).toContain('txt2img');
    expect(batchSource).toMatch(/function\s+mapTxt2ImgArgs/);
  });

  it('batch supports img2img type', () => {
    expect(batchSource).toContain('img2img');
    expect(batchSource).toMatch(/function\s+mapImg2ImgArgs/);
  });

  it('batch supports txt2vid type', () => {
    expect(batchSource).toContain('txt2vid');
  });

  it('batch supports img2vid type', () => {
    expect(batchSource).toContain('img2vid');
  });

  it('batch supports 2img2video type', () => {
    expect(batchSource).toContain('2img2video');
  });

  it('batch supports imagescale type', () => {
    expect(batchSource).toContain('imagescale');
  });
});
