/**
 * Integration tests for batch.js - Progress file + resume behavior
 *
 * TEST-302: Progress file + resume integration tests (15 test cases)
 *
 * Tests the integration of getProgressFilePath, initProgress, saveProgress,
 * loadProgress, and the batchCommand resume/clean/restart logic.
 */
import { jest } from '@jest/globals';
import path from 'path';
import fs from 'fs';
import os from 'os';
import {
  getProgressFilePath,
  initProgress,
  saveProgress,
  loadProgress,
  batchCommand
} from '../../../src/commands/batch.js';

// ---------------------------------------------------------------------------
// Helper: temp directory for file-based tests, cleaned up after each test
// ---------------------------------------------------------------------------
const TMP_DIR = path.join(os.tmpdir(), 'comfycli-test-302');

// Helper: create a valid tasks JSON file and return its path
function createTasksFile(tasks, filename = 'tasks.json') {
  const filePath = path.join(TMP_DIR, filename);
  fs.writeFileSync(filePath, JSON.stringify(tasks, null, 2), 'utf-8');
  return filePath;
}

// Helper: write a .p progress file next to a tasks file
function createProgressFile(tasksFilePath, progressData) {
  const progressPath = getProgressFilePath(tasksFilePath);
  fs.writeFileSync(progressPath, JSON.stringify(progressData, null, 2), 'utf-8');
  return progressPath;
}

// Helper: build a minimal valid progress object
function buildProgress(overrides = {}) {
  return {
    sourceFile: 'tasks.json',
    startTime: '2026-01-01T00:00:00.000Z',
    lastUpdate: '2026-01-01T00:00:01.000Z',
    totalTasks: 3,
    nextIndex: 0,
    results: [],
    ...overrides
  };
}

// ---------------------------------------------------------------------------
// Setup / Teardown
// ---------------------------------------------------------------------------
beforeEach(() => {
  fs.rmSync(TMP_DIR, { recursive: true, force: true });
  fs.mkdirSync(TMP_DIR, { recursive: true });
});

afterEach(() => {
  fs.rmSync(TMP_DIR, { recursive: true, force: true });
});

// ===========================================================================
// Progress File Lifecycle (3 tests)
// ===========================================================================
describe('TC-302 Progress File Lifecycle', () => {
  test('TC-302-01 - initProgress + saveProgress creates correct .p file', () => {
    const tasks = [
      { type: 'txt2img', prompt: 'a' },
      { type: 'txt2img', prompt: 'b' },
      { type: 'txt2img', prompt: 'c' }
    ];
    const jsonFilePath = path.join(TMP_DIR, 'lifecycle.json');

    const progress = initProgress(tasks, jsonFilePath);
    const progressPath = getProgressFilePath(jsonFilePath);
    saveProgress(progressPath, progress);

    // File should exist
    expect(fs.existsSync(progressPath)).toBe(true);

    // Content should be valid JSON with expected fields
    const loaded = loadProgress(progressPath);
    expect(loaded.sourceFile).toBe('lifecycle.json');
    expect(loaded.totalTasks).toBe(3);
    expect(loaded.nextIndex).toBe(0);
    expect(loaded.results).toEqual([]);
    expect(loaded.startTime).toBeDefined();
    expect(loaded.lastUpdate).toBeDefined();
  });

  test('TC-302-02 - Progress updates correctly (update nextIndex, add results, save, load)', () => {
    const tasks = [
      { type: 'txt2img', prompt: 'first' },
      { type: 'txt2img', prompt: 'second' },
      { type: 'txt2img', prompt: 'third' }
    ];
    const jsonFilePath = path.join(TMP_DIR, 'update.json');
    const progressPath = getProgressFilePath(jsonFilePath);

    // Initialize and save
    let progress = initProgress(tasks, jsonFilePath);
    saveProgress(progressPath, progress);

    // Simulate completing task 0
    progress.results.push({ index: 0, type: 'txt2img', status: 'success', files: ['out1.png'] });
    progress.nextIndex = 1;
    progress.lastUpdate = new Date().toISOString();
    saveProgress(progressPath, progress);

    // Simulate completing task 1
    progress.results.push({ index: 1, type: 'txt2img', status: 'failed', error: 'timeout' });
    progress.nextIndex = 2;
    progress.lastUpdate = new Date().toISOString();
    saveProgress(progressPath, progress);

    // Load and verify
    const loaded = loadProgress(progressPath);
    expect(loaded.nextIndex).toBe(2);
    expect(loaded.results).toHaveLength(2);
    expect(loaded.results[0].status).toBe('success');
    expect(loaded.results[0].files).toEqual(['out1.png']);
    expect(loaded.results[1].status).toBe('failed');
    expect(loaded.results[1].error).toBe('timeout');
    expect(loaded.totalTasks).toBe(3);
  });

  test('TC-302-03 - .p file path matches JSON file directory', () => {
    const jsonFilePath = path.join(TMP_DIR, 'location.json');
    const progressPath = getProgressFilePath(jsonFilePath);

    expect(path.dirname(progressPath)).toBe(path.dirname(jsonFilePath));
    expect(path.basename(progressPath)).toBe('location.p');
    expect(progressPath).toBe(path.join(TMP_DIR, 'location.p'));
  });
});

// ===========================================================================
// Resume (5 tests)
// ===========================================================================
describe('TC-302 Resume from existing progress', () => {
  test('TC-302-04 - Existing .p with nextIndex=2 resumes from task 2', async () => {
    const tasks = [
      { type: 'txt2img', prompt: 'task 0' },
      { type: 'txt2img', prompt: 'task 1' },
      { type: 'txt2img', prompt: 'task 2' }
    ];
    const jsonFilePath = createTasksFile(tasks);
    const progressPath = getProgressFilePath(jsonFilePath);

    // Create a progress file with 2 completed tasks
    const progress = buildProgress({
      sourceFile: path.basename(jsonFilePath),
      nextIndex: 2,
      results: [
        { index: 0, type: 'txt2img', status: 'success' },
        { index: 1, type: 'txt2img', status: 'success' }
      ]
    });
    createProgressFile(jsonFilePath, progress);

    // Use console spy to capture output
    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

    // batchCommand will try to execute task 2, which requires ComfyUI.
    // Mock executeTask to avoid real execution.
    // We test that batchCommand picks up the resume and starts from task 2.
    // Since executeTask will fail (no ComfyUI), we use --continue-on-error
    // and verify the resume message was printed.
    await batchCommand(jsonFilePath, { continueOnError: true });

    // Should have printed resume message
    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');
    expect(output).toContain('Resuming from task 3 of 3');

    // Progress file should now show nextIndex=3 (all tasks attempted)
    const updated = loadProgress(progressPath);
    expect(updated.nextIndex).toBe(3);

    consoleSpy.mockRestore();
  });

  test('TC-302-05 - .p with nextIndex=totalTasks shows all completed message', async () => {
    const tasks = [
      { type: 'txt2img', prompt: 'task 0' },
      { type: 'txt2img', prompt: 'task 1' },
      { type: 'txt2img', prompt: 'task 2' }
    ];
    const jsonFilePath = createTasksFile(tasks);

    // Create progress file with all tasks completed
    const progress = buildProgress({
      sourceFile: path.basename(jsonFilePath),
      nextIndex: 3,
      results: [
        { index: 0, type: 'txt2img', status: 'success' },
        { index: 1, type: 'txt2img', status: 'success' },
        { index: 2, type: 'txt2img', status: 'success' }
      ]
    });
    createProgressFile(jsonFilePath, progress);

    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

    await batchCommand(jsonFilePath, {});

    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');
    expect(output).toContain('All tasks already completed!');

    consoleSpy.mockRestore();
  });

  test('TC-302-06 - .p with wrong sourceFile starts from beginning', async () => {
    const tasks = [
      { type: 'txt2img', prompt: 'task 0' },
      { type: 'txt2img', prompt: 'task 1' },
      { type: 'txt2img', prompt: 'task 2' }
    ];
    const jsonFilePath = createTasksFile(tasks);

    // Create progress file with WRONG sourceFile name
    const progress = buildProgress({
      sourceFile: 'different-file.json',
      nextIndex: 2,
      results: [
        { index: 0, type: 'txt2img', status: 'success' },
        { index: 1, type: 'txt2img', status: 'success' }
      ]
    });
    createProgressFile(jsonFilePath, progress);

    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

    await batchCommand(jsonFilePath, { continueOnError: true });

    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');
    // Should warn about modified file and start fresh
    expect(output).toContain('Warning: JSON file has been modified since last execution');
    expect(output).toContain('Starting from beginning');

    // Progress should have been re-initialized (nextIndex will be 3 after all 3 tasks attempted)
    const progressPath = getProgressFilePath(jsonFilePath);
    const updated = loadProgress(progressPath);
    // Since it started fresh, it re-initialized and attempted all 3 tasks
    expect(updated.sourceFile).toBe(path.basename(jsonFilePath));

    consoleSpy.mockRestore();
  });

  test('TC-302-07 - .p with wrong totalTasks starts from beginning', async () => {
    const tasks = [
      { type: 'txt2img', prompt: 'task 0' },
      { type: 'txt2img', prompt: 'task 1' },
      { type: 'txt2img', prompt: 'task 2' }
    ];
    const jsonFilePath = createTasksFile(tasks);

    // Create progress file with WRONG totalTasks (5 instead of 3)
    const progress = buildProgress({
      sourceFile: path.basename(jsonFilePath),
      totalTasks: 5,
      nextIndex: 2,
      results: [
        { index: 0, type: 'txt2img', status: 'success' },
        { index: 1, type: 'txt2img', status: 'success' }
      ]
    });
    createProgressFile(jsonFilePath, progress);

    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

    await batchCommand(jsonFilePath, { continueOnError: true });

    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');
    expect(output).toContain('Warning: JSON file has been modified since last execution');
    expect(output).toContain('Starting from beginning');

    consoleSpy.mockRestore();
  });

  test('TC-302-08 - Corrupted .p file starts from beginning', async () => {
    const tasks = [
      { type: 'txt2img', prompt: 'task 0' },
      { type: 'txt2img', prompt: 'task 1' },
      { type: 'txt2img', prompt: 'task 2' }
    ];
    const jsonFilePath = createTasksFile(tasks);

    // Write corrupted progress file
    const progressPath = getProgressFilePath(jsonFilePath);
    fs.writeFileSync(progressPath, 'this is not valid json {{{', 'utf-8');

    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

    await batchCommand(jsonFilePath, { continueOnError: true });

    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');
    // loadProgress returns null for corrupted file, so batchCommand starts fresh
    // It should NOT show the "Resuming" message
    expect(output).not.toContain('Resuming from');
    // It should execute all 3 tasks from the start
    expect(output).toContain('[1/3]');
    expect(output).toContain('[2/3]');
    expect(output).toContain('[3/3]');

    consoleSpy.mockRestore();
  });
});

// ===========================================================================
// --restart option (2 tests)
// ===========================================================================
describe('TC-302 --restart option', () => {
  test('TC-302-09 - --restart ignores .p file and starts from beginning', async () => {
    const tasks = [
      { type: 'txt2img', prompt: 'task 0' },
      { type: 'txt2img', prompt: 'task 1' },
      { type: 'txt2img', prompt: 'task 2' }
    ];
    const jsonFilePath = createTasksFile(tasks);

    // Create progress file indicating 2 tasks done
    const progress = buildProgress({
      sourceFile: path.basename(jsonFilePath),
      nextIndex: 2,
      results: [
        { index: 0, type: 'txt2img', status: 'success' },
        { index: 1, type: 'txt2img', status: 'success' }
      ]
    });
    createProgressFile(jsonFilePath, progress);

    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

    await batchCommand(jsonFilePath, { restart: true, continueOnError: true });

    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');
    // Should show restart message, not resume message
    expect(output).toContain('Restarting from beginning (--restart flag)');
    expect(output).not.toContain('Resuming from');

    // Should have started from task 1, not task 3
    expect(output).toContain('[1/3]');

    consoleSpy.mockRestore();
  });

  test('TC-302-10 - --restart shows restart message', async () => {
    const tasks = [
      { type: 'txt2img', prompt: 'only task' }
    ];
    const jsonFilePath = createTasksFile(tasks);

    // Create progress file indicating task already done
    const progress = buildProgress({
      sourceFile: path.basename(jsonFilePath),
      totalTasks: 1,
      nextIndex: 1,
      results: [
        { index: 0, type: 'txt2img', status: 'success' }
      ]
    });
    createProgressFile(jsonFilePath, progress);

    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

    await batchCommand(jsonFilePath, { restart: true, continueOnError: true });

    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');
    expect(output).toContain('Restarting from beginning (--restart flag)');

    // Progress file should be re-initialized
    const progressPath = getProgressFilePath(jsonFilePath);
    const updated = loadProgress(progressPath);
    expect(updated.nextIndex).toBe(1);
    expect(updated.results[0].index).toBe(0);

    consoleSpy.mockRestore();
  });
});

// ===========================================================================
// --clean option (2 tests)
// ===========================================================================
describe('TC-302 --clean option', () => {
  test('TC-302-11 - --clean deletes .p file and exits', async () => {
    const tasks = [
      { type: 'txt2img', prompt: 'task 0' },
      { type: 'txt2img', prompt: 'task 1' }
    ];
    const jsonFilePath = createTasksFile(tasks);
    const progressPath = getProgressFilePath(jsonFilePath);

    // Create progress file
    const progress = buildProgress({
      sourceFile: path.basename(jsonFilePath),
      nextIndex: 1,
      results: [{ index: 0, type: 'txt2img', status: 'success' }]
    });
    saveProgress(progressPath, progress);

    // Verify .p file exists
    expect(fs.existsSync(progressPath)).toBe(true);

    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

    await batchCommand(jsonFilePath, { clean: true });

    // .p file should be deleted
    expect(fs.existsSync(progressPath)).toBe(false);

    // Should print deletion message
    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');
    expect(output).toContain('Progress file deleted');

    consoleSpy.mockRestore();
  });

  test('TC-302-12 - --clean with no .p file shows no progress file found', async () => {
    const tasks = [
      { type: 'txt2img', prompt: 'task 0' }
    ];
    const jsonFilePath = createTasksFile(tasks);
    const progressPath = getProgressFilePath(jsonFilePath);

    // Verify .p file does NOT exist
    expect(fs.existsSync(progressPath)).toBe(false);

    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

    await batchCommand(jsonFilePath, { clean: true });

    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');
    expect(output).toContain('No progress file found');

    consoleSpy.mockRestore();
  });
});

// ===========================================================================
// Interrupt Recovery (3 tests)
// ===========================================================================
describe('TC-302 Interrupt Recovery', () => {
  test('TC-302-13 - Failed task saves progress with failed result', async () => {
    const tasks = [
      { type: 'txt2img', prompt: 'task 0' },
      { type: 'txt2img', prompt: 'task 1' },
      { type: 'txt2img', prompt: 'task 2' }
    ];
    const jsonFilePath = createTasksFile(tasks);
    const progressPath = getProgressFilePath(jsonFilePath);

    // No existing progress file, batchCommand will create one
    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

    // Without continueOnError, batchCommand exits on first failure.
    // process.exit(1) would be called, so we mock it.
    const mockExit = jest.spyOn(process, 'exit').mockImplementation((code) => {
      throw new Error(`process.exit(${code})`);
    });

    await expect(
      batchCommand(jsonFilePath, {})
    ).rejects.toThrow('process.exit(1)');

    // Progress file should exist with the failed task recorded
    const progress = loadProgress(progressPath);
    expect(progress).not.toBeNull();
    expect(progress.results).toHaveLength(1);
    expect(progress.results[0].status).toBe('failed');
    expect(progress.results[0].index).toBe(0);
    expect(progress.nextIndex).toBe(1);

    consoleSpy.mockRestore();
    mockExit.mockRestore();
  });

  test('TC-302-14 - Resume from saved progress picks up where left off', async () => {
    const tasks = [
      { type: 'txt2img', prompt: 'task 0' },
      { type: 'txt2img', prompt: 'task 1' },
      { type: 'txt2img', prompt: 'task 2' }
    ];
    const jsonFilePath = createTasksFile(tasks);
    const progressPath = getProgressFilePath(jsonFilePath);

    // Create progress simulating task 0 failed and was saved
    const progress = buildProgress({
      sourceFile: path.basename(jsonFilePath),
      nextIndex: 1,
      results: [
        { index: 0, type: 'txt2img', status: 'failed', error: 'connection refused' }
      ]
    });
    createProgressFile(jsonFilePath, progress);

    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

    await batchCommand(jsonFilePath, { continueOnError: true });

    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');

    // Should resume from task 2 (index 1)
    expect(output).toContain('Resuming from task 2 of 3');
    // Should not re-execute task 0
    expect(output).toContain('[2/3]');

    // Updated progress should have results from both original and new run
    const updated = loadProgress(progressPath);
    // The original failed result is kept, plus the newly attempted tasks
    expect(updated.results.length).toBeGreaterThanOrEqual(1);
    // First result from original progress should still be the failed one
    expect(updated.results[0].status).toBe('failed');
    expect(updated.results[0].error).toBe('connection refused');

    consoleSpy.mockRestore();
  });

  test('TC-302-15 - Completed run preserves .p file', async () => {
    const tasks = [
      { type: 'txt2img', prompt: 'task 0' },
      { type: 'txt2img', prompt: 'task 1' },
      { type: 'txt2img', prompt: 'task 2' }
    ];
    const jsonFilePath = createTasksFile(tasks);
    const progressPath = getProgressFilePath(jsonFilePath);

    // Create progress file showing all tasks completed
    const progress = buildProgress({
      sourceFile: path.basename(jsonFilePath),
      nextIndex: 3,
      results: [
        { index: 0, type: 'txt2img', status: 'success', files: ['out0.png'] },
        { index: 1, type: 'txt2img', status: 'success', files: ['out1.png'] },
        { index: 2, type: 'txt2img', status: 'success', files: ['out2.png'] }
      ]
    });
    createProgressFile(jsonFilePath, progress);

    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

    await batchCommand(jsonFilePath, {});

    // .p file should still exist
    expect(fs.existsSync(progressPath)).toBe(true);

    // .p file content should be unchanged (not overwritten)
    const preserved = loadProgress(progressPath);
    expect(preserved.nextIndex).toBe(3);
    expect(preserved.results).toHaveLength(3);
    expect(preserved.results[0].files).toEqual(['out0.png']);
    expect(preserved.results[1].files).toEqual(['out1.png']);
    expect(preserved.results[2].files).toEqual(['out2.png']);

    const output = consoleSpy.mock.calls.map(args => args.join(' ')).join('\n');
    expect(output).toContain('All tasks already completed!');

    consoleSpy.mockRestore();
  });
});
