import fs from 'fs';
import path from 'path';
import ConfigManager from '../../src/utils/config.js';

const BASE_DIR = path.resolve(path.dirname(import.meta.url).replace(/^file:\/\/\//, '').replace(/^\/([A-Z]:)/, '$1'), '../..');
const FIXTURES_DIR = path.join(BASE_DIR, 'tests', 'fixtures');

/**
 * 创建标准测试用服务器配置
 */
export function createDefaultServerConfig() {
  return {
    host: 'test-server.example.com',
    port: 9010,
    api_key: 'test-api-key-123',
    upload: {
      server: 'upload-server.example.com:9998',
      user: 'testuser',
      pwd: 'testpwd123',
      dir: 'comfy',
      share_url: 'http://share.example.com:10020'
    }
  };
}

/**
 * 创建标准测试用工作流配置
 */
export function createDefaultComfyConfig() {
  return {
    prompts: {
      'test-workflow': {
        description: 'Test workflow for unit testing',
        type: 'txt2img',
        api: 'tests/fixtures/mock-api.json',
        data: [
          { 'active##1##inputs##prompt': '##active_prompt##' }
        ]
      }
    },
    resolution: {
      pic_gen: {
        '0': [{ name: 'low', width: 512, height: 512 }]
      }
    }
  };
}

/**
 * 将配置写入临时目录
 */
export function writeConfigFiles(tmpDir, serverConfig = null, comfyConfig = null) {
  if (comfyConfig !== null) {
    fs.writeFileSync(
      path.join(tmpDir, 'comfy_config.json'),
      JSON.stringify(comfyConfig, null, 2),
      'utf-8'
    );
  }
  if (serverConfig !== null) {
    fs.writeFileSync(
      path.join(tmpDir, 'server_config.json'),
      JSON.stringify(serverConfig, null, 2),
      'utf-8'
    );
  }
}

/**
 * 创建带指定配置的 ConfigManager 实例
 */
export function createConfigManager(tmpDir, serverConfig = null, comfyConfig = null) {
  writeConfigFiles(tmpDir, serverConfig, comfyConfig);
  const configPath = path.join(tmpDir, 'comfy_config.json');
  const serverConfigPath = path.join(tmpDir, 'server_config.json');
  return new ConfigManager(configPath, serverConfigPath);
}

/**
 * 从 fixtures 目录读取夹具文件
 */
export function readFixture(filename) {
  const filePath = path.join(FIXTURES_DIR, filename);
  return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
}

/**
 * 获取夹具文件路径
 */
export function getFixturePath(filename) {
  return path.join(FIXTURES_DIR, filename);
}
