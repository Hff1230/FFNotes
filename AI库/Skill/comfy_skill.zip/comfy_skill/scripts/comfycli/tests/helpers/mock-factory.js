import sinon from 'sinon';

/**
 * 创建 ConfigManager mock
 */
export function createMockConfigManager(overrides = {}) {
  const defaults = {
    load: sinon.stub().returns(true),
    isLoaded: sinon.stub().returns(true),
    getWorkflow: sinon.stub().returns({
      type: 'txt2img',
      description: 'Test workflow',
      api: './tests/fixtures/mock-api.json',
      data: []
    }),
    getServerConfig: sinon.stub().returns({
      host: '127.0.0.1',
      port: 8188,
      apiKey: ''
    }),
    getUploadConfig: sinon.stub().returns({
      server: '192.168.0.92:9998',
      user: 'testuser',
      pwd: 'testpwd',
      dir: 'comfy',
      share_url: 'http://47.109.205.195:10020'
    }),
    loadApiFile: sinon.stub().returns({
      '1': { class_type: 'KSampler', inputs: { seed: 1 } },
      '2': { class_type: 'SaveImage', inputs: {} }
    }),
    getDefaultWorkflowName: sinon.stub().returns('test-workflow'),
    listWorkflows: sinon.stub().returns([
      { name: 'test-workflow', type: 'txt2img', description: 'Test' }
    ]),
    resolveResolution: sinon.stub().returns({ width: 512, height: 512 })
  };
  return { ...defaults, ...overrides };
}

/**
 * 创建 ComfyHelper mock
 */
export function createMockComfyHelper(overrides = {}) {
  const defaults = {
    connect: sinon.stub().resolves(),
    disconnect: sinon.stub().resolves(),
    queuePrompt: sinon.stub().resolves({ prompt_id: 'test-prompt-123' }),
    getHistory: sinon.stub().resolves({
      'test-prompt-123': {
        outputs: {
          '2': {
            images: [
              { filename: 'output.png', subfolder: '', type: 'output' }
            ]
          }
        }
      }
    }),
    downloadOutput: sinon.stub().resolves(true)
  };
  return { ...defaults, ...overrides };
}

/**
 * 创建 ProgressMonitor mock
 */
export function createMockProgressMonitor() {
  return {
    waitForCompletion: sinon.stub().resolves()
  };
}

/**
 * 创建 DufsUploader mock
 */
export function createMockUploader(overrides = {}) {
  const defaults = {
    uploadFile: sinon.stub().resolves({ success: true, url: 'http://test.url/file.png' }),
    uploadFiles: sinon.stub().resolves({
      success: true,
      results: [
        { local: '/test/file.png', success: true, url: 'http://test.url/file.png' }
      ]
    }),
    getProjectShareUrl: sinon.stub().callsFake((filename, project, category) => {
      return `http://47.109.205.195:10020/projects/${project}/${category}/${filename}`;
    }),
    getShareUrl: sinon.stub().callsFake((filename) => {
      return `http://192.168.0.92:9998/comfy/2026-3-31/${filename}`;
    }),
    getShareDirUrl: sinon.stub().returns('http://47.109.205.195:10020/comfy/2026-3-31/'),
    getProjectRemotePath: sinon.stub().callsFake((filename, project, category) => {
      return `/projects/${project}/${category}/${filename}`;
    })
  };
  return { ...defaults, ...overrides };
}

/**
 * 创建临时测试文件
 */
export function createTestFile(content, filename = 'test.png') {
  return Buffer.from(content);
}
