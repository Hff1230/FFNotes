// Jest setup file
import nock from 'nock';
import { jest } from '@jest/globals';

// Disable HTTP requests by default
nock.disableNetConnect();

// Allow localhost connections for certain tests
nock.enableNetConnect('127.0.0.1');

// Global test timeout
jest.setTimeout(30000);

// Cleanup after each test
afterEach(() => {
  nock.cleanAll();
});
