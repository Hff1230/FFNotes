# ComfyCLI

A powerful CLI tool for ComfyUI workflow execution. Generate images and videos using AI with simple commands.

## Features

- Text to Image generation
- Image to Image transformation
- Text to Video generation
- Image to Video animation
- Dynamic workflow discovery
- Real-time progress monitoring
- Claude Code skill integration

## Installation

### Using npx (Recommended)
```bash
npx comfycli --help
```

### Global Installation
```bash
npm install -g comfycli
comfycli --help
```

## Quick Start

### 1. Configure ComfyUI Server
Edit `config/comfy_config.json`:
```json
{
  "host": "192.168.0.99",
  "port": 10000,
  "api_key": ""
}
```

### 2. List Available Workflows
```bash
npx comfycli list
```

### 3. Generate Your First Image
```bash
npx comfycli txt2img "a beautiful sunset over mountains"
```

## Commands

### List Workflows
```bash
npx comfycli list
```

### Validate Configuration
```bash
npx comfycli validate --config ./config/comfy_config.json
```

### Text to Image
```bash
npx comfycli txt2img "<prompt>" [options]
```

**Options:**
- `--negative, -n` - Negative prompt
- `--output, -o` - Output directory (default: ./output)
- `--workflow, -w` - Workflow name (default: qwent2i)
- `--steps` - Sampling steps
- `--cfg` - CFG scale
- `--seed` - Random seed
- `--width` - Image width
- `--height` - Image height

**Example:**
```bash
npx comfycli txt2img "a cat sitting on a tree" \
  --negative "blurry, low quality" \
  --output ./my_images \
  --steps 30 \
  --cfg 7.5
```

### Image to Image
```bash
npx comfycli img2img <input> "<prompt>" [options]
```

**Options:**
- `--negative, -n` - Negative prompt
- `--output, -o` - Output directory
- `--workflow, -w` - Workflow name (default: qwen2511i2i)
- `--strength, -s` - Denoise strength (0-1, default: 0.75)
- `--steps` - Sampling steps
- `--cfg` - CFG scale
- `--seed` - Random seed

**Example:**
```bash
npx comfycli img2img ./photo.jpg "oil painting style" \
  --strength 0.8 \
  --output ./styled
```

### Text to Video
```bash
npx comfycli txt2vid "<prompt>" [options]
```

**Options:**
- `--negative, -n` - Negative prompt
- `--output, -o` - Output directory
- `--workflow, -w` - Workflow name (default: want2v)
- `--format, -f` - Output format: mp4/gif (default: mp4)
- `--fps` - Frames per second
- `--frames` - Total frames
- `--width` - Video width
- `--height` - Video height

**Example:**
```bash
npx comfycli txt2vid "a cat walking in the park" \
  --format gif \
  --fps 24 \
  --frames 60
```

### Image to Video
```bash
npx comfycli img2vid <input> [options]
```

**Options:**
- `--prompt, -p` - Text prompt
- `--negative, -n` - Negative prompt
- `--output, -o` - Output directory
- `--workflow, -w` - Workflow name (default: wani2v)
- `--format, -f` - Output format: mp4/gif (default: mp4)
- `--fps` - Frames per second
- `--frames` - Total frames

**Example:**
```bash
npx comfycli img2vid ./portrait.jpg \
  --prompt "gentle movement" \
  --frames 60
```

## Configuration

### Configuration File Structure

The main configuration file is `config/comfy_config.json`:

```json
{
  "host": "192.168.0.99",
  "port": 10000,
  "api_key": "",
  "prompts": {
    "qwent2i": {
      "description": "Qwen Text to Image",
      "type": "txt2img",
      "api": "config/comfy/txt_to_image_qwen_api.json",
      "data": [
        {"active##6##inputs##text": "##active_prompt##"},
        {"native##7##inputs##text": "##negative_prompt##"}
      ]
    }
  }
}
```

### Adding New Workflows

1. Export your workflow from ComfyUI as API JSON
2. Save it in `config/comfy/` directory
3. Add configuration to `comfy_config.json`:
```json
{
  "prompts": {
    "my_workflow": {
      "description": "My Custom Workflow",
      "type": "txt2img",
      "api": "config/comfy/my_workflow_api.json",
      "data": [
        {"node##id##inputs##field": "##variable_name##"}
      ]
    }
  }
}
```

## Claude Code Integration

This project includes a Claude Code skill for automatic AI generation.

### Usage

Simply ask Claude Code to generate images or videos:
- "Generate an image of a sunset"
- "Transform this image into oil painting style"
- "Create a video of a cat walking"

Claude Code will automatically use the comfy-skill to execute the appropriate commands.

## Development

### Prerequisites
- Node.js >= 18.0.0
- ComfyUI server

### Local Development
```bash
# Install dependencies
npm install

# Run tests
npm test

# Run locally
node src/index.js --help
```

## License

MIT
