const fs = require('fs');
const path = require('path');

// Create a mock Logger since we're testing with require, not import
const mockLogger = {
  error: (...args) => console.log('[ERROR]', ...args),
  warn: (...args) => console.log('[WARN]', ...args),
  info: (...args) => console.log('[INFO]', ...args),
};

// Read and eval the config.js code (replacing import with require)
let code = fs.readFileSync(path.join(__dirname, 'src/utils/config.js'), 'utf-8');
// Remove import/export statements for CommonJS compatibility
code = code.replace(/import fs from 'fs';/, 'const fs = require("fs");');
code = code.replace(/import path from 'path';/, 'const path = require("path");');
code = code.replace(/import Logger from '.\/logger.js';/, 'const Logger = { error: (...a)=>console.log("[ERR]",...a), warn: (...a)=>console.log("[WARN]",...a), info: (...a)=>console.log("[INFO]",...a) };');
code = code.replace(/export default ConfigManager;/, '');

// Eval the code to get ConfigManager class
eval(code);

const configDir = path.join(__dirname, 'config');

// Test 1: Constructor with default paths
console.log('=== Test 1: Constructor defaults ===');
const cm1 = new ConfigManager(path.join(configDir, 'comfy_config.json'));
console.log('serverConfigPath:', cm1.serverConfigPath);
console.log('Expected:', path.join(configDir, 'server_config.json'));
console.log('Match:', cm1.serverConfigPath === path.join(configDir, 'server_config.json'));

// Test 2: Constructor with custom server config path
console.log('\n=== Test 2: Custom server config path ===');
const cm2 = new ConfigManager(
  path.join(configDir, 'comfy_config.json'),
  path.join(configDir, 'custom_server.json')
);
console.log('serverConfigPath:', cm2.serverConfigPath);
console.log('Match:', cm2.serverConfigPath === path.join(configDir, 'custom_server.json'));

// Test 3: Load with both files present
console.log('\n=== Test 3: Load with both files ===');
const cm3 = new ConfigManager(path.join(configDir, 'comfy_config.json'));
const loadResult = cm3.load();
console.log('load() returned:', loadResult);
console.log('loaded:', cm3.loaded);
console.log('config is null:', cm3.config === null);
console.log('serverConfig is null:', cm3.serverConfig === null);
console.log('serverConfig.host:', cm3.serverConfig?.host);
console.log('serverConfig.port:', cm3.serverConfig?.port);

// Test 4: getServerConfig() reads from server_config.json
console.log('\n=== Test 4: getServerConfig() ===');
const serverConfig = cm3.getServerConfig();
console.log('host:', serverConfig.host);
console.log('port:', serverConfig.port);
console.log('apiKey:', serverConfig.apiKey);
console.log('host is 42.121.167.241:', serverConfig.host === '42.121.167.241');
console.log('port is 9010:', serverConfig.port === 9010);

// Test 5: getUploadConfig() reads from server_config.json
console.log('\n=== Test 5: getUploadConfig() ===');
const uploadConfig = cm3.getUploadConfig();
console.log('uploadConfig:', JSON.stringify(uploadConfig, null, 2));
console.log('server is 192.168.0.92:9998:', uploadConfig?.server === '192.168.0.92:9998');

// Test 6: Backward compatibility - server_config.json not found
console.log('\n=== Test 6: Backward compatibility (no server_config.json) ===');
const cm6 = new ConfigManager(path.join(configDir, 'comfy_config.json'), path.join(configDir, 'nonexistent.json'));
cm6.load();
console.log('serverConfig is null:', cm6.serverConfig === null);
// Falls back to comfy_config.json which has no host, so should get defaults
const sc6 = cm6.getServerConfig();
console.log('getServerConfig() fallback defaults - host:', sc6.host, 'port:', sc6.port);
const uc6 = cm6.getUploadConfig();
console.log('getUploadConfig() returns null:', uc6 === null);

// Test 7: Workflows still work (from comfy_config.json)
console.log('\n=== Test 7: Workflows still work ===');
const workflows = cm3.listWorkflows();
console.log('Workflow count:', workflows.length);
console.log('First workflow:', workflows[0]?.name);

// Cleanup
fs.unlinkSync(path.join(__dirname, 'test_dual_config.cjs'));
