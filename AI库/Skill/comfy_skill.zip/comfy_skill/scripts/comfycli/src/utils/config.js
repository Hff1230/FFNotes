import fs from 'fs';
import path from 'path';
import Logger from './logger.js';

// Supported workflow types
const WORKFLOW_TYPES = [
  'txt2img',
  'img2img',
  'txt2vid',
  'img2vid',
  '2img2img',
  '3img2img',
  '4img2img',
  'imagescale'
];

/**
 * ConfigManager class for managing ComfyUI configurations
 */
class ConfigManager {
  /**
   * Create a ConfigManager instance
   * @param {string} configPath - Path to configuration file
   * @param {string|null} serverConfigPath - Path to server configuration file (auto-inferred if null)
   */
  constructor(configPath = './config/comfy_config.json', serverConfigPath = null) {
    this.configPath = configPath;
    this.configDir = path.dirname(path.resolve(configPath));
    this.serverConfigPath = serverConfigPath ||
        path.join(this.configDir, 'server_config.json');
    this.config = null;
    this.serverConfig = null;
    this.loaded = false;
  }

  /**
   * Load configuration file
   * @returns {boolean} Success status
   */
  load() {
    try {
      const resolvedPath = path.resolve(this.configPath);

      if (!fs.existsSync(resolvedPath)) {
        Logger.error(`Configuration file not found: ${resolvedPath}`);
        this.loaded = false;
        return false;
      }

      const content = fs.readFileSync(resolvedPath, 'utf-8');
      this.config = JSON.parse(content);
      this.loaded = true;

      // Attempt to load server configuration (optional, no error if missing)
      const serverPath = path.resolve(this.serverConfigPath);
      if (fs.existsSync(serverPath)) {
        try {
          const serverContent = fs.readFileSync(serverPath, 'utf-8');
          this.serverConfig = JSON.parse(serverContent);
        } catch (error) {
          Logger.warn('Failed to load server config: '+ error.message);
        }
      }

      return true;
    } catch (error) {
      if (error instanceof SyntaxError) {
        Logger.error(`Invalid JSON in configuration file: ${error.message}`);
      } else {
        Logger.error(`Failed to load configuration: ${error.message}`);
      }
      this.loaded = false;
      return false;
    }
  }

  /**
   * List all available workflows
   * @returns {Array<{name: string, description: string, type: string, api: string}>} List of workflows
   */
  listWorkflows() {
    if (!this.loaded) {
      Logger.warn('Configuration not loaded, calling load()');
      this.load();
    }

    if (!this.config || !this.config.prompts) {
      return [];
    }

    const workflows = [];
    for (const [name, promptConfig] of Object.entries(this.config.prompts)) {
      workflows.push({
        name,
        description: promptConfig.description || 'No description',
        type: promptConfig.type || 'unknown',
        api: promptConfig.api || ''
      });
    }

    return workflows;
  }

  /**
   * Get workflow configuration by name
   * @param {string} name - Workflow name
   * @returns {object|null} Workflow configuration or null if not found
   */
  getWorkflow(name) {
    if (!this.loaded) {
      this.load();
    }

    if (!this.config || !this.config.prompts) {
      return null;
    }

    return this.config.prompts[name] || null;
  }

  /**
   * Validate comfy_config.json (workflow configuration)
   * Only validates fields belonging to comfy_config.json.
   * Server-related fields (host, port, api_key) are validated by validateServerConfig().
   * @returns {{valid: boolean, errors: string[]}} Validation result
   */
  validate() {
    const errors = [];

    if (!this.loaded) {
      const loadResult = this.load();
      if (!loadResult) {
        return {
          valid: false,
          errors: ['Failed to load configuration file']
        };
      }
    }

    // Check for required top-level fields
    if (!this.config) {
      errors.push('Configuration is empty or invalid');
      return { valid: false, errors };
    }

    // Check prompts field
    if (!this.config.prompts) {
      errors.push('Missing required field: prompts');
    } else if (typeof this.config.prompts !== 'object') {
      errors.push('Field "prompts" must be an object');
    } else {
      // Validate each prompt
      for (const [promptName, promptConfig] of Object.entries(this.config.prompts)) {
        const promptErrors = this._validatePrompt(promptName, promptConfig);
        errors.push(...promptErrors);
      }
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }

  /**
   * Validate server_config.json (server and upload configuration)
   * - host and port are required
   * - api_key is optional
   * - upload section is entirely optional; if present, its sub-fields are validated
   * @returns {{valid: boolean, errors: string[]}} Validation result
   */
  validateServerConfig() {
    const errors = [];

    if (!this.loaded) {
      const loadResult = this.load();
      if (!loadResult) {
        return {
          valid: false,
          errors: ['Failed to load configuration file']
        };
      }
    }

    // server_config.json is optional; fall back to comfy_config.json for backward compatibility
    const source = this.serverConfig || this.config;

    if (!source) {
      errors.push('No server configuration available (neither server_config.json nor comfy_config.json)');
      return { valid: false, errors };
    }

    // Check host field (required)
    if (!source.host) {
      errors.push('Missing required field: host');
    } else if (typeof source.host !== 'string') {
      errors.push('Field "host" must be a string');
    }

    // Check port field (required)
    if (source.port === undefined) {
      errors.push('Missing required field: port');
    } else if (typeof source.port !== 'number') {
      errors.push('Field "port" must be a number');
    } else if (source.port < 1 || source.port > 65535) {
      errors.push('Field "port" must be between 1 and 65535');
    }

    // Check api_key field (optional, but if present must be string)
    if (source.api_key !== undefined && typeof source.api_key !== 'string') {
      errors.push('Field "api_key" must be a string');
    }

    // Check upload section (entirely optional)
    if (source.upload !== undefined) {
      if (typeof source.upload !== 'object' || source.upload === null) {
        errors.push('Field "upload" must be an object');
      } else {
        if (!source.upload.server || typeof source.upload.server !== 'string') {
          errors.push('Field "upload.server" is required and must be a string');
        }
        if (!source.upload.user || typeof source.upload.user !== 'string') {
          errors.push('Field "upload.user" is required and must be a string');
        }
        if (!source.upload.pwd || typeof source.upload.pwd !== 'string') {
          errors.push('Field "upload.pwd" is required and must be a string');
        }
        if (!source.upload.dir || typeof source.upload.dir !== 'string') {
          errors.push('Field "upload.dir" is required and must be a string');
        }
        if (source.upload.share_url !== undefined && typeof source.upload.share_url !== 'string') {
          errors.push('Field "upload.share_url" must be a string if present');
        }
      }
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }

  /**
   * Validate a single prompt configuration
   * @param {string} name - Prompt name
   * @param {object} promptConfig - Prompt configuration
   * @returns {string[]} Array of error messages
   * @private
   */
  _validatePrompt(name, promptConfig) {
    const errors = [];
    const prefix = `Prompt "${name}":`;

    // Check if promptConfig is an object
    if (typeof promptConfig !== 'object' || promptConfig === null) {
      errors.push(`${prefix} must be an object`);
      return errors;
    }

    // Check description field
    if (!promptConfig.description) {
      errors.push(`${prefix} missing required field: description`);
    } else if (typeof promptConfig.description !== 'string') {
      errors.push(`${prefix} field "description" must be a string`);
    }

    // Check type field
    if (!promptConfig.type) {
      errors.push(`${prefix} missing required field: type`);
    } else if (typeof promptConfig.type !== 'string') {
      errors.push(`${prefix} field "type" must be a string`);
    } else if (!WORKFLOW_TYPES.includes(promptConfig.type)) {
      errors.push(`${prefix} field "type" must be one of: ${WORKFLOW_TYPES.join(', ')}`);
    }

    // Check optional default field
    if (promptConfig.default !== undefined && typeof promptConfig.default !== 'boolean') {
      errors.push(`${prefix} field "default" must be a boolean if present`);
    }

    // Check api field
    if (!promptConfig.api) {
      errors.push(`${prefix} missing required field: api`);
    } else if (typeof promptConfig.api !== 'string') {
      errors.push(`${prefix} field "api" must be a string`);
    } else {
      // Check if API file exists
      const apiPath = path.resolve(this.configDir, promptConfig.api);
      if (!fs.existsSync(apiPath)) {
        errors.push(`${prefix} API file not found: ${apiPath}`);
      } else {
        // Try to parse the API file
        try {
          const apiContent = fs.readFileSync(apiPath, 'utf-8');
          JSON.parse(apiContent);
        } catch (error) {
          errors.push(`${prefix} API file contains invalid JSON: ${error.message}`);
        }
      }
    }

    // Check data field
    if (!promptConfig.data) {
      errors.push(`${prefix} missing required field: data`);
    } else if (!Array.isArray(promptConfig.data)) {
      errors.push(`${prefix} field "data" must be an array`);
    } else {
      // Validate each data entry
      promptConfig.data.forEach((entry, index) => {
        if (typeof entry !== 'object' || entry === null) {
          errors.push(`${prefix} data[${index}] must be an object`);
        } else {
          // Check that data entry keys are in correct format
          for (const key of Object.keys(entry)) {
            if (!key.includes('##')) {
              errors.push(`${prefix} data[${index}] key "${key}" is not in valid format (expected "type##nodeId##inputs##field")`);
            }
          }
        }
      });
    }

    return errors;
  }

  /**
   * Get server configuration
   * Reads from server_config.json first, falls back to comfy_config.json for backward compatibility
   * @returns {{host: string, port: number, apiKey: string}} Server configuration
   */
  getServerConfig() {
    if (!this.loaded) {
      this.load();
    }

    const source = this.serverConfig || this.config;
    return {
      host: source?.host || '127.0.0.1',
      port: source?.port || 8188,
      apiKey: source?.api_key || ''
    };
  }

  /**
   * Load API JSON file
   * @param {string} apiPath - Path to API file
   * @returns {object|null} Parsed API content or null if failed
   */
  loadApiFile(apiPath) {
    try {
      const resolvedPath = path.resolve(this.configDir, apiPath);

      if (!fs.existsSync(resolvedPath)) {
        Logger.error(`API file not found: ${resolvedPath}`);
        return null;
      }

      const content = fs.readFileSync(resolvedPath, 'utf-8');
      return JSON.parse(content);
    } catch (error) {
      if (error instanceof SyntaxError) {
        Logger.error(`Invalid JSON in API file: ${error.message}`);
      } else {
        Logger.error(`Failed to load API file: ${error.message}`);
      }
      return null;
    }
  }

  /**
   * Get the current configuration object
   * @returns {object|null} Configuration object
   */
  getConfig() {
    return this.config;
  }

  /**
   * Check if configuration is loaded
   * @returns {boolean} True if loaded
   */
  isLoaded() {
    return this.loaded;
  }

  /**
   * Get default workflow name for a given type
   * @param {string} type - Workflow type
   * @returns {string|null} Default workflow name or null
   */
  getDefaultWorkflowName(type) {
    const workflows = this.listWorkflows();
    const defaultWorkflow = workflows.find(w =>
      w.type === type && this.config.prompts[w.name]?.default === true
    );

    if (defaultWorkflow) {
      return defaultWorkflow.name;
    }

    // Return first matching workflow if no default
    const firstMatch = workflows.find(w => w.type === type);
    return firstMatch ? firstMatch.name : null;
  }

  /**
   * Resolve a resolution preset alias to width and height
   * @param {string} sizeAlias - Resolution preset name (e.g., 'low', 'mid', 'high', '2k', '4k', '8k')
   * @param {string} orientation - Orientation key: '0' for landscape, '1' for portrait (default: '0')
   * @param {string} resolutionType - Resolution category (e.g., 'pic_gen', 'pic_upscale') (default: 'pic_gen')
   * @returns {{width: number, height: number}|null} Resolved resolution or null if not found
   */
  resolveResolution(sizeAlias, orientation = '0', resolutionType = 'pic_gen') {
    if (!this.loaded) {
      this.load();
    }

    if (!this.config || !this.config.resolution) {
      return null;
    }

    const typeConfig = this.config.resolution[resolutionType];
    if (!typeConfig) {
      return null;
    }

    const orientationList = typeConfig[orientation];
    if (!Array.isArray(orientationList)) {
      return null;
    }

    const entry = orientationList.find(item => item.name === sizeAlias);
    if (!entry) {
      return null;
    }

    return { width: entry.width, height: entry.height };
  }

  /**
   * List all available resolution presets for a given resolution type
   * @param {string} resolutionType - Resolution category (e.g., 'pic_gen', 'pic_upscale') (default: 'pic_gen')
   * @returns {object|null} Resolution presets grouped by orientation, or null if not found
   */
  listResolutions(resolutionType = 'pic_gen') {
    if (!this.loaded) {
      this.load();
    }

    if (!this.config || !this.config.resolution) {
      return null;
    }

    const typeConfig = this.config.resolution[resolutionType];
    if (!typeConfig) {
      return null;
    }

    return typeConfig;
  }

  /**
   * Get all available resolution type keys
   * @returns {string[]} Array of resolution type names (e.g., ['pic_gen', 'pic_upscale'])
   */
  getResolutionTypes() {
    if (!this.loaded) {
      this.load();
    }

    if (!this.config || !this.config.resolution) {
      return [];
    }

    return Object.keys(this.config.resolution);
  }

  /**
   * Get upload configuration
   * Reads from server_config.json first, falls back to comfy_config.json for backward compatibility
   * @returns {{server: string, user: string, pwd: string, dir: string, share_url: string}|null} Upload configuration or null if not configured
   */
  getUploadConfig() {
    if (!this.loaded) {
      this.load();
    }

    const source = this.serverConfig || this.config;
    if (!source || !source.upload) {
      return null;
    }

    return {
      server: source.upload.server || '',
      user: source.upload.user || '',
      pwd: source.upload.pwd || '',
      dir: source.upload.dir || '',
      share_url: source.upload.share_url || ''
    };
  }

  /**
   * Get default upload setting
   * Reads from server_config.json first, falls back to comfy_config.json
   * @returns {boolean} Default upload setting (default: true)
   */
  getDefaultUpload() {
    if (!this.loaded) {
      this.load();
    }

    const source = this.serverConfig || this.config;
    if (!source || source.uploadDefault === undefined) {
      return true;
    }

    return source.uploadDefault === true;
  }
}

export default ConfigManager;
