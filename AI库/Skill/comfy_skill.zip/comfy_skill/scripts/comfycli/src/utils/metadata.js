import fs from 'fs';
import path from 'path';

/**
 * Determine if a CLIPTextEncode node is the positive prompt
 * by checking its connections in the workflow
 * @param {string} nodeId - The node ID to check
 * @param {object} prompt - The workflow prompt object
 * @returns {boolean} True if this is the positive prompt node
 */
function isPositivePrompt(nodeId, prompt) {
  // Find nodes that connect to this CLIPTextEncode node
  // Typically, positive prompts connect to KSampler's positive input
  // Negative prompts connect to KSampler's negative input

  for (const [id, node] of Object.entries(prompt)) {
    if (node.class_type === 'KSampler' || node.class_type === 'KSampler (advanced)') {
      const inputs = node.inputs || {};
      // Check if this node is connected as positive prompt
      // Connection format: ["nodeId", outputIndex]
      if (Array.isArray(inputs.positive) && inputs.positive[0] === nodeId) {
        return true;
      }
    }
  }

  // If we can't determine by connection, use heuristic:
  // Check if there's a connection to negative input
  for (const [id, node] of Object.entries(prompt)) {
    if (node.class_type === 'KSampler' || node.class_type === 'KSampler (advanced)') {
      const inputs = node.inputs || {};
      if (Array.isArray(inputs.negative) && inputs.negative[0] === nodeId) {
        return false;
      }
    }
  }

  // Default: first CLIPTextEncode is positive, second is negative
  // This is a fallback when connection info is not available
  return true;
}

/**
 * Extract metadata from ComfyUI history data
 * @param {object} historyData - The data returned from /history/{prompt_id} API
 * @param {string} workflowName - Name of the workflow
 * @param {object} options - Additional options
 * @param {string} options.promptId - The prompt ID
 * @param {string} options.inputPath - Input image path (optional)
 * @param {string} options.outputFilename - Output filename (optional)
 * @returns {object} Metadata object
 */
export function extractMetadata(historyData, workflowName, options = {}) {
  // Get the prompt section from history data
  // History API returns: { prompt_id: { prompt: {...}, outputs: {...} } }
  let promptData = historyData;

  // Handle case where historyData is wrapped with prompt_id
  if (historyData && typeof historyData === 'object') {
    const keys = Object.keys(historyData);
    if (keys.length === 1 && historyData[keys[0]]?.prompt) {
      promptData = historyData[keys[0]];
    }
  }

  const prompt = promptData.prompt || promptData || {};

  // Initialize metadata with base fields
  const metadata = {
    workflow: workflowName,
    timestamp: new Date().toISOString(),
    prompt_id: options.promptId || null,
    input_image: options.inputPath || null,
    output_filename: options.outputFilename || null
  };

  // Track CLIPTextEncode nodes to distinguish positive/negative prompts
  const clipNodes = [];

  // First pass: collect all nodes by type
  for (const [nodeId, node] of Object.entries(prompt)) {
    const classType = node.class_type;
    const inputs = node.inputs || {};

    switch (classType) {
      case 'KSampler':
      case 'KSampler (advanced)':
        metadata.seed = inputs.seed;
        metadata.steps = inputs.steps;
        metadata.cfg = inputs.cfg;
        metadata.sampler_name = inputs.sampler_name;
        metadata.scheduler = inputs.scheduler;
        metadata.denoise = inputs.denoise;
        break;

      case 'CLIPTextEncode':
        if (inputs.text !== undefined) {
          clipNodes.push({
            nodeId,
            text: inputs.text,
            inputs: node.inputs
          });
        }
        break;

      case 'EmptyLatentImage':
        metadata.width = inputs.width;
        metadata.height = inputs.height;
        break;

      case 'CheckpointLoaderSimple':
        metadata.model = inputs.ckpt_name;
        break;

      // Additional loaders that might be used
      case 'CheckpointLoader':
        metadata.model = inputs.ckpt_name;
        break;

      // Handle VAELoader
      case 'VAELoader':
        if (!metadata.vae) {
          metadata.vae = inputs.vae_name;
        }
        break;

      // Handle LoraLoader
      case 'LoraLoader':
        if (!metadata.lora) {
          metadata.lora = [];
        }
        metadata.lora.push({
          name: inputs.lora_name,
          strength_model: inputs.strength_model,
          strength_clip: inputs.strength_clip
        });
        break;
    }
  }

  // Second pass: determine positive/negative prompts
  // Method 1: Check connections to KSampler
  let positiveFound = false;
  let negativeFound = false;

  for (const clipNode of clipNodes) {
    // Check if this node connects to KSampler positive/negative
    let isPositive = null;

    for (const [nodeId, node] of Object.entries(prompt)) {
      if (node.class_type === 'KSampler' || node.class_type === 'KSampler (advanced)') {
        const inputs = node.inputs || {};

        // Check positive connection
        if (Array.isArray(inputs.positive)) {
          const connectedNodeId = String(inputs.positive[0]);
          if (connectedNodeId === clipNode.nodeId) {
            isPositive = true;
            break;
          }
        }

        // Check negative connection
        if (Array.isArray(inputs.negative)) {
          const connectedNodeId = String(inputs.negative[0]);
          if (connectedNodeId === clipNode.nodeId) {
            isPositive = false;
            break;
          }
        }
      }
    }

    // Assign prompts based on connection analysis
    if (isPositive === true && !positiveFound) {
      metadata.prompt = clipNode.text;
      positiveFound = true;
    } else if (isPositive === false && !negativeFound) {
      metadata.negative_prompt = clipNode.text;
      negativeFound = true;
    }
  }

  // Fallback: If we couldn't determine by connections, use position-based heuristics
  // First CLIPTextEncode is usually positive, second is negative
  if (!positiveFound && clipNodes.length > 0) {
    metadata.prompt = clipNodes[0].text;
  }
  if (!negativeFound && clipNodes.length > 1) {
    metadata.negative_prompt = clipNodes[1].text;
  }

  return metadata;
}

/**
 * Save metadata to a JSON file
 * @param {string} imageFilename - The image filename (will be used to generate JSON filename)
 * @param {object} metadata - The metadata object to save
 * @param {string} outputDir - The output directory
 * @returns {Promise<string>} Path to the saved JSON file
 */
export async function saveMetadata(imageFilename, metadata, outputDir) {
  // Generate JSON filename by replacing the extension
  const jsonFilename = imageFilename.replace(/\.[^.]+$/, '.json');
  const jsonPath = path.join(outputDir, jsonFilename);

  // Ensure output directory exists
  await fs.promises.mkdir(outputDir, { recursive: true });

  // Write JSON file with pretty formatting
  await fs.promises.writeFile(jsonPath, JSON.stringify(metadata, null, 2), 'utf-8');

  return jsonPath;
}

/**
 * Extract output filename from history data
 * @param {object} historyData - The history data from API
 * @returns {string|null} The output filename or null
 */
export function extractOutputFilename(historyData) {
  let promptData = historyData;

  // Handle case where historyData is wrapped with prompt_id
  if (historyData && typeof historyData === 'object') {
    const keys = Object.keys(historyData);
    if (keys.length === 1 && historyData[keys[0]]?.outputs) {
      promptData = historyData[keys[0]];
    }
  }

  const outputs = promptData.outputs || {};

  // Find the first image output
  for (const [nodeId, nodeOutput] of Object.entries(outputs)) {
    if (nodeOutput.images && nodeOutput.images.length > 0) {
      return nodeOutput.images[0].filename;
    }
    // Also check for videos/GIFs
    if (nodeOutput.videos && nodeOutput.videos.length > 0) {
      return nodeOutput.videos[0].filename;
    }
    if (nodeOutput.gifs && nodeOutput.gifs.length > 0) {
      return nodeOutput.gifs[0].filename;
    }
  }

  return null;
}

/**
 * Extract all output files from history data
 * @param {object} historyData - The history data from API
 * @returns {Array} Array of output file info objects
 */
export function extractOutputFiles(historyData) {
  const files = [];
  let promptData = historyData;

  // Handle case where historyData is wrapped with prompt_id
  if (historyData && typeof historyData === 'object') {
    const keys = Object.keys(historyData);
    if (keys.length === 1 && historyData[keys[0]]?.outputs) {
      promptData = historyData[keys[0]];
    }
  }

  const outputs = promptData.outputs || {};

  for (const [nodeId, nodeOutput] of Object.entries(outputs)) {
    // Images
    if (nodeOutput.images) {
      for (const image of nodeOutput.images) {
        files.push({
          type: 'image',
          filename: image.filename,
          subfolder: image.subfolder || '',
          nodeType: image.type || 'output'
        });
      }
    }

    // Videos
    if (nodeOutput.videos) {
      for (const video of nodeOutput.videos) {
        files.push({
          type: 'video',
          filename: video.filename,
          subfolder: video.subfolder || '',
          format: video.format || 'mp4'
        });
      }
    }

    // GIFs
    if (nodeOutput.gifs) {
      for (const gif of nodeOutput.gifs) {
        files.push({
          type: 'gif',
          filename: gif.filename,
          subfolder: gif.subfolder || '',
          format: gif.format || 'gif'
        });
      }
    }
  }

  return files;
}

/**
 * Save metadata for all output images
 * @param {Object} outputs - The outputs object from history (contains images by node id)
 * @param {Object} metadata - The metadata object to save for each image
 * @param {string} outputDir - The output directory path
 * @returns {Promise<string[]>} Array of paths to saved metadata files
 */
export async function saveMetadataForOutput(outputs, metadata, outputDir) {
  const savedPaths = [];

  if (!outputs || typeof outputs !== 'object') {
    return savedPaths;
  }

  // Iterate through each node's output
  for (const nodeId of Object.keys(outputs)) {
    const nodeOutput = outputs[nodeId];

    // Check if the output has images
    if (nodeOutput.images && Array.isArray(nodeOutput.images)) {
      for (const imageInfo of nodeOutput.images) {
        // Get the filename from the image info
        const filename = imageInfo.filename || imageInfo;

        if (typeof filename === 'string' && filename.length > 0) {
          try {
            const savedPath = await saveMetadata(filename, metadata, outputDir);
            savedPaths.push(savedPath);
          } catch (error) {
            console.error(`Error saving metadata for ${filename}:`, error.message);
          }
        }
      }
    }
  }

  return savedPaths;
}

export default {
  extractMetadata,
  saveMetadata,
  saveMetadataForOutput,
  extractOutputFilename,
  extractOutputFiles
};
