import fs from 'fs';
import path from 'path';
import Logger from './logger.js';

/**
 * DufsUploader class for uploading files to dufs server
 * Documentation: https://deepwiki.com/sigoden/dufs/8-http-api-reference
 */
class DufsUploader {
  /**
   * Create a DufsUploader instance
   * @param {object} uploadConfig - Upload configuration
   * @param {string} uploadConfig.server - Server address (e.g., '192.168.0.92:9998')
   * @param {string} uploadConfig.user - Username for authentication
   * @param {string} uploadConfig.pwd - Password for authentication
   * @param {string} uploadConfig.dir - Base directory on server (e.g., 'comfy')
   * @param {string} uploadConfig.share_url - Share URL prefix for public access (e.g., 'http://47.109.205.195:10020')
   */
  constructor(uploadConfig) {
    this.server = uploadConfig.server;
    this.user = uploadConfig.user;
    this.pwd = uploadConfig.pwd;
    this.baseDir = uploadConfig.dir || '';
    this.baseUrl = `http://${uploadConfig.server}`;
    this.shareUrl = uploadConfig.share_url || '';
  }

  /**
   * Generate date path in format: YYYY-M-D (e.g., 2026-3-30)
   * @returns {string} Date path string
   */
  generateDatePath() {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth() + 1;
    const day = now.getDate();
    return `${year}-${month}-${day}`;
  }

  /**
   * Get full remote path for a file
   * @param {string} filename - Filename to upload
   * @returns {string} Full remote path
   */
  getRemotePath(filename) {
    const datePath = this.generateDatePath();
    if (this.baseDir) {
      return `/${this.baseDir}/${datePath}/${filename}`;
    }
    return `/${datePath}/${filename}`;
  }

  /**
   * Get project-based remote path for a file
   * @param {string} filename - Filename to upload
   * @param {string} project - Project name
   * @param {string} category - Category within the project
   * @returns {string} Full remote path with project structure
   */
  getProjectRemotePath(filename, project, category) {
    return `/projects/${project}/${category}/${filename}`;
  }

  /**
   * Get remote directory path
   * @returns {string} Remote directory path
   */
  getRemoteDirPath() {
    const datePath = this.generateDatePath();
    if (this.baseDir) {
      return `/${this.baseDir}/${datePath}/`;
    }
    return `/${datePath}/`;
  }

  /**
   * Create authorization header value
   * @returns {string} Basic auth header value
   */
  getAuthHeader() {
    const credentials = Buffer.from(`${this.user}:${this.pwd}`).toString('base64');
    return `Basic ${credentials}`;
  }

  /**
   * Ensure remote directory exists by creating a .placeholder file
   * dufs automatically creates parent directories when uploading files
   * @returns {Promise<boolean>} Success status
   */
  async ensureDirectoryExists() {
    try {
      const dirPath = this.getRemoteDirPath();
      // dufs creates directories automatically when uploading files
      // No need to explicitly create directory
      Logger.debug(`Remote directory will be: ${dirPath}`);
      return true;
    } catch (error) {
      Logger.error(`Failed to ensure directory: ${error.message}`);
      return false;
    }
  }

  /**
   * Upload a single file to dufs server
   * @param {string} localPath - Local file path
   * @param {string} remoteFilename - Remote filename (optional, uses local filename if not provided)
   * @returns {Promise<{success: boolean, url?: string, error?: string}>} Upload result
   */
  async uploadFile(localPath, remoteFilename = null, options = {}) {
    try {
      // Check if local file exists
      if (!fs.existsSync(localPath)) {
        return {
          success: false,
          error: `Local file not found: ${localPath}`
        };
      }

      // Get filename
      const filename = remoteFilename || path.basename(localPath);
      let remotePath;
      if (options.project && options.category) {
        remotePath = this.getProjectRemotePath(filename, options.project, options.category);
      } else {
        remotePath = this.getRemotePath(filename);
      }

      // Read file content
      const fileContent = fs.readFileSync(localPath);

      // Construct upload URL
      const uploadUrl = `${this.baseUrl}${remotePath}`;

      Logger.debug(`Uploading ${localPath} to ${uploadUrl}`);

      // Make PUT request to upload file
      // dufs API: PUT /path/to/file creates new file or overwrites existing
      const response = await fetch(uploadUrl, {
        method: 'PUT',
        headers: {
          'Authorization': this.getAuthHeader(),
          'Content-Type': 'application/octet-stream'
        },
        body: fileContent
      });

      if (response.status === 201 || response.status === 200) {
        const publicUrl = uploadUrl;
        Logger.info(`Uploaded: ${publicUrl}`);
        return {
          success: true,
          url: publicUrl
        };
      } else if (response.status === 401) {
        const errorText = await response.text();
        return {
          success: false,
          error: `Authentication failed: ${errorText}`
        };
      } else if (response.status === 403) {
        const errorText = await response.text();
        return {
          success: false,
          error: `Upload forbidden: ${errorText}`
        };
      } else {
        const errorText = await response.text();
        return {
          success: false,
          error: `Upload failed with status ${response.status}: ${errorText}`
        };
      }
    } catch (error) {
      Logger.error(`Upload error: ${error.message}`);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Upload multiple files to dufs server
   * @param {string[]} localPaths - Array of local file paths
   * @returns {Promise<{success: boolean, results: Array<{local: string, success: boolean, url?: string, error?: string}>}>} Upload results
   */
  async uploadFiles(localPaths, options = {}) {
    const results = [];

    for (const localPath of localPaths) {
      const result = await this.uploadFile(localPath, null, options);
      results.push({
        local: localPath,
        ...result
      });
    }

    const successCount = results.filter(r => r.success).length;
    Logger.info(`Uploaded ${successCount}/${results.length} files`);

    return {
      success: successCount === results.length,
      results
    };
  }

  /**
   * Get public URL for a file (without uploading)
   * @param {string} filename - Filename
   * @returns {string} Public URL
   */
  getPublicUrl(filename) {
    const remotePath = this.getRemotePath(filename);
    return `${this.baseUrl}${remotePath}`;
  }

  /**
   * Get public URL for remote directory
   * @returns {string} Public URL for directory
   */
  getDirUrl() {
    const dirPath = this.getRemoteDirPath();
    return `${this.baseUrl}${dirPath}`;
  }

  /**
   * Get share URL for a file (using share_url if configured)
   * @param {string} filename - Filename
   * @returns {string} Share URL for the file
   */
  getShareUrl(filename) {
    const remotePath = this.getRemotePath(filename);
    if (this.shareUrl) {
      return `${this.shareUrl}${remotePath}`;
    }
    return `${this.baseUrl}${remotePath}`;
  }

  /**
   * Get share URL for a project-based file (using share_url if configured)
   * @param {string} filename - Filename
   * @param {string} project - Project name
   * @param {string} category - Category within the project
   * @returns {string} Share URL for the file
   */
  getProjectShareUrl(filename, project, category) {
    const remotePath = this.getProjectRemotePath(filename, project, category);
    if (this.shareUrl) {
      return `${this.shareUrl}${remotePath}`;
    }
    return `${this.baseUrl}${remotePath}`;
  }

  /**
   * Get share URL for remote directory (using share_url if configured)
   * @returns {string} Share URL for directory
   */
  getShareDirUrl() {
    const dirPath = this.getRemoteDirPath();
    if (this.shareUrl) {
      return `${this.shareUrl}${dirPath}`;
    }
    return `${this.baseUrl}${dirPath}`;
  }
}

export default DufsUploader;
