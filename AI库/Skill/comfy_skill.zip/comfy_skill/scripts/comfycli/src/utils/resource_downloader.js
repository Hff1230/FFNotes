import path from 'path';
import fs from 'fs';

/**
 * 检测输入是否为HTTP/HTTPS URL
 * @param {string} input - 输入字符串
 * @returns {boolean} - 是否为有效的HTTP/HTTPS URL
 */
function isUrl(input) {
  // 空值或非字符串返回 false
  if (!input || typeof input !== 'string') {
    return false;
  }

  try {
    const url = new URL(input);
    // 只接受 http: 或 https: 协议
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch (e) {
    return false;
  }
}

/**
 * 从URL提取文件名
 * @param {string} url - URL字符串
 * @returns {string} - 提取的文件名
 */
function getFilenameFromUrl(url) {
  try {
    const urlObj = new URL(url);
    // 从 pathname 中提取 basename
    const basename = path.basename(urlObj.pathname);

    // 检查是否有有效扩展名
    const ext = path.extname(basename);
    if (ext && ext.length > 1) {
      return basename;
    }

    // 如果没有有效扩展名，生成 download_${timestamp} 格式名称
    const timestamp = Date.now();
    return `download_${timestamp}`;
  } catch (e) {
    // URL 解析失败，生成默认文件名
    const timestamp = Date.now();
    return `download_${timestamp}`;
  }
}

/**
 * 下载资源到临时目录
 * @param {string} url - 要下载的URL
 * @param {string} tmpDir - 临时目录路径，默认为 './tmp'
 * @returns {Promise<string>} - 下载后的本地文件路径
 */
async function downloadResource(url, tmpDir = './tmp') {
  // 创建目录（如果不存在）
  if (!fs.existsSync(tmpDir)) {
    fs.mkdirSync(tmpDir, { recursive: true });
  }

  // 获取文件名
  let filename = getFilenameFromUrl(url);
  let filepath = path.join(tmpDir, filename);

  // 处理文件名冲突（追加序号）
  if (fs.existsSync(filepath)) {
    const ext = path.extname(filename);
    const nameWithoutExt = path.basename(filename, ext);
    let counter = 1;

    while (fs.existsSync(filepath)) {
      filename = `${nameWithoutExt}_${counter}${ext}`;
      filepath = path.join(tmpDir, filename);
      counter++;
    }
  }

  // 使用 fetch 下载
  const response = await fetch(url);

  // HTTP 错误时抛出包含状态码的异常
  if (!response.ok) {
    throw new Error(`Failed to download resource: HTTP ${response.status}`);
  }

  // 获取数据并写入文件
  const arrayBuffer = await response.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);
  fs.writeFileSync(filepath, buffer);

  return filepath;
}

/**
 * 统一入口（单个）- 处理单个输入资源
 * @param {string} input - 输入（URL或本地路径）
 * @param {string} tmpDir - 临时目录路径，默认为 './tmp'
 * @returns {Promise<{localPath: string, wasDownloaded: boolean}>} - 本地路径和是否下载标志
 */
async function resolveInputResource(input, tmpDir = './tmp') {
  if (isUrl(input)) {
    // URL → 下载 → 返回 {localPath, wasDownloaded: true}
    const localPath = await downloadResource(input, tmpDir);
    return { localPath, wasDownloaded: true };
  } else {
    // 本地路径 → 返回 {localPath: input, wasDownloaded: false}
    return { localPath: input, wasDownloaded: false };
  }
}

/**
 * 批量版本 - 处理多个输入资源
 * @param {string[]} inputs - 输入数组（URL或本地路径）
 * @param {string} tmpDir - 临时目录路径，默认为 './tmp'
 * @returns {Promise<{localPaths: string[], downloaded: string[]}>} - 本地路径数组和已下载的路径数组
 */
async function resolveInputResources(inputs, tmpDir = './tmp') {
  const localPaths = [];
  const downloaded = [];

  for (const input of inputs) {
    const result = await resolveInputResource(input, tmpDir);
    localPaths.push(result.localPath);
    if (result.wasDownloaded) {
      downloaded.push(result.localPath);
    }
  }

  return { localPaths, downloaded };
}

// Named exports
export { isUrl, getFilenameFromUrl, downloadResource, resolveInputResource, resolveInputResources };

// Default export
export default {
  isUrl,
  getFilenameFromUrl,
  downloadResource,
  resolveInputResource,
  resolveInputResources
};
