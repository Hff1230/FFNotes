import chalk from 'chalk';

/**
 * Logger class for colored console output
 */
class Logger {
  /**
   * Log with timestamp and color
   * @param {string} level - Log level
   * @param {string} message - Message to log
   * @param {Function} colorFn - Chalk color function
   */
  static _log(level, message, colorFn = chalk.white) {
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const formattedMessage = `[${timestamp}] [${level}] ${message}`;
    console.log(colorFn(formattedMessage));
  }

  /**
   * Log info message (white)
   * @param {string} message - Message to log
   */
  static info(message) {
    this._log('INFO', message, chalk.white);
  }

  /**
   * Log success message (green)
   * @param {string} message - Message to log
   */
  static success(message) {
    this._log('SUCCESS', message, chalk.green);
  }

  /**
   * Log warning message (yellow)
   * @param {string} message - Message to log
   */
  static warn(message) {
    this._log('WARN', message, chalk.yellow);
  }

  /**
   * Log error message (red)
   * @param {string} message - Message to log
   */
  static error(message) {
    this._log('ERROR', message, chalk.red);
  }

  /**
   * Log debug message (gray)
   * @param {string} message - Message to log
   */
  static debug(message) {
    this._log('DEBUG', message, chalk.gray);
  }

  /**
   * Log info blue message (blue)
   * @param {string} message - Message to log
   */
  static infoBlue(message) {
    this._log('INFO', message, chalk.blue);
  }

  /**
   * Log info cyan message (cyan)
   * @param {string} message - Message to log
   */
  static infoCyan(message) {
    this._log('INFO', message, chalk.cyan);
  }

  /**
   * Log info magenta message (magenta)
   * @param {string} message - Message to log
   */
  static infoMagenta(message) {
    this._log('INFO', message, chalk.magenta);
  }

  /**
   * Log exception with stack trace
   * @param {Error} error - Error object
   * @param {string} label - Label for the exception
   */
  static exception(error, label = 'Exception') {
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const errorMessage = error instanceof Error ? error.message : String(error);
    const stackTrace = error instanceof Error ? error.stack : '';

    const formattedMessage = `[${timestamp}] [ERROR] ${label}\n${errorMessage}\n${stackTrace}`;
    console.log(chalk.red(formattedMessage));
  }
}

export default Logger;
