const fs = require('fs');
const path = require('path');

const filepath = path.join(__dirname, 'config.js');
let content = fs.readFileSync(filepath, 'utf-8');

// 1. Replace constructor: add serverConfigPath parameter and serverConfig property
content = content.replace(
  /constructor\(configPath = '\.\/config\/comfy_config\.json'\) \{[\s\S]*?this\.loaded = false;\s*\n  \}/,
  `constructor(configPath = './config/comfy_config.json', serverConfigPath = null) {
    this.configPath = configPath;
    this.configDir = path.dirname(path.resolve(configPath));
    this.serverConfigPath = serverConfigPath ||
        path.join(this.configDir, 'server_config.json');
    this.config = null;
    this.serverConfig = null;
    this.loaded = false;
  }`
);

// 2. Replace load() method: add server config loading after comfy config is loaded
content = content.replace(
  /      const content = fs\.readFileSync\(resolvedPath, 'utf-8'\);\n      this\.config = JSON\.parse\(content\);\n      this\.loaded = true;\n\n      return true;/,
  `      const content = fs.readFileSync(resolvedPath, 'utf-8');
      this.config = JSON.parse(content);
      this.loaded = true;

      // Attempt to load server configuration (optional, no error if missing)
      const serverPath = path.resolve(this.serverConfigPath);
      if (fs.existsSync(serverPath)) {
        try {
          const serverContent = fs.readFileSync(serverPath, 'utf-8');
          this.serverConfig = JSON.parse(serverContent);
        } catch (error) {
          Logger.warn(\`Failed to load server config: \${error.message}\`);
        }
      }

      return true;`
);

// 3. Replace getServerConfig(): prioritize serverConfig over config
content = content.replace(
  /getServerConfig\(\) \{\n    if \(!this\.loaded\) \{\n      this\.load\(\);\n    \}\n\n    return \{\n      host: this\.config\?\.host \|\| '127\.0\.0\.1',\n      port: this\.config\?\.port \|\| 8188,\n      apiKey: this\.config\?\.api_key \|\| ''\n    \};\n  \}/,
  `getServerConfig() {
    if (!this.loaded) {
      this.load();
    }

    const source = this.serverConfig || this.config;
    return {
      host: source?.host || '127.0.0.1',
      port: source?.port || 8188,
      apiKey: source?.api_key || ''
    };
  }`
);

// 4. Replace getUploadConfig(): prioritize serverConfig, return null when not configured
content = content.replace(
  /getUploadConfig\(\) \{\n    if \(!this\.loaded\) \{\n      this\.load\(\);\n    \}\n\n    if \(!this\.config \|\| !this\.config\.upload\) \{\n      return null;\n    \}\n\n    return \{\n      server: this\.config\.upload\.server \|\| '',\n      user: this\.config\.upload\.user \|\| '',\n      pwd: this\.config\.upload\.pwd \|\| '',\n      dir: this\.config\.upload\.dir \|\| '',\n      share_url: this\.config\.upload\.share_url \|\| ''\n    \};\n  \}/,
  `getUploadConfig() {
    if (!this.loaded) {
      this.load();
    }

    const source = this.serverConfig || this.config;
    if (!source || !source.upload) {
      return null;
    }

    return {
      server: source.upload.server || '',
      user: source.upload.user || '',
      pwd: source.upload.pwd || '',
      dir: source.upload.dir || '',
      share_url: source.upload.share_url || ''
    };
  }`
);

// 5. Replace getDefaultUpload(): prioritize serverConfig over config
content = content.replace(
  /getDefaultUpload\(\) \{\n    if \(!this\.loaded\) \{\n      this\.load\(\);\n    \}\n\n    if \(!this\.config \|\| this\.config\.uploadDefault === undefined\) \{\n      return true;\n    \}\n\n    return this\.config\.uploadDefault === true;\n  \}/,
  `getDefaultUpload() {
    if (!this.loaded) {
      this.load();
    }

    const source = this.serverConfig || this.config;
    if (!source || source.uploadDefault === undefined) {
      return true;
    }

    return source.uploadDefault === true;
  }`
);

// 6. Update JSDoc for constructor
content = content.replace(
  /   \* @param \{string\} configPath - Path to configuration file\n   \*\/\n  constructor/,
  `   * @param {string} configPath - Path to configuration file
   * @param {string|null} serverConfigPath - Path to server configuration file (auto-inferred if null)
   */
  constructor`
);

// 7. Update JSDoc for getServerConfig
content = content.replace(
  /   \* Get server configuration\n   \* @returns \{\{host: string, port: number, apiKey: string\}\} Server configuration\n   \*\//,
  `   * Get server configuration
   * Reads from server_config.json first, falls back to comfy_config.json for backward compatibility
   * @returns {{host: string, port: number, apiKey: string}} Server configuration
   */`
);

// 8. Update JSDoc for getUploadConfig
content = content.replace(
  /   \* Get upload configuration\n   \* @returns \{\{server: string, user: string, pwd: string, dir: string, share_url: string\}\|null\} Upload configuration or null if not configured\n   \*\//,
  `   * Get upload configuration
   * Reads from server_config.json first, falls back to comfy_config.json for backward compatibility
   * @returns {{server: string, user: string, pwd: string, dir: string, share_url: string}|null} Upload configuration or null if not configured
   */`
);

// 9. Update JSDoc for getDefaultUpload
content = content.replace(
  /   \* Get default upload setting\n   \* @returns \{boolean\} Default upload setting \(default: true\)\n   \*\//,
  `   * Get default upload setting
   * Reads from server_config.json first, falls back to comfy_config.json
   * @returns {boolean} Default upload setting (default: true)
   */`
);

fs.writeFileSync(filepath, content, 'utf-8');
console.log('config.js patched successfully');
