import path from 'path';
import Logger from '../utils/logger.js';

// Type families for related workflows
const TYPE_FAMILIES = {
  img2img: ['img2img', '2img2img', '3img2img', '4img2img'],
  txt2img: ['txt2img'],
  txt2vid: ['txt2vid'],
  img2vid: ['img2vid'],
  '2img2video': ['2img2video'],
  imagescale: ['imagescale'],
};

/**
 * Find default workflow for a given type
 * @param {Array} workflows - List of workflows from config
 * @param {string} type - Workflow type
 * @returns {object|null} Default workflow or first one if no default set
 */
export function findDefaultWorkflow(workflows, type) {
  // Filter workflows by type (or type family)
  const typeFamily = TYPE_FAMILIES[type] || [type];
  const matchingWorkflows = workflows.filter(w => typeFamily.includes(w.type));

  if (matchingWorkflows.length === 0) {
    return null;
  }

  // Find workflow with default: true
  const defaultWorkflow = matchingWorkflows.find(w => w.default === true);
  if (defaultWorkflow) {
    return defaultWorkflow;
  }

  // Return first matching workflow if no default
  return matchingWorkflows[0];
}

/**
 * Replace workflow variables with provided values
 * @param {object} workflow - Workflow object
 * @param {object} data - Data configuration array
 * @param {object} values - Variable values to replace
 * @returns {object} Modified workflow
 */
export function replaceVariables(workflow, data, values) {
  // Create a deep copy of the workflow
  const modifiedWorkflow = JSON.parse(JSON.stringify(workflow));

  // If data is provided, use it for variable replacement
  if (data && Array.isArray(data)) {
    for (const entry of data) {
      for (const [key, valueTemplate] of Object.entries(entry)) {
        // Parse the key format: type##nodeId##inputs##field
        const parts = key.split('##');
        if (parts.length >= 4) {
          const nodeType = parts[0];
          const nodeId = parts[1];
          const fieldType = parts[2];
          const fieldName = parts[3];

          // Check if node exists
          if (modifiedWorkflow[nodeId] && modifiedWorkflow[nodeId][fieldType]) {
            // Replace variables in the value template
            let finalValue = valueTemplate;
            for (const [varName, varValue] of Object.entries(values)) {
              const placeholder = `##${varName}##`;
              if (finalValue.includes(placeholder)) {
                // Skip replacement if value is undefined or null, preserve template placeholder
                if (varValue === undefined || varValue === null) {
                  continue;
                }
                finalValue = finalValue.replace(new RegExp(placeholder, 'g'), String(varValue));
              }
            }

            // Check if finalValue still contains unresolved placeholders
            // If so, don't update the field - preserve the original workflow default value
            const hasUnresolvedPlaceholders = /##[^#]+##/.test(finalValue);
            if (!hasUnresolvedPlaceholders) {
              modifiedWorkflow[nodeId][fieldType][fieldName] = finalValue;
            }
          }
        }
      }
    }
  } else {
    // Fallback: replace ##var## placeholders in all string inputs
    for (const key in modifiedWorkflow) {
      const node = modifiedWorkflow[key];
      if (node.inputs) {
        for (const inputKey in node.inputs) {
          let value = node.inputs[inputKey];
          if (typeof value === 'string') {
            // Replace all ##var## placeholders
            for (const [varName, varValue] of Object.entries(values)) {
              const placeholder = `##${varName}##`;
              if (value.includes(placeholder)) {
                // Skip replacement if value is undefined or null, preserve template placeholder
                if (varValue === undefined || varValue === null) {
                  continue;
                }
                value = value.replace(new RegExp(placeholder, 'g'), String(varValue));
              }
            }
            // Only update if no unresolved placeholders remain
            const hasUnresolvedPlaceholders = /##[^#]+##/.test(value);
            if (!hasUnresolvedPlaceholders) {
              node.inputs[inputKey] = value;
            }
          }
        }
      }
    }
  }

  return modifiedWorkflow;
}

/**
 * Validate workflow format
 * @param {object} workflow - Workflow object to validate
 * @returns {{valid: boolean, errors: string[]}} Validation result
 */
export function validateWorkflow(workflow) {
  const errors = [];

  if (!workflow || typeof workflow !== 'object') {
    errors.push('Workflow must be an object');
    return { valid: false, errors };
  }

  if (Object.keys(workflow).length === 0) {
    errors.push('Workflow is empty');
    return { valid: false, errors };
  }

  // Validate each node
  for (const [nodeId, node] of Object.entries(workflow)) {
    if (!node || typeof node !== 'object') {
      errors.push(`Node ${nodeId} must be an object`);
      continue;
    }

    if (!node.class_type) {
      errors.push(`Node ${nodeId} missing class_type`);
    }

    if (!node.inputs && !node.widgets_values) {
      // Node might not have inputs, that's okay
    }
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Merge workflow parameters
 * @param {object} workflow - Base workflow object
 * @param {object} params - Parameters to merge
 * @returns {object} Modified workflow
 */
export function mergeWorkflowParams(workflow, params) {
  // Create a deep copy of the workflow
  const modifiedWorkflow = JSON.parse(JSON.stringify(workflow));

  // Supported parameters and their default node paths
  // Format: paramName -> [nodeId, fieldType, fieldName]
  const paramMappings = {
    seed: null,  // Will search for seed in any node
    steps: null,
    cfg: null,
    width: null,
    height: null,
    sampler_name: null,
    scheduler: null,
    denoise: null
  };

  // Apply parameters
  for (const [paramName, paramValue] of Object.entries(params)) {
    if (paramValue === undefined || paramValue === null) {
      continue;
    }

    // Search for the parameter in workflow nodes
    for (const [nodeId, node] of Object.entries(modifiedWorkflow)) {
      if (node.inputs && node.inputs.hasOwnProperty(paramName)) {
        // Type conversion for numeric parameters
        let finalValue = paramValue;
        if (typeof node.inputs[paramName] === 'number') {
          finalValue = Number(paramValue);
        }
        modifiedWorkflow[nodeId].inputs[paramName] = finalValue;
        break;
      }
    }
  }

  return modifiedWorkflow;
}

/**
 * Check if a type belongs to img2img family
 * @param {string} type - Workflow type
 * @returns {boolean} True if type is in img2img family
 */
export function isImg2ImgFamily(type) {
  return ['img2img', '2img2img', '3img2img', '4img2img'].includes(type);
}

/**
 * Find text-to-image workflows from configuration
 * @param {Array} workflows - List of workflows from config
 * @returns {Array} Filtered list of txt2img workflows
 */
export function findTxt2ImgWorkflows(workflows) {
  return workflows.filter(w => w.type === 'txt2img');
}

/**
 * Find image-to-image workflows from configuration (including 2img2img, 3img2img, 4img2img)
 * @param {Array} workflows - List of workflows from config
 * @returns {Array} Filtered list of img2img family workflows
 */
export function findImg2ImgWorkflows(workflows) {
  return workflows.filter(w => isImg2ImgFamily(w.type));
}

/**
 * Find text-to-video workflows from configuration
 * @param {Array} workflows - List of workflows from config
 * @returns {Array} Filtered list of txt2vid workflows
 */
export function findTxt2VidWorkflows(workflows) {
  return workflows.filter(w => w.type === 'txt2vid');
}

/**
 * Find image-to-video workflows from configuration
 * @param {Array} workflows - List of workflows from config
 * @returns {Array} Filtered list of img2vid workflows
 */
export function findImg2VidWorkflows(workflows) {
  return workflows.filter(w => w.type === 'img2vid');
}

/**
 * Find image scale workflows from configuration
 * @param {Array} workflows - List of workflows from config
 * @returns {Array} Filtered list of imagescale workflows
 */
export function findImageScaleWorkflows(workflows) {
  return workflows.filter(w => w.type === 'imagescale');
}

/**
 * Find 2img2video workflows from configuration
 * @param {Array} workflows - List of workflows from config
 * @returns {Array} Filtered list of 2img2video workflows
 */
export function find2Img2VideoWorkflows(workflows) {
  return workflows.filter(w => w.type === '2img2video');
}

/**
 * Generate output filename for generated image
 * @param {string} workflowName - Name of the workflow
 * @param {string} extension - File extension (default: .png)
 * @param {object} options - Optional project-based naming options
 * @param {string} options.project - Project name
 * @param {string} options.category - Resource category
 * @param {string} options.name - Explicit resource name (without extension)
 * @returns {string} Generated filename
 */
export function generateOutputFilename(workflowName, extension = '.png', options = {}) {
  // Project-based naming: if project, category, and name are all provided, use name directly
  if (options.project && options.category && options.name) {
    return `${options.name}${extension}`;
  }

  // Project-based naming: if project and category are provided but no name, use timestamp pattern
  if (options.project && options.category) {
    const now = new Date();
    const timestamp = now.getFullYear() +
      String(now.getMonth() + 1).padStart(2, '0') +
      String(now.getDate()).padStart(2, '0') + '_' +
      String(now.getHours()).padStart(2, '0') +
      String(now.getMinutes()).padStart(2, '0') +
      String(now.getSeconds()).padStart(2, '0');
    return `${options.project}_${options.category}_${timestamp}${extension}`;
  }

  // Default: workflow name + timestamp
  const now = new Date();
  const timestamp = now.getFullYear() +
    String(now.getMonth() + 1).padStart(2, '0') +
    String(now.getDate()).padStart(2, '0') + '_' +
    String(now.getHours()).padStart(2, '0') +
    String(now.getMinutes()).padStart(2, '0') +
    String(now.getSeconds()).padStart(2, '0');

  return `${workflowName}_${timestamp}${extension}`;
}

/**
 * Generate output directory path based on project and category
 * @param {string} baseOutputDir - Base output directory
 * @param {object} options - Optional project-based path options
 * @param {string} options.project - Project name
 * @param {string} options.category - Resource category
 * @returns {string} Resolved output directory path
 */
export function generateOutputPath(baseOutputDir, options = {}) {
  if (options.project && options.category) {
    return path.join(baseOutputDir, options.project, 'resources', options.category);
  }
  return baseOutputDir;
}

/**
 * Extract all image variable names from data configuration
 * @param {Array} data - Data configuration array
 * @returns {Array<string>} Sorted array of image variable names
 */
export function extractImageVariables(data) {
  const imageVariables = new Set();

  if (!data || !Array.isArray(data)) {
    return [];
  }

  // Regex to match sample_image pattern variables (e.g., sample_image, sample_image2, etc.)
  const imagePattern = /##(sample_image\d*)##/g;

  for (const entry of data) {
    if (entry && typeof entry === 'object') {
      for (const value of Object.values(entry)) {
        if (typeof value === 'string') {
          let match;
          while ((match = imagePattern.exec(value)) !== null) {
            imageVariables.add(match[1]);
          }
        }
      }
    }
  }

  // Sort the variables: sample_image first, then sample_image2, sample_image3, etc.
  return Array.from(imageVariables).sort((a, b) => {
    const numA = parseInt(a.replace('sample_image', '')) || 1;
    const numB = parseInt(b.replace('sample_image', '')) || 1;
    return numA - numB;
  });
}

/**
 * Get the required image count from workflow configuration
 * @param {object} workflowConfig - Workflow configuration object with data array
 * @returns {number} Number of required images
 */
export function getRequiredImageCount(workflowConfig) {
  if (!workflowConfig || !workflowConfig.data) {
    return 0;
  }

  const imageVariables = extractImageVariables(workflowConfig.data);
  return imageVariables.length;
}

/**
 * Find img2img workflows that match the specified image count
 * @param {Array} workflows - List of workflows from config
 * @param {number} count - Required image count
 * @returns {Array} Filtered list of img2img workflows matching the image count
 */
export function findImg2ImgWorkflowByImageCount(workflows, count) {
  // First filter to get only img2img family workflows (including 2img2img, 3img2img, 4img2img)
  const img2imgWorkflows = workflows.filter(w => isImg2ImgFamily(w.type));

  // Then filter by image count
  return img2imgWorkflows.filter(workflow => {
    const requiredCount = getRequiredImageCount(workflow);
    return requiredCount === count;
  });
}

export default {
  findDefaultWorkflow,
  replaceVariables,
  validateWorkflow,
  mergeWorkflowParams,
  isImg2ImgFamily,
  findTxt2ImgWorkflows,
  findImg2ImgWorkflows,
  findTxt2VidWorkflows,
  findImg2VidWorkflows,
  findImageScaleWorkflows,
  find2Img2VideoWorkflows,
  generateOutputFilename,
  generateOutputPath,
  extractImageVariables,
  getRequiredImageCount,
  findImg2ImgWorkflowByImageCount
};
