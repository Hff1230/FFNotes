import chalk from 'chalk';
import Logger from '../utils/logger.js';
import ora from 'ora';

/**
 * ProgressMonitor class for monitoring ComfyUI workflow execution progress
 */
class ProgressMonitor {
  /**
   * Create a ProgressMonitor instance
   * @param {object} helper - ComfyHelper instance
   */
  constructor(helper) {
    this.helper = helper;
    this.monitoring = false;
    this.currentPromptId = null;
    this.progressCallback = null;
    this.statusCallback = null;
    this.lastProgress = 0;
  }

  /**
   * Start monitoring workflow execution
   * @param {string} promptId - Prompt ID to monitor
   * @param {object} callbacks - Callback functions
   * @param {Function} callbacks.onProgress - Progress callback
   * @param {Function} callbacks.onStatus - Status callback
   * @param {Function} callbacks.onNodeExecuting - Node executing callback
   * @param {Function} callbacks.onNodeExecuted - Node executed callback
   */
  start(promptId, callbacks = {}) {
    this.currentPromptId = promptId;
    this.monitoring = true;
    this.lastProgress = 0;

    // Register progress callback
    this.progressCallback = (data) => {
      if (!this.monitoring) return;

      if (data.type === 'progress_state') {
        const formattedProgress = this.formatProgress(data);
        if (callbacks.onProgress) {
          callbacks.onProgress(formattedProgress);
        }

        // Log progress at intervals
        const currentProgress = Math.round(data.overall_progress * 100);
        if (currentProgress > this.lastProgress || data.finished) {
          this.lastProgress = currentProgress;
          this._logProgressUpdate(formattedProgress);
        }
      } else if (data.value !== undefined && data.max !== undefined) {
        // Legacy progress format
        const progress = data.max > 0 ? Math.round((data.value / data.max) * 100) : 0;
        Logger.debug(`Progress: ${progress}% (${data.value}/${data.max})`);
      }
    };

    // Register status callback
    this.statusCallback = (message) => {
      if (!this.monitoring) return;

      if (message.type === 'executing') {
        const nodeInfo = this.formatNodeStatus(message);
        if (callbacks.onNodeExecuting) {
          callbacks.onNodeExecuting(nodeInfo);
        }
        this._logNodeExecuting(nodeInfo);
      } else if (message.type === 'executed') {
        const nodeInfo = this.formatNodeStatus(message);
        if (callbacks.onNodeExecuted) {
          callbacks.onNodeExecuted(nodeInfo);
        }
        this._logNodeExecuted(nodeInfo);
      } else if (message.type === 'execution_cached') {
        const nodeInfo = this.formatNodeStatus(message);
        this._logNodeCached(nodeInfo);
      }
    };

    // Register callbacks with helper
    this.helper.onProgress(this.progressCallback);
    this.helper.onStatus(this.statusCallback);
  }

  /**
   * Stop monitoring
   */
  stop() {
    this.monitoring = false;
    this.currentPromptId = null;
    this.progressCallback = null;
    this.statusCallback = null;
    this.lastProgress = 0;
  }

  /**
   * Format progress information
   * @param {object} data - Progress data from ComfyUI
   * @returns {object} Formatted progress information
   */
  formatProgress(data) {
    if (data.type === 'progress_state') {
      const overallProgress = Math.round(data.overall_progress * 100);
      const nodeInfoList = [];

      // Format node progress information
      for (const node of (data.nodes || [])) {
        const nodeProgress = Math.round(node.progress * 100);
        nodeInfoList.push({
          nodeId: node.node_id,
          progress: nodeProgress,
          value: node.value,
          max: node.max,
          state: node.state,
          formatted: `${nodeProgress}% (${node.value}/${node.max})`
        });
      }

      // Find active sampling node if any
      const samplingNode = nodeInfoList.find(n =>
        n.state === 'running' && n.max > 1
      );

      let statusText = '';
      if (samplingNode) {
        statusText = `Step ${samplingNode.value}/${samplingNode.max}`;
      } else if (data.finished) {
        statusText = 'Completing...';
      } else {
        statusText = 'Processing...';
      }

      return {
        percentage: overallProgress,
        finished: data.finished,
        nodes: nodeInfoList,
        statusText,
        formatted: `${overallProgress}% | ${statusText}`
      };
    }

    // Legacy format
    if (data.value !== undefined && data.max !== undefined) {
      const progress = data.max > 0 ? Math.round((data.value / data.max) * 100) : 0;
      return {
        percentage: progress,
        finished: false,
        nodes: [],
        statusText: `Step ${data.value}/${data.max}`,
        formatted: `${progress}% | Step ${data.value}/${data.max}`
      };
    }

    return {
      percentage: 0,
      finished: false,
      nodes: [],
      statusText: 'Starting...',
      formatted: '0% | Starting...'
    };
  }

  /**
   * Format node status information
   * @param {object} message - Status message from ComfyUI
   * @returns {object} Formatted node information
   */
  formatNodeStatus(message) {
    return {
      type: message.type,
      nodeId: message.node ? String(message.node) : null,
      promptId: message.prompt_id,
      formatted: message.node ? `Node ${message.node}` : 'System'
    };
  }

  /**
   * Log progress update
   * @param {object} formattedProgress - Formatted progress information
   * @private
   */
  _logProgressUpdate(formattedProgress) {
    const { percentage, statusText, finished } = formattedProgress;

    if (finished) {
      Logger.info(`Progress: ${percentage}% | ${statusText}`);
    } else {
      Logger.debug(`Progress: ${percentage}% | ${statusText}`);
    }
  }

  /**
   * Log node executing
   * @param {object} nodeInfo - Node information
   * @private
   */
  _logNodeExecuting(nodeInfo) {
    Logger.debug(`Executing: ${nodeInfo.formatted}`);
  }

  /**
   * Log node executed
   * @param {object} nodeInfo - Node information
   * @private
   */
  _logNodeExecuted(nodeInfo) {
    Logger.debug(`Executed: ${nodeInfo.formatted}`);
  }

  /**
   * Log node cached
   * @param {object} nodeInfo - Node information
   * @private
   */
  _logNodeCached(nodeInfo) {
    Logger.debug(`Cached: ${nodeInfo.formatted}`);
  }

  /**
   * Create a spinner for progress display
   * @param {string} text - Spinner text
   * @returns {object} Ora spinner instance
   */
  createSpinner(text) {
    return ora(text).start();
  }

  /**
   * Update spinner with progress information
   * @param {object} spinner - Ora spinner instance
   * @param {object} progressData - Progress data
   * @param {string} workflowName - Workflow name
   */
  updateSpinner(spinner, progressData, workflowName) {
    const { percentage, statusText } = progressData;
    spinner.text = `Running workflow (${workflowName})...\n  Progress: ${percentage}% | ${statusText}`;
  }

  /**
   * Wait for workflow completion with progress monitoring
   * @param {string} promptId - Prompt ID
   * @param {object} options - Options
   * @param {number} options.timeout - Timeout in milliseconds
   * @param {string} options.workflowName - Workflow name for display
   * @returns {Promise<boolean>} Success status
   */
  async waitForCompletion(promptId, options = {}) {
    const { timeout = 300000, workflowName = 'workflow' } = options;
    const startTime = Date.now();
    let completed = false;

    // Create spinner
    const spinner = this.createSpinner(`Running workflow (${workflowName})...`);

    return new Promise((resolve, reject) => {
      const checkInterval = setInterval(() => {
        if (Date.now() - startTime > timeout) {
          clearInterval(checkInterval);
          spinner.fail(`Workflow execution timeout after ${timeout}ms`);
          this.stop();
          reject(new Error('Workflow execution timeout'));
          return;
        }

        this.helper.getHistory(promptId).then((history) => {
          if (!history) return;

          const promptData = history[promptId];
          if (!promptData) return;

          const status = promptData.status;
          if (status && status.completed) {
            clearInterval(checkInterval);
            completed = true;
            spinner.succeed('Workflow completed successfully');
            this.stop();
            resolve(true);
          }
        });
      }, 500);

      // Update spinner with progress
      const originalCallback = this.progressCallback;
      this.progressCallback = (data) => {
        if (originalCallback) originalCallback(data);
        if (data.type === 'progress_state') {
          const formattedProgress = this.formatProgress(data);
          this.updateSpinner(spinner, formattedProgress, workflowName);
        }
      };

      // Handle errors
      this.helper.onStatus((message) => {
        if (this.statusCallback) this.statusCallback(message);

        if (message.type === 'execution_error') {
          clearInterval(checkInterval);
          const errorMsg = message.exception_message || message.exception || 'Unknown error';
          spinner.fail(`Workflow execution failed: ${errorMsg}`);
          this.stop();
          reject(new Error(errorMsg));
        }
      });

      // Setup cleanup on timeout
      setTimeout(() => {
        if (!completed) {
          clearInterval(checkInterval);
          spinner.fail(`Workflow execution timeout`);
          this.stop();
          reject(new Error('Workflow execution timeout'));
        }
      }, timeout);
    });
  }
}

export default ProgressMonitor;
