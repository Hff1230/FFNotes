import WebSocket from 'ws';
import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';
import { randomUUID } from 'crypto';
import Logger from '../utils/logger.js';

/**
 * ComfyHelper class for interacting with ComfyUI API
 */
class ComfyHelper {
  /**
   * Create a ComfyHelper instance
   * @param {string} host - ComfyUI server host
   * @param {number} port - ComfyUI server port
   * @param {string} apiKey - API key for authentication (optional)
   */
  constructor(host, port, apiKey = '') {
    this.serverAddr = `http://${host}:${port}`;
    this.wsAddr = `ws://${host}:${port}/ws`;
    this.apiKey = apiKey;
    this.clientId = randomUUID();
    this.ws = null;
    this.connected = false;
    this.progressCallbacks = [];
    this.statusCallbacks = [];

    // Build headers
    this.headers = {
      'Content-Type': 'application/json'
    };
    if (this.apiKey) {
      this.headers['Authorization'] = `Bearer ${this.apiKey}`;
    }
  }

  /**
   * Connect to ComfyUI WebSocket server
   * @returns {Promise<void>}
   */
  async connect() {
    return new Promise((resolve, reject) => {
      try {
        this.ws = new WebSocket(`${this.wsAddr}?clientId=${this.clientId}`);

        this.ws.on('open', () => {
          this.connected = true;
          Logger.info(`Connected to ComfyUI at ${this.wsAddr}`);
          this._setupWebSocketHandlers();
          resolve();
        });

        this.ws.on('error', (error) => {
          Logger.error(`WebSocket error: ${error.message}`);
          reject(error);
        });

        this.ws.on('close', () => {
          this.connected = false;
          Logger.info('WebSocket connection closed');
        });
      } catch (error) {
        Logger.error(`Failed to connect: ${error.message}`);
        reject(error);
      }
    });
  }

  /**
   * Setup WebSocket message handlers
   * @private
   */
  _setupWebSocketHandlers() {
    if (!this.ws) return;

    this.ws.on('message', (data) => {
      try {
        const message = JSON.parse(data.toString());
        this._handleWebSocketMessage(message);
      } catch (error) {
        Logger.debug(`Failed to parse WebSocket message: ${error.message}`);
      }
    });
  }

  /**
   * Handle incoming WebSocket messages
   * @param {object} message - Parsed WebSocket message
   * @private
   */
  _handleWebSocketMessage(message) {
    const type = message.type;

    switch (type) {
      case 'progress':
        this._emitProgress(message.data);
        break;
      case 'executing':
        this._emitStatus(message);
        break;
      case 'executed':
        this._emitStatus(message);
        break;
      case 'execution_cached':
        this._emitStatus(message);
        break;
      case 'status':
        this._emitStatus(message);
        break;
      case 'progress_state':
        this._emitProgressState(message.data);
        break;
      default:
        Logger.debug(`Unhandled message type: ${type}`);
    }
  }

  /**
   * Emit progress to callbacks
   * @param {object} data - Progress data
   * @private
   */
  _emitProgress(data) {
    this.progressCallbacks.forEach(callback => {
      try {
        callback(data);
      } catch (error) {
        Logger.error(`Progress callback error: ${error.message}`);
      }
    });
  }

  /**
   * Emit progress state to callbacks
   * @param {object} data - Progress state data
   * @private
   */
  _emitProgressState(data) {
    const nodes = data.nodes || {};
    const nodeInfoList = [];
    let totalProgress = 0.0;
    let finishedNodes = 0;
    const totalNodes = Object.keys(nodes).length;

    for (const [nodeId, nodeData] of Object.entries(nodes)) {
      const value = nodeData.value || 0;
      const max = nodeData.max || 1;
      const state = nodeData.state || 'running';
      const nodeProgress = max > 0 ? value / max : 0.0;

      nodeInfoList.push({
        node_id: nodeId,
        value,
        max,
        progress: nodeProgress,
        state
      });

      if (state === 'finished') {
        finishedNodes++;
      }
      totalProgress += nodeProgress;
    }

    const overallProgress = totalNodes > 0 ? totalProgress / totalNodes : 0.0;
    const finished = finishedNodes === totalNodes;

    const progressInfo = {
      type: 'progress_state',
      overall_progress: overallProgress,
      finished,
      nodes: nodeInfoList
    };

    this.progressCallbacks.forEach(callback => {
      try {
        callback(progressInfo);
      } catch (error) {
        Logger.error(`Progress callback error: ${error.message}`);
      }
    });
  }

  /**
   * Emit status to callbacks
   * @param {object} message - Status message
   * @private
   */
  _emitStatus(message) {
    this.statusCallbacks.forEach(callback => {
      try {
        callback(message);
      } catch (error) {
        Logger.error(`Status callback error: ${error.message}`);
      }
    });
  }

  /**
   * Disconnect from ComfyUI
   * @returns {Promise<void>}
   */
  async disconnect() {
    return new Promise((resolve) => {
      if (this.ws) {
        this.ws.close();
        this.ws = null;
        this.connected = false;
        Logger.info('Disconnected from ComfyUI');
      }
      resolve();
    });
  }

  /**
   * Register progress callback
   * @param {Function} callback - Progress callback function
   */
  onProgress(callback) {
    if (typeof callback === 'function') {
      this.progressCallbacks.push(callback);
    }
  }

  /**
   * Register status callback
   * @param {Function} callback - Status callback function
   */
  onStatus(callback) {
    if (typeof callback === 'function') {
      this.statusCallbacks.push(callback);
    }
  }

  /**
   * Set variable in workflow
   * @param {object} workflow - Workflow object
   * @param {string} key - Variable key in format "nodeId##inputs##field"
   * @param {*} value - Value to set
   * @returns {object} Modified workflow
   */
  setVariable(workflow, key, value) {
    const parts = key.split('##');
    if (parts.length >= 4) {
      const nodeType = parts[0];
      const nodeId = parts[1];
      const fieldType = parts[2];
      const fieldName = parts[3];

      if (workflow[nodeId] && workflow[nodeId][fieldType]) {
        // Replace variables in value
        let replacedValue = value;
        if (typeof value === 'string') {
          replacedValue = value;
        }
        workflow[nodeId][fieldType][fieldName] = replacedValue;
      }
    }
    return workflow;
  }

  /**
   * Replace workflow prompts with variables
   * @param {object} workflow - Workflow object
   * @param {object} promptVars - Variables to replace
   * @returns {object} Modified workflow
   */
  replaceWorkflowPrompts(workflow, promptVars) {
    const workflowCopy = JSON.parse(JSON.stringify(workflow));

    for (const key in workflowCopy) {
      const node = workflowCopy[key];
      if (node.inputs) {
        for (const inputKey in node.inputs) {
          let value = node.inputs[inputKey];
          if (typeof value === 'string') {
            // Replace all ##var## placeholders
            for (const [varName, varValue] of Object.entries(promptVars)) {
              const placeholder = `##${varName}##`;
              if (value.includes(placeholder)) {
                value = value.replace(new RegExp(placeholder, 'g'), String(varValue || ''));
              }
            }
            node.inputs[inputKey] = value;
          }
        }
      }
    }

    return workflowCopy;
  }

  /**
   * Queue a prompt for execution
   * @param {object} workflow - Workflow object
   * @returns {Promise<object>} Queue response
   */
  async queuePrompt(workflow) {
    try {
      const response = await fetch(`${this.serverAddr}/prompt`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify({
          prompt: workflow,
          client_id: this.clientId
        })
      });

      if (response.ok) {
        const result = await response.json();
        Logger.info(`Prompt queued: ${result.prompt_id}`);
        return result;
      } else {
        const errorText = await response.text();
        Logger.error(`Queue prompt failed: ${response.status} - ${errorText}`);
        return null;
      }
    } catch (error) {
      Logger.error(`Queue prompt error: ${error.message}`);
      return null;
    }
  }

  /**
   * Get execution history
   * @param {string} promptId - Prompt ID
   * @returns {Promise<object>} History data
   */
  async getHistory(promptId) {
    try {
      const response = await fetch(`${this.serverAddr}/history/${promptId}`, {
        method: 'GET',
        headers: this.headers
      });

      if (response.ok) {
        return await response.json();
      } else {
        Logger.error(`Get history failed: ${response.status}`);
        return null;
      }
    } catch (error) {
      Logger.error(`Get history error: ${error.message}`);
      return null;
    }
  }

  /**
   * Run a workflow and wait for completion
   * @param {object} workflow - Workflow object
   * @returns {Promise<string>} Prompt ID
   */
  async runWorkflow(workflow) {
    const result = await this.queuePrompt(workflow);
    if (result && result.prompt_id) {
      return result.prompt_id;
    }
    throw new Error('Failed to queue workflow');
  }

  /**
   * Wait for workflow completion
   * @param {string} promptId - Prompt ID
   * @param {number} timeout - Timeout in milliseconds (default: 300000)
   * @returns {Promise<boolean>} Success status
   */
  async waitForCompletion(promptId, timeout = 300000) {
    return new Promise((resolve, reject) => {
      const startTime = Date.now();
      let completed = false;

      const checkInterval = setInterval(() => {
        if (Date.now() - startTime > timeout) {
          clearInterval(checkInterval);
          reject(new Error('Workflow execution timeout'));
          return;
        }

        this.getHistory(promptId).then((history) => {
          if (!history) return;

          const promptData = history[promptId];
          if (!promptData) return;

          const status = promptData.status;
          if (status && status.completed) {
            clearInterval(checkInterval);
            completed = true;
            Logger.success(`Workflow completed: ${promptId}`);
            resolve(true);
          }
        });
      }, 1000);

      // Listen for status messages
      const statusCallback = (message) => {
        if (message.type === 'executed' && message.prompt_id === promptId) {
          clearInterval(checkInterval);
          completed = true;
          Logger.success(`Workflow executed: ${promptId}`);
          resolve(true);
        }
      };

      this.onStatus(statusCallback);
    });
  }

  /**
   * Upload an image to ComfyUI
   * @param {string} imagePath - Path to image file
   * @param {string} subfolder - Subfolder path (default: '')
   * @param {boolean} overwrite - Overwrite existing file (default: true)
   * @returns {Promise<object>} Upload response
   */
  async uploadImage(imagePath, subfolder = '', overwrite = true) {
    try {
      if (!fs.existsSync(imagePath)) {
        Logger.error(`File not found: ${imagePath}`);
        return null;
      }

      const filename = path.basename(imagePath);
      const fileBuffer = await fs.promises.readFile(imagePath);

      // Create FormData
      const { FormData } = await import('formdata-polyfill/esm.min.js');
      const formData = new FormData();
      formData.append('image', new Blob([fileBuffer]), filename);
      formData.append('overwrite', String(overwrite));
      formData.append('subfolder', subfolder);

      const response = await fetch(`${this.serverAddr}/upload/image`, {
        method: 'POST',
        headers: this.apiKey ? { 'Authorization': `Bearer ${this.apiKey}` } : {},
        body: formData
      });

      if (response.ok) {
        const result = await response.json();
        Logger.success(`Image uploaded: ${result.name}`);
        return result;
      } else {
        const errorText = await response.text();
        Logger.error(`Upload image failed: ${response.status} - ${errorText}`);
        return null;
      }
    } catch (error) {
      Logger.error(`Upload image error: ${error.message}`);
      return null;
    }
  }

  /**
   * Download output file from ComfyUI
   * @param {string} filename - Filename to download
   * @param {string} outputPath - Local output path
   * @param {string} subfolder - Subfolder path (default: '')
   * @param {string} folderType - Folder type (default: 'output')
   * @returns {Promise<boolean>} Success status
   */
  async downloadOutput(filename, outputPath, subfolder = '', folderType = 'output') {
    try {
      const params = new URLSearchParams({
        filename,
        subfolder,
        type: folderType
      });

      const response = await fetch(`${this.serverAddr}/view?${params}`, {
        method: 'GET',
        headers: this.headers
      });

      if (response.ok) {
        const arrayBuffer = await response.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);
        const dir = path.dirname(outputPath);
        await fs.promises.mkdir(dir, { recursive: true });
        await fs.promises.writeFile(outputPath, buffer);
        Logger.success(`File downloaded: ${outputPath}`);
        return true;
      } else {
        Logger.error(`Download output failed: ${response.status}`);
        return false;
      }
    } catch (error) {
      Logger.error(`Download output error: ${error.message}`);
      return false;
    }
  }

  /**
   * Get image from ComfyUI
   * @param {string} filename - Filename
   * @param {string} subfolder - Subfolder path (default: '')
   * @param {string} folderType - Folder type (default: 'input')
   * @returns {Promise<Buffer|null>} Image buffer
   */
  async getImage(filename, subfolder = '', folderType = 'input') {
    try {
      const params = new URLSearchParams({
        filename,
        subfolder,
        type: folderType
      });

      const response = await fetch(`${this.serverAddr}/view?${params}`, {
        method: 'GET',
        headers: this.headers
      });

      if (response.ok) {
        const arrayBuffer = await response.arrayBuffer();
        return Buffer.from(arrayBuffer);
      } else {
        Logger.error(`Get image failed: ${response.status}`);
        return null;
      }
    } catch (error) {
      Logger.error(`Get image error: ${error.message}`);
      return null;
    }
  }

  /**
   * Get video from ComfyUI
   * @param {string} filename - Filename
   * @param {string} subfolder - Subfolder path (default: '')
   * @param {string} formatType - Video format (default: 'mp4')
   * @returns {Promise<Buffer|null>} Video buffer
   */
  async getVideo(filename, subfolder = '', formatType = 'mp4') {
    try {
      const params = new URLSearchParams({
        filename,
        subfolder,
        format: formatType
      });

      const response = await fetch(`${this.serverAddr}/view?${params}`, {
        method: 'GET',
        headers: this.headers
      });

      if (response.ok) {
        const arrayBuffer = await response.arrayBuffer();
        return Buffer.from(arrayBuffer);
      } else {
        Logger.error(`Get video failed: ${response.status}`);
        return null;
      }
    } catch (error) {
      Logger.error(`Get video error: ${error.message}`);
      return null;
    }
  }

  /**
   * Get all outputs from a workflow execution
   * @param {string} promptId - Prompt ID
   * @param {string} outputDir - Output directory (default: './output')
   * @returns {Promise<boolean>} Success status
   */
  async getAllOutputs(promptId, outputDir = './output') {
    try {
      const history = await this.getHistory(promptId);
      if (!history || !history[promptId]) {
        Logger.error(`No history found for prompt: ${promptId}`);
        return false;
      }

      const data = history[promptId];
      const outputs = data.outputs || {};

      // Create output directory
      await fs.promises.mkdir(outputDir, { recursive: true });

      // Process all outputs
      for (const [nodeId, nodeOutput] of Object.entries(outputs)) {
        // Handle images
        if (nodeOutput.images) {
          for (const image of nodeOutput.images) {
            const buffer = await this.getImage(
              image.filename,
              image.subfolder || '',
              image.type || 'output'
            );
            if (buffer) {
              const outputPath = path.join(outputDir, image.filename);
              await fs.promises.writeFile(outputPath, buffer);
              Logger.info(`Image saved: ${outputPath}`);
            }
          }
        }

        // Handle GIFs
        if (nodeOutput.gifs) {
          for (const gif of nodeOutput.gifs) {
            const buffer = await this.getVideo(
              gif.filename,
              gif.subfolder || '',
              gif.format || 'gif'
            );
            if (buffer) {
              const outputPath = path.join(outputDir, gif.filename);
              await fs.promises.writeFile(outputPath, buffer);
              Logger.info(`GIF saved: ${outputPath}`);
            }
          }
        }
      }

      return true;
    } catch (error) {
      Logger.error(`Get all outputs error: ${error.message}`);
      return false;
    }
  }

  /**
   * Execute a complete workflow with file uploads and output downloads
   * @param {object} workflow - Workflow object
   * @param {object} promptVars - Variables to replace in workflow
   * @param {object} uploadFiles - Files to upload {key: filepath}
   * @param {string} outputPath - Output directory path
   * @param {Function} progressFunc - Progress callback function
   * @returns {Promise<boolean>} Success status
   */
  async exec(workflow, promptVars = {}, uploadFiles = {}, outputPath = './output', progressFunc = null) {
    try {
      // Replace workflow prompts
      const modifiedWorkflow = this.replaceWorkflowPrompts(workflow, promptVars);

      // Upload files
      for (const [key, filePath] of Object.entries(uploadFiles)) {
        const subfolder = path.dirname(key);
        const result = await this.uploadImage(filePath, subfolder);
        if (!result) {
          Logger.error(`Failed to upload file: ${filePath}`);
          return false;
        }
      }

      // Queue the workflow
      const queueResult = await this.queuePrompt(modifiedWorkflow);
      if (!queueResult || !queueResult.prompt_id) {
        Logger.error('Failed to queue workflow');
        return false;
      }

      const promptId = queueResult.prompt_id;

      // Wait for completion with progress tracking
      if (progressFunc) {
        this.onProgress(progressFunc);
        await this.waitForCompletion(promptId);
      } else {
        await this.waitForCompletion(promptId);
      }

      // Download outputs
      return await this.getAllOutputs(promptId, outputPath);
    } catch (error) {
      Logger.error(`Exec workflow error: ${error.message}`);
      return false;
    }
  }
}

export default ComfyHelper;
