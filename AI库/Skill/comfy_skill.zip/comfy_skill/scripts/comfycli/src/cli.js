#!/usr/bin/env node
import { Command } from 'commander';
import chalk from 'chalk';
import path from 'path';
import { fileURLToPath } from 'url';
import { listCommand } from './commands/list.js';
import { validateCommand } from './commands/validate.js';
import { runCommand } from './commands/run.js';
import { txt2imgCommand } from './commands/txt2img.js';
import { img2imgCommand } from './commands/img2img.js';
import { txt2vidCommand } from './commands/txt2vid.js';
import { img2vidCommand } from './commands/img2vid.js';
import { img2vid2Command } from './commands/2img2vid.js';
import { imagescaleCommand } from './commands/imagescale.js';
import { batchCommand } from './commands/batch.js';

// Get script directory for resolving default paths
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DEFAULT_CONFIG_PATH = path.join(__dirname, '../config/comfy_config.json');

// 默认输出路径：优先使用调用者传入的项目根目录，降级为CWD
const DEFAULT_OUTPUT_PATH = process.env.COMFY_PROJECT_ROOT
  ? path.join(process.env.COMFY_PROJECT_ROOT, 'output')
  : path.join(process.cwd(), 'output');

/**
 * Collector function for --images option to support multiple values
 * @param {string} value - The image path value
 * @param {string[]} previous - Previously collected values
 * @returns {string[]} Combined array of image paths
 */
function collectImages(value, previous) {
  return previous.concat([value]);
}

// Create CLI program
const program = new Command();

// Package information
const packageInfo = {
  name: 'comfycli',
  version: '1.0.0',
  description: 'CLI tool for ComfyUI workflow management'
};

// Configure CLI program
program
  .name(packageInfo.name)
  .description(packageInfo.description)
  .version(packageInfo.version);

// List workflows command
program
  .command('list')
  .description('List available workflows')
  .option('-c, --config <path>', 'Path to configuration file')
  .action((options) => {
    listCommand(options);
  });

// Validate configuration command
program
  .command('validate')
  .description('Validate configuration file')
  .option('-c, --config <path>', 'Path to configuration file')
  .action((options) => {
    validateCommand(options.config);
  });

// Run workflow command
program
  .command('run')
  .description('Run a workflow by name')
  .argument('<workflow>', 'Workflow name to run')
  .option('-p, --prompt <text>', 'Positive prompt text')
  .option('-n, --negative <text>', 'Negative prompt text')
  .option('-o, --output <path>', 'Output directory path', DEFAULT_OUTPUT_PATH)
  .option('-c, --config <path>', 'Path to configuration file')
  .option('-i, --image <path>', 'Input image path (for img2img workflows)')
  .option('-w, --watch', 'Watch execution progress')
  .option('--upload', 'Upload generated files to dufs server (default: true)', true)
  .option('--no-upload', 'Skip uploading to dufs server', false)
  .action((workflow, options) => {
    runCommand(workflow, options);
  });

// Text to Image command
program
  .command('txt2img')
  .description('Generate image from text prompt')
  .argument('<prompt>', 'Text prompt for image generation')
  .option('-n, --negative <text>', 'Negative prompt text')
  .option('-o, --output <path>', 'Output directory path', DEFAULT_OUTPUT_PATH)
  .option('-c, --config <path>', 'Path to configuration file', DEFAULT_CONFIG_PATH)
  .option('-w, --workflow <name>', 'Workflow name (default: zimageturbot2i)', 'zimageturbot2i')
  .option('-s, --steps <number>', 'Sampling steps')
  .option('--cfg <number>', 'CFG scale')
  .option('--seed <number>', 'Random seed (default: random)')
  .option('--width <number>', 'Image width')
  .option('--height <number>', 'Image height')
  .option('-S, --size <alias>', 'Size preset alias (e.g. low/mid/high)')
  .option('--orientation <0|1>', 'Orientation: 0=landscape, 1=portrait (default: 0)', '0')
  .option('--upload', 'Upload generated files to dufs server (default: true)', true)
  .option('--no-upload', 'Skip uploading to dufs server', false)
  .option('--project <name>', 'Project name for organized output (e.g. wusong)')
  .option('--category <type>', 'Resource category (characters/tigers/scenes/props/videos/upscale)')
  .option('--name <name>', 'Resource name for filename (e.g. C01_武松_正面全身)')
  .action((prompt, options) => {
    txt2imgCommand(prompt, options);
  });

// Image to Image command
program
  .command('img2img')
  .description('Transform image using text prompt')
  .argument('<image>', 'Input image path(s) - single path or comma-separated paths (e.g., "photo1.jpg,photo2.jpg")')
  .argument('<prompt>', 'Text prompt for transformation')
  .option('-n, --negative <text>', 'Negative prompt text')
  .option('-o, --output <path>', 'Output directory path', DEFAULT_OUTPUT_PATH)
  .option('-c, --config <path>', 'Path to configuration file', DEFAULT_CONFIG_PATH)
  .option('-w, --workflow <name>', 'Workflow name (auto-selected based on image count if not specified)')
  .option('-s, --strength <number>', 'Denoise strength (0.0-1.0, default: 0.75)', '0.75')
  .option('--steps <number>', 'Sampling steps')
  .option('--cfg <number>', 'CFG scale')
  .option('--seed <number>', 'Random seed (default: random)')
  .option('--width <number>', 'Image width')
  .option('--height <number>', 'Image height')
  .option('-S, --size <alias>', 'Size preset alias (e.g. low/mid/high)')
  .option('--orientation <0|1>', 'Orientation: 0=landscape, 1=portrait (default: 0)', '0')
  .option('--images <path>', 'Additional image path (can be specified multiple times)', collectImages, [])
  .option('--upload', 'Upload generated files to dufs server (default: true)', true)
  .option('--no-upload', 'Skip uploading to dufs server', false)
  .action((image, prompt, options) => {
    // Combine positional image argument with --images options
    // Parse comma-separated images from positional argument
    const positionalImages = image.split(',').map(p => p.trim()).filter(p => p.length > 0);
    // Merge with images from --images option
    const allImages = [...positionalImages, ...(options.images || [])];

    // Pass the first image as primary and all images array in options
    // for backward compatibility with single-image workflows
    options.allImages = allImages;
    img2imgCommand(image, prompt, options);
  });

// Text to Video command
program
  .command('txt2vid')
  .description('Generate video from text prompt')
  .argument('<prompt>', 'Text prompt for video generation')
  .option('-n, --negative <text>', 'Negative prompt text')
  .option('-o, --output <path>', 'Output directory path', DEFAULT_OUTPUT_PATH)
  .option('-c, --config <path>', 'Path to configuration file', DEFAULT_CONFIG_PATH)
  .option('-w, --workflow <name>', 'Workflow name (default: want2v)', 'want2v')
  .option('-f, --format <format>', 'Output format (mp4/gif)', 'mp4')
  .option('--fps <number>', 'Frame rate')
  .option('--frames <number>', 'Total number of frames')
  .option('--steps <number>', 'Sampling steps')
  .option('--cfg <number>', 'CFG scale')
  .option('--seed <number>', 'Random seed (default: random)')
  .option('--width <number>', 'Video width')
  .option('--height <number>', 'Video height')
  .option('-S, --size <alias>', 'Size preset alias (e.g. low/mid/high)')
  .option('--orientation <0|1>', 'Orientation: 0=landscape, 1=portrait (default: 0)', '0')
  .option('--upload', 'Upload generated files to dufs server (default: true)', true)
  .option('--no-upload', 'Skip uploading to dufs server', false)
  .action((prompt, options) => {
    txt2vidCommand(prompt, options);
  });

// 2 Image to Image command
program
  .command('2img2img')
  .description('Transform 2 images using text prompt')
  .argument('<image1>', 'First input image path')
  .argument('<image2>', 'Second input image path')
  .argument('<prompt>', 'Text prompt for transformation')
  .option('-n, --negative <text>', 'Negative prompt text')
  .option('-o, --output <path>', 'Output directory path', DEFAULT_OUTPUT_PATH)
  .option('-c, --config <path>', 'Path to configuration file', DEFAULT_CONFIG_PATH)
  .option('-w, --workflow <name>', 'Workflow name (default: qwen2511i2i2)', 'qwen2511i2i2')
  .option('-s, --strength <number>', 'Denoise strength (0.0-1.0, default: 0.75)', '0.75')
  .option('--steps <number>', 'Sampling steps')
  .option('--cfg <number>', 'CFG scale')
  .option('--seed <number>', 'Random seed (default: random)')
  .option('--width <number>', 'Image width')
  .option('--height <number>', 'Image height')
  .option('-S, --size <alias>', 'Size preset alias (e.g. low/mid/high)')
  .option('--orientation <0|1>', 'Orientation: 0=landscape, 1=portrait (default: 0)', '0')
  .option('--upload', 'Upload generated files to dufs server (default: true)', true)
  .option('--no-upload', 'Skip uploading to dufs server', false)
  .action((image1, image2, prompt, options) => {
    img2imgCommand(image1, prompt, { ...options, allImages: [image1, image2] });
  });

// 3 Image to Image command
program
  .command('3img2img')
  .description('Transform 3 images using text prompt')
  .argument('<image1>', 'First input image path')
  .argument('<image2>', 'Second input image path')
  .argument('<image3>', 'Third input image path')
  .argument('<prompt>', 'Text prompt for transformation')
  .option('-n, --negative <text>', 'Negative prompt text')
  .option('-o, --output <path>', 'Output directory path', DEFAULT_OUTPUT_PATH)
  .option('-c, --config <path>', 'Path to configuration file', DEFAULT_CONFIG_PATH)
  .option('-w, --workflow <name>', 'Workflow name (default: qwen2511i2i3)', 'qwen2511i2i3')
  .option('-s, --strength <number>', 'Denoise strength (0.0-1.0, default: 0.75)', '0.75')
  .option('--steps <number>', 'Sampling steps')
  .option('--cfg <number>', 'CFG scale')
  .option('--seed <number>', 'Random seed (default: random)')
  .option('--width <number>', 'Image width')
  .option('--height <number>', 'Image height')
  .option('-S, --size <alias>', 'Size preset alias (e.g. low/mid/high)')
  .option('--orientation <0|1>', 'Orientation: 0=landscape, 1=portrait (default: 0)', '0')
  .option('--upload', 'Upload generated files to dufs server (default: true)', true)
  .option('--no-upload', 'Skip uploading to dufs server', false)
  .action((image1, image2, image3, prompt, options) => {
    img2imgCommand(image1, prompt, { ...options, allImages: [image1, image2, image3] });
  });

// 4 Image to Image command
program
  .command('4img2img')
  .description('Transform 4 images using text prompt')
  .argument('<image1>', 'First input image path')
  .argument('<image2>', 'Second input image path')
  .argument('<image3>', 'Third input image path')
  .argument('<image4>', 'Fourth input image path')
  .argument('<prompt>', 'Text prompt for transformation')
  .option('-n, --negative <text>', 'Negative prompt text')
  .option('-o, --output <path>', 'Output directory path', DEFAULT_OUTPUT_PATH)
  .option('-c, --config <path>', 'Path to configuration file', DEFAULT_CONFIG_PATH)
  .option('-w, --workflow <name>', 'Workflow name (default: qwen2511i2i4)', 'qwen2511i2i4')
  .option('-s, --strength <number>', 'Denoise strength (0.0-1.0, default: 0.75)', '0.75')
  .option('--steps <number>', 'Sampling steps')
  .option('--cfg <number>', 'CFG scale')
  .option('--seed <number>', 'Random seed (default: random)')
  .option('--width <number>', 'Image width')
  .option('--height <number>', 'Image height')
  .option('-S, --size <alias>', 'Size preset alias (e.g. low/mid/high)')
  .option('--orientation <0|1>', 'Orientation: 0=landscape, 1=portrait (default: 0)', '0')
  .option('--upload', 'Upload generated files to dufs server (default: true)', true)
  .option('--no-upload', 'Skip uploading to dufs server', false)
  .action((image1, image2, image3, image4, prompt, options) => {
    img2imgCommand(image1, prompt, { ...options, allImages: [image1, image2, image3, image4] });
  });

// Image to Video command
program
  .command('img2vid')
  .description('Generate video from image')
  .argument('<image>', 'Input image path')
  .option('-p, --prompt <text>', 'Text prompt for video generation')
  .option('-n, --negative <text>', 'Negative prompt text')
  .option('-o, --output <path>', 'Output directory path', DEFAULT_OUTPUT_PATH)
  .option('-c, --config <path>', 'Path to configuration file', DEFAULT_CONFIG_PATH)
  .option('-w, --workflow <name>', 'Workflow name (default: wani2v)', 'wani2v')
  .option('-f, --format <format>', 'Output format (mp4/gif)', 'mp4')
  .option('--fps <number>', 'Frame rate')
  .option('--frames <number>', 'Total number of frames')
  .option('--steps <number>', 'Sampling steps')
  .option('--cfg <number>', 'CFG scale')
  .option('--seed <number>', 'Random seed (default: random)')
  .option('--width <number>', 'Video width')
  .option('--height <number>', 'Video height')
  .option('-S, --size <alias>', 'Size preset alias (e.g. low/mid/high)')
  .option('--orientation <0|1>', 'Orientation: 0=landscape, 1=portrait (default: 0)', '0')
  .option('--motion <number>', 'Motion bucket strength (1-255)')
  .option('--upload', 'Upload generated files to dufs server (default: true)', true)
  .option('--no-upload', 'Skip uploading to dufs server', false)
  .action((image, options) => {
    img2vidCommand(image, options);
  });

// 2 Image to Video command
program
  .command('2img2vid')
  .description('Generate video from two images (first frame + last frame)')
  .argument('<image1>', 'First input image path (first frame)')
  .argument('<image2>', 'Second input image path (last frame)')
  .option('-p, --prompt <text>', 'Text prompt for video generation')
  .option('-n, --negative <text>', 'Negative prompt text')
  .option('-o, --output <path>', 'Output directory path', DEFAULT_OUTPUT_PATH)
  .option('-c, --config <path>', 'Path to configuration file', DEFAULT_CONFIG_PATH)
  .option('-w, --workflow <name>', 'Workflow name (default: ltx2img2vid)', 'ltx2img2vid')
  .option('-f, --format <format>', 'Output format (mp4/gif)', 'mp4')
  .option('--fps <number>', 'Frame rate')
  .option('--frames <number>', 'Total number of frames')
  .option('--steps <number>', 'Sampling steps')
  .option('--cfg <number>', 'CFG scale')
  .option('--seed <number>', 'Random seed (default: random)')
  .option('--width <number>', 'Video width')
  .option('--height <number>', 'Video height')
  .option('-S, --size <alias>', 'Size preset alias (e.g. low/mid/high)')
  .option('--orientation <0|1>', 'Orientation: 0=landscape, 1=portrait (default: 0)', '0')
  .option('--upload', 'Upload generated files to dufs server (default: true)', true)
  .option('--no-upload', 'Skip uploading to dufs server', false)
  .action((image1, image2, options) => {
    img2vid2Command(image1, image2, options);
  });

// Image Scale command
program
  .command('imagescale')
  .description('Upscale image resolution using AI model')
  .argument('<image>', 'Input image path')
  .option('-o, --output <path>', 'Output directory path', DEFAULT_OUTPUT_PATH)
  .option('-c, --config <path>', 'Path to configuration file', DEFAULT_CONFIG_PATH)
  .option('-w, --workflow <name>', 'Workflow name (default: zimageupscale)', 'zimageupscale')
  .option('-s, --size <alias>', 'Size preset alias (2k/4k/8k)')
  .option('--orientation <0|1>', 'Orientation: 0=landscape, 1=portrait (default: 0)', '0')
  .option('--width <number>', 'Custom target width')
  .option('--height <number>', 'Custom target height')
  .option('--seed <number>', 'Random seed (default: random)')
  .option('--upload', 'Upload generated files to dufs server (default: true)', true)
  .option('--no-upload', 'Skip uploading to dufs server', false)
  .action((image, options) => {
    imagescaleCommand(image, options);
  });

// Batch execution command
program
  .command('batch')
  .description('Execute multiple commands from a JSON file')
  .argument('<file>', 'Path to JSON file containing tasks')
  .option('-c, --config <path>', 'Path to configuration file')
  .option('--continue-on-error', 'Continue executing remaining tasks when one fails')
  .option('--dry-run', 'Validate JSON file without executing')
  .option('--restart', 'Force restart from beginning, ignore progress file')
  .option('--clean', 'Delete progress file and exit')
  .option('-o, --output <path>', 'Default output directory (overridden by task-level)')
  .option('--no-upload', 'Skip uploading for all tasks')
  .action((file, options) => {
    batchCommand(file, options);
  });

// Export CLI function
export function cli() {
  program.parse();
}
