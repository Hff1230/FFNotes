import ConfigManager from '../utils/config.js';
import Logger from '../utils/logger.js';
import chalk from 'chalk';

/**
 * List command implementation
 * @param {object} options - Command options
 * @param {string} options.config - Path to configuration file
 */
export function listCommand(options = {}) {
  const configPath = options.config || './config/comfy_config.json';
  const configManager = new ConfigManager(configPath);

  // Load configuration
  if (!configManager.load()) {
    Logger.error('Failed to load configuration file');
    process.exit(1);
  }

  // Get workflows
  const workflows = configManager.listWorkflows();

  if (workflows.length === 0) {
    console.log(chalk.yellow('No workflows found in configuration.'));
    return;
  }

  // Display header
  console.log(chalk.bold.green('\nAvailable Workflows:'));

  // Format table data
  const tableData = workflows.map(workflow => ({
    'Name': workflow.name,
    'Description': workflow.description,
    'Type': workflow.type
  }));

  // Display table using console.table
  console.table(tableData);

  // Display server info
  const serverConfig = configManager.getServerConfig();
  console.log(chalk.gray(`\nServer: ${serverConfig.host}:${serverConfig.port}`));
}

export default listCommand;
