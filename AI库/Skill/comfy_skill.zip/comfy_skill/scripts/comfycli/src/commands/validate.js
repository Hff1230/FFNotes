import ConfigManager from '../utils/config.js';
import Logger from '../utils/logger.js';
import chalk from 'chalk';
import path from 'path';

/**
 * Validate command implementation
 * @param {string} configPath - Path to configuration file (optional)
 */
export function validateCommand(configPath) {
  const resolvedConfigPath = configPath || './config/comfy_config.json';

  console.log(chalk.bold.blue(`\nValidating configuration: ${resolvedConfigPath}\n`));

  const configManager = new ConfigManager(resolvedConfigPath);
  const result = configManager.validate();

  if (result.valid) {
    console.log(chalk.green.bold('✓ Configuration is valid!\n'));

    // Display configuration summary
    const workflows = configManager.listWorkflows();
    console.log(chalk.gray(`Server: ${configManager.getServerConfig().host}:${configManager.getServerConfig().port}`));
    console.log(chalk.gray(`Workflows: ${workflows.length}\n`));

    if (workflows.length > 0) {
      console.log(chalk.bold('Workflows found:'));
      workflows.forEach(workflow => {
        console.log(chalk.gray(`  - ${workflow.name}: ${workflow.description} (${workflow.type})`));
      });
      console.log();
    }

    process.exit(0);
  } else {
    console.log(chalk.red.bold('✗ Configuration validation failed!\n'));

    if (result.errors.length > 0) {
      console.log(chalk.bold.red('Errors found:'));
      result.errors.forEach((error, index) => {
        console.log(chalk.red(`  ${index + 1}. ${error}`));
      });
      console.log();
    }

    process.exit(1);
  }
}

export default validateCommand;
