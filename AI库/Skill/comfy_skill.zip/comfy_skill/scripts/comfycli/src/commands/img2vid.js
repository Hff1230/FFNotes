import ConfigManager from '../utils/config.js';
import Logger from '../utils/logger.js';
import ComfyHelper from '../core/helper.js';
import ProgressMonitor from '../core/progress.js';
import {
  replaceVariables,
  validateWorkflow,
  mergeWorkflowParams,
  findImg2VidWorkflows,
  generateOutputFilename
} from '../core/workflow.js';
import { extractMetadata, saveMetadata } from '../utils/metadata.js';
import DufsUploader from '../utils/uploader.js';
import ResourceDownloader from '../utils/resource_downloader.js';
import chalk from 'chalk';
import path from 'path';
import fs from 'fs';
import { randomInt } from 'crypto';
import ora from 'ora';

/**
 * Image to Video command implementation
 * @param {string} input - Input image path
 * @param {object} options - Command options
 * @param {string} options.prompt - Positive prompt text
 * @param {string} options.negative - Negative prompt text
 * @param {string} options.output - Output directory path
 * @param {string} options.config - Path to configuration file
 * @param {string} options.workflow - Workflow name (default: wani2v)
 * @param {string} options.format - Output format (mp4/gif, default: mp4)
 * @param {number} options.fps - Frame rate
 * @param {number} options.frames - Total number of frames
 * @param {number} options.width - Video width
 * @param {number} options.height - Video height
 * @param {number} options.seed - Random seed (default: random)
 * @param {number} options.motion - Motion bucket strength (1-255)
 */
export async function img2vidCommand(input, options = {}) {
  // Validate input image
  if (!input || input.trim().length === 0) {
    if (options._batchMode) {
      throw new Error('Input image path is required');
    }
    console.log(chalk.red.bold('Error: Input image path is required'));
    console.log(chalk.gray('Usage: npx comfycli img2vid <input>'));
    process.exit(1);
  }

  // Handle URL input - download if necessary
  let localInput = input;
  if (ResourceDownloader.isUrl(input)) {
    console.log(chalk.blue('Downloading input image from URL...'));
    try {
      const result = await ResourceDownloader.resolveInputResource(input);
      localInput = result.localPath;
      console.log(chalk.green(`Downloaded to: ${localInput}`));
    } catch (downloadError) {
      console.log(chalk.red.bold(`Error: Failed to download image: ${downloadError.message}`));
      if (options._batchMode) {
        throw new Error(`Failed to download image: ${downloadError.message}`);
      }
      process.exit(1);
    }
  }

  // Validate input image file exists
  const inputPath = path.resolve(localInput);
  if (!fs.existsSync(inputPath)) {
    console.log(chalk.red.bold(`Error: Input image not found: ${localInput}`));
    console.log(chalk.gray(`Resolved path: ${inputPath}`));
    if (options._batchMode) {
      throw new Error(`Input image not found: ${localInput}`);
    }
    process.exit(1);
  }

  // Validate image format
  const supportedFormats = ['.png', '.jpg', '.jpeg', '.webp'];
  const ext = path.extname(inputPath).toLowerCase();
  if (!supportedFormats.includes(ext)) {
    console.log(chalk.red.bold(`Error: Unsupported image format: ${ext}`));
    console.log(chalk.yellow(`Supported formats: ${supportedFormats.join(', ')}`));
    if (options._batchMode) {
      throw new Error(`Unsupported image format: ${ext}`);
    }
    process.exit(1);
  }

  // Set default options
  const configPath = options.config || './config/comfy_config.json';
  const outputDir = options.output;
  const workflowName = options.workflow || 'wani2v';
  const prompt = options.prompt || '';
  const negative = options.negative || '';
  const format = options.format || 'mp4';

  // Validate format
  const supportedVideoFormats = ['mp4', 'gif'];
  if (!supportedVideoFormats.includes(format.toLowerCase())) {
    console.log(chalk.red.bold(`Error: Unsupported format: ${format}`));
    console.log(chalk.yellow(`Supported formats: ${supportedVideoFormats.join(', ')}`));
    if (options._batchMode) {
      throw new Error(`Unsupported format: ${format}`);
    }
    process.exit(1);
  }

  // Display command info
  console.log(chalk.bold.blue('\nImage to Video Generation'));
  console.log(chalk.gray('─'.repeat(50)));
  console.log(chalk.gray(`Input: ${input}`));
  if (prompt) {
    console.log(chalk.gray(`Prompt: ${prompt}`));
  }
  if (negative) {
    console.log(chalk.gray(`Negative: ${negative}`));
  }
  console.log(chalk.gray(`Workflow: ${workflowName}`));
  console.log(chalk.gray(`Format: ${format}`));
  console.log(chalk.gray(`Output: ${outputDir}`));
  if (options.fps) console.log(chalk.gray(`FPS: ${options.fps}`));
  if (options.frames) console.log(chalk.gray(`Frames: ${options.frames}`));
  if (options.width) console.log(chalk.gray(`Width: ${options.width}`));
  if (options.height) console.log(chalk.gray(`Height: ${options.height}`));
  if (options.motion) console.log(chalk.gray(`Motion: ${options.motion}`));
  console.log();

  // Initialize configuration manager
  const configManager = new ConfigManager(configPath);

  // Load configuration
  if (!configManager.load()) {
    console.log(chalk.red.bold('Error: Failed to load configuration file'));
    console.log(chalk.gray(`Path: ${configPath}`));
    if (options._batchMode) {
      throw new Error('Failed to load configuration file');
    }
    process.exit(1);
  }

  // Validate that the workflow exists and is img2vid type
  const workflowConfig = configManager.getWorkflow(workflowName);

  if (!workflowConfig) {
    console.log(chalk.red.bold(`Error: Workflow not found: ${workflowName}`));
    if (options._batchMode) {
      throw new Error('Workflow not found: ' + workflowName);
    }

    // List available img2vid workflows
    const allWorkflows = configManager.listWorkflows();
    const img2vidWorkflows = findImg2VidWorkflows(allWorkflows);

    if (img2vidWorkflows.length > 0) {
      console.log(chalk.yellow('\nAvailable image-to-video workflows:'));
      img2vidWorkflows.forEach(w => {
        console.log(chalk.gray(`  - ${w.name}: ${w.description}`));
      });
      console.log();
    }

    process.exit(1);
  }

  if (workflowConfig.type !== 'img2vid') {
    console.log(chalk.red.bold(`Error: Workflow "${workflowName}" is not an image-to-video workflow`));
    console.log(chalk.gray(`Type: ${workflowConfig.type}`));
    if (options._batchMode) {
      throw new Error(`Workflow "${workflowName}" is not an image-to-video workflow`);
    }
    process.exit(1);
  }

  console.log(chalk.gray(`Description: ${workflowConfig.description}`));

  // Load API file
  const apiPath = workflowConfig.api;
  if (!apiPath) {
    console.log(chalk.red.bold('Error: Workflow configuration missing "api" field'));
    if (options._batchMode) {
      throw new Error('Workflow configuration missing "api" field');
    }
    process.exit(1);
  }

  const apiData = configManager.loadApiFile(apiPath);
  if (!apiData) {
    console.log(chalk.red.bold(`Error: Failed to load API file: ${apiPath}`));
    if (options._batchMode) {
      throw new Error('Failed to load API file: ' + apiPath);
    }
    process.exit(1);
  }

  // Validate workflow
  const validation = validateWorkflow(apiData);
  if (!validation.valid) {
    console.log(chalk.red.bold('Error: Invalid workflow format'));
    validation.errors.forEach((error, index) => {
      console.log(chalk.red(`  ${index + 1}. ${error}`));
    });
    if (options._batchMode) {
      throw new Error('Invalid workflow format: ' + validation.errors.join('; '));
    }
    process.exit(1);
  }

  // Get server configuration
  const serverConfig = configManager.getServerConfig();

  // Create ComfyHelper instance
  const comfyHelper = new ComfyHelper(
    serverConfig.host,
    serverConfig.port,
    serverConfig.apiKey
  );

  // Upload input image
  const uploadSpinner = ora('Uploading input image...').start();

  try {
    // Connect to ComfyUI server
    await comfyHelper.connect();

    // Upload the input image
    const uploadResult = await comfyHelper.uploadImage(inputPath);

    if (!uploadResult) {
      uploadSpinner.fail('Failed to upload input image');
      await comfyHelper.disconnect();
      if (options._batchMode) {
        throw new Error('Failed to upload input image');
      }
      process.exit(1);
    }

    const uploadedFilename = uploadResult.name;
    uploadSpinner.succeed(`Input image uploaded: ${uploadedFilename}`);

    // Connect confirmation
    console.log(chalk.gray(`Connected to ${serverConfig.host}:${serverConfig.port}`));

    // Prepare prompt variables
    const promptVars = {
      active_prompt: prompt,
      negative_prompt: negative,
      sample_image: uploadedFilename
    };

    // Prepare workflow parameters
    const workflowParams = {};
    if (options.steps !== undefined) workflowParams.steps = options.steps;
    if (options.cfg !== undefined) workflowParams.cfg = options.cfg;
    if (options.seed !== undefined) {
      workflowParams.seed = options.seed;
    } else {
      // Generate random seed if not provided
      workflowParams.seed = randomInt(1, 2147483647);
      console.log(chalk.gray(`Generated seed: ${workflowParams.seed}`));
    }
    if (options.width !== undefined) workflowParams.width = options.width;
    if (options.height !== undefined) workflowParams.height = options.height;
    if (options.fps !== undefined) workflowParams.fps = options.fps;
    if (options.frames !== undefined) workflowParams.frames = options.frames;
    if (options.format !== undefined) workflowParams.format = format;
    if (options.motion !== undefined) workflowParams.motion = options.motion;

    // Resolve size alias if provided
    if (options.size) {
      const resolutionType = 'pic_gen';
      const orientation = options.orientation || '0';
      const resolved = configManager.resolveResolution(options.size, orientation, resolutionType);
      if (resolved) {
        if (options.width === undefined) workflowParams.width = resolved.width;
        if (options.height === undefined) workflowParams.height = resolved.height;
      } else {
        console.log(chalk.yellow(`Warning: Unknown size alias "${options.size}" for orientation "${orientation}"`));
      }
    }

    // Apply variable replacement and parameter merging
    let workflow = replaceVariables(apiData, workflowConfig.data || [], promptVars);
    workflow = mergeWorkflowParams(workflow, workflowParams);

    // Create progress monitor
    const progressMonitor = new ProgressMonitor(comfyHelper);

    // Queue the workflow
    console.log(chalk.blue('Submitting workflow...'));
    const queueResult = await comfyHelper.queuePrompt(workflow);

    if (!queueResult || !queueResult.prompt_id) {
      throw new Error('Failed to queue workflow');
    }

    const promptId = queueResult.prompt_id;
    console.log(chalk.gray(`Prompt ID: ${promptId}`));

    // Wait for completion with progress monitoring
    // Video generation can take longer, use 10 minute timeout
    console.log(chalk.blue(`Running workflow (${workflowName})...`));
    await progressMonitor.waitForCompletion(promptId, {
      timeout: 600000, // 10 minutes for video generation
      workflowName
    });

    // Get history to find output files
    console.log(chalk.blue('Retrieving output...'));
    const history = await comfyHelper.getHistory(promptId);

    if (!history || !history[promptId]) {
      throw new Error('No history found for completed workflow');
    }

    const promptData = history[promptId];
    const outputs = promptData.outputs || {};

    // Create output directory
    await fs.promises.mkdir(outputDir, { recursive: true });

    // Download output videos
    let downloadedCount = 0;
    const downloadedFiles = [];

    for (const [nodeId, nodeOutput] of Object.entries(outputs)) {
      // Check for videos
      if (nodeOutput.videos && nodeOutput.videos.length > 0) {
        for (const video of nodeOutput.videos) {
          const filename = video.filename;
          const subfolder = video.subfolder || '';
          const videoType = video.type || 'output';
          const videoFormat = video.format || format;

          // Generate output filename with correct extension
          const extension = `.${videoFormat}`;
          const outputFilename = generateOutputFilename(workflowName, extension);
          const outputPath = path.join(outputDir, outputFilename);

          // Download video using getVideo
          const buffer = await comfyHelper.getVideo(filename, subfolder, videoFormat);
          if (buffer) {
            await fs.promises.writeFile(outputPath, buffer);
            downloadedCount++;
            downloadedFiles.push(outputPath);
          }
        }
      }

      // Check for GIFs (some workflows output GIFs)
      if (nodeOutput.gifs && nodeOutput.gifs.length > 0) {
        for (const gif of nodeOutput.gifs) {
          const filename = gif.filename;
          const subfolder = gif.subfolder || '';
          const gifFormat = gif.format || 'gif';

          // Generate output filename
          const outputFilename = generateOutputFilename(workflowName, '.gif');
          const outputPath = path.join(outputDir, outputFilename);

          // Download GIF using getVideo
          const buffer = await comfyHelper.getVideo(filename, subfolder, gifFormat);
          if (buffer) {
            await fs.promises.writeFile(outputPath, buffer);
            downloadedCount++;
            downloadedFiles.push(outputPath);
          }
        }
      }

      // Also check for images (some video workflows save as image sequences)
      if (nodeOutput.images && nodeOutput.images.length > 0) {
        for (const image of nodeOutput.images) {
          const filename = image.filename;
          const subfolder = image.subfolder || '';
          const imageType = image.type || 'output';

          // Only download if it looks like a video file (has video extension)
          const ext = path.extname(filename).toLowerCase();
          if (['.mp4', '.webm', '.gif', '.mov'].includes(ext)) {
            const outputFilename = generateOutputFilename(workflowName, ext);
            const outputPath = path.join(outputDir, outputFilename);

            // Try to download as video first
            const buffer = await comfyHelper.getVideo(filename, subfolder, ext.replace('.', ''));
            if (buffer) {
              await fs.promises.writeFile(outputPath, buffer);
              downloadedCount++;
              downloadedFiles.push(outputPath);
            } else {
              // Fallback to downloadOutput
              const success = await comfyHelper.downloadOutput(
                filename,
                outputPath,
                subfolder,
                imageType
              );

              if (success) {
                downloadedCount++;
                downloadedFiles.push(outputPath);
              }
            }
          }
        }
      }
    }

    // Extract and save metadata for each downloaded file
    const metadataPaths = [];
    if (downloadedCount > 0) {
      for (const outputFile of downloadedFiles) {
        const outputFilename = path.basename(outputFile);
        const metadata = extractMetadata(history, workflowName, {
          promptId,
          inputPath: input,
          outputFilename
        });

        try {
          const metadataPath = await saveMetadata(outputFilename, metadata, outputDir);
          metadataPaths.push(metadataPath);
        } catch (error) {
          console.error(`Error saving metadata for ${outputFilename}:`, error.message);
        }
      }
    }

    // Display results
    console.log();
    if (downloadedCount > 0) {
      console.log(chalk.green.bold('Workflow completed successfully!'));
      console.log(chalk.gray(`Generated ${downloadedCount} video(s):`));
      downloadedFiles.forEach(file => {
        console.log(chalk.green(`✔ Video saved to: ${file}`));
      });
      if (metadataPaths.length > 0) {
        console.log(chalk.gray(`Metadata saved:`));
        metadataPaths.forEach(metaPath => {
          console.log(chalk.cyan(`  - ${metaPath}`));
        });
      }
      console.log();

      // Upload to dufs server if enabled (default: true)
      const shouldUpload = options.upload !== false;
      if (shouldUpload) {
        const uploadConfig = configManager.getUploadConfig();
        if (uploadConfig && uploadConfig.server) {
          console.log(chalk.blue('Uploading to server...'));
          const uploader = new DufsUploader(uploadConfig);

          // Upload all generated files
          const allFilesToUpload = [...downloadedFiles, ...metadataPaths];
          const uploadResult = await uploader.uploadFiles(allFilesToUpload);

          if (uploadResult.success) {
            console.log(chalk.green.bold('All files uploaded successfully!'));
            // Display share URL if configured, otherwise use local URL
            const dirUrl = uploader.getShareDirUrl();
            console.log(chalk.gray(`Directory: ${dirUrl}`));
            // Display each file's share URL
            console.log(chalk.gray('Files:'));
            uploadResult.results.forEach(r => {
              if (r.success) {
                const shareUrl = uploader.getShareUrl(path.basename(r.local));
                console.log(chalk.cyan(`  - ${shareUrl}`));
              }
            });
          } else {
            console.log(chalk.yellow('Some files failed to upload:'));
            uploadResult.results.forEach(r => {
              if (!r.success) {
                console.log(chalk.red(`  - ${r.local}: ${r.error}`));
              }
            });
          }
          console.log();
        } else {
          console.log(chalk.yellow('Upload skipped: server not configured in server_config.json'));
          console.log();
        }
      }
    } else {
      console.log(chalk.yellow('Workflow completed but no videos were generated'));
      console.log();
    }

    // Disconnect
    await comfyHelper.disconnect();

    if (options._batchMode) {
      return { success: true, files: downloadedFiles, metadata: metadataPaths };
    }
    process.exit(0);

  } catch (error) {
    console.log();
    console.log(chalk.red.bold('Workflow execution failed!'));
    console.log(chalk.red(`Error: ${error.message}`));

    // Disconnect
    try {
      await comfyHelper.disconnect();
    } catch (e) {
      // Ignore disconnect errors
    }

    if (options._batchMode) {
      throw error;
    }
    process.exit(1);
  }
}

export default img2vidCommand;
