import { txt2imgCommand } from './txt2img.js';
import { img2imgCommand } from './img2img.js';
import { txt2vidCommand } from './txt2vid.js';
import { img2vidCommand } from './img2vid.js';
import { img2vid2Command } from './2img2vid.js';
import { imagescaleCommand } from './imagescale.js';
import chalk from 'chalk';
import path from 'path';
import fs from 'fs';

const SUPPORTED_TYPES = ['txt2img', 'img2img', 'txt2vid', 'img2vid', '2img2video', 'imagescale'];

// Argument mapping functions

function mapTxt2ImgArgs(task, globalOptions) {
  return {
    positional: [task.prompt || ''],
    options: {
      negative: task.negative,
      output: globalOptions.output || task.output,
      config: globalOptions.config || task.config,
      workflow: task.workflow,
      steps: task.steps,
      cfg: task.cfg,
      seed: task.seed,
      width: task.width,
      height: task.height,
      size: task.size,
      orientation: task.orientation,
      upload: globalOptions.upload !== undefined ? globalOptions.upload : task.upload,
      project: task.project,
      category: task.category,
      name: task.name,
      _batchMode: true,
    }
  };
}

function mapImg2ImgArgs(task, globalOptions) {
  return {
    positional: [task.image || '', task.prompt || ''],
    options: {
      negative: task.negative,
      output: globalOptions.output || task.output,
      config: globalOptions.config || task.config,
      workflow: task.workflow,
      strength: task.strength,
      steps: task.steps,
      cfg: task.cfg,
      seed: task.seed,
      width: task.width,
      height: task.height,
      size: task.size,
      orientation: task.orientation,
      upload: globalOptions.upload !== undefined ? globalOptions.upload : task.upload,
      _batchMode: true,
    }
  };
}

function mapTxt2VidArgs(task, globalOptions) {
  return {
    positional: [task.prompt || ''],
    options: {
      negative: task.negative,
      output: globalOptions.output || task.output,
      config: globalOptions.config || task.config,
      workflow: task.workflow,
      format: task.format,
      fps: task.fps,
      frames: task.frames,
      steps: task.steps,
      cfg: task.cfg,
      seed: task.seed,
      width: task.width,
      height: task.height,
      size: task.size,
      orientation: task.orientation,
      upload: globalOptions.upload !== undefined ? globalOptions.upload : task.upload,
      _batchMode: true,
    }
  };
}

function mapImg2VidArgs(task, globalOptions) {
  return {
    positional: [task.image || ''],
    options: {
      prompt: task.prompt,
      negative: task.negative,
      output: globalOptions.output || task.output,
      config: globalOptions.config || task.config,
      workflow: task.workflow,
      format: task.format,
      fps: task.fps,
      frames: task.frames,
      steps: task.steps,
      cfg: task.cfg,
      seed: task.seed,
      width: task.width,
      height: task.height,
      size: task.size,
      orientation: task.orientation,
      motion: task.motion,
      upload: globalOptions.upload !== undefined ? globalOptions.upload : task.upload,
      _batchMode: true,
    }
  };
}

function map2Img2VideoArgs(task, globalOptions) {
  const [img1, img2] = (task.image || '').split(',').map(p => p.trim());
  return {
    positional: [img1 || '', img2 || ''],
    options: {
      prompt: task.prompt,
      negative: task.negative,
      output: globalOptions.output || task.output,
      config: globalOptions.config || task.config,
      workflow: task.workflow,
      format: task.format,
      fps: task.fps,
      frames: task.frames,
      steps: task.steps,
      cfg: task.cfg,
      seed: task.seed,
      width: task.width,
      height: task.height,
      size: task.size,
      orientation: task.orientation,
      motion: task.motion,
      upload: globalOptions.upload !== undefined ? globalOptions.upload : task.upload,
      _batchMode: true,
    }
  };
}

function mapImageScaleArgs(task, globalOptions) {
  return {
    positional: [task.image || ''],
    options: {
      output: globalOptions.output || task.output,
      config: globalOptions.config || task.config,
      workflow: task.workflow,
      size: task.size,
      orientation: task.orientation,
      width: task.width,
      height: task.height,
      seed: task.seed,
      upload: globalOptions.upload !== undefined ? globalOptions.upload : task.upload,
      _batchMode: true,
    }
  };
}

const COMMAND_MAP = {
  'txt2img': { fn: txt2imgCommand, mapArgs: mapTxt2ImgArgs },
  'img2img': { fn: img2imgCommand, mapArgs: mapImg2ImgArgs },
  'txt2vid': { fn: txt2vidCommand, mapArgs: mapTxt2VidArgs },
  'img2vid': { fn: img2vidCommand, mapArgs: mapImg2VidArgs },
  '2img2video': { fn: img2vid2Command, mapArgs: map2Img2VideoArgs },
  'imagescale': { fn: imagescaleCommand, mapArgs: mapImageScaleArgs },
};

// Progress file management

function getProgressFilePath(jsonFilePath) {
  const dir = path.dirname(jsonFilePath);
  const ext = path.extname(jsonFilePath);
  const base = path.basename(jsonFilePath, ext);
  return path.join(dir, base + '.p');
}

function initProgress(tasks, jsonFilePath) {
  return {
    sourceFile: path.basename(jsonFilePath),
    startTime: new Date().toISOString(),
    lastUpdate: new Date().toISOString(),
    totalTasks: tasks.length,
    nextIndex: 0,
    results: []
  };
}

function saveProgress(progressPath, progress) {
  fs.writeFileSync(progressPath, JSON.stringify(progress, null, 2), 'utf-8');
}

function loadProgress(progressPath) {
  if (!fs.existsSync(progressPath)) return null;
  try {
    const data = fs.readFileSync(progressPath, 'utf-8');
    return JSON.parse(data);
  } catch {
    return null;
  }
}

function validateTasks(tasks) {
  if (!Array.isArray(tasks)) {
    throw new Error('JSON file must contain an array of tasks');
  }
  for (let i = 0; i < tasks.length; i++) {
    const task = tasks[i];
    if (!task.type) {
      throw new Error(`Task at index ${i} is missing "type" field`);
    }
    if (!SUPPORTED_TYPES.includes(task.type)) {
      throw new Error(`Task at index ${i} has unsupported type "${task.type}". Supported: ${SUPPORTED_TYPES.join(', ')}`);
    }
  }
}

function printSummary(progress) {
  const successCount = progress.results.filter(r => r.status === 'success').length;
  const failedCount = progress.results.filter(r => r.status === 'failed').length;
  const skippedCount = progress.totalTasks - progress.nextIndex;

  console.log();
  console.log(chalk.bold.blue('Batch Execution Summary'));
  console.log(chalk.gray('\u2500'.repeat(50)));
  console.log(chalk.gray(`Total tasks: ${progress.totalTasks}`));
  console.log(chalk.green(`Successful: ${successCount}`));
  if (failedCount > 0) {
    console.log(chalk.red(`Failed: ${failedCount}`));
  }
  if (skippedCount > 0) {
    console.log(chalk.yellow(`Skipped: ${skippedCount}`));
  }
  console.log(chalk.gray(`Executed: ${progress.nextIndex} of ${progress.totalTasks}`));

  // List failed tasks
  const failedTasks = progress.results.filter(r => r.status === 'failed');
  if (failedTasks.length > 0) {
    console.log();
    console.log(chalk.red.bold('Failed Tasks:'));
    failedTasks.forEach(r => {
      console.log(chalk.red(`  [${r.index}] ${r.type}: ${r.error}`));
    });
  }

  // List successful tasks with files
  const successTasks = progress.results.filter(r => r.status === 'success' && r.files && r.files.length > 0);
  if (successTasks.length > 0) {
    console.log();
    console.log(chalk.green.bold('Generated Files:'));
    successTasks.forEach(r => {
      r.files.forEach(f => {
        console.log(chalk.green(`  [${r.index}] ${r.type}: ${f}`));
      });
    });
  }

  console.log();
}

/**
 * Execute a single task by routing to the appropriate command function
 */
async function executeTask(task, globalOptions) {
  const entry = COMMAND_MAP[task.type];
  if (!entry) {
    throw new Error(`Unknown task type: ${task.type}`);
  }

  const { positional, options } = entry.mapArgs(task, globalOptions);

  // Call the command function with positional args and options
  const result = await entry.fn(...positional, options);
  return result;
}

/**
 * Batch command - execute multiple commands from a JSON file
 * @param {string} jsonFilePath - Path to JSON file containing tasks
 * @param {object} options - Command options
 */
export async function batchCommand(jsonFilePath, options = {}) {
  // Resolve absolute path
  const absJsonPath = path.resolve(jsonFilePath);

  // Handle --clean option
  if (options.clean) {
    const progressPath = getProgressFilePath(absJsonPath);
    if (fs.existsSync(progressPath)) {
      fs.unlinkSync(progressPath);
      console.log(chalk.green(`Progress file deleted: ${progressPath}`));
    } else {
      console.log(chalk.yellow('No progress file found'));
    }
    return;
  }

  // Read and validate JSON file
  if (!fs.existsSync(absJsonPath)) {
    console.log(chalk.red.bold(`Error: File not found: ${jsonFilePath}`));
    process.exit(1);
  }

  let tasks;
  try {
    const rawContent = fs.readFileSync(absJsonPath, 'utf-8');
    tasks = JSON.parse(rawContent);
  } catch (error) {
    console.log(chalk.red.bold(`Error: Failed to parse JSON file: ${error.message}`));
    process.exit(1);
  }

  try {
    validateTasks(tasks);
  } catch (error) {
    console.log(chalk.red.bold(`Error: Invalid tasks format: ${error.message}`));
    process.exit(1);
  }

  // Handle --dry-run option
  if (options.dryRun) {
    console.log(chalk.green.bold('Dry run - JSON validation passed'));
    console.log(chalk.gray(`Found ${tasks.length} tasks:`));
    tasks.forEach((task, i) => {
      console.log(chalk.gray(`  ${i + 1}. ${task.type}${task.prompt ? ': ' + task.prompt.substring(0, 50) : ''}`));
    });
    return;
  }

  console.log(chalk.bold.blue('\nBatch Execution'));
  console.log(chalk.gray('\u2500'.repeat(50)));
  console.log(chalk.gray(`File: ${jsonFilePath}`));
  console.log(chalk.gray(`Tasks: ${tasks.length}`));
  console.log();

  // Determine progress file path
  const progressPath = getProgressFilePath(absJsonPath);

  // Load or initialize progress
  let progress;
  if (options.restart) {
    // Force restart - ignore progress file
    progress = initProgress(tasks, absJsonPath);
    console.log(chalk.yellow('Restarting from beginning (--restart flag)'));
  } else {
    const existingProgress = loadProgress(progressPath);
    if (existingProgress) {
      // Validate existing progress matches current file
      if (existingProgress.sourceFile === path.basename(absJsonPath) &&
          existingProgress.totalTasks === tasks.length) {
        if (existingProgress.nextIndex >= tasks.length) {
          console.log(chalk.green.bold('All tasks already completed!'));
          printSummary(existingProgress);
          return;
        }
        progress = existingProgress;
        console.log(chalk.cyan(`Resuming from task ${progress.nextIndex + 1} of ${tasks.length}`));
        console.log(chalk.gray(`Previously completed: ${progress.results.length} tasks`));
        console.log();
      } else {
        // File has changed - warn user
        console.log(chalk.yellow.bold('Warning: JSON file has been modified since last execution'));
        console.log(chalk.yellow('Starting from beginning'));
        progress = initProgress(tasks, absJsonPath);
      }
    } else {
      progress = initProgress(tasks, absJsonPath);
    }
  }

  // Execute tasks from nextIndex
  for (let i = progress.nextIndex; i < tasks.length; i++) {
    const task = tasks[i];
    const taskNum = i + 1;

    console.log(chalk.bold.cyan(`[${taskNum}/${tasks.length}] Executing: ${task.type}`));
    if (task.prompt) {
      console.log(chalk.gray(`  Prompt: ${task.prompt.substring(0, 80)}`));
    }
    if (task.image) {
      console.log(chalk.gray(`  Image: ${task.image}`));
    }

    const startTime = Date.now();
    try {
      const result = await executeTask(task, options);
      const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);

      const resultEntry = {
        index: i,
        type: task.type,
        status: 'success',
        files: (result && result.files) ? result.files : [],
        timestamp: new Date().toISOString()
      };
      progress.results.push(resultEntry);

      console.log(chalk.green(`  Completed in ${elapsed}s`));
      if (resultEntry.files.length > 0) {
        resultEntry.files.forEach(f => {
          console.log(chalk.green(`  Output: ${f}`));
        });
      }
    } catch (error) {
      const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
      const resultEntry = {
        index: i,
        type: task.type,
        status: 'failed',
        error: error.message,
        timestamp: new Date().toISOString()
      };
      progress.results.push(resultEntry);

      console.log(chalk.red(`  Failed in ${elapsed}s: ${error.message}`));

      if (!options.continueOnError) {
        console.log(chalk.yellow('Stopping batch execution (use --continue-on-error to continue)'));
        progress.nextIndex = i + 1;
        progress.lastUpdate = new Date().toISOString();
        saveProgress(progressPath, progress);
        printSummary(progress);
        process.exit(1);
      }
    }

    // Update progress after each task
    progress.nextIndex = i + 1;
    progress.lastUpdate = new Date().toISOString();
    saveProgress(progressPath, progress);
    console.log();
  }

  // Print summary
  printSummary(progress);
}

export {
  mapTxt2ImgArgs,
  mapImg2ImgArgs,
  mapTxt2VidArgs,
  mapImg2VidArgs,
  map2Img2VideoArgs,
  mapImageScaleArgs,
  getProgressFilePath,
  initProgress,
  saveProgress,
  loadProgress,
  validateTasks,
  executeTask
};

export default batchCommand;
