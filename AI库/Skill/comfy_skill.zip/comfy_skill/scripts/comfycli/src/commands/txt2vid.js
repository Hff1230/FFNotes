import ConfigManager from '../utils/config.js';
import Logger from '../utils/logger.js';
import ComfyHelper from '../core/helper.js';
import ProgressMonitor from '../core/progress.js';
import {
  replaceVariables,
  validateWorkflow,
  mergeWorkflowParams,
  findTxt2VidWorkflows,
  generateOutputFilename
} from '../core/workflow.js';
import { extractMetadata, saveMetadata } from '../utils/metadata.js';
import DufsUploader from '../utils/uploader.js';
import chalk from 'chalk';
import path from 'path';
import fs from 'fs';
import { randomInt } from 'crypto';

/**
 * Text to Video command implementation
 * @param {string} prompt - Positive prompt text
 * @param {object} options - Command options
 * @param {string} options.negative - Negative prompt text
 * @param {string} options.output - Output directory path
 * @param {string} options.config - Path to configuration file
 * @param {string} options.workflow - Workflow name (default: want2v)
 * @param {string} options.format - Output format (mp4/gif, default: mp4)
 * @param {number} options.fps - Frame rate
 * @param {number} options.frames - Total number of frames
 * @param {number} options.width - Video width
 * @param {number} options.height - Video height
 * @param {number} options.seed - Random seed (default: random)
 */
export async function txt2vidCommand(prompt, options = {}) {
  // Validate prompt
  if (!prompt || prompt.trim().length === 0) {
    if (options._batchMode) {
      throw new Error('Prompt is required');
    }
    console.log(chalk.red.bold('Error: Prompt is required'));
    console.log(chalk.gray('Usage: npx comfycli txt2vid "<your prompt>"'));
    process.exit(1);
  }

  // Set default options
  const configPath = options.config || './config/comfy_config.json';
  const outputDir = options.output;
  const workflowName = options.workflow || 'want2v';
  const negative = options.negative || '';
  const format = options.format || 'mp4';

  // Validate format
  const supportedFormats = ['mp4', 'gif'];
  if (!supportedFormats.includes(format.toLowerCase())) {
    if (options._batchMode) {
      throw new Error(`Unsupported format: ${format}`);
    }
    console.log(chalk.red.bold(`Error: Unsupported format: ${format}`));
    console.log(chalk.yellow(`Supported formats: ${supportedFormats.join(', ')}`));
    process.exit(1);
  }

  // Display command info
  console.log(chalk.bold.blue('\nText to Video Generation'));
  console.log(chalk.gray('─'.repeat(50)));
  console.log(chalk.gray(`Prompt: ${prompt}`));
  if (negative) {
    console.log(chalk.gray(`Negative: ${negative}`));
  }
  console.log(chalk.gray(`Workflow: ${workflowName}`));
  console.log(chalk.gray(`Format: ${format}`));
  console.log(chalk.gray(`Output: ${outputDir}`));
  if (options.fps) console.log(chalk.gray(`FPS: ${options.fps}`));
  if (options.frames) console.log(chalk.gray(`Frames: ${options.frames}`));
  if (options.width) console.log(chalk.gray(`Width: ${options.width}`));
  if (options.height) console.log(chalk.gray(`Height: ${options.height}`));
  console.log();

  // Initialize configuration manager
  const configManager = new ConfigManager(configPath);

  // Load configuration
  if (!configManager.load()) {
    if (options._batchMode) {
      throw new Error('Failed to load configuration file');
    }
    console.log(chalk.red.bold('Error: Failed to load configuration file'));
    console.log(chalk.gray(`Path: ${configPath}`));
    process.exit(1);
  }

  // Validate that the workflow exists and is txt2vid type
  const workflowConfig = configManager.getWorkflow(workflowName);

  if (!workflowConfig) {
    if (options._batchMode) {
      throw new Error('Workflow not found: ' + workflowName);
    }
    console.log(chalk.red.bold(`Error: Workflow not found: ${workflowName}`));

    // List available txt2vid workflows
    const allWorkflows = configManager.listWorkflows();
    const txt2vidWorkflows = findTxt2VidWorkflows(allWorkflows);

    if (txt2vidWorkflows.length > 0) {
      console.log(chalk.yellow('\nAvailable text-to-video workflows:'));
      txt2vidWorkflows.forEach(w => {
        console.log(chalk.gray(`  - ${w.name}: ${w.description}`));
      });
      console.log();
    }

    process.exit(1);
  }

  if (workflowConfig.type !== 'txt2vid') {
    if (options._batchMode) {
      throw new Error(`Workflow "${workflowName}" is not a text-to-video workflow`);
    }
    console.log(chalk.red.bold(`Error: Workflow "${workflowName}" is not a text-to-video workflow`));
    console.log(chalk.gray(`Type: ${workflowConfig.type}`));
    process.exit(1);
  }

  console.log(chalk.gray(`Description: ${workflowConfig.description}`));

  // Load API file
  const apiPath = workflowConfig.api;
  if (!apiPath) {
    if (options._batchMode) {
      throw new Error('Workflow configuration missing "api" field');
    }
    console.log(chalk.red.bold('Error: Workflow configuration missing "api" field'));
    process.exit(1);
  }

  const apiData = configManager.loadApiFile(apiPath);
  if (!apiData) {
    if (options._batchMode) {
      throw new Error('Failed to load API file: ' + apiPath);
    }
    console.log(chalk.red.bold(`Error: Failed to load API file: ${apiPath}`));
    process.exit(1);
  }

  // Validate workflow
  const validation = validateWorkflow(apiData);
  if (!validation.valid) {
    if (options._batchMode) {
      throw new Error('Invalid workflow format: ' + validation.errors.join('; '));
    }
    console.log(chalk.red.bold('Error: Invalid workflow format'));
    validation.errors.forEach((error, index) => {
      console.log(chalk.red(`  ${index + 1}. ${error}`));
    });
    process.exit(1);
  }

  // Prepare prompt variables
  const promptVars = {
    active_prompt: prompt,
    negative_prompt: negative
  };

  // Prepare workflow parameters
  const workflowParams = {};
  if (options.steps !== undefined) workflowParams.steps = options.steps;
  if (options.cfg !== undefined) workflowParams.cfg = options.cfg;
  if (options.seed !== undefined) {
    workflowParams.seed = options.seed;
  } else {
    // Generate random seed if not provided
    workflowParams.seed = randomInt(1, 2147483647);
    console.log(chalk.gray(`Generated seed: ${workflowParams.seed}`));
  }
  if (options.width !== undefined) workflowParams.width = options.width;
  if (options.height !== undefined) workflowParams.height = options.height;
  if (options.fps !== undefined) workflowParams.fps = options.fps;
  if (options.frames !== undefined) workflowParams.frames = options.frames;
  if (options.format !== undefined) workflowParams.format = format;

  // Resolve size alias if provided
  if (options.size) {
    const resolutionType = 'pic_gen';
    const orientation = options.orientation || '0';
    const resolved = configManager.resolveResolution(options.size, orientation, resolutionType);
    if (resolved) {
      if (options.width === undefined) workflowParams.width = resolved.width;
      if (options.height === undefined) workflowParams.height = resolved.height;
    } else {
      console.log(chalk.yellow(`Warning: Unknown size alias "${options.size}" for orientation "${orientation}"`));
    }
  }

  // Apply variable replacement and parameter merging
  let workflow = replaceVariables(apiData, workflowConfig.data || [], promptVars);
  workflow = mergeWorkflowParams(workflow, workflowParams);

  // Get server configuration
  const serverConfig = configManager.getServerConfig();

  // Create ComfyHelper instance
  const comfyHelper = new ComfyHelper(
    serverConfig.host,
    serverConfig.port,
    serverConfig.apiKey
  );

  // Create progress monitor
  const progressMonitor = new ProgressMonitor(comfyHelper);

  try {
    // Connect to ComfyUI server
    console.log(chalk.blue('Connecting to ComfyUI server...'));
    await comfyHelper.connect();
    console.log(chalk.green(`Connected to ${serverConfig.host}:${serverConfig.port}`));

    // Queue the workflow
    console.log(chalk.blue('Submitting workflow...'));
    const queueResult = await comfyHelper.queuePrompt(workflow);

    if (!queueResult || !queueResult.prompt_id) {
      throw new Error('Failed to queue workflow');
    }

    const promptId = queueResult.prompt_id;
    console.log(chalk.gray(`Prompt ID: ${promptId}`));

    // Wait for completion with progress monitoring
    // Video generation can take longer, use 10 minute timeout
    console.log(chalk.blue('Running workflow...'));
    await progressMonitor.waitForCompletion(promptId, {
      timeout: 600000, // 10 minutes for video generation
      workflowName
    });

    // Get history to find output files
    console.log(chalk.blue('Retrieving output...'));
    const history = await comfyHelper.getHistory(promptId);

    if (!history || !history[promptId]) {
      throw new Error('No history found for completed workflow');
    }

    const promptData = history[promptId];
    const outputs = promptData.outputs || {};

    // Extract metadata from history data
    const metadata = extractMetadata(history, workflowName, {
      promptId,
      outputFilename: null // Will be updated after download
    });

    // Create output directory
    await fs.promises.mkdir(outputDir, { recursive: true });

    // Download output videos
    let downloadedCount = 0;
    const downloadedFiles = [];
    const metadataPaths = [];

    for (const [nodeId, nodeOutput] of Object.entries(outputs)) {
      // Check for videos
      if (nodeOutput.videos && nodeOutput.videos.length > 0) {
        for (const video of nodeOutput.videos) {
          const filename = video.filename;
          const subfolder = video.subfolder || '';
          const videoType = video.type || 'output';
          const videoFormat = video.format || format;

          // Generate output filename with correct extension
          const extension = `.${videoFormat}`;
          const outputFilename = generateOutputFilename(workflowName, extension);
          const outputPath = path.join(outputDir, outputFilename);

          // Download video using getVideo
          const buffer = await comfyHelper.getVideo(filename, subfolder, videoFormat);
          if (buffer) {
            await fs.promises.writeFile(outputPath, buffer);
            downloadedCount++;
            downloadedFiles.push(outputPath);

            // Save metadata for this video
            metadata.output_filename = outputFilename;
            const metadataPath = await saveMetadata(outputFilename, metadata, outputDir);
            metadataPaths.push(metadataPath);
          }
        }
      }

      // Check for GIFs (some workflows output GIFs)
      if (nodeOutput.gifs && nodeOutput.gifs.length > 0) {
        for (const gif of nodeOutput.gifs) {
          const filename = gif.filename;
          const subfolder = gif.subfolder || '';
          const gifFormat = gif.format || 'gif';

          // Generate output filename
          const outputFilename = generateOutputFilename(workflowName, '.gif');
          const outputPath = path.join(outputDir, outputFilename);

          // Download GIF using getVideo
          const buffer = await comfyHelper.getVideo(filename, subfolder, gifFormat);
          if (buffer) {
            await fs.promises.writeFile(outputPath, buffer);
            downloadedCount++;
            downloadedFiles.push(outputPath);

            // Save metadata for this GIF
            metadata.output_filename = outputFilename;
            const metadataPath = await saveMetadata(outputFilename, metadata, outputDir);
            metadataPaths.push(metadataPath);
          }
        }
      }

      // Also check for images (some video workflows save as image sequences)
      if (nodeOutput.images && nodeOutput.images.length > 0) {
        for (const image of nodeOutput.images) {
          const filename = image.filename;
          const subfolder = image.subfolder || '';
          const imageType = image.type || 'output';

          // Only download if it looks like a video file (has video extension)
          const ext = path.extname(filename).toLowerCase();
          if (['.mp4', '.webm', '.gif', '.mov'].includes(ext)) {
            const outputFilename = generateOutputFilename(workflowName, ext);
            const outputPath = path.join(outputDir, outputFilename);

            // Try to download as video first
            const buffer = await comfyHelper.getVideo(filename, subfolder, ext.replace('.', ''));
            if (buffer) {
              await fs.promises.writeFile(outputPath, buffer);
              downloadedCount++;
              downloadedFiles.push(outputPath);

              // Save metadata for this video
              metadata.output_filename = outputFilename;
              const metadataPath = await saveMetadata(outputFilename, metadata, outputDir);
              metadataPaths.push(metadataPath);
            } else {
              // Fallback to downloadOutput
              const success = await comfyHelper.downloadOutput(
                filename,
                outputPath,
                subfolder,
                imageType
              );

              if (success) {
                downloadedCount++;
                downloadedFiles.push(outputPath);

                // Save metadata for this video
                metadata.output_filename = outputFilename;
                const metadataPath = await saveMetadata(outputFilename, metadata, outputDir);
                metadataPaths.push(metadataPath);
              }
            }
          }
        }
      }
    }

    // Display results
    console.log();
    if (downloadedCount > 0) {
      console.log(chalk.green.bold('Workflow completed successfully!'));
      console.log(chalk.gray(`Generated ${downloadedCount} video(s):`));
      downloadedFiles.forEach(file => {
        console.log(chalk.green(`  Video saved to: ${file}`));
      });
      // Display metadata save paths
      if (metadataPaths.length > 0) {
        console.log(chalk.gray(`Metadata saved:`));
        metadataPaths.forEach(metaPath => {
          console.log(chalk.cyan(`  Metadata saved to: ${metaPath}`));
        });
      }
      console.log();

      // Upload to dufs server if enabled (default: true)
      const shouldUpload = options.upload !== false;
      if (shouldUpload) {
        const uploadConfig = configManager.getUploadConfig();
        if (uploadConfig && uploadConfig.server) {
          console.log(chalk.blue('Uploading to server...'));
          const uploader = new DufsUploader(uploadConfig);

          // Upload all generated files
          const allFilesToUpload = [...downloadedFiles, ...metadataPaths];
          const uploadResult = await uploader.uploadFiles(allFilesToUpload);

          if (uploadResult.success) {
            console.log(chalk.green.bold('All files uploaded successfully!'));
            // Display share URL if configured, otherwise use local URL
            const dirUrl = uploader.getShareDirUrl();
            console.log(chalk.gray(`Directory: ${dirUrl}`));
            // Display each file's share URL
            console.log(chalk.gray('Files:'));
            uploadResult.results.forEach(r => {
              if (r.success) {
                const shareUrl = uploader.getShareUrl(path.basename(r.local));
                console.log(chalk.cyan(`  - ${shareUrl}`));
              }
            });
          } else {
            console.log(chalk.yellow('Some files failed to upload:'));
            uploadResult.results.forEach(r => {
              if (!r.success) {
                console.log(chalk.red(`  - ${r.local}: ${r.error}`));
              }
            });
          }
          console.log();
        } else {
          console.log(chalk.yellow('Upload skipped: server not configured in server_config.json'));
          console.log();
        }
      }
    } else {
      console.log(chalk.yellow('Workflow completed but no videos were generated'));
      console.log();
    }

    // Disconnect
    await comfyHelper.disconnect();

    if (options._batchMode) {
      return { success: true, files: downloadedFiles, metadata: metadataPaths };
    }
    process.exit(0);

  } catch (error) {
    console.log();
    console.log(chalk.red.bold('Workflow execution failed!'));
    console.log(chalk.red(`Error: ${error.message}`));

    // Disconnect
    try {
      await comfyHelper.disconnect();
    } catch (e) {
      // Ignore disconnect errors
    }

    if (options._batchMode) {
      throw error;
    }
    process.exit(1);
  }
}

export default txt2vidCommand;
