import ConfigManager from '../utils/config.js';
import Logger from '../utils/logger.js';
import ComfyHelper from '../core/helper.js';
import ProgressMonitor from '../core/progress.js';
import {
  replaceVariables,
  validateWorkflow,
  mergeWorkflowParams,
  findTxt2ImgWorkflows,
  generateOutputFilename,
  generateOutputPath
} from '../core/workflow.js';
import { extractMetadata, saveMetadata } from '../utils/metadata.js';
import DufsUploader from '../utils/uploader.js';
import chalk from 'chalk';
import path from 'path';
import fs from 'fs';
import { randomInt } from 'crypto';

/**
 * Text to Image command implementation
 * @param {string} prompt - Positive prompt text
 * @param {object} options - Command options
 * @param {string} options.negative - Negative prompt text
 * @param {string} options.output - Output directory path
 * @param {string} options.config - Path to configuration file
 * @param {string} options.workflow - Workflow name (default: zimageturbot2i)
 * @param {number} options.steps - Sampling steps
 * @param {number} options.cfg - CFG scale
 * @param {number} options.seed - Random seed (default: random)
 * @param {number} options.width - Image width
 * @param {number} options.height - Image height
 */
export async function txt2imgCommand(prompt, options = {}) {
  // Validate prompt
  if (!prompt || prompt.trim().length === 0) {
    if (options._batchMode) {
      throw new Error('Prompt is required');
    }
    console.log(chalk.red.bold('Error: Prompt is required'));
    console.log(chalk.gray('Usage: npx comfycli txt2img "<your prompt>"'));
    process.exit(1);
  }

  // Set default options
  const configPath = options.config || './config/comfy_config.json';
  let outputDir = options.output;
  if (options.project && options.category) {
    outputDir = generateOutputPath(outputDir, {
      project: options.project,
      category: options.category
    });
  }
  const negative = options.negative || '';

  // Initialize configuration manager
  const configManager = new ConfigManager(configPath);

  // Load configuration
  if (!configManager.load()) {
    if (options._batchMode) {
      throw new Error('Failed to load configuration file');
    }
    console.log(chalk.red.bold('Error: Failed to load configuration file'));
    console.log(chalk.gray(`Path: ${configPath}`));
    process.exit(1);
  }

  // Determine workflow name: command line option > default from config > fallback
  const workflowName = options.workflow || configManager.getDefaultWorkflowName('txt2img') || 'zimageturbot2i';

  // Display command info
  console.log(chalk.bold.blue('\nText to Image Generation'));
  console.log(chalk.gray('─'.repeat(50)));
  console.log(chalk.gray(`Prompt: ${prompt}`));
  if (negative) {
    console.log(chalk.gray(`Negative: ${negative}`));
  }
  console.log(chalk.gray(`Workflow: ${workflowName}`));
  console.log(chalk.gray(`Output: ${outputDir}`));
  if (options.project) {
    console.log(chalk.gray(`Project: ${options.project}`));
    if (options.category) {
      console.log(chalk.gray(`Category: ${options.category}`));
    }
    if (options.name) {
      console.log(chalk.gray(`Name: ${options.name}`));
    }
  }
  console.log();

  // Validate that the workflow exists and is txt2img type
  const workflowConfig = configManager.getWorkflow(workflowName);

  if (!workflowConfig) {
    if (options._batchMode) {
      throw new Error('Workflow not found: ' + workflowName);
    }
    console.log(chalk.red.bold(`Error: Workflow not found: ${workflowName}`));

    // List available txt2img workflows
    const allWorkflows = configManager.listWorkflows();
    const txt2imgWorkflows = findTxt2ImgWorkflows(allWorkflows);

    if (txt2imgWorkflows.length > 0) {
      console.log(chalk.yellow('\nAvailable text-to-image workflows:'));
      txt2imgWorkflows.forEach(w => {
        console.log(chalk.gray(`  - ${w.name}: ${w.description}`));
      });
      console.log();
    }

    process.exit(1);
  }

  if (workflowConfig.type !== 'txt2img') {
    if (options._batchMode) {
      throw new Error(`Workflow "${workflowName}" is not a text-to-image workflow`);
    }
    console.log(chalk.red.bold(`Error: Workflow "${workflowName}" is not a text-to-image workflow`));
    console.log(chalk.gray(`Type: ${workflowConfig.type}`));
    process.exit(1);
  }

  console.log(chalk.gray(`Description: ${workflowConfig.description}`));

  // Load API file
  const apiPath = workflowConfig.api;
  if (!apiPath) {
    if (options._batchMode) {
      throw new Error('Workflow configuration missing "api" field');
    }
    console.log(chalk.red.bold('Error: Workflow configuration missing "api" field'));
    process.exit(1);
  }

  const apiData = configManager.loadApiFile(apiPath);
  if (!apiData) {
    if (options._batchMode) {
      throw new Error('Failed to load API file: ' + apiPath);
    }
    console.log(chalk.red.bold(`Error: Failed to load API file: ${apiPath}`));
    process.exit(1);
  }

  // Validate workflow
  const validation = validateWorkflow(apiData);
  if (!validation.valid) {
    if (options._batchMode) {
      throw new Error('Invalid workflow format: ' + validation.errors.join('; '));
    }
    console.log(chalk.red.bold('Error: Invalid workflow format'));
    validation.errors.forEach((error, index) => {
      console.log(chalk.red(`  ${index + 1}. ${error}`));
    });
    process.exit(1);
  }

  // Prepare workflow parameters
  const workflowParams = {};
  if (options.steps !== undefined) workflowParams.steps = options.steps;
  if (options.cfg !== undefined) workflowParams.cfg = options.cfg;
  if (options.seed !== undefined) {
    workflowParams.seed = options.seed;
  } else {
    // Generate random seed if not provided
    workflowParams.seed = randomInt(1, 2147483647);
    console.log(chalk.gray(`Generated seed: ${workflowParams.seed}`));
  }
  if (options.width !== undefined) workflowParams.width = options.width;
  if (options.height !== undefined) workflowParams.height = options.height;

  // Resolve size alias if provided
  if (options.size) {
    const resolutionType = 'pic_gen';
    const orientation = options.orientation || '0';
    const resolved = configManager.resolveResolution(options.size, orientation, resolutionType);
    if (resolved) {
      if (options.width === undefined) workflowParams.width = resolved.width;
      if (options.height === undefined) workflowParams.height = resolved.height;
    } else {
      console.log(chalk.yellow(`Warning: Unknown size alias "${options.size}" for orientation "${orientation}"`));
    }
  }

  // Prepare prompt variables (includes width/height for variable replacement)
  const promptVars = {
    active_prompt: prompt,
    negative_prompt: negative,
    width: workflowParams.width,
    height: workflowParams.height
  };

  // Apply variable replacement and parameter merging
  let workflow = replaceVariables(apiData, workflowConfig.data || [], promptVars);
  workflow = mergeWorkflowParams(workflow, workflowParams);

  // Get server configuration
  const serverConfig = configManager.getServerConfig();

  // Create ComfyHelper instance
  const comfyHelper = new ComfyHelper(
    serverConfig.host,
    serverConfig.port,
    serverConfig.apiKey
  );

  // Create progress monitor
  const progressMonitor = new ProgressMonitor(comfyHelper);

  try {
    // Connect to ComfyUI server
    console.log(chalk.blue('Connecting to ComfyUI server...'));
    await comfyHelper.connect();
    console.log(chalk.green(`Connected to ${serverConfig.host}:${serverConfig.port}`));

    // Queue the workflow
    console.log(chalk.blue('Submitting workflow...'));
    const queueResult = await comfyHelper.queuePrompt(workflow);

    if (!queueResult || !queueResult.prompt_id) {
      throw new Error('Failed to queue workflow');
    }

    const promptId = queueResult.prompt_id;
    console.log(chalk.gray(`Prompt ID: ${promptId}`));

    // Wait for completion with progress monitoring
    console.log(chalk.blue('Running workflow...'));
    await progressMonitor.waitForCompletion(promptId, {
      timeout: 300000, // 5 minutes
      workflowName
    });

    // Get history to find output files
    console.log(chalk.blue('Retrieving output...'));
    const history = await comfyHelper.getHistory(promptId);

    if (!history || !history[promptId]) {
      throw new Error('No history found for completed workflow');
    }

    const promptData = history[promptId];
    const outputs = promptData.outputs || {};

    // Create output directory
    await fs.promises.mkdir(outputDir, { recursive: true });

    // Download output images
    let downloadedCount = 0;
    const downloadedFiles = [];

    for (const [nodeId, nodeOutput] of Object.entries(outputs)) {
      if (nodeOutput.images && nodeOutput.images.length > 0) {
        for (const image of nodeOutput.images) {
          const filename = image.filename;
          const subfolder = image.subfolder || '';
          const imageType = image.type || 'output';

          // Generate output filename
          const outputFilename = generateOutputFilename(workflowName, path.extname(filename) || '.png', {
            project: options.project,
            category: options.category,
            name: options.name
          });
          const outputPath = path.join(outputDir, outputFilename);

          // Download image
          const success = await comfyHelper.downloadOutput(
            filename,
            outputPath,
            subfolder,
            imageType
          );

          if (success) {
            downloadedCount++;
            downloadedFiles.push(outputPath);
          }
        }
      }
    }

    // Extract and save metadata
    const metadata = extractMetadata(workflow, promptData);

    // Save metadata for each downloaded image (use actual saved filename)
    const metadataPaths = [];
    for (const downloadedFile of downloadedFiles) {
      const filename = path.basename(downloadedFile);
      const savedPath = await saveMetadata(filename, metadata, outputDir);
      metadataPaths.push(savedPath);
    }

    // Display results
    console.log();
    if (downloadedCount > 0) {
      console.log(chalk.green.bold('Workflow completed successfully!'));
      console.log(chalk.gray(`Generated ${downloadedCount} image(s):`));
      downloadedFiles.forEach(file => {
        console.log(chalk.green(`  - ${file}`));
      });
      if (metadataPaths.length > 0) {
        console.log(chalk.gray(`Metadata saved:`));
        metadataPaths.forEach(metaPath => {
          console.log(chalk.cyan(`  - ${metaPath}`));
        });
      }
      console.log();

      // Upload to dufs server if enabled (default: true)
      const shouldUpload = options.upload !== false;
      if (shouldUpload) {
        const uploadConfig = configManager.getUploadConfig();
        if (uploadConfig && uploadConfig.server) {
          console.log(chalk.blue('Uploading to server...'));
          const uploader = new DufsUploader(uploadConfig);

          // Upload all generated files
          const allFilesToUpload = [...downloadedFiles, ...metadataPaths];
          const uploadOptions = {};
          if (options.project && options.category) {
            uploadOptions.project = options.project;
            uploadOptions.category = options.category;
          }
          const uploadResult = await uploader.uploadFiles(allFilesToUpload, uploadOptions);

          if (uploadResult.success) {
            console.log(chalk.green.bold('All files uploaded successfully!'));
            // Display share URL if configured, otherwise use local URL
            const dirUrl = uploader.getShareDirUrl();
            console.log(chalk.gray(`Directory: ${dirUrl}`));
            // Display each file's share URL
            console.log(chalk.gray('Files:'));
            uploadResult.results.forEach(r => {
              if (r.success) {
                let shareUrl;
                if (options.project && options.category) {
                  shareUrl = uploader.getProjectShareUrl(path.basename(r.local), options.project, options.category);
                } else {
                  shareUrl = uploader.getShareUrl(path.basename(r.local));
                }
                console.log(chalk.cyan(`  - ${shareUrl}`));
              }
            });
          } else {
            console.log(chalk.yellow('Some files failed to upload:'));
            uploadResult.results.forEach(r => {
              if (!r.success) {
                console.log(chalk.red(`  - ${r.local}: ${r.error}`));
              }
            });
          }
          console.log();
        } else {
          console.log(chalk.yellow('Upload skipped: server not configured in server_config.json'));
          console.log();
        }
      }
    } else {
      console.log(chalk.yellow('Workflow completed but no images were generated'));
      console.log();
    }

    // Disconnect
    await comfyHelper.disconnect();

    if (options._batchMode) {
      return { success: true, files: downloadedFiles, metadata: metadataPaths };
    }
    process.exit(0);

  } catch (error) {
    console.log();
    console.log(chalk.red.bold('Workflow execution failed!'));
    console.log(chalk.red(`Error: ${error.message}`));

    // Disconnect
    try {
      await comfyHelper.disconnect();
    } catch (e) {
      // Ignore disconnect errors
    }

    if (options._batchMode) {
      throw error;
    }
    process.exit(1);
  }
}

export default txt2imgCommand;
