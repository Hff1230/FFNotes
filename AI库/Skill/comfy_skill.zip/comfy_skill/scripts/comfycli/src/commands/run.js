import ConfigManager from '../utils/config.js';
import Logger from '../utils/logger.js';
import chalk from 'chalk';
import path from 'path';
import { fileURLToPath } from 'url';
import ComfyHelper from '../core/helper.js';

// Get the directory name of the current module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Default parameter values for workflow execution
 */
const DEFAULT_PARAMS = {
  width: 1024,
  height: 1024,
  steps: 20,
  cfg: 7.0,
  seed: -1,
  batch_size: 1
};

/**
 * Run command implementation
 * @param {string} workflowName - Name of the workflow to run
 * @param {object} options - Command options
 * @param {string} options.prompt - Positive prompt text
 * @param {string} options.negative - Negative prompt text
 * @param {string} options.output - Output directory path
 * @param {string} options.config - Path to configuration file
 * @param {string} options.image - Input image path (for img2img)
 * @param {boolean} options.watch - Watch execution progress
 * @param {boolean} options.upload - Upload generated files to dufs server
 */
export async function runCommand(workflowName, options = {}) {
  const configPath = options.config || path.join(__dirname, '../config/comfy_config.json');
  const configManager = new ConfigManager(configPath);

  console.log(chalk.bold.blue(`\nRunning workflow: ${workflowName}\n`));

  // Load configuration
  if (!configManager.load()) {
    Logger.error('Failed to load configuration file');
    process.exit(1);
  }

  // Get workflow configuration
  const workflowConfig = configManager.getWorkflow(workflowName);

  if (!workflowConfig) {
    Logger.error(`Workflow not found: ${workflowName}`);
    console.log(chalk.gray('\nAvailable workflows:'));
    const workflows = configManager.listWorkflows();
    workflows.forEach(w => {
      console.log(chalk.gray(`  - ${w.name}: ${w.description}`));
    });
    console.log();
    process.exit(1);
  }

  console.log(chalk.gray(`Description: ${workflowConfig.description || 'N/A'}`));
  console.log(chalk.gray(`Type: ${workflowConfig.type || 'unknown'}`));

  // Load API file
  const apiPath = workflowConfig.api;
  if (!apiPath) {
    Logger.error('Workflow configuration missing "api" field');
    process.exit(1);
  }

  const apiData = configManager.loadApiFile(apiPath);
  if (!apiData) {
    Logger.error(`Failed to load API file: ${apiPath}`);
    process.exit(1);
  }

  // Get default parameters from config or use built-in defaults
  const configDefaults = configManager.getDefaults() || {};
  const params = {
    width: options.width || configDefaults.width || DEFAULT_PARAMS.width,
    height: options.height || configDefaults.height || DEFAULT_PARAMS.height,
    steps: options.steps || configDefaults.steps || DEFAULT_PARAMS.steps,
    cfg: options.cfg || configDefaults.cfg || DEFAULT_PARAMS.cfg,
    seed: options.seed || configDefaults.seed || DEFAULT_PARAMS.seed,
    batch_size: options.batchSize || configDefaults.batchSize || DEFAULT_PARAMS.batch_size
  };

  // Prepare prompt variables with default parameters
  const promptVars = {
    active_prompt: options.prompt || '',
    negative_prompt: options.negative || '',
    sample_image: options.image || '',
    width: params.width,
    height: params.height,
    steps: params.steps,
    cfg: params.cfg,
    seed: params.seed,
    batch_size: params.batch_size
  };

  console.log(chalk.gray(`Prompt: ${promptVars.active_prompt}`));
  if (promptVars.negative_prompt) {
    console.log(chalk.gray(`Negative: ${promptVars.negative_prompt}`));
  }
  if (promptVars.sample_image) {
    console.log(chalk.gray(`Image: ${promptVars.sample_image}`));
  }
  console.log();

  // Prepare upload files
  const uploadFiles = {};
  if (workflowConfig.type === 'img2img' && options.image) {
    uploadFiles['sample_image'] = options.image;
  }

  // Prepare output directory
  const outputDir = options.output;

  // Apply data configuration to workflow
  const workflow = _applyDataConfig(apiData, workflowConfig.data || [], promptVars);

  // Get server configuration
  const serverConfig = configManager.getServerConfig();

  // Create ComfyHelper instance
  const comfyHelper = new ComfyHelper(
    serverConfig.host,
    serverConfig.port,
    serverConfig.apiKey
  );

  try {
    // Connect to ComfyUI server
    console.log(chalk.blue('Connecting to ComfyUI server...'));
    await comfyHelper.connect();

    // Setup progress callback if watch is enabled
    let progressFunc = null;
    if (options.watch) {
      progressFunc = (data) => {
        if (data.type === 'progress_state') {
          const progress = Math.round(data.overall_progress * 100);
          const finished = data.finished ? ' (completed)' : '';
          console.log(chalk.gray(`\rProgress: ${progress}%${finished}`));
        }
      };
    }

    // Execute workflow
    console.log(chalk.blue('Executing workflow...'));
    const success = await comfyHelper.exec(
      workflow,
      promptVars,
      uploadFiles,
      outputDir,
      progressFunc
    );

    if (success) {
      console.log();
      console.log(chalk.green.bold('✓ Workflow completed successfully!'));
      console.log(chalk.gray(`Output directory: ${path.resolve(outputDir)}`));
      console.log();

      // Disconnect
      await comfyHelper.disconnect();
      process.exit(0);
    } else {
      console.log();
      console.log(chalk.red.bold('✗ Workflow execution failed!'));
      console.log();

      // Disconnect
      await comfyHelper.disconnect();
      process.exit(1);
    }
  } catch (error) {
    console.log();
    Logger.error(`Workflow execution error: ${error.message}`);
    console.log(chalk.red(error.stack));
    console.log();

    // Disconnect
    try {
      await comfyHelper.disconnect();
    } catch (e) {
      // Ignore disconnect errors
    }
    process.exit(1);
  }
}

/**
 * Apply data configuration to workflow
 * @param {object} workflow - Base workflow from API file
 * @param {Array} dataConfig - Data configuration array
 * @param {object} promptVars - Prompt variables
 * @returns {object} Modified workflow
 * @private
 */
function _applyDataConfig(workflow, dataConfig, promptVars) {
  // Create a deep copy of the workflow
  const modifiedWorkflow = JSON.parse(JSON.stringify(workflow));

  // Apply each data configuration entry
  for (const entry of dataConfig) {
    for (const [key, valueTemplate] of Object.entries(entry)) {
      // Parse the key format: type##nodeId##inputs##field
      const parts = key.split('##');
      if (parts.length >= 4) {
        const nodeType = parts[0];
        const nodeId = parts[1];
        const fieldType = parts[2];
        const fieldName = parts[3];

        // Check if node exists
        if (modifiedWorkflow[nodeId] && modifiedWorkflow[nodeId][fieldType]) {
          // Replace variables in the value template
          let finalValue = valueTemplate;
          for (const [varName, varValue] of Object.entries(promptVars)) {
            const placeholder = `##${varName}##`;
            if (finalValue.includes(placeholder)) {
              finalValue = finalValue.replace(new RegExp(placeholder, 'g'), String(varValue || ''));
            }
          }

          // Set the value
          modifiedWorkflow[nodeId][fieldType][fieldName] = finalValue;
        }
      }
    }
  }

  return modifiedWorkflow;
}

export default runCommand;
