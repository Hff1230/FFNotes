import ConfigManager from '../utils/config.js';
import Logger from '../utils/logger.js';
import ComfyHelper from '../core/helper.js';
import ProgressMonitor from '../core/progress.js';
import {
  replaceVariables,
  validateWorkflow,
  mergeWorkflowParams,
  findImg2ImgWorkflows,
  findImg2ImgWorkflowByImageCount,
  getRequiredImageCount,
  generateOutputFilename,
  isImg2ImgFamily
} from '../core/workflow.js';
import { extractMetadata, saveMetadata } from '../utils/metadata.js';
import DufsUploader from '../utils/uploader.js';
import { resolveInputResources, isUrl } from '../utils/resource_downloader.js';
import chalk from 'chalk';
import path from 'path';
import fs from 'fs';
import { randomInt } from 'crypto';
import ora from 'ora';

// Supported image formats
const SUPPORTED_FORMATS = ['.png', '.jpg', '.jpeg', '.webp'];

// Default workflow mapping based on image count
const DEFAULT_WORKFLOW_MAP = {
  1: 'qwen2511i2i',
  2: 'qwen2511i2i2',
  3: 'qwen2511i2i3',
  4: 'qwen2511i2i4'
};

// Maximum supported images
const MAX_IMAGES = 4;

/**
 * Parse input images from various formats
 * @param {string} input - Input string (comma-separated paths)
 * @param {string[]} additionalImages - Additional images from --images option
 * @returns {string[]} Array of image paths
 */
function parseInputImages(input, additionalImages = []) {
  const images = [];

  // Parse comma-separated paths from input
  if (input && input.trim().length > 0) {
    const parsedPaths = input.split(',')
      .map(p => p.trim())
      .filter(p => p.length > 0);
    images.push(...parsedPaths);
  }

  // Add additional images from --images option
  if (additionalImages && Array.isArray(additionalImages)) {
    images.push(...additionalImages);
  }

  return images;
}

/**
 * Validate image files
 * @param {string[]} imagePaths - Array of image paths to validate
 * @returns {Promise<{valid: boolean, errors: string[], validPaths: string[]}>}
 */
async function validateImages(imagePaths) {
  const errors = [];
  const validPaths = [];
  const missingFiles = [];
  const unsupportedFormats = [];

  // First, resolve any URL inputs by downloading them
  const resolvedInputs = await resolveInputResources(imagePaths);

  for (let i = 0; i < imagePaths.length; i++) {
    const imageInput = imagePaths[i];
    const localPath = resolvedInputs.localPaths[i];
    const resolvedPath = path.resolve(localPath);

    // Check file exists
    if (!fs.existsSync(resolvedPath)) {
      missingFiles.push(imageInput);
      continue;
    }

    // Check format
    const ext = path.extname(resolvedPath).toLowerCase();
    if (!SUPPORTED_FORMATS.includes(ext)) {
      unsupportedFormats.push({ path: imageInput, format: ext });
      continue;
    }

    validPaths.push(resolvedPath);
  }

  // Build error messages
  if (missingFiles.length > 0) {
    errors.push(`Image files not found:\n  ${missingFiles.map(p => `- ${p}`).join('\n  ')}`);
  }

  if (unsupportedFormats.length > 0) {
    errors.push(`Unsupported image formats:\n  ${unsupportedFormats.map(f => `- ${f.path} (${f.format})`).join('\n  ')}\n  Supported formats: ${SUPPORTED_FORMATS.join(', ')}`);
  }

  return {
    valid: errors.length === 0,
    errors,
    validPaths
  };
}

/**
 * Get recommended workflow name based on image count
 * @param {number} imageCount - Number of images
 * @returns {string|null} Workflow name or null if not supported
 */
function getRecommendedWorkflow(imageCount) {
  return DEFAULT_WORKFLOW_MAP[imageCount] || null;
}

/**
 * Image to Image command implementation
 * @param {string} input - Input image path(s) - single path or comma-separated
 * @param {string} prompt - Positive prompt text
 * @param {object} options - Command options
 * @param {string} options.negative - Negative prompt text
 * @param {string} options.output - Output directory path
 * @param {string} options.config - Path to configuration file
 * @param {string} options.workflow - Workflow name (optional, auto-selected based on image count)
 * @param {number} options.strength - Denoise strength (0-1, default: 0.75)
 * @param {number} options.steps - Sampling steps
 * @param {number} options.cfg - CFG scale
 * @param {number} options.seed - Random seed (default: random)
 * @param {number} options.width - Output width
 * @param {number} options.height - Output height
 * @param {string[]} options.allImages - All image paths (from CLI parsing)
 */
export async function img2imgCommand(input, prompt, options = {}) {
  // Parse input images - use allImages if already parsed by CLI, otherwise parse input
  const imagePaths = options.allImages && options.allImages.length > 0
    ? options.allImages
    : parseInputImages(input, []);

  // Validate at least one image provided
  if (imagePaths.length === 0) {
    if (options._batchMode) {
      throw new Error('At least one input image path is required');
    }
    console.log(chalk.red.bold('Error: At least one input image path is required'));
    console.log(chalk.gray('Usage: npx comfycli img2img <input> "<prompt>"'));
    console.log(chalk.gray('  Single image: npx comfycli img2img photo.jpg "enhance this image"'));
    console.log(chalk.gray('  Multiple images: npx comfycli img2img "photo1.jpg,photo2.jpg" "combine these"'));
    console.log(chalk.gray('  Or use --images: npx comfycli img2img photo1.jpg "prompt" --images photo2.jpg --images photo3.jpg'));
    process.exit(1);
  }

  // Validate image count is within supported range
  if (imagePaths.length > MAX_IMAGES) {
    if (options._batchMode) {
      throw new Error('Too many images provided');
    }
    console.log(chalk.red.bold(`Error: Too many images provided (${imagePaths.length})`));
    console.log(chalk.yellow(`Maximum supported: ${MAX_IMAGES} images`));
    console.log(chalk.gray('Please provide 1-4 images for image-to-image workflows.'));
    process.exit(1);
  }

  // Validate prompt
  if (!prompt || prompt.trim().length === 0) {
    if (options._batchMode) {
      throw new Error('Prompt is required');
    }
    console.log(chalk.red.bold('Error: Prompt is required'));
    console.log(chalk.gray('Usage: npx comfycli img2img <input> "<prompt>"'));
    process.exit(1);
  }

  // Validate all image files
  const imageValidation = await validateImages(imagePaths);
  if (!imageValidation.valid) {
    if (options._batchMode) {
      throw new Error('Image validation failed');
    }
    console.log(chalk.red.bold('Error: Image validation failed'));
    imageValidation.errors.forEach(error => {
      console.log(chalk.red(error));
    });
    process.exit(1);
  }

  // Get validated image paths
  const validImagePaths = imageValidation.validPaths;
  const imageCount = validImagePaths.length;

  // Set default options
  const configPath = options.config || './config/comfy_config.json';
  const outputDir = options.output;
  const negative = options.negative || '';
  const strength = options.strength !== undefined ? parseFloat(options.strength) : 0.75;

  // Validate strength
  if (isNaN(strength) || strength < 0 || strength > 1) {
    if (options._batchMode) {
      throw new Error('Strength must be a number between 0 and 1');
    }
    console.log(chalk.red.bold('Error: Strength must be a number between 0 and 1'));
    console.log(chalk.gray(`Provided: ${options.strength}`));
    process.exit(1);
  }

  // Determine workflow - auto-select based on image count if not specified
  let workflowName = options.workflow;
  let autoSelected = false;

  if (!workflowName) {
    workflowName = getRecommendedWorkflow(imageCount);
    autoSelected = true;

    if (!workflowName) {
      if (options._batchMode) {
        throw new Error('No default workflow available');
      }
      console.log(chalk.red.bold(`Error: No default workflow available for ${imageCount} images`));
      console.log(chalk.yellow(`Supported image counts: 1-4`));
      console.log(chalk.gray('Please specify a workflow with --workflow option.'));
      process.exit(1);
    }
  }

  // Display command info
  console.log(chalk.bold.blue('\nImage to Image Generation'));
  console.log(chalk.gray('─'.repeat(50)));

  // Show URL download hint if any URL inputs
  const urlInputs = imagePaths.filter(p => isUrl(p));
  if (urlInputs.length > 0) {
    console.log(chalk.gray(`  Downloading ${urlInputs.length} URL resource(s) to ./tmp...`));
  }

  console.log(chalk.gray(`Input images (${imageCount}):`));
  validImagePaths.forEach((p, i) => {
    console.log(chalk.gray(`  ${i + 1}. ${p}`));
  });
  console.log(chalk.gray(`Prompt: ${prompt}`));
  if (negative) {
    console.log(chalk.gray(`Negative: ${negative}`));
  }
  console.log(chalk.gray(`Workflow: ${workflowName}${autoSelected ? ' (auto-selected)' : ''}`));
  console.log(chalk.gray(`Strength: ${strength}`));
  console.log(chalk.gray(`Output: ${outputDir}`));
  console.log();

  // Initialize configuration manager
  const configManager = new ConfigManager(configPath);

  // Load configuration
  if (!configManager.load()) {
    if (options._batchMode) {
      throw new Error('Failed to load configuration file');
    }
    console.log(chalk.red.bold('Error: Failed to load configuration file'));
    console.log(chalk.gray(`Path: ${configPath}`));
    process.exit(1);
  }

  // Validate that the workflow exists and is img2img type
  const workflowConfig = configManager.getWorkflow(workflowName);

  if (!workflowConfig) {
    console.log(chalk.red.bold(`Error: Workflow not found: ${workflowName}`));

    // List available img2img workflows grouped by image count
    const allWorkflows = configManager.listWorkflows();
    const img2imgWorkflows = findImg2ImgWorkflows(allWorkflows);

    if (img2imgWorkflows.length > 0) {
      console.log(chalk.yellow('\nAvailable image-to-image workflows:'));

      // Group by required image count
      const workflowsByCount = {};
      for (const w of img2imgWorkflows) {
        const count = getRequiredImageCount(w);
        const key = count || 'unknown';
        if (!workflowsByCount[key]) {
          workflowsByCount[key] = [];
        }
        workflowsByCount[key].push(w);
      }

      // Display workflows organized by image count
      for (const [count, workflows] of Object.entries(workflowsByCount)) {
        const countLabel = count === 'unknown' ? 'Unknown' : `${count} image${count > 1 ? 's' : ''}`;
        console.log(chalk.cyan(`\n  For ${countLabel}:`));
        workflows.forEach(w => {
          console.log(chalk.gray(`    - ${w.name}: ${w.description}`));
        });
      }
      console.log();

      // Suggest matching workflow
      const matchingWorkflows = findImg2ImgWorkflowByImageCount(allWorkflows, imageCount);
      if (matchingWorkflows.length > 0) {
        console.log(chalk.green(`Suggested workflow for ${imageCount} image${imageCount > 1 ? 's' : ''}:`));
        matchingWorkflows.forEach(w => {
          console.log(chalk.green(`  - ${w.name}`));
        });
      }
    }

    if (options._batchMode) {
      throw new Error('Workflow not found');
    }
    process.exit(1);
  }

  if (!isImg2ImgFamily(workflowConfig.type)) {
    if (options._batchMode) {
      throw new Error('Workflow is not an image-to-image workflow');
    }
    console.log(chalk.red.bold(`Error: Workflow "${workflowName}" is not an image-to-image workflow`));
    console.log(chalk.gray(`Type: ${workflowConfig.type}`));
    console.log(chalk.gray('Supported types: img2img, 2img2img, 3img2img, 4img2img'));
    process.exit(1);
  }

  console.log(chalk.gray(`Description: ${workflowConfig.description}`));

  // Validate image count matches workflow requirements
  const requiredImageCount = getRequiredImageCount(workflowConfig);
  if (requiredImageCount > 0 && requiredImageCount !== imageCount) {
    console.log(chalk.red.bold(`Error: Image count mismatch`));
    console.log(chalk.yellow(`Workflow "${workflowName}" requires ${requiredImageCount} image${requiredImageCount > 1 ? 's' : ''}`));
    console.log(chalk.yellow(`You provided ${imageCount} image${imageCount > 1 ? 's' : ''}`));

    // Suggest matching workflow
    const recommendedWorkflow = getRecommendedWorkflow(imageCount);
    if (recommendedWorkflow) {
      console.log(chalk.green(`\nSuggested workflow: ${recommendedWorkflow}`));
      console.log(chalk.gray(`Use: npx comfycli img2img "${validImagePaths.join(',')}" "${prompt}" -w ${recommendedWorkflow}`));
    } else {
      const matchingWorkflows = findImg2ImgWorkflowByImageCount(configManager.listWorkflows(), imageCount);
      if (matchingWorkflows.length > 0) {
        console.log(chalk.green('\nMatching workflows:'));
        matchingWorkflows.forEach(w => {
          console.log(chalk.green(`  - ${w.name}`));
        });
      }
    }

    if (options._batchMode) {
      throw new Error('Image count mismatch');
    }
    process.exit(1);
  }

  // Load API file
  const apiPath = workflowConfig.api;
  if (!apiPath) {
    if (options._batchMode) {
      throw new Error('Workflow configuration missing api field');
    }
    console.log(chalk.red.bold('Error: Workflow configuration missing "api" field'));
    process.exit(1);
  }

  const apiData = configManager.loadApiFile(apiPath);
  if (!apiData) {
    if (options._batchMode) {
      throw new Error('Failed to load API file');
    }
    console.log(chalk.red.bold(`Error: Failed to load API file: ${apiPath}`));
    process.exit(1);
  }

  // Validate workflow
  const validation = validateWorkflow(apiData);
  if (!validation.valid) {
    if (options._batchMode) {
      throw new Error('Invalid workflow format');
    }
    console.log(chalk.red.bold('Error: Invalid workflow format'));
    validation.errors.forEach((error, index) => {
      console.log(chalk.red(`  ${index + 1}. ${error}`));
    });
    process.exit(1);
  }

  // Get server configuration
  const serverConfig = configManager.getServerConfig();

  // Create ComfyHelper instance
  const comfyHelper = new ComfyHelper(
    serverConfig.host,
    serverConfig.port,
    serverConfig.apiKey
  );

  try {
    // Connect to ComfyUI server
    await comfyHelper.connect();

    // Upload spinner for multiple images
    const uploadSpinner = ora(`Uploading ${imageCount} image${imageCount > 1 ? 's' : ''}...`).start();

    // Batch upload all images
    const uploadedFilenames = [];
    const uploadErrors = [];

    for (let i = 0; i < validImagePaths.length; i++) {
      const imagePath = validImagePaths[i];
      try {
        const uploadResult = await comfyHelper.uploadImage(imagePath);
        if (uploadResult && uploadResult.name) {
          uploadedFilenames.push(uploadResult.name);
        } else {
          uploadErrors.push({ path: imagePath, error: 'Upload returned no filename' });
        }
      } catch (uploadError) {
        uploadErrors.push({ path: imagePath, error: uploadError.message });
      }
    }

    // Check for upload errors
    if (uploadErrors.length > 0) {
      uploadSpinner.fail(`Failed to upload ${uploadErrors.length} image${uploadErrors.length > 1 ? 's' : ''}`);
      uploadErrors.forEach(({ path, error }) => {
        console.log(chalk.red(`  - ${path}: ${error}`));
      });
      await comfyHelper.disconnect();
      if (options._batchMode) {
        throw new Error('Failed to upload images');
      }
      process.exit(1);
    }

    uploadSpinner.succeed(`Uploaded ${imageCount} image${imageCount > 1 ? 's' : ''} successfully`);

    // Display uploaded files
    uploadedFilenames.forEach((filename, i) => {
      console.log(chalk.gray(`  ${i + 1}. ${filename}`));
    });

    // Connect message
    console.log(chalk.green(`Connected to ${serverConfig.host}:${serverConfig.port}`));

    // Prepare workflow parameters
    const workflowParams = {
      denoise: strength
    };

    if (options.steps !== undefined) workflowParams.steps = options.steps;
    if (options.cfg !== undefined) workflowParams.cfg = options.cfg;
    if (options.seed !== undefined) {
      workflowParams.seed = options.seed;
    } else {
      // Generate random seed if not provided
      workflowParams.seed = randomInt(1, 2147483647);
      console.log(chalk.gray(`Generated seed: ${workflowParams.seed}`));
    }
    if (options.width !== undefined) workflowParams.width = options.width;
    if (options.height !== undefined) workflowParams.height = options.height;

    // Resolve size alias if provided
    if (options.size) {
      const resolutionType = 'pic_gen';
      const orientation = options.orientation || '0';
      const resolved = configManager.resolveResolution(options.size, orientation, resolutionType);
      if (resolved) {
        if (options.width === undefined) workflowParams.width = resolved.width;
        if (options.height === undefined) workflowParams.height = resolved.height;
      } else {
        console.log(chalk.yellow(`Warning: Unknown size alias "${options.size}" for orientation "${orientation}"`));
      }
    }

    // Build prompt variables with sample_image, sample_image2, sample_image3, sample_image4
    // Also includes width/height for variable replacement
    const promptVars = {
      active_prompt: prompt,
      negative_prompt: negative,
      width: workflowParams.width,
      height: workflowParams.height
    };

    // Map uploaded files to sample_image variables
    // sample_image -> first image, sample_image2 -> second image, etc.
    for (let i = 0; i < uploadedFilenames.length; i++) {
      const varName = i === 0 ? 'sample_image' : `sample_image${i + 1}`;
      promptVars[varName] = uploadedFilenames[i];
    }

    // Apply variable replacement and parameter merging
    let workflow = replaceVariables(apiData, workflowConfig.data || [], promptVars);
    workflow = mergeWorkflowParams(workflow, workflowParams);

    // Create progress monitor
    const progressMonitor = new ProgressMonitor(comfyHelper);

    // Queue the workflow
    console.log(chalk.blue('Submitting workflow...'));
    const queueResult = await comfyHelper.queuePrompt(workflow);

    if (!queueResult || !queueResult.prompt_id) {
      throw new Error('Failed to queue workflow');
    }

    const promptId = queueResult.prompt_id;
    console.log(chalk.gray(`Prompt ID: ${promptId}`));

    // Wait for completion with progress monitoring
    console.log(chalk.blue(`Running workflow (${workflowName})...`));
    await progressMonitor.waitForCompletion(promptId, {
      timeout: 300000, // 5 minutes
      workflowName
    });

    // Get history to find output files
    console.log(chalk.blue('Retrieving output...'));
    const history = await comfyHelper.getHistory(promptId);

    if (!history || !history[promptId]) {
      throw new Error('No history found for completed workflow');
    }

    const promptData = history[promptId];
    const outputs = promptData.outputs || {};

    // Create output directory
    await fs.promises.mkdir(outputDir, { recursive: true });

    // Download output images
    let downloadedCount = 0;
    const downloadedFiles = [];

    for (const [nodeId, nodeOutput] of Object.entries(outputs)) {
      if (nodeOutput.images && nodeOutput.images.length > 0) {
        for (const image of nodeOutput.images) {
          const filename = image.filename;
          const subfolder = image.subfolder || '';
          const imageType = image.type || 'output';

          // Generate output filename
          const outputFilename = generateOutputFilename(workflowName, path.extname(filename) || '.png');
          const outputPath = path.join(outputDir, outputFilename);

          // Download image
          const success = await comfyHelper.downloadOutput(
            filename,
            outputPath,
            subfolder,
            imageType
          );

          if (success) {
            downloadedCount++;
            downloadedFiles.push(outputPath);
          }
        }
      }
    }

    // Extract and save metadata
    const metadata = extractMetadata(workflow, promptData.prompt || workflow);
    // Add input_images to metadata
    metadata.input_images = validImagePaths;
    metadata.workflow_name = workflowName;
    metadata.prompt_text = prompt;
    metadata.negative_prompt = negative;
    metadata.strength = strength;
    metadata.options = {
      steps: workflowParams.steps,
      cfg: workflowParams.cfg,
      seed: workflowParams.seed,
      width: workflowParams.width,
      height: workflowParams.height
    };

    // Save metadata for each downloaded image (use actual saved filename)
    const savedMetadataPaths = [];
    for (const downloadedFile of downloadedFiles) {
      const filename = path.basename(downloadedFile);
      const savedPath = await saveMetadata(filename, metadata, outputDir);
      savedMetadataPaths.push(savedPath);
    }

    // Display results
    console.log();
    if (downloadedCount > 0) {
      console.log(chalk.green.bold('Workflow completed successfully!'));
      console.log(chalk.gray(`Generated ${downloadedCount} image${downloadedCount > 1 ? 's' : ''}:`));
      downloadedFiles.forEach(file => {
        console.log(chalk.green(`  Image saved to: ${file}`));
      });
      // Display metadata save paths
      if (savedMetadataPaths.length > 0) {
        console.log(chalk.gray(`Metadata saved:`));
        savedMetadataPaths.forEach(metaPath => {
          console.log(chalk.cyan(`  ${metaPath}`));
        });
      }
      console.log();

      // Upload to dufs server if enabled (default: true)
      const shouldUpload = options.upload !== false;
      if (shouldUpload) {
        const uploadConfig = configManager.getUploadConfig();
        if (uploadConfig && uploadConfig.server) {
          console.log(chalk.blue('Uploading to server...'));
          const uploader = new DufsUploader(uploadConfig);

          // Upload all generated files
          const allFilesToUpload = [...downloadedFiles, ...savedMetadataPaths];
          const uploadResult = await uploader.uploadFiles(allFilesToUpload);

          if (uploadResult.success) {
            console.log(chalk.green.bold('All files uploaded successfully!'));
            // Display share URL if configured, otherwise use local URL
            const dirUrl = uploader.getShareDirUrl();
            console.log(chalk.gray(`Directory: ${dirUrl}`));
            // Display each file's share URL
            console.log(chalk.gray('Files:'));
            uploadResult.results.forEach(r => {
              if (r.success) {
                const shareUrl = uploader.getShareUrl(path.basename(r.local));
                console.log(chalk.cyan(`  - ${shareUrl}`));
              }
            });
          } else {
            console.log(chalk.yellow('Some files failed to upload:'));
            uploadResult.results.forEach(r => {
              if (!r.success) {
                console.log(chalk.red(`  - ${r.local}: ${r.error}`));
              }
            });
          }
          console.log();
        } else {
          console.log(chalk.yellow('Upload skipped: server not configured in server_config.json'));
          console.log();
        }
      }
    } else {
      console.log(chalk.yellow('Workflow completed but no images were generated'));
      console.log();
    }

    // Disconnect
    await comfyHelper.disconnect();
    if (options._batchMode) {
      return { success: true, files: downloadedFiles, metadata: savedMetadataPaths };
    }
    process.exit(0);

  } catch (error) {
    console.log();
    console.log(chalk.red.bold('Workflow execution failed!'));
    console.log(chalk.red(`Error: ${error.message}`));

    // Disconnect
    try {
      await comfyHelper.disconnect();
    } catch (e) {
      // Ignore disconnect errors
    }
    if (options._batchMode) {
      throw error;
    }
    process.exit(1);
  }
}

export default img2imgCommand;
