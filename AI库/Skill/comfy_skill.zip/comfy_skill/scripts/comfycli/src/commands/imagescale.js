import ConfigManager from '../utils/config.js';
import Logger from '../utils/logger.js';
import ComfyHelper from '../core/helper.js';
import ProgressMonitor from '../core/progress.js';
import {
  replaceVariables,
  validateWorkflow,
  mergeWorkflowParams,
  findImageScaleWorkflows,
  generateOutputFilename
} from '../core/workflow.js';
import { extractMetadata, saveMetadata } from '../utils/metadata.js';
import DufsUploader from '../utils/uploader.js';
import ResourceDownloader from '../utils/resource_downloader.js';
import chalk from 'chalk';
import path from 'path';
import fs from 'fs';
import { randomInt } from 'crypto';
import ora from 'ora';

// Supported image formats
const SUPPORTED_FORMATS = ['.png', '.jpg', '.jpeg', '.webp'];

// Default workflow name
const DEFAULT_WORKFLOW_NAME = 'zimageupscale';

/**
 * Image Scale command implementation - Super-resolution upscaling
 * @param {string} imagePath - Input image path (required)
 * @param {object} options - Command options
 * @param {string} options.size - Resolution preset alias (e.g., '2k', '4k', '8k')
 * @param {string} options.orientation - Orientation: '0' for landscape (default), '1' for portrait
 * @param {number} options.width - Custom output width (overrides preset)
 * @param {number} options.height - Custom output height (overrides preset)
 * @param {string} options.output - Output directory path
 * @param {string} options.config - Path to configuration file
 * @param {string} options.workflow - Workflow name (default: zimageupscale)
 * @param {number} options.seed - Random seed (default: random)
 */
export async function imagescaleCommand(imagePath, options = {}) {
  // Validate input image path
  if (!imagePath || imagePath.trim().length === 0) {
    console.log(chalk.red.bold('Error: Input image path is required'));
    console.log(chalk.gray('Usage: npx comfycli imagescale <image_path> [options]'));
    console.log(chalk.gray('  npx comfycli imagescale photo.jpg --size 4k'));
    console.log(chalk.gray('  npx comfycli imagescale photo.jpg --width 3840 --height 2160'));
    if (options._batchMode) {
      throw new Error('Input image path is required');
    }
    process.exit(1);
  }

  // Handle URL input
  let localImagePath = imagePath;
  if (ResourceDownloader.isUrl(imagePath)) {
    console.log(chalk.blue('Downloading input image from URL...'));
    try {
      const result = await ResourceDownloader.resolveInputResource(imagePath);
      localImagePath = result.localPath;
      console.log(chalk.green(`Downloaded to: ${localImagePath}`));
    } catch (downloadError) {
      console.log(chalk.red.bold(`Error: Failed to download image: ${downloadError.message}`));
      if (options._batchMode) {
        throw new Error(`Failed to download image: ${downloadError.message}`);
      }
      process.exit(1);
    }
  }

  // Resolve and validate image file
  const resolvedImagePath = path.resolve(localImagePath.trim());

  if (!fs.existsSync(resolvedImagePath)) {
    console.log(chalk.red.bold(`Error: Image file not found: ${resolvedImagePath}`));
    console.log(chalk.gray('Please provide a valid image file path.'));
    if (options._batchMode) {
      throw new Error(`Image file not found: ${resolvedImagePath}`);
    }
    process.exit(1);
  }

  const ext = path.extname(resolvedImagePath).toLowerCase();
  if (!SUPPORTED_FORMATS.includes(ext)) {
    console.log(chalk.red.bold(`Error: Unsupported image format: ${ext}`));
    console.log(chalk.gray(`Supported formats: ${SUPPORTED_FORMATS.join(', ')}`));
    if (options._batchMode) {
      throw new Error(`Unsupported image format: ${ext}`);
    }
    process.exit(1);
  }

  // Set default options
  const configPath = options.config || './config/comfy_config.json';
  const outputDir = options.output;

  // Initialize configuration manager
  const configManager = new ConfigManager(configPath);

  // Load configuration
  if (!configManager.load()) {
    console.log(chalk.red.bold('Error: Failed to load configuration file'));
    console.log(chalk.gray(`Path: ${configPath}`));
    if (options._batchMode) {
      throw new Error('Failed to load configuration file');
    }
    process.exit(1);
  }

  // Determine workflow name
  const workflowName = options.workflow || configManager.getDefaultWorkflowName('imagescale') || DEFAULT_WORKFLOW_NAME;

  // Resolve target resolution
  let targetWidth, targetHeight;

  if (options.size) {
    const resolved = configManager.resolveResolution(options.size, options.orientation || '0', 'pic_upscale');
    if (!resolved) {
      console.log(chalk.red.bold(`Error: Unknown resolution preset "${options.size}"`));
      if (options._batchMode) {
        throw new Error(`Unknown resolution preset "${options.size}"`);
      }
      console.log(chalk.gray('Available presets for pic_upscale:'));

      const resolutionPresets = configManager.listResolutions('pic_upscale');
      if (resolutionPresets) {
        const orientationKey = options.orientation || '0';
        const presetList = resolutionPresets[orientationKey];
        if (presetList && Array.isArray(presetList)) {
          presetList.forEach(preset => {
            console.log(chalk.gray(`  - ${preset.name}: ${preset.width}x${preset.height}`));
          });
        }
      }

      process.exit(1);
    }

    targetWidth = options.width !== undefined ? parseInt(options.width) : resolved.width;
    targetHeight = options.height !== undefined ? parseInt(options.height) : resolved.height;
  } else if (options.width && options.height) {
    targetWidth = parseInt(options.width);
    targetHeight = parseInt(options.height);
  } else {
    // Default: 2k landscape
    const resolved = configManager.resolveResolution('2k', '0', 'pic_upscale');
    if (!resolved) {
      console.log(chalk.red.bold('Error: Default resolution preset "2k" not found in configuration'));
      if (options._batchMode) {
        throw new Error('Default resolution preset "2k" not found in configuration');
      }
      process.exit(1);
    }
    targetWidth = resolved.width;
    targetHeight = resolved.height;
  }

  // Validate parsed dimensions
  if (isNaN(targetWidth) || targetWidth <= 0) {
    console.log(chalk.red.bold('Error: Invalid width value'));
    if (options._batchMode) {
      throw new Error('Invalid width value');
    }
    console.log(chalk.gray(`Provided width: ${options.width}`));
    process.exit(1);
  }

  if (isNaN(targetHeight) || targetHeight <= 0) {
    console.log(chalk.red.bold('Error: Invalid height value'));
    if (options._batchMode) {
      throw new Error('Invalid height value');
    }
    console.log(chalk.gray(`Provided height: ${options.height}`));
    process.exit(1);
  }

  // Display command info
  console.log(chalk.bold.blue('\nImage Super-Resolution Upscale'));
  console.log(chalk.gray('─'.repeat(50)));
  console.log(chalk.gray(`Input image: ${resolvedImagePath}`));
  console.log(chalk.gray(`Target resolution: ${targetWidth}x${targetHeight}`));
  console.log(chalk.gray(`Workflow: ${workflowName}`));
  console.log(chalk.gray(`Output: ${outputDir}`));
  console.log();

  // Validate that the workflow exists and is imagescale type
  const workflowConfig = configManager.getWorkflow(workflowName);

  if (!workflowConfig) {
    console.log(chalk.red.bold(`Error: Workflow not found: ${workflowName}`));
    if (options._batchMode) {
      throw new Error('Workflow not found: ' + workflowName);
    }

    // List available imagescale workflows
    const allWorkflows = configManager.listWorkflows();
    const scaleWorkflows = findImageScaleWorkflows(allWorkflows);

    if (scaleWorkflows.length > 0) {
      console.log(chalk.yellow('\nAvailable image scale workflows:'));
      scaleWorkflows.forEach(w => {
        console.log(chalk.gray(`  - ${w.name}: ${w.description}`));
      });
      console.log();
    }

    process.exit(1);
  }

  if (workflowConfig.type !== 'imagescale') {
    console.log(chalk.red.bold(`Error: Workflow "${workflowName}" is not an image scale workflow`));
    console.log(chalk.gray(`Type: ${workflowConfig.type}`));
    if (options._batchMode) {
      throw new Error(`Workflow "${workflowName}" is not an image scale workflow`);
    }
    process.exit(1);
  }

  console.log(chalk.gray(`Description: ${workflowConfig.description}`));

  // Load API file
  const apiPath = workflowConfig.api;
  if (!apiPath) {
    console.log(chalk.red.bold('Error: Workflow configuration missing "api" field'));
    if (options._batchMode) {
      throw new Error('Workflow configuration missing "api" field');
    }
    process.exit(1);
  }

  const apiData = configManager.loadApiFile(apiPath);
  if (!apiData) {
    console.log(chalk.red.bold(`Error: Failed to load API file: ${apiPath}`));
    if (options._batchMode) {
      throw new Error('Failed to load API file: ' + apiPath);
    }
    process.exit(1);
  }

  // Validate workflow
  const validation = validateWorkflow(apiData);
  if (!validation.valid) {
    console.log(chalk.red.bold('Error: Invalid workflow format'));
    validation.errors.forEach((error, index) => {
      console.log(chalk.red(`  ${index + 1}. ${error}`));
    });
    if (options._batchMode) {
      throw new Error('Invalid workflow format: ' + validation.errors.join('; '));
    }
    process.exit(1);
  }

  // Get server configuration
  const serverConfig = configManager.getServerConfig();

  // Create ComfyHelper instance
  const comfyHelper = new ComfyHelper(
    serverConfig.host,
    serverConfig.port,
    serverConfig.apiKey
  );

  try {
    // Connect to ComfyUI server
    await comfyHelper.connect();

    // Upload input image
    const uploadSpinner = ora('Uploading image...').start();

    let uploadedFilename;
    try {
      const uploadResult = await comfyHelper.uploadImage(resolvedImagePath);
      if (uploadResult && uploadResult.name) {
        uploadedFilename = uploadResult.name;
      } else {
        uploadSpinner.fail('Upload returned no filename');
        await comfyHelper.disconnect();
        if (options._batchMode) {
          throw new Error('Upload returned no filename');
        }
        process.exit(1);
      }
    } catch (uploadError) {
      uploadSpinner.fail(`Failed to upload image: ${uploadError.message}`);
      await comfyHelper.disconnect();
      if (options._batchMode) {
        throw new Error(`Failed to upload image: ${uploadError.message}`);
      }
      process.exit(1);
    }

    uploadSpinner.succeed(`Image uploaded: ${uploadedFilename}`);

    // Connect message
    console.log(chalk.green(`Connected to ${serverConfig.host}:${serverConfig.port}`));

    // Prepare workflow parameters
    const workflowParams = {
      width: targetWidth,
      height: targetHeight
    };

    if (options.seed !== undefined) {
      workflowParams.seed = options.seed;
    } else {
      // Generate random seed if not provided
      workflowParams.seed = randomInt(1, 2147483647);
      console.log(chalk.gray(`Generated seed: ${workflowParams.seed}`));
    }

    // Build prompt variables - input image maps to sample_image placeholder
    // Also includes width/height for variable replacement
    const promptVars = {
      sample_image: uploadedFilename,
      width: targetWidth,
      height: targetHeight
    };

    // Apply variable replacement and parameter merging
    let workflow = replaceVariables(apiData, workflowConfig.data || [], promptVars);
    workflow = mergeWorkflowParams(workflow, workflowParams);

    // Create progress monitor
    const progressMonitor = new ProgressMonitor(comfyHelper);

    // Queue the workflow
    console.log(chalk.blue('Submitting workflow...'));
    const queueResult = await comfyHelper.queuePrompt(workflow);

    if (!queueResult || !queueResult.prompt_id) {
      throw new Error('Failed to queue workflow');
    }

    const promptId = queueResult.prompt_id;
    console.log(chalk.gray(`Prompt ID: ${promptId}`));

    // Wait for completion with progress monitoring
    console.log(chalk.blue(`Running workflow (${workflowName})...`));
    await progressMonitor.waitForCompletion(promptId, {
      timeout: 300000, // 5 minutes
      workflowName
    });

    // Get history to find output files
    console.log(chalk.blue('Retrieving output...'));
    const history = await comfyHelper.getHistory(promptId);

    if (!history || !history[promptId]) {
      throw new Error('No history found for completed workflow');
    }

    const promptData = history[promptId];
    const outputs = promptData.outputs || {};

    // Create output directory
    await fs.promises.mkdir(outputDir, { recursive: true });

    // Download output images
    let downloadedCount = 0;
    const downloadedFiles = [];

    for (const [nodeId, nodeOutput] of Object.entries(outputs)) {
      if (nodeOutput.images && nodeOutput.images.length > 0) {
        for (const image of nodeOutput.images) {
          const filename = image.filename;
          const subfolder = image.subfolder || '';
          const imageType = image.type || 'output';

          // Generate output filename
          const outputFilename = generateOutputFilename(workflowName, path.extname(filename) || '.png');
          const outputPath = path.join(outputDir, outputFilename);

          // Download image
          const success = await comfyHelper.downloadOutput(
            filename,
            outputPath,
            subfolder,
            imageType
          );

          if (success) {
            downloadedCount++;
            downloadedFiles.push(outputPath);
          }
        }
      }
    }

    // Extract and save metadata
    const metadata = extractMetadata(workflow, promptData, {
      promptId,
      inputPath: resolvedImagePath
    });
    // Add width and height to metadata
    metadata.width = targetWidth;
    metadata.height = targetHeight;

    // Save metadata for each downloaded image (use actual saved filename)
    const metadataPaths = [];
    for (const downloadedFile of downloadedFiles) {
      const filename = path.basename(downloadedFile);
      const savedPath = await saveMetadata(filename, metadata, outputDir);
      metadataPaths.push(savedPath);
    }

    // Display results
    console.log();
    if (downloadedCount > 0) {
      console.log(chalk.green.bold('Workflow completed successfully!'));
      console.log(chalk.gray(`Generated ${downloadedCount} image${downloadedCount > 1 ? 's' : ''}:`));
      downloadedFiles.forEach(file => {
        console.log(chalk.green(`  Image saved to: ${file}`));
      });
      if (metadataPaths.length > 0) {
        console.log(chalk.gray(`Metadata saved:`));
        metadataPaths.forEach(metaPath => {
          console.log(chalk.cyan(`  - ${metaPath}`));
        });
      }
      console.log();

      // Upload to dufs server if enabled (default: true)
      const shouldUpload = options.upload !== false;
      if (shouldUpload) {
        const uploadConfig = configManager.getUploadConfig();
        if (uploadConfig && uploadConfig.server) {
          console.log(chalk.blue('Uploading to server...'));
          const uploader = new DufsUploader(uploadConfig);

          // Upload all generated files
          const allFilesToUpload = [...downloadedFiles, ...metadataPaths];
          const uploadResult = await uploader.uploadFiles(allFilesToUpload);

          if (uploadResult.success) {
            console.log(chalk.green.bold('All files uploaded successfully!'));
            // Display share URL if configured, otherwise use local URL
            const dirUrl = uploader.getShareDirUrl();
            console.log(chalk.gray(`Directory: ${dirUrl}`));
            // Display each file's share URL
            console.log(chalk.gray('Files:'));
            uploadResult.results.forEach(r => {
              if (r.success) {
                const shareUrl = uploader.getShareUrl(path.basename(r.local));
                console.log(chalk.cyan(`  - ${shareUrl}`));
              }
            });
          } else {
            console.log(chalk.yellow('Some files failed to upload:'));
            uploadResult.results.forEach(r => {
              if (!r.success) {
                console.log(chalk.red(`  - ${r.local}: ${r.error}`));
              }
            });
          }
          console.log();
        } else {
          console.log(chalk.yellow('Upload skipped: server not configured in server_config.json'));
          console.log();
        }
      }
    } else {
      console.log(chalk.yellow('Workflow completed but no images were generated'));
      console.log();
    }

    // Disconnect
    await comfyHelper.disconnect();

    if (options._batchMode) {
      return { success: true, files: downloadedFiles, metadata: metadataPaths };
    }
    process.exit(0);

  } catch (error) {
    console.log();
    console.log(chalk.red.bold('Workflow execution failed!'));
    console.log(chalk.red(`Error: ${error.message}`));

    // Disconnect
    try {
      await comfyHelper.disconnect();
    } catch (e) {
      // Ignore disconnect errors
    }

    if (options._batchMode) {
      throw error;
    }
    process.exit(1);
  }
}

export default imagescaleCommand;
