---
name: test-agents
description: >
  大规模子Agent并发流水线编排技能 — 仅手动调用。
  通过 /test-agents 触发。支持4到50+个子Agent并发执行，
  完成从需求采集、分析、文档设计、代码实现到测试的全流程自动化。
  仅当用户明确使用 /test-agents 命令时触发，不自动触发。
---

# Agent Pipeline Orchestrator

大规模子Agent并发流水线编排系统。主窗口仅负责对话与调度，所有具体任务由子Agent完成。

## 核心原则

**主窗口 = 纯调度者**
- 主窗口只做三件事：与用户对话、分析任务依赖、调度子Agent
- 主窗口禁止：读写业务文件、编写代码、执行测试、搜索网页内容
- 所有具体工作必须委托给子Agent执行

**可扩展并发**
- 默认从4个子Agent起步，可扩展到50+
- 用户可自定义每个阶段的Agent数量
- 并发上限由用户指定，默认不设硬性上限

## 完整流水线（6个阶段）

```
Phase 1: 需求采集 ──→ Phase 2: 需求分析 ──→ Phase 3: 文档设计
     (xsearch)         (N个Agent并行)        (汇总Agent)

Phase 4: 代码实现 ──→ Phase 5: 测试文档 ──→ Phase 6: 测试执行
   (M个Agent并行)      (K个Agent并行)       (K个Agent并行)
```

每个阶段的输出是下一阶段的输入。阶段之间串行，阶段内部并行。

---

## Phase 1: 需求采集

**目标：** 使用xsearch工具从网络抓取需求点

**调度方式：** 主窗口启动1个Agent执行采集

**Agent指令模板：**

```
你是一个需求采集Agent。使用 xsearch MCP工具（mcp__xsearch__firecrawl_search
和 mcp__xsearch__firecrawl_scrape）完成以下任务：

1. 根据用户的主题关键词，搜索相关技术文章、产品文档、行业规范
2. 从搜索结果中提取至少 {requirement_count} 个需求点
3. 每个需求点包含：
   - 需求ID（REQ-001格式）
   - 需求标题
   - 需求描述（2-3句话）
   - 来源URL
   - 优先级（P0/P1/P2）
4. 将所有需求点保存到 {output_path}/requirements.md
5. 同时保存JSON格式到 {output_path}/requirements.json

搜索策略：
- 使用 firecrawl_search 进行多轮搜索，每轮使用不同关键词
- 对关键结果使用 firecrawl_scrape 获取详细内容
- 确保需求点覆盖功能需求、非功能需求、安全需求
```

**输出文件：**
- `{workspace}/phase1_requirements/requirements.md`
- `{workspace}/phase1_requirements/requirements.json`

---

## Phase 2: 需求分析

**目标：** 每个需求点由一个独立Agent进行深入分析

**调度方式：** 主窗口读取Phase 1输出的需求列表，为每个需求点启动1个Agent，全部并行

**Agent数量计算：**
```python
agent_count = min(requirement_count, user_specified_max)
# 默认: requirement_count (每个需求一个Agent)
# 用户可指定上限: --max-analysts N
```

**Agent指令模板：**

```
你是一个需求分析Agent。负责分析以下需求点：

需求ID: {req_id}
需求标题: {req_title}
需求描述: {req_description}
优先级: {priority}

请完成以下分析并保存到 {output_path}/{req_id}_analysis.md：

1. **需求细化**：将需求拆解为3-5个具体的功能点
2. **技术可行性评估**：评估实现难度（高/中/低）及建议技术方案
3. **依赖关系识别**：列出与其他需求的前后依赖关系
4. **验收标准**：为每个功能点定义可测试的验收条件
5. **风险点**：识别潜在的技术风险和业务风险
6. **工作量估算**：预估复杂度（S/M/L/XL）
```

**主窗口在Phase 2完成后：**
- 等待所有分析Agent完成
- 启动1个汇总Agent，读取所有分析结果，生成统一的需求分析汇总文档

**汇总Agent指令：**

```
你是一个需求汇总Agent。读取以下目录中的所有分析文件：
{workspace}/phase2_analysis/

请生成汇总文档并保存到 {workspace}/phase2_analysis/summary.md，包含：
1. 需求全景图（所有需求及其关系）
2. 依赖关系图（文字描述）
3. 分组建议（哪些需求可并行开发）
4. 优先级排序（综合评分）
5. 关键路径识别
6. 总体风险评估
```

---

## Phase 3: 文档设计

**目标：** 将汇总后的分析转换为详细的功能实现文档

**调度方式：** 主窗口启动多个Agent，按模块/功能分组并行生成

**Agent指令模板：**

```
你是一个功能设计文档生成Agent。基于需求分析汇总文档，
为以下模块生成详细的功能实现文档：

模块名称: {module_name}
包含需求: {req_ids}

请读取 {workspace}/phase2_analysis/summary.md 获取完整上下文。

生成文档并保存到 {output_path}/{module_name}_design.md，包含：

1. **模块概述**：模块职责、边界、与其他模块的接口
2. **架构设计**：
   - 模块内部架构图（文字描述）
   - 核心类/接口设计
   - 数据模型设计
3. **详细设计**：
   - 每个功能点的详细设计（输入、处理、输出）
   - 状态管理方案
   - 错误处理策略
4. **Agent任务拆分**：
   - 将本模块拆分为具体的编码任务
   - 每个任务包含：任务ID、描述、输入、输出、依赖、验收标准
   - 标注哪些任务可并行执行
5. **技术选型**：框架、库、工具的选择及理由
6. **配置项清单**：所有需要配置的参数及其默认值
```

**并发策略：**
- 每个模块1个Agent，模块之间完全并行
- Agent数量 = 模块数量（由汇总文档的分组决定）

---

## Phase 4: 代码实现

**目标：** 基于功能设计文档，多Agent并行编写代码

**调度方式：** 主窗口读取所有设计文档，提取任务列表，按依赖关系分层并行

**分层策略：**
```
Layer 1 (并行): 所有无依赖的任务
Layer 2 (并行): 依赖Layer 1的任务
Layer 3 (并行): 依赖Layer 2的任务
...
```

**每层内Agent全部并行启动，层间串行等待。**

**Agent指令模板：**

```
你是一个代码实现Agent。请根据功能设计文档完成以下编码任务：

任务ID: {task_id}
任务描述: {task_description}
所属模块: {module_name}

设计文档路径: {design_doc_path}
依赖的代码路径: {dependency_paths}

请完成：
1. 阅读设计文档中与本任务相关的部分
2. 阅读依赖代码（如果有），了解现有接口和数据结构
3. 编写代码，遵循以下规范：
   - 文件路径和命名按设计文档规定
   - 包含必要的错误处理
   - 代码注释清晰
4. 将代码文件保存到指定路径
5. 生成任务完成报告保存到 {output_path}/{task_id}_report.md

报告格式：
- 已创建/修改的文件列表
- 实现说明
- 遗留问题（如果有）
```

**主窗口职责：**
1. 读取所有Phase 3设计文档
2. 提取全部任务及其依赖关系
3. 计算分层拓扑排序
4. 逐层启动Agent（层内并行，层间串行）
5. 收集每层结果后启动下一层
6. 最终汇总所有完成报告

---

## Phase 5: 测试文档生成

**目标：** 为已实现的代码生成详细的测试文档

**调度方式：** 按模块并行，每个模块1个Agent

**Agent指令模板：**

```
你是一个测试文档生成Agent。请为以下模块生成详细的测试文档：

模块名称: {module_name}
设计文档: {design_doc_path}
代码路径: {code_paths}
任务完成报告: {task_reports}

请完成：
1. 阅读设计文档了解功能需求
2. 阅读代码了解实际实现
3. 生成测试文档保存到 {output_path}/{module_name}_test.md

测试文档内容：
1. **测试范围**：需要测试的功能点清单
2. **测试用例设计**：
   - 单元测试用例（每个函数/方法至少2个用例）
   - 集成测试用例（模块间交互场景）
   - 功能测试用例（端到端场景）
3. **测试数据准备**：所需的测试数据及生成方式
4. **预期结果**：每个用例的预期输出
5. **边界条件**：需要特别测试的边界情况
6. **测试优先级**：P0（必须通过）/P1（应该通过）/P2（建议通过）
```

---

## Phase 6: 测试执行

**目标：** 多Agent并行执行所有测试

**调度方式：** 按模块并行，每个模块1个Agent执行其测试

**Agent指令模板：**

```
你是一个测试执行Agent。请为以下模块执行全部测试：

模块名称: {module_name}
代码路径: {code_paths}
测试文档: {test_doc_path}

请完成：
1. 阅读测试文档了解测试计划
2. 编写测试代码（按照测试文档中的用例设计）
3. 将测试代码保存到 {test_code_path}
4. 执行测试
5. 记录测试结果保存到 {output_path}/{module_name}_results.md

结果报告格式：
- 总用例数 / 通过数 / 失败数
- 每个失败用例的详细分析
- 代码覆盖率评估（如有工具支持）
- 需要修复的问题列表（按优先级排序）
- 建议的后续行动
```

**主窗口在Phase 6完成后：**
- 汇总所有测试结果
- 向用户报告整体通过率和关键失败项
- 如有失败，询问用户是否需要修复循环

---

## 并发控制与配置

### 默认配置

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `start_agents` | 4 | 起始Agent数量 |
| `max_agents` | 50 | 最大Agent数量 |
| `phase1_agents` | 1 | 需求采集Agent数 |
| `phase2_agents` | N | 等于需求数量（每需求1个） |
| `phase3_agents` | M | 等于模块数量 |
| `phase4_agents` | K | 等于任务数量（分批） |
| `phase5_agents` | M | 等于模块数量 |
| `phase6_agents` | M | 等于模块数量 |

### 并发规模测试模式

当用户要求"压力测试"或"并发测试"时，启用逐步扩容模式：

```
Round 1: 启动 4 个并行Agent → 记录完成时间、成功率
Round 2: 启动 8 个并行Agent → 记录完成时间、成功率
Round 3: 启动 16 个并行Agent → 记录完成时间、成功率
Round 4: 启动 32 个并行Agent → 记录完成时间、成功率
Round 5: 启动 50 个并行Agent → 记录完成时间、成功率
```

用户可自定义每轮的Agent数量，例如：
- "从4个开始，每次翻倍，到50个"
- "分别用4、10、20、30、40、50个Agent测试"
- "固定用20个Agent执行完整流程"

### 并发报告

每轮测试完成后，主窗口汇总并发性能数据：

```
{workspace}/concurrency_report.md

| Agent数量 | 总耗时 | 平均Agent耗时 | 成功率 | 错误数 | 备注 |
|-----------|--------|--------------|--------|--------|------|
| 4         | 45s    | 38s          | 100%   | 0      | -    |
| 8         | 52s    | 41s          | 100%   | 0      | -    |
| 16        | 68s    | 55s          | 98%    | 1      | 超时 |
| 32        | 95s    | 78s          | 94%    | 2      | 超时 |
| 50        | 130s   | 105s         | 88%    | 6      | 超时 |
```

---

## 工作区结构

```
{workspace}/
├── phase1_requirements/
│   ├── requirements.md
│   └── requirements.json
├── phase2_analysis/
│   ├── REQ-001_analysis.md
│   ├── REQ-002_analysis.md
│   ├── ...
│   └── summary.md
├── phase3_design/
│   ├── module1_design.md
│   ├── module2_design.md
│   └── ...
├── phase4_implementation/
│   ├── src/                    # 实际代码
│   ├── module1/
│   │   ├── task1_report.md
│   │   └── ...
│   └── ...
├── phase5_test_docs/
│   ├── module1_test.md
│   ├── module2_test.md
│   └── ...
├── phase6_test_results/
│   ├── module1_results.md
│   ├── module2_results.md
│   └── ...
├── concurrency_report.md       # 并发测试报告（可选）
└── pipeline_status.json        # 流水线状态追踪
```

---

## 执行流程

### 启动时

主窗口向用户确认以下信息：

1. **项目主题**：需要采集需求的主题/关键词
2. **工作区路径**：输出文件存放位置（默认：当前目录下的 `pipeline_workspace/`）
3. **并发规模**：
   - 默认：从4开始，逐步到50
   - 自定义：用户指定数量
4. **阶段选择**：
   - 完整流程（Phase 1-6）
   - 指定阶段（如只执行Phase 4-6，跳过前面阶段）
5. **语言偏好**：文档和代码使用的语言

### 执行中

主窗口维护 `pipeline_status.json` 追踪状态：

```json
{
  "project": "项目名称",
  "current_phase": 2,
  "phase_status": {
    "phase1": {"status": "completed", "agents_used": 1, "duration_s": 30},
    "phase2": {"status": "in_progress", "agents_launched": 12, "agents_completed": 5},
    "phase3": {"status": "pending"},
    "phase4": {"status": "pending"},
    "phase5": {"status": "pending"},
    "phase6": {"status": "pending"}
  },
  "total_agents_used": 13,
  "start_time": "2026-04-11T10:00:00Z"
}
```

### 阶段转换

每个阶段完成后，主窗口：
1. 向用户报告本阶段结果摘要
2. 展示下一阶段的Agent数量和预计工作内容
3. 等待用户确认后继续（或自动继续，取决于用户偏好）

### 错误处理

- 单个Agent失败：记录错误，标记该任务为失败，继续执行其他任务
- 阶段性失败：如果某阶段失败率超过50%，暂停并通知用户
- 主窗口崩溃恢复：通过 `pipeline_status.json` 恢复进度

---

## 使用示例

**示例1：完整流程**
> 用户："用agent流水线完成一个用户管理系统的开发，从4个agent测试到50个"

**示例2：指定阶段**
> 用户："我已有设计文档，从Phase 4开始用20个agent并发实现代码"

**示例3：压力测试**
> 用户："并发测试：4、8、16、32、50个agent分别执行代码实现阶段"

**示例4：自定义规模**
> 用户："用10个agent完成全流程，需求采集主题是电商支付系统"

---

## 关键约束提醒

1. **主窗口零执行**：主窗口绝对不执行任何读写文件、编码、测试等具体操作
2. **xsearch优先**：Phase 1必须使用 `mcp__xsearch__firecrawl_search` 和 `mcp__xsearch__firecrawl_scrape`
3. **依赖尊重**：跨阶段依赖严格遵守，阶段内最大化并行
4. **结果可追溯**：每个Agent的输出都有明确的文件路径和格式
5. **渐进式扩容**：并发测试模式下，从小到大逐步增加Agent数量
