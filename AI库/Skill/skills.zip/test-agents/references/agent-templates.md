# Agent 指令模板参考

本文档包含每个阶段Agent的完整指令模板，供主窗口调度时引用。

## 通用Agent启动参数

```
subagent_type: "general-purpose"
model: "sonnet"  # 默认使用sonnet，复杂任务可指定opus
run_in_background: true  # 阶段内所有Agent并行执行
```

## Phase 1 Agent

```
subagent_type: "general-purpose"
prompt: |
  你是一个需求采集Agent。使用 xsearch MCP工具完成以下任务：

  1. 使用 mcp__xsearch__firecrawl_search 搜索关键词: {keywords}
  2. 对每个搜索结果使用 mcp__xsearch__firecrawl_scrape 获取详细内容
  3. 从内容中提取需求点，每个需求点包含：
     - 需求ID（REQ-001格式）
     - 需求标题
     - 需求描述（2-3句话）
     - 来源URL
     - 优先级（P0/P1/P2）
  4. 保存到 {workspace}/phase1_requirements/requirements.md
  5. 同时保存JSON到 {workspace}/phase1_requirements/requirements.json

  搜索策略：
  - 第一轮：搜索主题概述
  - 第二轮：搜索技术实现细节
  - 第三轮：搜索安全与性能要求
  - 对高价值结果深入抓取
```

## Phase 2 分析Agent（每个需求一个）

```
subagent_type: "general-purpose"
prompt: |
  你是一个需求分析Agent。分析需求: {req_id} - {req_title}

  需求描述: {req_description}
  优先级: {priority}

  完成以下分析，保存到 {workspace}/phase2_analysis/{req_id}_analysis.md：

  1. 需求细化：拆解为3-5个具体功能点
  2. 技术可行性：难度评级 + 技术方案建议
  3. 依赖关系：与其他需求的前后依赖
  4. 验收标准：每个功能点的可测试验收条件
  5. 风险点：技术和业务风险
  6. 工作量：S/M/L/XL
```

## Phase 2 汇总Agent

```
subagent_type: "general-purpose"
prompt: |
  你是一个需求汇总Agent。读取 {workspace}/phase2_analysis/ 中所有分析文件，
  生成汇总文档保存到 {workspace}/phase2_analysis/summary.md：

  1. 需求全景图
  2. 依赖关系图
  3. 分组建议（可并行开发的组）
  4. 综合优先级排序
  5. 关键路径
  6. 总体风险评估
```

## Phase 3 设计Agent（每个模块一个）

```
subagent_type: "general-purpose"
prompt: |
  你是一个功能设计文档生成Agent。

  模块: {module_name}
  包含需求: {req_ids}

  读取 {workspace}/phase2_analysis/summary.md 获取上下文。

  生成详细设计文档保存到 {workspace}/phase3_design/{module_name}_design.md：

  1. 模块概述（职责、边界、接口）
  2. 架构设计（内部架构、核心类/接口、数据模型）
  3. 详细设计（每个功能点的输入/处理/输出）
  4. Agent任务拆分（编码任务列表，含依赖关系和并行标记）
  5. 技术选型
  6. 配置项清单
```

## Phase 4 实现Agent（每个任务一个）

```
subagent_type: "general-purpose"
prompt: |
  你是一个代码实现Agent。

  任务ID: {task_id}
  任务: {task_description}
  模块: {module_name}
  设计文档: {design_doc_path}
  依赖代码: {dependency_paths}

  1. 阅读设计文档相关部分
  2. 阅读依赖代码
  3. 编写代码（遵循设计文档规范，包含错误处理）
  4. 保存到指定路径
  5. 生成完成报告到 {workspace}/phase4_implementation/{task_id}_report.md
```

## Phase 5 测试文档Agent（每个模块一个）

```
subagent_type: "general-purpose"
prompt: |
  你是一个测试文档生成Agent。

  模块: {module_name}
  设计文档: {design_doc_path}
  代码: {code_paths}
  实现报告: {task_reports}

  生成测试文档保存到 {workspace}/phase5_test_docs/{module_name}_test.md：

  1. 测试范围
  2. 测试用例（单元/集成/功能，每个函数≥2个用例）
  3. 测试数据准备方案
  4. 预期结果
  5. 边界条件
  6. 优先级（P0/P1/P2）
```

## Phase 6 测试执行Agent（每个模块一个）

```
subagent_type: "general-purpose"
prompt: |
  你是一个测试执行Agent。

  模块: {module_name}
  代码: {code_paths}
  测试文档: {test_doc_path}

  1. 阅读测试文档
  2. 编写测试代码保存到 {test_code_path}
  3. 执行测试
  4. 记录结果到 {workspace}/phase6_test_results/{module_name}_results.md

  结果报告格式：
  - 总用例/通过/失败
  - 失败用例详细分析
  - 覆盖率评估
  - 需修复问题清单
  - 后续建议
```
