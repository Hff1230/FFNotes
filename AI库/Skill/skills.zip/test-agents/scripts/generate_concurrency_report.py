#!/usr/bin/env python3
"""
并发性能报告生成器
读取各轮并发测试的 timing.json，生成汇总报告。
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path


def load_timing(path):
    """加载 timing.json"""
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def generate_report(workspace_dir, output_path=None):
    """生成并发测试报告"""
    workspace = Path(workspace_dir)
    rounds = []

    # 扫描每个并发轮次目录
    for d in sorted(workspace.glob("round_*")):
        if not d.is_dir():
            continue
        agents_dir = d / "agents"
        if not agents_dir.exists():
            continue

        agent_count = len(list(agents_dir.iterdir()))
        timings = []
        errors = 0

        for agent_dir in agents_dir.iterdir():
            timing_file = agent_dir / "timing.json"
            if timing_file.exists():
                t = load_timing(timing_file)
                timings.append(t.get("total_duration_seconds", 0))
                if t.get("errors", 0) > 0:
                    errors += 1

        if timings:
            total_time = max(timings)
            avg_time = sum(timings) / len(timings)
            success_rate = (agent_count - errors) / agent_count * 100
            rounds.append({
                "agents": agent_count,
                "total_s": round(total_time, 1),
                "avg_s": round(avg_time, 1),
                "success_pct": round(success_rate, 1),
                "errors": errors
            })

    if not rounds:
        print("No timing data found")
        return

    # 生成 Markdown 报告
    report = f"# 并发测试报告\n\n"
    report += f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
    report += "| Agent数量 | 总耗时(s) | 平均耗时(s) | 成功率(%) | 错误数 |\n"
    report += "|-----------|-----------|-------------|-----------|--------|\n"
    for r in rounds:
        report += f"| {r['agents']} | {r['total_s']} | {r['avg_s']} | {r['success_pct']} | {r['errors']} |\n"

    report += "\n## 结论\n\n"

    # 自动分析
    if len(rounds) >= 2:
        first = rounds[0]
        last = rounds[-1]
        if last['success_pct'] >= 95:
            report += f"- 系统在 {last['agents']} 个并发Agent下仍保持 {last['success_pct']}% 成功率\n"
        else:
            # 找到成功率开始下降的拐点
            for i in range(1, len(rounds)):
                if rounds[i]['success_pct'] < 95:
                    report += f"- 并发瓶颈出现在 {rounds[i]['agents']} 个Agent（成功率降至 {rounds[i]['success_pct']}%）\n"
                    break

        time_increase = (last['total_s'] - first['total_s']) / first['total_s'] * 100
        report += f"- 从 {first['agents']} 到 {last['agents']} 个Agent，耗时增长 {round(time_increase, 1)}%\n"

    out = output_path or workspace / "concurrency_report.md"
    with open(out, 'w', encoding='utf-8') as f:
        f.write(report)
    print(f"Report saved to: {out}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python generate_concurrency_report.py <workspace_dir> [output_path]")
        sys.exit(1)
    generate_report(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
