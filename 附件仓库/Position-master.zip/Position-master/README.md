Unity进阶技巧 - RectTransform详解
https://www.jianshu.com/p/dbefa746e50d

localPosition与anchoredPosition转化之瞎猫找死耗子
https://zhuanlan.zhihu.com/p/114829066

localPosition与anchoredPosition转化
https://zhuanlan.zhihu.com/p/119442308
