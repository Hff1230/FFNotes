using System;

namespace ROK
{
    internal struct HeroOffsetData
    {
        public Formation.ENMU_SQUARE_TYPE m_square_type;

        public HeroOffsetItem[] m_heroOffset_data;
    }
}
