using System;

namespace ROK
{
    internal struct HeroOffsetItem
    {
        public int m_type;

        public float m_x_offset;

        public float m_z_offset;
    }
}