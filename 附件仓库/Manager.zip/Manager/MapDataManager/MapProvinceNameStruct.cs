using System;
using UnityEngine;

namespace ROK
{
    public struct MapProvinceNameStruct
    {
        public Vector3 m_pos;

        public string m_province_name;
    }
}