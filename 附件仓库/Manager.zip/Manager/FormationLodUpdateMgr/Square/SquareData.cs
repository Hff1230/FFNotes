using System;

namespace ROK
{
    internal struct SquareData
    {
        public Formation.ENMU_SQUARE_TYPE m_square_type;

        public UnitData[] m_unit_data;
    }
}