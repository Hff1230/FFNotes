namespace NPBehave
{
    public enum Operator
    {
        IS_SET,
        IS_NOT_SET,
        IS_EQUAL,
        IS_NOT_EQUAL,
        IS_GREATER_OR_EQUAL,
        IS_GREATER,
        IS_SMALLER_OR_EQUAL,
        IS_SMALLER,
        ALWAYS_TRUE
    }
}