﻿namespace NPBehave
{
    public enum Stops
    {
        NONE,
        SELF,
        LOWER_PRIORITY,
        BOTH,
        IMMEDIATE_RESTART,
        LOWER_PRIORITY_IMMEDIATE_RESTART
    }
}